# NEXUS Portfolio Dashboard v3.3 — Feature Roadmap

## ✅ Built (29 modules, 24 tabs)

### Core
- Multi-portfolio support (create/switch/delete portfolios)
- Position tracking: stocks, crypto, forex
- NaN-safe calculations across all asset types
- Real-time ticker bar + UTC clock
- PWA installable (service worker + manifest)
- Shareable read-only portfolio link
- CSV export + browser print/PDF

### Data (zero simulation, all real)
- Crypto: Binance WebSocket real-time + REST initial snapshot
- Stocks: Yahoo Finance v7/v8 (prices + OHLC charts)
- Forex: open.er-api.com rates + Frankfurter ECB OHLC
- Global markets: 22 instruments from Yahoo Finance
- Heatmap: Binance bulk + Yahoo bulk (70+ assets)
- News: server-side RSS scraper (/api/news) + rss2json + allorigins

### Expert Tools
- TradingView Pro Charts embed (100+ indicators, drawing tools)
- Native canvas candlestick charts (RSI + MACD sub-panels)
- Strategy Backtester (EMA cross, RSI reversal, MACD, BB breakout)
- Chart Pattern Scanner (double top/bottom, H&S, flags, triangles, divergence)
- Advanced TA suite (SMC/ICT, Wyckoff, Ichimoku+MTF, Fibonacci/Elliott, real order flow, harmonics) — feeds the Perps composite score + dedicated per-symbol deep-dive tab
- Monte Carlo Simulator (500 paths, fan chart)
- Fear & Greed Index (alternative.me)
- Position Sizer (Kelly Criterion + Fixed Risk)
- P&L Calculator with fees & leverage
- Correlation Matrix (live price history)
- Macro Dashboard (yield curve, funding rates, DeFi TVL, gas tracker, stress test)
- Fundamentals panel (P/E, EPS, market cap, analyst targets, earnings date)
- Signal Scanner (RSI/MACD/BB — 30s scan on all positions)
- Live Order Book (Binance WebSocket depth10@100ms)
- Trending Assets (Binance + Yahoo top movers)
- Trade Journal (auto-log + manual + CSV export)
- P&L Calendar (daily performance heatmap)
- Telegram Bot Alerts (free, user's own bot)
- Telegram Signal Engine — in-process channel watcher + parser + confidence
  scorer + technical-analysis confluence check (see SETUP.md)
- Economic Calendar (Forex Factory RSS + static fallback)
- Theme Customiser (5 themes + 3 density modes)
- Currency Converter (17 currencies incl GHS, NGN, KES, ZAR)
- Price Alerts + push notifications

## 🔜 Next (planned)

### Phase 4 — Advanced
- [ ] Volume Profile (TPO) — Point of Control, Value Area
- [ ] Options Chain Viewer — Yahoo Finance calls/puts, IV, Greeks
- [ ] Multi-timeframe panel — 4 timeframes simultaneously
- [ ] Fibonacci auto-draw — detects swings, draws retracement levels
- [ ] Support & Resistance auto-detection
- [ ] Orderflow delta — buy vs sell volume per candle (Binance aggTrades)
- [ ] Ichimoku Cloud overlay
- [ ] RSI/MACD divergence scanner (hidden + regular)

### Phase 5 — Monetization
- [ ] Auth system — password protection, per-user portfolios (JSON files)
- [ ] White-label config — change logo/name/colors via config.json
- [ ] PDF report generator (jsPDF — professional client reports)
- [ ] Embed widget — iFrame your portfolio on any website
- [ ] Leaderboard mode — anonymous % return rankings
- [ ] Scheduled reports — auto-generate daily/weekly summaries
- [ ] Webhook alerts — POST to Discord/Slack/IFTTT on signal

### Phase 6 — Crypto Native
- [ ] DeFi yield tracker — APY across Aave, Uniswap, Compound (DefiLlama)
- [ ] Wallet tracker — ETH/BTC address → holdings + PnL (Etherscan free)
- [ ] Token unlock calendar — upcoming vesting events
- [ ] Cross-exchange arbitrage — price differences between Binance/Kraken/Coinbase
- [ ] NFT floor tracker — collection floor prices via OpenSea RSS

## 🚀 Deploy in 5 minutes

```bash
# Local
node server.js && open http://localhost:3000

# Docker
docker-compose up -d && open http://localhost:3000

# Railway (free tier)
# Push to GitHub → connect Railway → set PORT=3000 → deploy

# Render (free tier)
# Connect repo → Build: npm install → Start: node server.js
```

## 📡 Data Sources (all free, no API keys)

| Source | Used For | Rate |
|--------|----------|------|
| Binance WebSocket | Crypto real-time prices | Real-time |
| Binance REST | Crypto OHLC, bulk tickers, funding rates | On-demand |
| Yahoo Finance v7/v8 | Stocks, global markets, fundamentals | Every 15s |
| open.er-api.com | Forex rates | Every 60s |
| Frankfurter ECB | Forex OHLC | On-demand |
| alternative.me | Fear & Greed Index | Daily |
| DefiLlama | DeFi protocol TVL | On-demand |
| rss2json.com | News RSS (browser) | On-demand |
| api.telegram.org | Alert delivery | On trigger |
| Binance Futures REST (fapi) | Perps: mark price, funding, OI | On-demand (batched) |
| Hyperliquid /info | DEX perps: universe, funding, OI, candles | On-demand (batched) |
| allorigins.win | RSS proxy fallback, econ calendar | On-demand |

---

## 🎯 v3.3 — Accuracy & Reliability (do these before more features)

Adding features on a shaky data layer just adds more things that can be
wrong. This section is graded honestly against what's actually in the repo
right now, not a generic wishlist — each item below is a specific weak point
found while building v3.1–3.2.

### Data accuracy — confirmed issues
- [x] ~~Economic calendar showed static June/July fallback events as if current~~ — **fixed**: now filters to upcoming-only, shows nothing rather than wrong dates when the live feed and static list both come up empty.
- [ ] **Single-exchange bias on perps.** CEX side is Binance-only, DEX side is Hyperliquid-only. Funding and price can diverge meaningfully from Bybit/OKX/dYdX — the RSI/funding numbers are accurate *for Binance*, not "the market."
- [ ] **No retry/backoff anywhere.** Every fetch is a single try/catch — one dropped packet on a big Perps "Load All" scan silently loses that symbol's RSI forever instead of retrying. Same for news, forex, stocks.
- [ ] **Third-party CORS proxies as a hard dependency.** rss2json.com and allorigins.win are free-tier, rate-limited, and can throttle or go down without warning — when they do, News and the econ calendar go dark with no fallback.
- [ ] **Keyword-based sentiment has no negation handling.** "Fed signals it is *not* considering a rate hike" would still score hawkish/bullish in macroNews.js — a lexicon match, not real NLP. Should be labeled as a heuristic in the UI, not just in code comments.
- [ ] **Correlation matrix aligns by array index, not timestamp.** Documented in-app now, but the real fix is resampling both series to a shared time grid before computing Pearson r.
- [ ] **No staleness indicator on prices.** If a WS drops silently, the price on screen can be minutes old with nothing telling you that.
- [ ] Yahoo Finance v7/v8 are undocumented/unofficial endpoints — reliable today, but nothing stops them from changing shape without notice. No schema validation on the response currently.

### Quick wins (small effort, real value)
- [x] ~~Service worker was serving stale data/code indefinitely~~ — **fixed** (`sw.js` v2→v3): the fetch handler was cache-first for every same-origin request, including `/api/news` and `/proxy` — those are relative paths, so their `url.hostname` is just `location.hostname`, which was never in the old `isAPI` exclusion list (that only matched absolute external hostnames like `api.binance.com`). Once either endpoint was fetched once for a given URL, every later identical request got the stale cached response forever, bypassing both the network and server.js's own 4-minute cache — no server restart could ever fix this, since the staleness lived entirely in the browser's Cache Storage. The entire app shell (all `/src/*.js`) was cache-first too, so code changes silently didn't show up until a manual hard-refresh/cache-clear either. New strategy: local dynamic endpoints and external market-data hosts are network-only (never cached), and the app shell is network-first with cache-as-offline-fallback only. Also added a `visibilitychange` handler (`main.js`) that forces an immediate WebSocket reconnect check and refetches crypto/forex/stock prices the moment a backgrounded tab becomes visible again, rather than waiting on `setTimeout`/`setInterval` timers that browsers throttle heavily (Chrome clamps to ~1/min after ~5 min hidden) — covers the case where a long-idle socket drops silently (laptop sleep, network change) without promptly firing `onclose`. Verified: server boots clean, all new/existing static routes return 200 with the intended `no-cache` header, no syntax errors in any touched file.
- [x] ~~"Last updated Xs ago" badge~~ — **shipped as a global Data Health pill** (top-right of the topbar) instead of per-panel badges: click it for a dropdown showing every tracked source (hostname), status dot, last-success time, and error count.
- [x] ~~Retry-with-backoff wrapper for `apiFetch`/`hlPost`~~ — **shipped**: `dataHealth.js` adds `withRetry()` (2 retries, exponential backoff + jitter) wrapped around both shared fetch helpers. Every existing caller benefits automatically — no per-module changes needed.
- [x] ~~Second CEX perp source (Bybit) as a cross-check~~ — **shipped**: Bybit's unified v5 tickers endpoint (one call, full universe) cross-checks every Binance-sourced perp. Flags 🔀 when price diverges >0.15% or funding diverges >0.03pp — tested against synthetic data to confirm it flags real divergence and stays quiet on noise.
- [ ] Label sentiment/mood gauges explicitly as "keyword heuristic, not NLP" in the UI tooltip.

### Bigger features (worth a dedicated session each)
- [x] ~~Cross-exchange arbitrage scanner~~ — **shipped**, built on the same cross-check data rather than as a separate system: for every symbol live on 2+ of Binance/Bybit/Hyperliquid, computes the widest pairwise price spread + funding spread, surfaced as a leaderboard column (⚡ Arbitrage Spread). Verified it correctly picks the *widest* pair (not just Binance-vs-X) and excludes single-exchange symbols.
- [ ] **Options chain viewer** — Yahoo Finance calls/puts, IV, Greeks (already on the Phase 4 list below, ties in well with the Perps work).
- [ ] **Wallet tracker** — ETH/BTC address → live holdings + P&L via Etherscan (free tier), ties portfolio tracking to actual on-chain positions instead of manual entry.
- [ ] **Server-side caching layer** — `server.js` already proxies some requests; adding a short-TTL cache there would cut third-party rate-limit exposure across every module at once, not just one.
- [x] ~~Volume Profile / Support-Resistance auto-detection~~ — **shipped**: fractal swing-point detection clustered into S/R levels, volume-profile POC/value-area from the same candle fetch (no extra API calls — reused the data already being pulled for RSI). Ties directly into the RSI screening: a new "confluence" check flags 🎯 only when an RSI extreme lines up *directionally* with a real level (overbought at resistance/POC, oversold at support/POC) — an isolated RSI extreme and one confirmed by structure are different signals now. Tested against synthetic OHLCV with known support/resistance/POC: correctly flagged all 4 directional cases, correctly rejected both wrong-direction cases, correctly returned null with no nearby level and with too few candles.
- [x] ~~Advanced TA suite (SMC/ICT, Wyckoff, Ichimoku, Fibonacci/Elliott, real order flow, harmonics)~~ — **shipped**: `src/ta/` (8 modules) covering six frameworks beyond RSI/MACD/BB:
  - **SMC/ICT** (`structure.js`) — market structure (HH/HL vs LH/LL), BOS/CHoCH breaks, order blocks, Fair Value Gaps, liquidity sweeps, equal-high/low pools. All objectively defined (a close beyond a swing point, a 3-candle price gap, a wick-then-reclaim) — no discretionary "read the chart" step.
  - **Wyckoff** (`wyckoff.js`) — trading-range detection, spring/UTAD, effort-vs-result (volume/price correlation). Explicitly labeled **heuristic** in the UI: full Wyckoff phase analysis is inherently discretionary, so this implements only the mechanically checkable pieces, not a phase-A/B/C/D/E call.
  - **Ichimoku** (`ichimoku.js`) — full 9/26/52 cloud, TK cross, chikou check, plus multi-timeframe alignment (1h/4h/1d agreement) — this is the piece that actually made Ichimoku worth adding over a single-timeframe read.
  - **Fibonacci/Elliott** (`fibWave.js`) — retracement/extension confluence zones (clusters where multiple fib levels + swing levels overlap), and a **rule-checked** (not discretionary) Elliott Wave count: mechanically verifies the 3 hard Elliott rules against zigzag pivots rather than claiming a definitive wave label, which professional analysts routinely disagree on for the same chart.
  - **Order flow** (`orderflow.js`) — VWAP + deviation bands, and **real** cumulative volume delta from Binance aggTrades' `isBuyerMaker` flag (genuine taker buy/sell classification), not a candle-body approximation. Includes absorption detection (heavy one-sided flow, no price follow-through).
  - **Harmonics** (`harmonics.js`) — Gartley/Bat/Butterfly/Crab XABCD pattern matching, requires all 4 ratio legs to simultaneously fit within tolerance, not just one.
  - **Wiring**: the sync tier (structure/Wyckoff/Ichimoku-1TF/Fib-Elliott/harmonics — no extra network calls) feeds directly into `computeCompositeSignal` in `perps.js` for every scanned perp, wrapped in try/catch so a bug in one framework can't take down the composite score. The deep tier (real order flow + true multi-timeframe Ichimoku) is on-demand only, via the new "🧬 Advanced TA" tab — deliberately *not* run for the whole watchlist on a timer, since that would multiply outbound Binance requests exactly the way the rate-limit section above already flags as a risk.
  - **Testing**: unit-tested with both random-walk synthetic data (no exceptions across uptrend/downtrend/chop) and manufactured positive-path cases (a clean breakout, a spring, a rule-valid 5-wave impulse, a textbook Gartley) to confirm true positives, not just quiet negatives. Caught and fixed 3 real bugs in the process: the zigzag pivot tracker was overwriting its running extreme every bar instead of accumulating it (near-zero pivots detected on real trend data), the Wyckoff range window included the spring/UTAD candle's own extreme in its own boundary (self-referential, could never trigger), and the harmonic "AD ratio" was measured from the wrong endpoint (X instead of A), silently rejecting valid patterns. Verified no naming collisions with existing globals and confirmed the composite scorer adds ~1ms/symbol (150-symbol scan: 140ms total) — negligible against the existing scan cycle.
- [x] ~~Extended indicator library (ADX/DMI, CCI, Williams %R, OBV, MFI, Parabolic SAR, SuperTrend, Keltner, Donchian, Aroon, CMF, ROC)~~ — **shipped**, directly in `indicators.js` alongside RSI/MACD/BB rather than as a separate module, since these are the same class of thing:
  - **Trend strength/direction**: ADX/+DI/-DI (Wilder-smoothed — is there a real trend to trust the rest of the signals on, and which way), SuperTrend (single ATR-band flip-flop line, cleaner "long above/short below" read than a channel), Parabolic SAR, Aroon (time-since-extreme, a different angle on "is this trending" than ADX's smoothed directional movement).
  - **Momentum/overbought-oversold**: CCI (unbounded, keeps signaling through a sustained trend unlike RSI pinning at 100), Williams %R (faster/noisier cousin of Stochastic), MFI (RSI's exact formula but volume-weighted — a "cheap" RSI reading and a heavy-volume MFI reading at the same price level are different situations).
  - **Volume confirmation**: OBV (divergence check — wired into `generateSignals()` as its own line: price and OBV disagreeing over the last 15 bars, distinct from anything RSI/MACD already catch), CMF (volume-weighted read of where each close falls in its own range).
  - **Volatility bands**: Keltner (ATR-width bands, pairs with Bollinger for a TTM-Squeeze-style "is volatility contracting" check), Donchian (raw n-bar high/low breakout — literally the original Turtle Trading entry rule, zero smoothing lag).
  - **Wiring**: ADX/DI, CCI, Williams %R, MFI, SuperTrend, and an OBV/price divergence check were added to `TA.generateSignals()` (the per-symbol chart panel) at conservative weights alongside the existing RSI/MACD/BB/EMA-cross signals. ADX/DI, SuperTrend, MFI, and CMF were also added to `computeCompositeSignal` in `perps.js` as factor #13, deliberately lower-weighted than RSI+Structure/MACD/BB since they mostly overlap conceptually — treated as confirmation, not new independent votes.
  - **Testing**: unit-tested against both noisy random-walk data and clean, noise-free monotonic up/down trends to verify directional correctness (e.g. +DI > -DI and CCI positive on every clean uptrend, the mirror on downtrends, SuperTrend flips to the correct side, Aroon pins at 100/0). All passed with no exceptions and correct signs. Confirmed negligible performance cost (11 new indicators, 150-symbol simulated scan: 333ms total, ~2.2ms/symbol — and only 4 of those 11 are in the always-on composite path).

> **On "100% accuracy":** not a real target for any live-market-data system — every exchange has its own order book and can legitimately disagree with another by a few basis points (that disagreement is literally what the arbitrage scanner above surfaces). What's achievable and now shipped: retries so transient failures don't silently drop data, visible health/staleness per source, and cross-exchange checks that make disagreement a visible signal instead of a hidden one.

## 🌐 Hosting — verified static-portable

Audited every code path for hard dependencies on `server.js`: **none exist for core functionality.** `news.js` and `globalMarkets.js` both check `location.hostname` and only use the local server's `/api/news`/`/proxy` endpoints when actually running on `localhost` — anywhere else, they go straight to the public RSS/CORS fallbacks (rss2json, allorigins) they already had. Verified this with a simulated non-localhost deployment: zero requests to the app's own server endpoints, every fetch correctly routed to the public fallback. This means the app runs as **pure static files** on any host — Namecheap shared hosting, GitHub Pages, Netlify, anywhere — with `server.js` only needed if you specifically want its slightly-faster server-side RSS path for local dev.

## 📊 Composite Signal — depth factors added

- [x] **Long/Short account ratio** (Binance) — genuinely different data from funding rate: funding is the *cost* of holding a position, this is *how many accounts* are actually positioned each way. Contrarian at extremes (>2.2:1 or <0.5:1), same logic as funding but an independent read.
- [x] **Daily trend context** — a 1h RSI extreme means something different depending on whether the higher timeframe agrees. Computes 50-day EMA position + slope; deliberately returns no signal (not a guess) when the daily read is mixed (e.g. above EMA but sloping down).
- Composite is now 7 factors deep: RSI+Structure, MACD, Bollinger, OI+Trend, Funding, L/S Ratio, Daily Trend. Tested individually and in a full-agreement integration scenario (6/6 factors correctly aligned to a single `strong_bearish` call).
