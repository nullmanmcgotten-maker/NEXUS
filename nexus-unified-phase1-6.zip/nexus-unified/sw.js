/**
 * sw.js — Service Worker for PWA offline support.
 *
 * v3: was cache-first for EVERYTHING same-origin, including /api/news and
 * /proxy — those are relative paths, so `url.hostname` for them equals
 * location.hostname, which was never in the isAPI exclusion list (that list
 * only covered absolute external hostnames like api.binance.com). Once any
 * of those endpoints were fetched once, every later identical request was
 * served the STALE cached response forever, bypassing both the network and
 * server.js's own 4-minute cache — this is very likely the "have to restart
 * the server every time I leave the tab" symptom: it wasn't the server, it
 * was the browser silently serving old cached responses (including old app
 * code) no matter what the server did.
 *
 * Fixed strategy:
 *  - Local dynamic endpoints (/api/*, /proxy) and external market-data
 *    hosts → network-only, never cached. These are meant to be live.
 *  - App shell (HTML/JS/CSS/manifest/icons) → network-first: try the
 *    network, cache the fresh response, and only fall back to the cache if
 *    the network fails (i.e. actually offline). This preserves offline PWA
 *    support without ever preferring stale code over live code while online.
 */
const CACHE   = 'nexus-v3';
const OFFLINE  = [
  '/',
  '/index.html',
  '/src/styles.css',
  '/src/data.js',
  '/src/realtime.js',
  '/src/utils.js',
  '/src/indicators.js',
  '/src/portfolio.js',
  '/src/charts.js',
  '/src/news.js',
  '/src/converter.js',
  '/src/alerts.js',
  '/src/ticker.js',
  '/src/assetChart.js',
  '/src/heatmap.js',
  '/src/screener.js',
  '/src/globalMarkets.js',
  '/src/forex.js',
  '/src/crypto.js',
  '/src/tradingview.js',
  '/src/backtester.js',
  '/src/macro.js',
  '/src/patterns.js',
  '/src/fundamentals.js',
  '/src/pnlHistory.js',
  '/src/telegram.js',
  '/src/montecarlo.js',
  '/src/trending.js',
  '/src/analytics.js',
  '/src/ta/taUtils.js',
  '/src/ta/structure.js',
  '/src/ta/wyckoff.js',
  '/src/ta/ichimoku.js',
  '/src/ta/fibWave.js',
  '/src/ta/orderflow.js',
  '/src/ta/harmonics.js',
  '/src/ta/advancedTA.js',
  '/src/advancedTAPanel.js',
  '/src/main.js',
  'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js',
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(OFFLINE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);

  // Live data — external market-data hosts, and this server's own dynamic
  // endpoints (both by exact hostname and by local path, since a relative
  // fetch's hostname is just location.hostname and wouldn't otherwise be
  // caught). Never cache these; always go to the network.
  const isExternalAPI = ['api.binance.com','stream.binance.com','open.er-api.com',
                  'api.allorigins.win','api.rss2json.com','api.frankfurter.app',
                  'query1.finance.yahoo.com'].includes(url.hostname);
  const isLocalAPI = url.pathname.startsWith('/api/') || url.pathname === '/proxy';
  if (isExternalAPI || isLocalAPI) return; // let the browser fetch it normally, no SW involvement at all

  // App shell — network-first, cache as a fallback for offline use only.
  e.respondWith(
    fetch(e.request).then(res => {
      if (res.ok) {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
      }
      return res;
    }).catch(() =>
      caches.match(e.request).then(cached => cached || caches.match('/index.html'))
    )
  );
});
