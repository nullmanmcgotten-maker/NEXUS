# Monetizing NEXUS — what's built, what to decide, how to launch

## What's actually implemented right now

- **Accounts.** `POST /api/auth/signup`, `/login`, `/logout`, `GET /api/auth/me`.
  File-backed (`data/users.json`), scrypt-hashed passwords, httpOnly session
  cookie. No external service required — works the moment you `npm start`.
- **Two tiers.** `free` and `pro`, stored per-user.
- **Three paywalled features, same free-teaser/pro-full pattern:**
  1. **Telegram signal engine** (`/api/signals`) — filtered, confidence-scored
     trade setups from channels you configure.
  2. **Perps Alpha** (`/api/perps-alpha`) — a composite mover score across
     all Binance USDT-M perps, computed server-side from public funding-rate
     + 24h price-change data (z-scored, weighted, ranked). No API key needed
     upstream; the scoring is what's behind the paywall, not the raw feed.
  3. **Polymarket Alpha** (`/api/polymarket-alpha`) — same idea for
     Polymarket's public Gamma API: ranks active markets by a "big, well-
     supported move" heuristic (price-change magnitude weighted by volume,
     downweighted by thin liquidity).
  All three refresh on a server-side timer (perps every 5 min, Polymarket
  every 10 min — tune in `server.js`'s `makeAlphaFeed(...)` calls) and keep
  a short rolling history so free users get a genuinely delayed snapshot,
  not just a truncated live one.
- **Stripe Checkout + Billing Portal + webhook**, implemented with raw
  HTTPS calls (`src/billing.js`) so there's no SDK to install before you
  can test it. `POST /api/billing/checkout` returns a Checkout URL for the
  logged-in user; `POST /api/billing/webhook` listens for
  `checkout.session.completed` and flips the user to `pro` automatically.

## What you still have to decide (I can't decide this for you)

**Price and what exactly "Pro" includes.** I picked "signal engine" as the
gate because it's the one feature in this codebase other people can't
trivially get elsewhere. Everything else (portfolio tracking, charts,
backtester, TA suite) is currently ungated — decide if any of that should
move behind the paywall too, or if the free dashboard should stay a loss
leader that drives signal-engine upgrades. Common patterns for a tool like
this: $15–30/mo for the signal feed alone, or a $0/$19/$49 free-pro-elite
ladder if you want an upsell tier (e.g. elite = multiple Telegram channels
+ priority alerts).

**Legal framing.** SETUP.md is already explicit that this is not signal
quality assurance and not financial advice — keep that language, or
something like it, visible on the paywall and in your terms of service.
Selling trading signals can trigger securities/investment-adviser
regulation in some jurisdictions depending on how you frame it ("we tell
you what to buy" vs. "we aggregate and score public channel posts, judge
for yourself") — that's a legal question for an actual lawyer in your
jurisdiction, not something I can clear for you.

**Refunds/trials/dunning.** Stripe Billing Portal (already wired) handles
cancellation and payment-method updates. Trials, proration, and failed-
payment retry policy are things you configure in the Stripe Dashboard
under the Price/Product, not in this code.

## Launch checklist

1. In the Stripe Dashboard: create a Product ("NEXUS Pro"), add a
   recurring Price, copy its `price_...` ID.
2. Set environment variables before `npm start`:
   ```
   STRIPE_SECRET_KEY=sk_live_...   (or sk_test_... while testing)
   STRIPE_PRICE_ID=price_...
   STRIPE_WEBHOOK_SECRET=whsec_... (from the webhook endpoint below)
   PUBLIC_URL=https://your-domain.com
   ```
3. In Stripe Dashboard → Developers → Webhooks, add an endpoint pointing
   at `https://your-domain.com/api/billing/webhook`, subscribed to at
   least `checkout.session.completed` and `customer.subscription.deleted`.
4. Test end-to-end with Stripe test mode + test card `4242 4242 4242 4242`
   before flipping to live keys.
5. Decide your free-tier limits (`server.js`, top of `handleSignalsAPI`)
   and update the paywall copy in `src/telegramSignals.js` to match.

## Honest limitation

Nothing above changes whether the underlying trades/bets are good — it
changes whether people pay for a better-organized, faster ranked view of
public data. All three composite scores (signal confidence, perps
composite, Polymarket mover score) are transparent sorting heuristics,
not backtested predictive models — I built them from first principles in
this session, not from validated historical performance. Before charging
real money for them, it's worth logging their calls for a few weeks and
checking, honestly, whether high-scoring picks actually outperform a
random sample — otherwise you're charging for the *feeling* of edge, which
tends to show up in refund requests and churn once people notice. Retention
lives or dies on that check, not on the paywall itself.
