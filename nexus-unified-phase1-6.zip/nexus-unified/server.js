/**
 * server.js — Local dev server + RSS scraper API + CORS proxy
 * Run: node server.js → http://localhost:3000
 */
const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const zlib  = require('zlib');
const { describeError } = require('./src/httpJson');

const PORT = 3000;
const ROOT = __dirname;

// ── SIGNAL ENGINE (formerly the separate signalbot Go service) ────────────
// Now runs in-process as part of this same server, if config.json turns it
// on. See src/signalEngine/ — the parsing/scoring logic there is a direct
// port of signalbot's Go code, plus a `breakdown` field for the "why did
// this score what it scored" UI. If signalEngine.enabled is false/missing,
// startSignalEngine() is a no-op and everything else in Nexus runs exactly
// as it did before this merge.
const { SignalEngine } = require('./src/signalEngine');
const signalEngine = new SignalEngine();
const auth = require('./src/auth');
const billing = require('./src/billing');
const polymarketAlpha = require('./src/polymarketAlpha');
const perpsAlpha = require('./src/perpsAlpha');
const CONFIG_PATH = path.join(ROOT, 'config.json');
if (fs.existsSync(CONFIG_PATH)) {
  signalEngine.start(CONFIG_PATH).catch((e) => console.error('[signalEngine] fatal:', e.message));
} else {
  console.log('[signalEngine] no config.json found — signal engine off, rest of Nexus runs normally. See config.example.json.');
}

const MIME = {
  '.html':'text/html','.css':'text/css','.js':'application/javascript',
  '.json':'application/json','.png':'image/png','.svg':'image/svg+xml',
  '.ico':'image/x-icon','.webp':'image/webp','.webmanifest':'application/manifest+json',
};

// RSS news cache (avoid refetching constantly)
const _newsCache = {};
const CACHE_TTL  = 4 * 60 * 1000; // 4 minutes

function fetchUrl(targetUrl, cb) {
  let done = false; // guard: the underlying socket can fire 'end' on the stream
                     // AND a later 'error'/close on the request for the same
                     // transfer — without this guard, cb() fires twice and the
                     // second res.writeHead() throws ERR_HTTP_HEADERS_SENT,
                     // which is an uncaught exception that kills the process.
  const safeCb = (err, status, body) => {
    if (done) return;
    done = true;
    cb(err, status, body);
  };
  const opts = {
    headers: {
      'User-Agent':      'Mozilla/5.0 (compatible; NexusPortfolio/3.0)',
      'Accept':          'application/rss+xml, application/xml, text/xml, application/json, */*',
      'Accept-Encoding': 'gzip, deflate',
      'Accept-Language': 'en-US,en;q=0.9',
    },
    timeout: 20000, // was 10000 — some upstream APIs (Binance full-universe endpoints especially) can legitimately take longer
    family: 4,      // avoid Node's Happy-Eyeballs dual-stack race throwing a blank-message AggregateError — see src/httpJson.js header
  };
  const req = https.get(targetUrl, opts, res => {
    const chunks = [];
    const encoding = res.headers['content-encoding'];
    let stream = res;
    if (encoding === 'gzip')    stream = res.pipe(zlib.createGunzip());
    if (encoding === 'deflate') stream = res.pipe(zlib.createInflate());
    stream.on('data', c => chunks.push(c));
    stream.on('end',  () => safeCb(null, res.statusCode, Buffer.concat(chunks).toString('utf8')));
    stream.on('error',e => safeCb(new Error(describeError(e))));
  });
  req.on('error',   e => safeCb(new Error(describeError(e))));
  req.on('timeout', () => { req.destroy(); safeCb(new Error('timeout')); });
}

// Writes a response exactly once, even if something upstream (e.g. fetchUrl's
// safeCb guard failing for an unforeseen reason) tries to write twice — this
// is the second layer of defense on top of fetchUrl's own done-guard.
function safeWrite(res, status, headers, body) {
  if (res.headersSent) return;
  res.writeHead(status, headers);
  res.end(body);
}

// Parse RSS XML into JSON array
function parseRSS(xmlText, source) {
  const items = [];
  const itemRx = /<item[\s>]([\s\S]*?)<\/item>/gi;
  const tagRx  = tag => new RegExp(`<${tag}[^>]*>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?<\\/${tag}>`, 'i');
  let m;
  while ((m = itemRx.exec(xmlText)) !== null) {
    const block   = m[1];
    const title   = (tagRx('title').exec(block)?.[1]||'').trim().replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&#[0-9]+;/g,'').trim();
    const link    = (tagRx('link').exec(block)?.[1]||'').trim();
    const pubDate = (tagRx('pubDate').exec(block)?.[1]||'').trim();
    const encImg  = /<enclosure[^>]+type="image[^"]*"[^>]+url="([^"]+)"/i.exec(block)?.[1] || null;
    const mediaImg= /<media:content[^>]+url="([^"]+)"/i.exec(block)?.[1] || null;
    if (title.length > 15) items.push({ title, link, pubDate, image: encImg||mediaImg, source });
  }
  return items;
}

// /api/news?url=<rssUrl> endpoint
function handleNewsAPI(req, res) {
  const parsed = new URL(req.url, `http://${req.headers.host}`);
  const feedUrl = parsed.searchParams.get('url');
  if (!feedUrl) {
    return safeWrite(res, 400, {'Content-Type':'application/json'}, JSON.stringify({ error:'Missing ?url=' }));
  }

  const cacheKey = feedUrl;
  const cached   = _newsCache[cacheKey];
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    return safeWrite(res, 200, { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Cache-Control':'public,max-age=180' }, JSON.stringify(cached.items));
  }

  let sourceName;
  try { sourceName = new URL(feedUrl).hostname.replace(/^(www\.|feeds\.)/, ''); }
  catch (e) { return safeWrite(res, 400, {'Content-Type':'application/json'}, JSON.stringify({ error:'Invalid url=' })); }

  fetchUrl(feedUrl, (err, status, body) => {
    if (err || status !== 200) {
      return safeWrite(res, 502, {'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}, JSON.stringify({ error: err?.message || 'HTTP '+status }));
    }
    const items = parseRSS(body, sourceName);
    _newsCache[cacheKey] = { items, ts: Date.now() };
    safeWrite(res, 200, { 'Content-Type':'application/json', 'Access-Control-Allow-Origin':'*', 'Cache-Control':'public,max-age=180' }, JSON.stringify(items));
  });
}

// /proxy?url=<targetUrl> — generic CORS proxy (for market data APIs)
function handleProxy(req, res) {
  let target;
  try { target = new URL(req.url, `http://${req.headers.host}`).searchParams.get('url'); }
  catch (e) { return safeWrite(res, 400, {}, 'Bad request'); }
  if (!target) return safeWrite(res, 400, {}, 'Missing ?url=');

  fetchUrl(target, (err, status, body) => {
    if (err) return safeWrite(res, 502, {}, 'Error: '+err.message);
    safeWrite(res, status, {
      'Content-Type':              'application/json',
      'Access-Control-Allow-Origin':'*',
      'Cache-Control':             'public,max-age=60',
    }, body);
  });
}

// /api/signals?limit=100 — recent parsed Telegram signals from the
// in-process signal engine. Same wire shape as standalone signalbot's
// /signals endpoint (see src/signalEngine, formerly internal/api/api.go),
// plus a `breakdown` array explaining the confidence score, and `channel`
// kept as the field name for drop-in front-end compatibility.
//
// PAYWALL: this is the flagship "pro" feature (curated + scored trade
// setups). Free-tier / logged-out users get a capped, delayed teaser so
// the tab isn't empty — full feed requires an active subscription.
const FREE_TIER_SIGNAL_LIMIT = 3;
const FREE_TIER_DELAY_MS = 30 * 60 * 1000; // 30 min delay on teaser signals

function handleSignalsAPI(req, res, user) {
  const parsed = new URL(req.url, `http://${req.headers.host}`);
  let limit = parseInt(parsed.searchParams.get('limit'), 10);
  if (!Number.isFinite(limit) || limit <= 0) limit = 100;

  const isPro = !!user && user.tier === 'pro';

  let recs;
  try {
    recs = signalEngine.getRecentSignals(limit);
  } catch (e) {
    return safeWrite(res, 500, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, JSON.stringify({ error: 'internal error' }));
  }

  if (!isPro) {
    const cutoff = Date.now() - FREE_TIER_DELAY_MS;
    recs = recs.filter(r => r.createdAt <= cutoff).slice(0, FREE_TIER_SIGNAL_LIMIT);
  }

  const out = recs.map(r => ({
    channel: r.channelName,
    coin: r.coin,
    pair: r.pair,
    direction: r.direction,
    entryMin: r.entryMin,
    entryMax: r.entryMax,
    takeProfits: r.takeProfits,
    stopLoss: r.stopLoss,
    leverage: r.leverage,
    timeframe: r.timeframe,
    confidence: r.confidence,
    breakdown: r.breakdown,
    rawText: r.rawText,
    createdAt: new Date(r.createdAt).toISOString(),
  }));
  safeWrite(res, 200, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store',
  }, JSON.stringify({
    tier: isPro ? 'pro' : 'free',
    delayedMinutes: isPro ? 0 : FREE_TIER_DELAY_MS / 60000,
    limit: isPro ? null : FREE_TIER_SIGNAL_LIMIT,
    signals: out,
  }));
}

// ── PERPS ALPHA + POLYMARKET ALPHA — same free-teaser/pro-full pattern as
// the Telegram signal feed, but for exchange/market data computed here on
// the server so gating actually works (client-side JS can't be paywalled —
// anyone can read the network tab). Both refresh on a timer and keep a
// short rolling history so the free tier can be served a genuinely-stale
// snapshot rather than just a truncated fresh one.
function makeAlphaFeed(name, fetchFn, { refreshMs, freeDelayMs, freeLimit }) {
  const history = []; // [{ ts, data }], oldest first, pruned to keep ~2x the delay window
  let lastError = null;

  async function refresh() {
    try {
      const data = await fetchFn();
      history.push({ ts: Date.now(), data });
      const cutoff = Date.now() - (freeDelayMs * 2 + refreshMs);
      while (history.length > 1 && history[0].ts < cutoff) history.shift();
      lastError = null;
    } catch (e) {
      lastError = e.message;
      console.error(`[${name}] refresh failed:`, e.message);
    }
  }

  refresh(); // fire on boot; don't block server startup on it
  setInterval(refresh, refreshMs);

  function getFor(user) {
    const isPro = !!user && user.tier === 'pro';
    if (isPro) {
      const latest = history[history.length - 1];
      return { tier: 'pro', delayedMinutes: 0, limit: null, updatedAt: latest ? latest.ts : null, error: latest ? null : lastError, data: latest ? latest.data : [] };
    }
    const cutoff = Date.now() - freeDelayMs;
    const snapshot = history.filter(h => h.ts <= cutoff).slice(-1)[0];
    const data = snapshot ? snapshot.data.slice(0, freeLimit) : [];
    return { tier: 'free', delayedMinutes: freeDelayMs / 60000, limit: freeLimit, updatedAt: snapshot ? snapshot.ts : null, error: snapshot ? null : (lastError || 'warming up'), data };
  }

  return { getFor };
}

const perpsAlphaFeed = makeAlphaFeed('perpsAlpha', () => perpsAlpha.fetchTopMovers(100), {
  refreshMs: 5 * 60 * 1000,      // recompute every 5 min
  freeDelayMs: 60 * 60 * 1000,   // free tier sees a snapshot >= 1hr old
  freeLimit: 5,
});

const polymarketAlphaFeed = makeAlphaFeed('polymarketAlpha', () => polymarketAlpha.fetchTopMovers(100), {
  refreshMs: 10 * 60 * 1000,     // recompute every 10 min (Gamma API is heavier)
  freeDelayMs: 60 * 60 * 1000,
  freeLimit: 5,
});

function handlePerpsAlphaAPI(req, res, user) {
  const out = perpsAlphaFeed.getFor(user);
  safeWrite(res, 200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' }, JSON.stringify(out));
}

function handlePolymarketAlphaAPI(req, res, user) {
  const out = polymarketAlphaFeed.getFor(user);
  safeWrite(res, 200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' }, JSON.stringify(out));
}

// ── AUTH + BILLING ROUTES ───────────────────────────────────────────────
function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', c => {
      raw += c;
      if (raw.length > 1e6) req.destroy(); // 1MB guard
    });
    req.on('end', () => {
      if (!raw) return resolve({ json: {}, raw: '' });
      try { resolve({ json: JSON.parse(raw), raw }); }
      catch (e) { reject(new Error('Invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

async function handleSignup(req, res) {
  try {
    const { json } = await readJsonBody(req);
    const user = auth.createUser(json.email, json.password);
    const token = auth.createSession(user.email);
    auth.setSessionCookie(res, token);
    safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ user: auth.publicUser(user) }));
  } catch (e) {
    safeWrite(res, 400, { 'Content-Type': 'application/json' }, JSON.stringify({ error: e.message }));
  }
}

async function handleLogin(req, res) {
  try {
    const { json } = await readJsonBody(req);
    const user = auth.authenticate(json.email, json.password);
    const token = auth.createSession(user.email);
    auth.setSessionCookie(res, token);
    safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ user: auth.publicUser(user) }));
  } catch (e) {
    safeWrite(res, 401, { 'Content-Type': 'application/json' }, JSON.stringify({ error: e.message }));
  }
}

function handleLogout(req, res) {
  const cookies = auth.parseCookies(req);
  const token = cookies[auth.SESSION_COOKIE];
  if (token) auth.destroySession(token);
  auth.clearSessionCookie(res);
  safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ ok: true }));
}

function handleMe(req, res, user) {
  safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ user: auth.publicUser(user) }));
}

async function handleCheckout(req, res, user) {
  if (!user) return safeWrite(res, 401, { 'Content-Type': 'application/json' }, JSON.stringify({ error: 'Log in first' }));
  try {
    const url = await billing.createCheckoutSession(user.email, user.stripeCustomerId);
    safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ url }));
  } catch (e) {
    safeWrite(res, 400, { 'Content-Type': 'application/json' }, JSON.stringify({ error: e.message }));
  }
}

async function handlePortal(req, res, user) {
  if (!user || !user.stripeCustomerId) return safeWrite(res, 400, { 'Content-Type': 'application/json' }, JSON.stringify({ error: 'No active subscription' }));
  try {
    const url = await billing.createPortalSession(user.stripeCustomerId);
    safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ url }));
  } catch (e) {
    safeWrite(res, 400, { 'Content-Type': 'application/json' }, JSON.stringify({ error: e.message }));
  }
}

// Stripe webhook: upgrades/downgrades a user's tier based on subscription
// lifecycle events. Must read the RAW body (not parsed JSON) for signature
// verification, so this bypasses readJsonBody.
function handleWebhook(req, res) {
  let raw = '';
  req.on('data', c => raw += c);
  req.on('end', () => {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    const sig = req.headers['stripe-signature'];
    if (secret && !billing.verifyWebhookSignature(raw, sig, secret)) {
      return safeWrite(res, 400, {}, 'Invalid signature');
    }
    let event;
    try { event = JSON.parse(raw); } catch (e) { return safeWrite(res, 400, {}, 'Bad JSON'); }

    const obj = event.data && event.data.object;
    if (event.type === 'checkout.session.completed' && obj) {
      const email = obj.customer_details?.email || obj.metadata?.nexus_email;
      if (email) auth.setTier(email, 'pro', { stripeCustomerId: obj.customer, subscriptionStatus: 'active' });
    } else if (event.type === 'customer.subscription.deleted' && obj) {
      // Downgrade whichever local user owns this Stripe customer id.
      let all = [];
      try { all = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'users.json'), 'utf8')).users; } catch (e) { /* no users yet */ }
      const match = all.find(u => u.stripeCustomerId === obj.customer);
      if (match) auth.setTier(match.email, 'free', { subscriptionStatus: 'canceled' });
    }
    safeWrite(res, 200, { 'Content-Type': 'application/json' }, JSON.stringify({ received: true }));
  });
}

function handleSignalsHealthAPI(req, res) {
  safeWrite(res, 200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, JSON.stringify(signalEngine.getHealth()));
}

// Static file server
function handleStatic(req, res) {
  let fp = path.join(ROOT, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
  if (!fp.startsWith(ROOT)) return safeWrite(res, 403, {}, 'Forbidden');
  const ext  = path.extname(fp);
  const mime = MIME[ext] || 'application/octet-stream';
  fs.readFile(fp, (err, data) => {
    if (err) return safeWrite(res, 404, {}, '404: ' + req.url);
    // No-cache on the app's own source files — this project's .js/.css/.html
    // change constantly during development, and browsers will otherwise
    // happily serve a stale cached copy under the same URL indefinitely,
    // which looks exactly like "a feature stopped working" when it's really
    // just running old code. Third-party assets (fonts etc.) aren't served
    // from here, so this only affects files that are actually being edited.
    const headers = { 'Content-Type': mime };
    if (['.js', '.css', '.html'].includes(ext)) {
      headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
    }
    safeWrite(res, 200, headers, data);
  });
}

const server = http.createServer((req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      return safeWrite(res, 204, { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET' }, undefined);
    }
    const p = new URL(req.url, `http://${req.headers.host}`).pathname;

    // Webhook must see the raw body before any auth lookup.
    if (p === '/api/billing/webhook' && req.method === 'POST') return handleWebhook(req, res);

    const user = auth.attachUser(req); // null if not logged in / session expired

    if (p === '/api/news')           return handleNewsAPI(req, res);
    if (p === '/api/signals')        return handleSignalsAPI(req, res, user);
    if (p === '/api/signals/health') return handleSignalsHealthAPI(req, res);
    if (p === '/api/perps-alpha')      return handlePerpsAlphaAPI(req, res, user);
    if (p === '/api/polymarket-alpha') return handlePolymarketAlphaAPI(req, res, user);
    if (p === '/proxy')              return handleProxy(req, res);

    if (p === '/api/auth/signup' && req.method === 'POST') return handleSignup(req, res);
    if (p === '/api/auth/login'  && req.method === 'POST') return handleLogin(req, res);
    if (p === '/api/auth/logout' && req.method === 'POST') return handleLogout(req, res);
    if (p === '/api/auth/me')                              return handleMe(req, res, user);
    if (p === '/api/billing/checkout' && req.method === 'POST') return handleCheckout(req, res, user);
    if (p === '/api/billing/portal'   && req.method === 'POST') return handlePortal(req, res, user);

    return handleStatic(req, res);
  } catch (e) {
    // Last-resort catch — a malformed request should return 500, not crash
    // the process. This is the same class of bug as the ERR_HTTP_HEADERS_SENT
    // crash: one bad request killing every other open connection.
    console.error('[server] request handler error:', e.message);
    safeWrite(res, 500, {}, 'Internal error');
  }
});

// Belt-and-suspenders: if anything still slips past the guards above (a bug
// we haven't seen yet), log it and keep the server alive instead of letting
// Node's default behavior — crashing the whole process — take down every
// other in-flight request too.
process.on('uncaughtException', (err) => {
  console.error('[server] uncaught exception (server stays up):', err.message);
});
process.on('unhandledRejection', (err) => {
  console.error('[server] unhandled rejection (server stays up):', err?.message || err);
});

process.on('SIGINT',  () => { signalEngine.stop().finally(() => process.exit(0)); });
process.on('SIGTERM', () => { signalEngine.stop().finally(() => process.exit(0)); });

server.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════════════════════╗
  ║   NEXUS Portfolio v3.1  —  http://localhost:${PORT}      ║
  ║                                                       ║
  ║   /api/news?url=<rss>   RSS scraper (server-side)    ║
  ║   /proxy?url=<api>      Generic CORS proxy           ║
  ║   PWA installable via browser address bar            ║
  ╚═══════════════════════════════════════════════════════╝`);
});
