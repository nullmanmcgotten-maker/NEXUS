/**
 * globalMarkets.js — Live data from Yahoo Finance v7 quote API.
 * No simulated nudges. If Yahoo fails, shows last known value with stale warning.
 */

const GM_YAHOO_SYMS = [
  '^GSPC','^IXIC','^DJI','^FTSE','^GDAXI','^N225','^HSI','^VIX',
  'GC=F','SI=F','CL=F','NG=F','HG=F','ZW=F',
  '^TNX','^TYX','^IRX',
  'DX-Y.NYB','EURUSD=X','GBPUSD=X','JPY=X',
];

const GM_LABEL = {
  '^GSPC':'S&P 500','^IXIC':'NASDAQ','^DJI':'DOW JONES','^FTSE':'FTSE 100',
  '^GDAXI':'DAX','^N225':'NIKKEI','^HSI':'HANG SENG','^VIX':'VIX',
  'GC=F':'Gold','SI=F':'Silver','CL=F':'Crude Oil','NG=F':'Nat Gas','HG=F':'Copper','ZW=F':'Wheat',
  '^TNX':'US 10Y','^TYX':'US 30Y','^IRX':'US 2Y',
  'DX-Y.NYB':'DXY','EURUSD=X':'EUR/USD','GBPUSD=X':'GBP/USD','JPY=X':'USD/JPY',
};

let _gmStale = false;

async function fetchGlobalMarkets() {
  const symsStr = GM_YAHOO_SYMS.join(',');
  const apiUrl  = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symsStr}&fields=regularMarketPrice,regularMarketChangePercent,shortName,regularMarketTime`;
  const isLocal = ['localhost','127.0.0.1'].includes(location.hostname);
  const pUrl    = isLocal
    ? `/proxy?url=${encodeURIComponent(apiUrl)}`
    : `https://api.allorigins.win/get?url=${encodeURIComponent(apiUrl)}`;

  try {
    const res  = await fetch(pUrl, { signal: AbortSignal.timeout(12000) });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const raw  = isLocal ? await res.text() : (await res.json()).contents;
    const data = JSON.parse(raw);
    const quotes = data?.quoteResponse?.result || [];

    if (!quotes.length) throw new Error('Empty response');

    quotes.forEach(q => {
      const label = GM_LABEL[q.symbol];
      if (!label) return;
      const gm = globalMarkets.find(g => g.sym === label);
      if (gm) {
        gm.val = safeNum(q.regularMarketPrice) || gm.val;
        gm.chg = parseFloat(safeNum(q.regularMarketChangePercent).toFixed(2));
      }
    });

    _gmStale = false;
    console.log('[GlobalMarkets] Yahoo: updated', quotes.length, 'instruments');
  } catch(e) {
    _gmStale = true;
    console.warn('[GlobalMarkets] Yahoo failed:', e.message);
  }

  renderGlobalMarkets();
  const ts = document.getElementById('gmTimestamp');
  if (ts) {
    ts.textContent = _gmStale
      ? '⚠ Stale — Yahoo unreachable · ' + new Date().toLocaleTimeString()
      : '✓ Live · ' + new Date().toLocaleTimeString();
    ts.style.color = _gmStale ? 'var(--amber)' : 'var(--green)';
  }
}

function renderGlobalMarkets() {
  const el = document.getElementById('globalMarketsGrid');
  if (!el) return;

  const GROUPS = {
    'Indices':     ['S&P 500','NASDAQ','DOW JONES','FTSE 100','DAX','NIKKEI','HANG SENG','VIX'],
    'Commodities': ['Gold','Silver','Crude Oil','Nat Gas','Copper','Wheat'],
    'Bonds':       ['US 10Y','US 2Y','US 30Y'],
    'FX & Dollar': ['DXY','EUR/USD','GBP/USD','USD/JPY'],
  };

  el.innerHTML = Object.entries(GROUPS).map(([grp, syms]) => {
    const items = syms.map(s => globalMarkets.find(g => g.sym === s)).filter(Boolean);
    return `<div class="gm-group">
      <div class="gm-group-hdr">${grp}</div>
      ${items.map(g => {
        const up   = g.chg >= 0;
        const vStr = g.val >= 1000 ? fmtNum(g.val, 2) : fmtNum(g.val, g.val < 10 ? 4 : 2);
        return `<div class="gm-row" onclick="tryOpenGmChart('${g.sym}')">
          <span class="gm-sym">${g.sym}</span>
          <span class="gm-val">${vStr}</span>
          <span class="gm-chg ${up?'up':'dn'}">${up?'▲':'▼'} ${Math.abs(g.chg).toFixed(2)}%</span>
        </div>`;
      }).join('')}
    </div>`;
  }).join('');
}

function tryOpenGmChart(sym) {
  const p = positions.find(x => x.sym === sym);
  const w = watchlist.find(x => x.sym === sym);
  if (p) openAssetChart(p.sym, p.name, p.type);
  else if (w) openAssetChart(w.sym, w.name, w.type);
}

function startGlobalMarkets() {
  fetchGlobalMarkets();
  setInterval(fetchGlobalMarkets, 90000);
}
