/**
 * screener.js — Real volatility from live price history only. No Math.random.
 */
let _sSort='chg_desc', _sType='all', _sMin=-100, _sMax=100;

function calcVolatility(sym) {
  const h = window._priceHistory?.[sym];
  if (!h || h.length < 5) return null; // null = no data yet
  const changes = h.slice(1).map((x,i) => Math.abs((x.p - h[i].p) / (h[i].p||1) * 100));
  return changes.length ? parseFloat((changes.reduce((a,b)=>a+b,0)/changes.length).toFixed(2)) : null;
}

function buildScreenerData() {
  return [
    ...positions.map(p => ({
      sym:p.sym, name:p.name, type:p.type,
      price:safeNum(p.price), chg:safeNum(p.chg),
      value:posDisplayValue(p), pnl:posPnl(p), pnlPct:posPnlPct(p),
      vol:calcVolatility(p.sym), src:'position',
    })),
    ...watchlist.map(w => ({
      sym:w.sym, name:w.name, type:w.type,
      price:safeNum(w.price), chg:safeNum(w.chg),
      value:0, pnl:0, pnlPct:0,
      vol:calcVolatility(w.sym), src:'watchlist',
    })),
  ]
  .filter(a => (_sType==='all'||a.type===_sType) && a.chg>=_sMin && a.chg<=_sMax)
  .sort((a,b) => {
    switch(_sSort) {
      case 'chg_desc': return b.chg - a.chg;
      case 'chg_asc':  return a.chg - b.chg;
      case 'val_desc': return b.value - a.value;
      case 'pnl_desc': return b.pnl - a.pnl;
      case 'vol_desc': {
        const av = a.vol??-1, bv = b.vol??-1; return bv - av;
      }
      default: return b.chg - a.chg;
    }
  });
}

function renderScreener() {
  const data = buildScreenerData();
  const el   = document.getElementById('screenerBody');
  if (!el) return;

  if (!data.length) {
    el.innerHTML = '<div style="padding:32px;text-align:center;font-family:var(--mono);font-size:13px;color:var(--muted);">No assets match filters.</div>';
    return;
  }

  el.innerHTML = data.map(a => {
    const isUp    = a.chg >= 0;
    const isPnlUp = a.pnl >= 0;
    const ps      = a.price < 10 ? a.price.toFixed(4) : fmtNum(a.price);
    const volDisplay = a.vol !== null
      ? `<div style="background:var(--bg4);border-radius:3px;height:5px;width:80px;margin-left:auto;margin-bottom:3px;overflow:hidden;">
           <div style="height:100%;width:${Math.min(a.vol/8*100,100).toFixed(0)}%;background:${a.vol>3?'var(--amber)':'var(--accent2)'};border-radius:3px;"></div>
         </div>
         <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">${a.vol.toFixed(2)}%</div>`
      : `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">Accumulating…</div>`;

    return `<div class="scr-row" onclick="openAssetChart('${a.sym}','${a.name}','${a.type}')">
      <div class="a-icon" style="background:${iconBg(a.type)};color:${iconColor(a.type)};width:32px;height:32px;font-size:8px;">${a.sym.replace('/','').slice(0,3)}</div>
      <div><div class="a-name">${a.sym}</div><div class="a-sub">${a.name} · ${a.src}</div></div>
      <div class="cr">$${ps}</div>
      <div class="cr ${isUp?'up':'dn'}" style="font-size:15px;font-weight:700;">${fmtPct(a.chg)}</div>
      <div class="cr">${a.value ? '$'+fmtNum(a.value) : '—'}</div>
      <div class="cr ${isPnlUp?'up':'dn'}">${a.pnl ? (isPnlUp?'+':'-')+'$'+fmtNum(Math.abs(a.pnl)) : '—'}</div>
      <div style="text-align:right;">${volDisplay}</div>
      <div class="r"><span class="badge ${typeBadge(a.type)}">${a.type.toUpperCase()}</span></div>
    </div>`;
  }).join('');
}

function updateScreenerSort(v)  { _sSort = v; renderScreener(); }
function updateScreenerType(v)  { _sType = v; renderScreener(); }
function updateScreenerRange()  {
  _sMin = parseFloat(document.getElementById('screenerMinChg')?.value) || -100;
  _sMax = parseFloat(document.getElementById('screenerMaxChg')?.value) ||  100;
  renderScreener();
}
