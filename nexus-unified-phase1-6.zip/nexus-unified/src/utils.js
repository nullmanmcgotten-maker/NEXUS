/**
 * utils.js — Shared helpers. NaN-safe everywhere.
 */
function safeNum(n,fallback=0){ const v=Number(n); return isFinite(v)?v:fallback; }
function fmtNum(n,dec=2){ return safeNum(n).toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec}); }
function fmtMoney(n,dec=2){ return '$'+fmtNum(Math.abs(safeNum(n)),dec); }
function fmtPct(n,dec=2){ const v=safeNum(n); return (v>=0?'+':'')+v.toFixed(dec)+'%'; }
function posValue(p){ return safeNum(p.qty)*safeNum(p.price); }
function posCost(p){ return safeNum(p.qty)*safeNum(p.avgPrice); }
function posPnl(p){ return (safeNum(p.price)-safeNum(p.avgPrice))*safeNum(p.qty); }
function posPnlPct(p){ const cost=posCost(p); return cost===0?0:((safeNum(p.price)-safeNum(p.avgPrice))/safeNum(p.avgPrice))*100; }
// Forex positions have huge qty but tiny price — cap their portfolio weight at notional USD value
function posDisplayValue(p){
  if(p.type==='forex'){ return safeNum(p.qty)*safeNum(p.price)*0.0001; } // pip-normalised
  return posValue(p);
}
function totalPortfolioValue(){
  const pos=positions.reduce((s,p)=>s+posDisplayValue(p),0);
  const cash=safeNum(window.portfolios?.[window.activePortfolioId]?.cash, 0);
  return pos+cash;
}
function iconBg(t){ return{stock:'#1a2e1a',crypto:'#1a1a2e',forex:'#111e2a'}[t]||'#1c2430'; }
function iconColor(t){ return{stock:'#00d4aa',crypto:'#9945ff',forex:'#0096ff'}[t]||'#5a6478'; }
function typeBadge(t){ return{stock:'badge-green',crypto:'badge-purple',forex:'badge-blue'}[t]||'badge-blue'; }
function clamp(n,mn,mx){ return Math.max(mn,Math.min(mx,safeNum(n))); }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escAttr(s){ return String(s).replace(/'/g,'%27'); }
function savePositions(){ try{localStorage.setItem('nexus_positions',JSON.stringify(positions));}catch(e){} }
function savePortfolios(){ try{localStorage.setItem('nexus_portfolios',JSON.stringify(window.portfolios));}catch(e){} }
function genId(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,6); }
