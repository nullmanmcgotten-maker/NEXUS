/** alerts.js — Price alerts + push notifications */
let _alertId=1,_pushOK=false;
async function requestPushPermission(){
  if(!('Notification'in window)){alert('Browser does not support notifications.');return;}
  const r=await Notification.requestPermission();_pushOK=r==='granted';
  const btn=document.getElementById('pushPermBtn');
  if(btn){btn.textContent=_pushOK?'🔔 Push ON':'🔕 Push OFF';btn.style.color=_pushOK?'var(--green)':'var(--muted)';}
}
function checkPushPermission(){
  if('Notification'in window&&Notification.permission==='granted'){_pushOK=true;const btn=document.getElementById('pushPermBtn');if(btn){btn.textContent='🔔 Push ON';btn.style.color='var(--green)';}}
}
function openAlertModal(){document.getElementById('alertModal').classList.remove('hidden');}
function closeAlertModal(){document.getElementById('alertModal').classList.add('hidden');['alertSymbol','alertPrice'].forEach(id=>{document.getElementById(id).value='';});}
function createAlert(){
  const sym=document.getElementById('alertSymbol').value.trim().toUpperCase();
  const dir=document.getElementById('alertDir').value;
  const target=parseFloat(document.getElementById('alertPrice').value);
  if(!sym||isNaN(target)||target<=0){alert('Fill all fields.');return;}
  alerts.push({id:_alertId++,sym,dir,target,triggered:false,createdAt:new Date().toLocaleTimeString()});
  closeAlertModal();renderAlerts();
}
function deleteAlert(id){const idx=alerts.findIndex(a=>a.id===id);if(idx!==-1){alerts.splice(idx,1);renderAlerts();}}
function checkAlerts(){
  let changed=false;
  alerts.forEach(a=>{
    if(a.triggered)return;
    const p=positions.find(x=>x.sym===a.sym),w=watchlist.find(x=>x.sym===a.sym);
    const price=p?p.price:w?w.price:null;if(price===null)return;
    const hit=a.dir==='above'?price>=a.target:price<=a.target;
    if(hit){a.triggered=true;a.triggeredAt=new Date().toLocaleTimeString();a.triggeredPrice=price;changed=true;fireAlert(a,price);}
  });
  if(changed)renderAlerts();
}
function fireAlert(a,price){
  const toast=document.createElement('div');
  toast.style.cssText='position:fixed;bottom:24px;right:24px;background:#1a2232;border:1px solid rgba(245,166,35,0.6);border-radius:10px;padding:18px 22px;font-family:\'IBM Plex Mono\',monospace;font-size:13px;color:#f5a623;z-index:3000;max-width:320px;box-shadow:0 12px 40px rgba(0,0,0,.6);';
  toast.innerHTML=`<div style="font-weight:700;margin-bottom:6px;font-size:15px;">🔔 ALERT TRIGGERED</div><div style="color:#eef0f6;margin-bottom:4px;">${a.sym} — $${fmtNum(price,price<1?6:2)}</div><div style="color:#5a6880;font-size:11px;">Target: ${a.dir.toUpperCase()} $${fmtNum(a.target,a.target<1?6:2)}</div>`;
  document.body.appendChild(toast);
  setTimeout(()=>{toast.style.opacity='0';toast.style.transition='opacity .5s';setTimeout(()=>toast.remove(),500);},5000);
  if(_pushOK&&Notification.permission==='granted')
    new Notification('NEXUS Alert: '+a.sym,{body:`Price ${a.dir} $${fmtNum(a.target,2)}\nCurrent: $${fmtNum(price,2)}`});
}
function renderAlerts(){
  const c=document.getElementById('alertsList');if(!c)return;
  if(!alerts.length){c.innerHTML='<div style="font-family:var(--mono);font-size:13px;color:var(--muted);text-align:center;padding:24px 0;">No active alerts. Click <strong style="color:var(--text)">+ New Alert</strong>.</div>';return;}
  c.innerHTML=alerts.map(a=>{
    const col=a.triggered?'var(--amber)':'var(--muted)';
    const lbl=a.triggered?`✓ Hit @ $${fmtNum(a.triggeredPrice,a.triggeredPrice<1?6:2)} · ${a.triggeredAt}`:`Watching · ${a.createdAt}`;
    return `<div class="alert-row">
      <div><div class="alert-sym">${a.sym}</div>
      <div class="alert-cond">Price ${a.dir==='above'?'≥':'≤'} $${fmtNum(a.target,a.target<1?6:2)}</div>
      <div class="alert-status" style="color:${col};">${lbl}</div></div>
      <button class="alert-del" onclick="deleteAlert(${a.id})">✕</button>
    </div>`;
  }).join('');
}
