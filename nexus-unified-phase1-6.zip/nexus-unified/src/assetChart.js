/**
 * assetChart.js — Real data charts.
 * Crypto  → Binance klines REST (free, no key)
 * Stocks  → Yahoo Finance chart API (free, no key)
 * Forex   → Frankfurter ECB API (free, no key)
 * All via CORS proxy chain.
 */
let _rsiInst = null, _macdInst = null;
let _currentAsset = null, _currentCandles = [], _chartMode = 'candle', _currentInterval = '1h';
let _activeIndicators = new Set(['ema9','ema21','bb','sr']);

async function openAssetChart(sym, name, type) {
  document.getElementById('assetChartModal').classList.remove('hidden');
  document.getElementById('assetChartTitle').textContent = `${sym}  ·  ${name}`;
  document.getElementById('assetSignals').innerHTML = '';
  document.getElementById('assetChartMeta').innerHTML =
    '<span style="font-family:var(--mono);font-size:12px;color:var(--muted);">Fetching live data…</span>';
  _currentAsset = { sym, name, type };
  await loadAndRender(sym, name, type, _currentInterval);
}

function closeAssetChart() {
  document.getElementById('assetChartModal').classList.add('hidden');
  [_rsiInst, _macdInst].forEach(c => { if(c) c.destroy(); });
  _rsiInst = _macdInst = null;
}

// ── DATA FETCHERS ─────────────────────────────────────────────────────────────
// fetchBinanceKlines, fetchYahooOHLC, fetchForexOHLC — defined in realtime.js

async function fetchStockOHLC(sym, interval='1h') {
  // Use Yahoo Finance chart endpoint
  if (typeof fetchYahooOHLC === 'function') {
    const candles = await fetchYahooOHLC(sym, interval);
    if (candles && candles.length >= 5) return candles;
  }
  return null;
}

async function fetchForexOHLCData(sym, interval='1h') {
  // Use Frankfurter ECB API for daily data
  if (typeof fetchForexOHLC === 'function') {
    const days = { '1h':30, '4h':60, '1d':180 }[interval] || 30;
    const candles = await fetchForexOHLC(sym, days);
    if (candles && candles.length >= 5) return candles;
  }
  return null;
}

// ── LOAD & RENDER ─────────────────────────────────────────────────────────────
async function loadAndRender(sym, name, type, interval) {
  let candles = null;
  let dataSource = '';

  if (type === 'crypto') {
    const binInterval = { '1h':'1h', '4h':'4h', '1d':'1d' }[interval] || '1h';
    const limit       = { '1h':150, '4h':120, '1d':180 }[interval] || 150;
    candles = await fetchBinanceKlines(sym, binInterval, limit);
    dataSource = candles ? '● Binance klines (live)' : '⚠ Binance unavailable';
  } else if (type === 'stock') {
    candles = await fetchStockOHLC(sym, interval);
    dataSource = candles ? '● Yahoo Finance (live)' : '⚠ Yahoo unavailable';
  } else if (type === 'forex') {
    candles = await fetchForexOHLCData(sym, interval);
    dataSource = candles ? '● Frankfurter ECB API (live)' : '⚠ Frankfurter unavailable';
  }

  // Update data source badge
  const dsEl = document.getElementById('chartDataSource');
  if (dsEl) {
    const isLive = candles && !dataSource.includes('⚠');
    dsEl.innerHTML = `<span class="data-source-badge ${isLive?'live':''}">${dataSource}</span>`;
  }

  if (!candles || candles.length < 5) {
    const reason = window._lastOHLCError?.[sym];
    const msg = reason
      ? `⚠ Could not load chart data for ${sym}: ${reason}`
      : `⚠ Could not fetch live data for ${sym}. This app doesn't require a server — if this persists, the exchange/data API itself may be rate-limiting or unreachable from your network right now.`;
    document.getElementById('assetChartMeta').innerHTML =
      `<span style="color:var(--amber);font-family:var(--mono);font-size:12px;">${esc(msg)}</span>`;
    return;
  }

  _currentCandles = candles;
  renderAll(sym, candles, type);
}

function renderAll(sym, candles, type) {
  const closes = candles.map(c => safeNum(c.c));
  const ema9   = TA.ema(closes, 9);
  const ema21  = TA.ema(closes, 21);
  const ema50  = TA.ema(closes, 50);
  const bb     = TA.bollinger(closes, 20);
  const macdR  = TA.macd(closes);
  const rsiV   = TA.rsi(closes, 14);

  drawCandleChart(sym, candles, closes, ema9, ema21, ema50, bb);
  drawRsiChart(rsiV);
  drawMacdChart(macdR);
  renderChartMeta(sym, candles, closes);
  renderSignals(closes, candles);
}

// ── NATIVE CANVAS CANDLESTICK RENDERER ───────────────────────────────────────
function drawCandleChart(sym, candles, closes, ema9, ema21, ema50, bb) {
  const canvas = document.getElementById('assetMainChart');
  if (!canvas) return;
  const W = canvas.clientWidth || 800, H = canvas.clientHeight || 320;
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, W, H);

  const PAD_L=10, PAD_R=68, PAD_T=18, PAD_B=28;
  const cW=W-PAD_L-PAD_R, cH=H-PAD_T-PAD_B;
  const n=candles.length;

  let allP = candles.flatMap(c => [safeNum(c.h), safeNum(c.l)]).filter(v=>v>0);
  if (_activeIndicators.has('bb')) { allP=allP.concat(bb.upper.filter(Boolean),bb.lower.filter(Boolean)); }
  const pMin = Math.min(...allP)*0.9995, pMax = Math.max(...allP)*1.0005, pRng = pMax-pMin || 1;

  const xS = i => PAD_L + (i/(n-1))*cW;
  const yS = p => PAD_T + cH - ((p-pMin)/pRng)*cH;

  // Grid
  ctx.strokeStyle='rgba(255,255,255,0.04)'; ctx.lineWidth=1;
  for(let j=0;j<=5;j++){const y=PAD_T+(j/5)*cH;ctx.beginPath();ctx.moveTo(PAD_L,y);ctx.lineTo(W-PAD_R,y);ctx.stroke();}
  for(let j=0;j<=6;j++){const x=PAD_L+(j/6)*cW;ctx.beginPath();ctx.moveTo(x,PAD_T);ctx.lineTo(x,PAD_T+cH);ctx.stroke();}

  // Y-axis labels
  ctx.fillStyle='#5a6880'; ctx.font='10px IBM Plex Mono,monospace'; ctx.textAlign='left'; ctx.textBaseline='middle';
  for(let j=0;j<=5;j++){
    const p=pMin+(1-j/5)*pRng, y=PAD_T+(j/5)*cH;
    const lbl=p>=1000?'$'+Math.round(p/1000)+'k':p>=1?'$'+p.toFixed(2):'$'+p.toFixed(5);
    ctx.fillText(lbl, W-PAD_R+4, y);
  }

  // X-axis labels
  ctx.textAlign='center'; ctx.textBaseline='top';
  const lstep=Math.max(1,Math.floor(n/6));
  for(let i=0;i<n;i+=lstep){
    const d=new Date(candles[i].t);
    ctx.fillText(d.getMonth()+1+'/'+d.getDate()+' '+String(d.getHours()).padStart(2,'0')+':00', xS(i), PAD_T+cH+5);
  }

  // Bollinger Bands
  if(_activeIndicators.has('bb')){
    const vi=bb.upper.map((v,i)=>v!==null?i:-1).filter(i=>i>=0);
    if(vi.length>2){
      ctx.beginPath();
      ctx.moveTo(xS(vi[0]),yS(bb.upper[vi[0]]));
      vi.forEach(i=>ctx.lineTo(xS(i),yS(bb.upper[i])));
      vi.slice().reverse().forEach(i=>ctx.lineTo(xS(i),yS(bb.lower[i])));
      ctx.closePath(); ctx.fillStyle='rgba(255,255,255,0.025)'; ctx.fill();
      const dl=(d,col,dash=[])=>{ctx.beginPath();ctx.strokeStyle=col;ctx.lineWidth=1;ctx.setLineDash(dash);let s=false;d.forEach((v,i)=>{if(v===null){s=false;return;}if(!s){ctx.moveTo(xS(i),yS(v));s=true;}else ctx.lineTo(xS(i),yS(v));});ctx.stroke();ctx.setLineDash([]);};
      dl(bb.upper,'rgba(200,200,255,0.35)',[4,4]);
      dl(bb.middle,'rgba(200,200,255,0.18)',[2,5]);
      dl(bb.lower,'rgba(200,200,255,0.35)',[4,4]);
    }
  }

  // EMA lines
  const drawEma=(d,col)=>{ctx.beginPath();ctx.strokeStyle=col;ctx.lineWidth=1.3;ctx.setLineDash([]);let s=false;d.forEach((v,i)=>{if(v===null){s=false;return;}if(!s){ctx.moveTo(xS(i),yS(v));s=true;}else ctx.lineTo(xS(i),yS(v));});ctx.stroke();};
  if(_activeIndicators.has('ema9'))  drawEma(ema9,'#f5a623');
  if(_activeIndicators.has('ema21')) drawEma(ema21,'#0096ff');
  if(_activeIndicators.has('ema50')) drawEma(ema50,'#9945ff');

  // Volume bars (bottom 12%)
  const maxV=Math.max(...candles.map(c=>safeNum(c.v)))||1;
  const vH=cH*0.12;
  const cw=Math.max(1,Math.min(12,cW/n*0.7));
  candles.forEach((c,i)=>{
    if(!safeNum(c.v))return;
    const x=xS(i), vh=(safeNum(c.v)/maxV)*vH;
    ctx.fillStyle=safeNum(c.c)>=safeNum(c.o)?'rgba(0,212,170,0.25)':'rgba(255,77,106,0.25)';
    ctx.fillRect(x-cw/2,PAD_T+cH-vh,cw,vh);
  });

  // Candles or Line
  if(_chartMode==='candle'){
    candles.forEach((c,i)=>{
      const x=xS(i),isUp=safeNum(c.c)>=safeNum(c.o);
      const col=isUp?'#00d4aa':'#ff4d6a';
      const yO=yS(safeNum(c.o)),yC=yS(safeNum(c.c)),yH=yS(safeNum(c.h)),yL=yS(safeNum(c.l));
      const top=Math.min(yO,yC),bot=Math.max(yO,yC),bH=Math.max(1,bot-top);
      ctx.strokeStyle=col;ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(x,yH);ctx.lineTo(x,yL);ctx.stroke();
      ctx.fillStyle=isUp?'rgba(0,212,170,0.8)':'rgba(255,77,106,0.8)';
      ctx.fillRect(x-cw/2,top,cw,bH);
      ctx.strokeStyle=col;ctx.lineWidth=0.5;ctx.strokeRect(x-cw/2,top,cw,bH);
    });
  } else {
    const isUp=closes[closes.length-1]>=closes[0],lc=isUp?'#00d4aa':'#ff4d6a';
    const grad=ctx.createLinearGradient(0,PAD_T,0,PAD_T+cH);
    grad.addColorStop(0,isUp?'rgba(0,212,170,0.18)':'rgba(255,77,106,0.18)');
    grad.addColorStop(1,'rgba(0,0,0,0)');
    ctx.beginPath();closes.forEach((p,i)=>{i===0?ctx.moveTo(xS(i),yS(p)):ctx.lineTo(xS(i),yS(p));});
    ctx.strokeStyle=lc;ctx.lineWidth=2;ctx.stroke();
    ctx.lineTo(xS(n-1),PAD_T+cH);ctx.lineTo(PAD_L,PAD_T+cH);ctx.closePath();
    ctx.fillStyle=grad;ctx.fill();
  }

  // Current price line
  const lp=closes[closes.length-1], ly=yS(lp);
  ctx.beginPath();ctx.strokeStyle='rgba(255,255,255,0.2)';ctx.lineWidth=1;ctx.setLineDash([4,4]);
  ctx.moveTo(PAD_L,ly);ctx.lineTo(W-PAD_R,ly);ctx.stroke();ctx.setLineDash([]);
  const isUp2=closes[closes.length-1]>=closes[0];
  ctx.fillStyle=isUp2?'#00d4aa':'#ff4d6a';ctx.font='bold 11px IBM Plex Mono,monospace';ctx.textAlign='left';ctx.textBaseline='middle';
  ctx.fillText((lp>=1?'$'+lp.toFixed(2):'$'+lp.toFixed(5)), W-PAD_R+4, ly);

  // Support/Resistance + Volume Profile POC — reuses the exact same fractal
  // clustering and volume-bucket math already tested against synthetic data
  // in perps.js, so a level drawn here means the same thing it means there.
  if (_activeIndicators.has('sr') && typeof computeSupportResistance === 'function') {
    const sr = computeSupportResistance(candles);
    const vp = typeof computeVolumeProfile === 'function' ? computeVolumeProfile(candles) : null;
    const drawLevel = (price, color, label, dash) => {
      if (price < pMin || price > pMax) return; // off-screen, skip rather than clip weirdly
      const y = yS(price);
      ctx.beginPath(); ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.setLineDash(dash);
      ctx.moveTo(PAD_L, y); ctx.lineTo(W-PAD_R, y); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = color; ctx.font = '9px IBM Plex Mono,monospace'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText(label, PAD_L+4, y-2);
    };
    if (sr) {
      sr.resistance.forEach((l,i) => drawLevel(l.price, 'rgba(255,77,106,0.55)', `R ${l.price>=1?'$'+l.price.toFixed(2):'$'+l.price.toFixed(5)} (${l.touches}x)`, [6,4]));
      sr.support.forEach((l,i)    => drawLevel(l.price, 'rgba(0,212,170,0.55)',  `S ${l.price>=1?'$'+l.price.toFixed(2):'$'+l.price.toFixed(5)} (${l.touches}x)`, [6,4]));
    }
    if (vp) {
      drawLevel(vp.poc, 'rgba(240,185,11,0.7)', `POC ${vp.poc>=1?'$'+vp.poc.toFixed(2):'$'+vp.poc.toFixed(5)}`, [2,3]);
    }
  }
}

// ── RSI & MACD CHART.JS PANELS ────────────────────────────────────────────────
function drawRsiChart(rsiV){
  const rc=document.getElementById('assetRsiChart'); if(!rc) return;
  if(_rsiInst)_rsiInst.destroy();
  _rsiInst=new Chart(rc.getContext('2d'),{type:'line',data:{labels:rsiV.map((_,i)=>i),datasets:[
    {data:rsiV,borderColor:'#9945ff',borderWidth:1.5,pointRadius:0,fill:false,tension:0.3},
    {data:new Array(rsiV.length).fill(70),borderColor:'rgba(255,77,106,0.4)',borderWidth:1,borderDash:[4,4],pointRadius:0,fill:false},
    {data:new Array(rsiV.length).fill(30),borderColor:'rgba(0,212,170,0.4)', borderWidth:1,borderDash:[4,4],pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:200},
    plugins:{legend:{display:false},tooltip:{backgroundColor:'#131920',callbacks:{label:c=>` RSI ${c.raw?.toFixed(1)}`}}},
    scales:{x:{display:false},y:{display:true,position:'right',min:0,max:100,grid:{color:'rgba(255,255,255,0.03)'},ticks:{color:'#5a6880',font:{family:"'IBM Plex Mono'",size:9},stepSize:25}}}}});
}

function drawMacdChart(macdR){
  const xc=document.getElementById('assetMacdChart'); if(!xc) return;
  if(_macdInst)_macdInst.destroy();
  _macdInst=new Chart(xc.getContext('2d'),{type:'bar',data:{labels:macdR.histogram.map((_,i)=>i),datasets:[
    {type:'bar', data:macdR.histogram,backgroundColor:macdR.histogram.map(v=>v>=0?'rgba(0,212,170,0.6)':'rgba(255,77,106,0.6)'),borderWidth:0.5},
    {type:'line',data:macdR.macd,   borderColor:'#0096ff',borderWidth:1.5,pointRadius:0,fill:false,tension:0.3},
    {type:'line',data:macdR.signal, borderColor:'#f5a623',borderWidth:1.5,pointRadius:0,fill:false,tension:0.3},
  ]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:200},
    plugins:{legend:{display:false},tooltip:{backgroundColor:'#131920'}},
    scales:{x:{display:false},y:{display:true,position:'right',grid:{color:'rgba(255,255,255,0.03)'},ticks:{color:'#5a6880',font:{family:"'IBM Plex Mono'",size:9}}}}}});
}

function renderChartMeta(sym, candles, closes){
  const last=closes[closes.length-1], first=closes[0];
  const high=Math.max(...candles.map(c=>safeNum(c.h))), low=Math.min(...candles.map(c=>safeNum(c.l)));
  const chgPct=((last-first)/first*100).toFixed(2), isUp=chgPct>=0;
  const atrArr=TA.atr(candles,14).filter(Boolean);
  const atr=atrArr.length?atrArr[atrArr.length-1]:0;
  document.getElementById('assetChartMeta').innerHTML=`
    <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;">
      <span style="font-family:var(--mono);font-size:20px;font-weight:700;color:${isUp?'var(--green)':'var(--red)'};">
        ${last>=1?'$'+fmtNum(last,2):'$'+last.toFixed(5)} &nbsp;${isUp?'▲':'▼'}${Math.abs(chgPct)}%
      </span>
      <span style="font-family:var(--mono);font-size:12px;color:var(--muted);">
        H:${last>=1?'$'+fmtNum(high,2):'$'+high.toFixed(5)} &nbsp;L:${last>=1?'$'+fmtNum(low,2):'$'+low.toFixed(5)}
      </span>
      <span style="font-family:var(--mono);font-size:12px;color:var(--amber);">ATR: ${atr>=1?'$'+atr.toFixed(2):'$'+atr.toFixed(5)}</span>
      <span style="font-family:var(--mono);font-size:11px;color:var(--muted);">${candles.length} bars</span>
    </div>`;
}

function renderSignals(closes, candles){
  const signals=TA.generateSignals(closes, candles);
  const C={buy:'var(--green)',sell:'var(--red)',neut:'var(--muted)',green:'var(--green)',red:'var(--red)',amber:'var(--amber)',info:'var(--muted)'};
  document.getElementById('assetSignals').innerHTML=signals.map(s=>`
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);color:${C[s.type]||'var(--muted)'};${s.bold?'font-weight:700;font-size:14px;':'font-size:13px;'}font-family:var(--mono);">
      <span style="width:14px;">${s.type==='buy'?'▲':s.type==='sell'?'▼':'●'}</span><span>${s.text}</span>
    </div>`).join('');
}

async function changeChartInterval(interval){
  if(!_currentAsset)return;
  _currentInterval=interval;
  document.querySelectorAll('.chart-int-btn').forEach(b=>b.classList.remove('active'));
  event.target.classList.add('active');
  await loadAndRender(_currentAsset.sym,_currentAsset.name,_currentAsset.type,interval);
}

function toggleChartMode(){
  _chartMode=_chartMode==='candle'?'line':'candle';
  const btn=document.getElementById('chartModeBtn');
  if(btn)btn.textContent=_chartMode==='candle'?'🕯 Candle':'📈 Line';
  if(_currentAsset&&_currentCandles.length) renderAll(_currentAsset.sym,_currentCandles,_currentAsset.type);
}

function toggleIndicator(name){
  _activeIndicators.has(name)?_activeIndicators.delete(name):_activeIndicators.add(name);
  const btn=document.getElementById('ind-'+name);
  if(btn)btn.classList.toggle('active',_activeIndicators.has(name));
  if(_currentAsset&&_currentCandles.length) renderAll(_currentAsset.sym,_currentCandles,_currentAsset.type);
}

window.addEventListener('resize',()=>{
  if(_currentAsset&&_currentCandles.length&&!document.getElementById('assetChartModal')?.classList.contains('hidden')){
    const c=_currentCandles.map(x=>safeNum(x.c));
    drawCandleChart(_currentAsset.sym,_currentCandles,c,TA.ema(c,9),TA.ema(c,21),TA.ema(c,50),TA.bollinger(c,20));
  }
});
