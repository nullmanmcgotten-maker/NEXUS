/**
 * perps.js — Perpetual futures aggregator: CEX (Binance USDT-M) + DEX (Hyperliquid).
 *
 * "Perps" here means perpetual-swap contracts specifically, not spot — traders
 * who run perps care about funding rate and overbought/oversold state, neither
 * of which the spot-only crypto.js/heatmap.js modules track.
 *
 * Sources (both browser-CORS-open, no key required):
 *   CEX — Binance Futures REST: /fapi/v1/premiumIndex (mark price + funding)
 *         merged with /fapi/v1/ticker/24hr (last price, 24h chg, volume).
 *         Regex-filtered to true perpetuals (excludes dated quarterly contracts
 *         like BTCUSD_231229).
 *   DEX — Hyperliquid /info metaAndAssetCtxs (on-chain perp DEX — full asset
 *         universe with mark price, funding, 24h notional volume, open interest).
 *
 * Overbought/oversold uses TA.rsi() from indicators.js on 1h closes (14-period).
 * RSI needs a kline fetch per symbol, so it's scanned in a concurrency-limited
 * batch rather than fired for the whole universe at once.
 */

const BINANCE_FAPI_BASE = 'https://fapi.binance.com/fapi/v1';
const BYBIT_TICKERS_BASE = 'https://api.bybit.com/v5/market/tickers';
const HL_BASE            = 'https://api.hyperliquid.xyz/info';

async function hlPost(body, timeout = 10000) {
  const doPost = async () => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(HL_BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      clearTimeout(t);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (e) { clearTimeout(t); throw e; }
  };
  if (typeof withRetry === 'function') {
    return withRetry(doPost, { retries: 2, baseDelayMs: 400, source: 'api.hyperliquid.xyz' });
  }
  return doPost();
}

// ── FETCH: CEX PERPS (Binance USDT-M Futures) ──────────────────────────────────
async function fetchCexPerps() {
  const [premium, tickers] = await Promise.all([
    apiFetch(`${BINANCE_FAPI_BASE}/premiumIndex`),
    apiFetch(`${BINANCE_FAPI_BASE}/ticker/24hr`),
  ]);
  const tMap = Object.fromEntries(tickers.map(t => [t.symbol, t]));
  return premium
    .filter(p => /^[A-Z0-9]+USDT$/.test(p.symbol)) // true perpetuals only — excludes dated futures (e.g. BTCUSD_231229)
    .map(p => {
      const t = tMap[p.symbol] || {};
      return {
        symbol: p.symbol.replace(/USDT$/, ''),
        source: 'CEX',
        exchange: 'Binance',
        price: safeNum(p.markPrice),
        chg24h: safeNum(t.priceChangePercent),
        fundingRate: safeNum(p.lastFundingRate) * 100,
        volume: safeNum(t.quoteVolume),
        openInterest: null,
        rsi: null,
        rsi4h: null,
      sr: null,
      volProfile: null,
      confluence: null,
      composite: null,
      longShortRatio: null,
      dailyTrend: null,
      scannedAt: null,
      volatility: null,
        sr: null,
        volProfile: null,
        confluence: null,
        composite: null,
        longShortRatio: null,
        dailyTrend: null,
        scannedAt: null,
        volatility: null,
        signal: null,
        fetchSymbol: p.symbol, // for klines
      };
    })
    .filter(x => x.price > 0);
}
async function fetchCexPerpCloses(fetchSymbol, interval = '1h') {
  const klines = await apiFetch(`${BINANCE_FAPI_BASE}/klines?symbol=${fetchSymbol}&interval=${interval}&limit=100`);
  return klines.map(k => parseFloat(k[4])).filter(v => isFinite(v));
}
// Full OHLCV — used for RSI *and* S/R + volume profile off one fetch, instead
// of a close-only call for RSI and a second call for the rest.
async function fetchCexPerpCandles(fetchSymbol, interval = '1h') {
  const klines = await apiFetch(`${BINANCE_FAPI_BASE}/klines?symbol=${fetchSymbol}&interval=${interval}&limit=100`);
  return klines.map(k => ({
    o: parseFloat(k[1]), h: parseFloat(k[2]), l: parseFloat(k[3]), c: parseFloat(k[4]), v: parseFloat(k[5]),
  })).filter(k => isFinite(k.c) && k.c > 0);
}
async function fetchCexOpenInterest(fetchSymbol) {
  const oi = await apiFetch(`${BINANCE_FAPI_BASE}/openInterest?symbol=${fetchSymbol}`);
  return safeNum(oi?.openInterest);
}

// ── DEPTH SIGNAL: crowd positioning (Binance-only — no equivalent free
// no-key endpoint exists for Bybit/Hyperliquid at this granularity) ────────────
// This is genuinely different information from funding rate: funding tells
// you the COST of being long/short right now; long/short ratio tells you how
// many accounts are actually positioned each way. They usually agree, but
// when they diverge (e.g. ratio extreme but funding calm) it's a distinct
// signal worth having as its own factor rather than folding into funding.
async function fetchLongShortRatio(fetchSymbol) {
  const data = await apiFetch(`${BINANCE_FAPI_BASE.replace('/fapi/v1','/futures/data')}/globalLongShortAccountRatio?symbol=${fetchSymbol}&period=1h&limit=1`);
  const last = Array.isArray(data) ? data[data.length-1] : null;
  return last ? safeNum(last.longShortRatio) : null;
}

// ── DEPTH SIGNAL: higher-timeframe trend context ────────────────────────────────
// A 1h RSI extreme means something different depending on whether the daily
// trend agrees or disagrees with it. This fetches daily candles (same
// fetchPerpCandles path, just a different interval) and computes where price
// sits relative to a 50-day EMA, plus its recent slope direction.
async function fetchDailyTrendContext(item) {
  const candles = await fetchPerpCandles(item, '1d');
  if (candles.length < 55) return null;
  const closes = candles.map(c => c.c);
  const ema50 = TA.ema(closes, 50).filter(v => v !== null);
  if (ema50.length < 5) return null;
  const lastEma = ema50[ema50.length-1];
  const priorEma = ema50[ema50.length-5]; // slope over the last 5 daily bars
  const lastClose = closes[closes.length-1];
  const aboveEma = lastClose > lastEma;
  const slopeUp = lastEma > priorEma;
  return { aboveEma, slopeUp, ema50: lastEma, priceVsEmaPct: ((lastClose-lastEma)/lastEma)*100 };
}

// ── CROSS-CHECK: Bybit (independent exchange, used to sanity-check Binance) ────
// Bybit v5 unified tickers endpoint returns the whole linear-perp universe in
// one call — no per-symbol fetching needed, so this is cheap regardless of
// how many symbols are loaded.
async function fetchBybitPerps() {
  const data = await apiFetch(`${BYBIT_TICKERS_BASE}?category=linear`);
  const list = data?.result?.list || [];
  const map = {};
  list.forEach(t => {
    if (!/USDT$/.test(t.symbol)) return;
    map[t.symbol] = {
      price:   safeNum(t.lastPrice),
      funding: safeNum(t.fundingRate) * 100,
      chg24h:  safeNum(t.price24hPcnt) * 100,
      volume:  safeNum(t.turnover24h),
    };
  });
  return map;
}

const CROSS_CHECK_PRICE_THRESHOLD_PCT = 0.15;   // flag if Binance vs Bybit price differs by more than this
const CROSS_CHECK_FUNDING_THRESHOLD_PP = 0.03;  // flag if funding differs by more than this many percentage points

// Attaches p.bybit = {price, funding, priceDivPct, fundingDivPct, flag} to
// every Binance-sourced item where Bybit has a matching symbol, and builds
// window._arbOpportunities from every pair of exchanges (Binance/Bybit/
// Hyperliquid) that has a live price for the same symbol.
function computeCrossExchangeData(all, bybitMap) {
  const binanceMap = {}, hlMap = {};
  all.forEach(p => {
    if (p.source === 'CEX') binanceMap[p.symbol] = { price: p.price, funding: p.fundingRate };
    else                    hlMap[p.symbol]       = { price: p.price, funding: p.fundingRate };
  });
  const bybitBare = {};
  Object.entries(bybitMap).forEach(([k, v]) => { bybitBare[k.replace(/USDT$/, '')] = v; });

  all.forEach(p => {
    if (p.source !== 'CEX') return;
    const b = bybitBare[p.symbol];
    if (!b || b.price <= 0) return;
    const priceDivPct   = ((p.price - b.price) / b.price) * 100;
    const fundingDivPct = p.fundingRate - b.funding;
    p.bybit = {
      price: b.price, funding: b.funding, priceDivPct, fundingDivPct,
      flag: Math.abs(priceDivPct) > CROSS_CHECK_PRICE_THRESHOLD_PCT || Math.abs(fundingDivPct) > CROSS_CHECK_FUNDING_THRESHOLD_PP,
    };
  });

  const symbols = new Set([...Object.keys(binanceMap), ...Object.keys(hlMap), ...Object.keys(bybitBare)]);
  const arb = [];
  symbols.forEach(sym => {
    const quotes = [];
    if (binanceMap[sym]) quotes.push({ ex:'Binance',     price: binanceMap[sym].price, funding: binanceMap[sym].funding });
    if (bybitBare[sym])  quotes.push({ ex:'Bybit',        price: bybitBare[sym].price,  funding: bybitBare[sym].funding });
    if (hlMap[sym])      quotes.push({ ex:'Hyperliquid',  price: hlMap[sym].price,      funding: hlMap[sym].funding });
    if (quotes.length < 2) return;
    let best = null;
    for (let i=0;i<quotes.length;i++) for (let j=i+1;j<quotes.length;j++) {
      const a=quotes[i], b2=quotes[j];
      const lo = Math.min(a.price,b2.price);
      if (lo<=0) continue;
      const spreadPct = Math.abs(a.price-b2.price)/lo*100;
      if (!best || spreadPct>best.spreadPct) best = { a, b: b2, spreadPct, fundingSpreadPp: Math.abs(a.funding-b2.funding) };
    }
    if (best) arb.push({ symbol: sym, exA: best.a, exB: best.b, spreadPct: best.spreadPct, fundingSpreadPp: best.fundingSpreadPp });
  });
  arb.sort((a,b) => b.spreadPct - a.spreadPct);
  window._arbOpportunities = arb;
}

// ── NEW PERP LISTING DETECTION ──────────────────────────────────────────────────
// Diffs each exchange's perp universe against what we saw last poll cycle.
// A symbol appearing for the first time gets alerted through the same
// pipeline as everything else. This is detection-by-diff on our own polling
// cadence (every 5min in the background, or whenever the tab is manually
// refreshed) — NOT a sub-second firehose. Said explicitly in the alert text
// so it's never read as faster than it actually is.
let _seenPerpUniverse = null; // null = no baseline yet (first run)
(function(){ try { const s = localStorage.getItem('nexus_perp_universe'); if (s) _seenPerpUniverse = JSON.parse(s); } catch(e){} })();
function saveSeenPerpUniverse() { try { localStorage.setItem('nexus_perp_universe', JSON.stringify(_seenPerpUniverse)); } catch(e){} }

function detectNewListings(cex, dex, bybitMap) {
  const current = {
    binance: cex.map(p => p.symbol),
    bybit:   Object.keys(bybitMap).map(s => s.replace(/USDT$/, '')),
    hyperliquid: dex.map(p => p.symbol),
  };
  const newItems = []; // returned so callers can immediately queue them for RSI/composite scoring

  if (!_seenPerpUniverse) {
    // First run ever — no baseline to diff against. Save silently; don't
    // alert on the entire existing universe as if every symbol just listed.
    _seenPerpUniverse = current;
    saveSeenPerpUniverse();
    return newItems;
  }

  Object.entries(current).forEach(([exchange, symbols]) => {
    const prevSet = new Set(_seenPerpUniverse[exchange] || []);
    if (!prevSet.size) return; // that exchange had no baseline last run (e.g. was down) — don't false-positive its whole universe as "new"
    const newOnes = symbols.filter(s => !prevSet.has(s));
    newOnes.forEach(sym => {
      const item = [...cex, ...dex].find(p => p.symbol === sym) || { symbol: sym, source: exchange==='hyperliquid'?'DEX':'CEX', price: 0 };
      logNewListing(item, exchange); // always recorded — independent of whether alerts are enabled
      if (item.price > 0) newItems.push(item); // only scannable if it's a real object from cex/dex (has fetchSymbol etc), not the price:0 fallback
      if (!_perpAlertConfig.onNewListing) return;
      firePerpAlert(item, 'new_listing',
        `First time seen on ${exchange} — detected this poll cycle, not a live firehose. New perps often have capped leverage and volatile funding early on.`);
    });
  });

  _seenPerpUniverse = current;
  saveSeenPerpUniverse();
  return newItems;
}

// Dedicated, always-on record of detected launches — separate from the
// alert toggle, since "did a new perp launch" and "did I want a popup about
// it" are different questions. The alert can be off; the log still fills.
let _newListingsLog = [];
(function(){ try { const s = localStorage.getItem('nexus_new_listings_log'); if (s) _newListingsLog = JSON.parse(s); } catch(e){} })();
function logNewListing(item, exchange) {
  _newListingsLog.unshift({ symbol: item.symbol, exchange, price: item.price, detectedAt: Date.now() });
  if (_newListingsLog.length > 100) _newListingsLog.length = 100;
  try { localStorage.setItem('nexus_new_listings_log', JSON.stringify(_newListingsLog)); } catch(e){}
  renderNewListingsPanel();
}
function renderNewListingsPanel() {
  const el = document.getElementById('newListingsPanel');
  if (!el) return;
  if (!_newListingsLog.length) {
    el.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:8px 0;">No new perp launches detected yet. Checked every ~10min in the background once Perps has been loaded once — first run establishes the baseline silently, so nothing shows up until the second check after that.</div>`;
    return;
  }
  el.innerHTML = _newListingsLog.slice(0, 20).map(l => `
    <div class="mn-hist-row" style="cursor:pointer;" onclick="typeof openAssetChart==='function' && openAssetChart('${esc(l.symbol)}','${esc(l.symbol)} Perpetual','crypto')">
      <span class="mn-hist-badge" style="color:#0096ff;border-color:#0096ff;">${esc(l.exchange)}</span>
      <span class="mn-hist-title">${esc(l.symbol)} — first seen at $${l.price ? fmtNum(l.price, l.price<1?6:2) : '?'}</span>
      <span class="mn-hist-time">${new Date(l.detectedAt).toLocaleString()}</span>
    </div>`).join('');
}


async function fetchDexPerps() {
  const data = await hlPost({ type: 'metaAndAssetCtxs' });
  const [meta, ctxs] = data;
  const universe = meta?.universe || [];
  return universe.map((u, i) => {
    const ctx   = ctxs[i] || {};
    const price = safeNum(ctx.markPx);
    const prev  = safeNum(ctx.prevDayPx);
    const chg   = prev ? ((price - prev) / prev) * 100 : 0;
    return {
      symbol: u.name,
      source: 'DEX',
      exchange: 'Hyperliquid',
      price,
      chg24h: chg,
      fundingRate: safeNum(ctx.funding) * 100,
      volume: safeNum(ctx.dayNtlVlm),
      openInterest: safeNum(ctx.openInterest),
      rsi: null,
      rsi4h: null,
      signal: null,
      fetchSymbol: u.name,
    };
  }).filter(x => x.price > 0);
}
async function fetchDexPerpCloses(coin, interval = '1h') {
  const now = Date.now();
  const spanMs = interval === '4h' ? 110 * 4 * 3600 * 1000 : 110 * 3600 * 1000;
  const data = await hlPost({
    type: 'candleSnapshot',
    req: { coin, interval, startTime: now - spanMs, endTime: now },
  });
  return (data || []).map(c => safeNum(c.c)).filter(v => v > 0);
}
async function fetchDexPerpCandles(coin, interval = '1h') {
  const now = Date.now();
  const spanMs = interval === '4h' ? 110 * 4 * 3600 * 1000 : 110 * 3600 * 1000;
  const data = await hlPost({
    type: 'candleSnapshot',
    req: { coin, interval, startTime: now - spanMs, endTime: now },
  });
  return (data || []).map(c => ({
    o: safeNum(c.o), h: safeNum(c.h), l: safeNum(c.l), c: safeNum(c.c), v: safeNum(c.v),
  })).filter(k => k.c > 0);
}

async function fetchPerpCandles(item, interval = '1h') {
  return item.source === 'CEX' ? fetchCexPerpCandles(item.fetchSymbol, interval) : fetchDexPerpCandles(item.fetchSymbol, interval);
}

async function fetchPerpCloses(item, interval = '1h') {
  return item.source === 'CEX' ? fetchCexPerpCloses(item.fetchSymbol, interval) : fetchDexPerpCloses(item.fetchSymbol, interval);
}

// ── RSI BATCH SCAN — multi-timeframe confluence (1h + 4h), concurrency-limited ──
let RSI_OVERBOUGHT = 70, RSI_OVERSOLD = 30;
let FUNDING_EXTREME_PCT = 0.05; // |funding| above this (per-interval %) flags a crowded trade
(function(){ try { const s = localStorage.getItem('nexus_perp_thresholds'); if (s) { const t=JSON.parse(s); RSI_OVERBOUGHT=t.ob??70; RSI_OVERSOLD=t.os??30; FUNDING_EXTREME_PCT=t.funding??0.05; } } catch(e){} })();
function savePerpThresholds() {
  try { localStorage.setItem('nexus_perp_thresholds', JSON.stringify({ ob:RSI_OVERBOUGHT, os:RSI_OVERSOLD, funding:FUNDING_EXTREME_PCT, proximity:LEVEL_PROXIMITY_PCT })); } catch(e){}
}
function setPerpThreshold(key, value) {
  const v = parseFloat(value);
  if (isNaN(v)) return;
  if (key === 'ob') RSI_OVERBOUGHT = v;
  if (key === 'os') RSI_OVERSOLD = v;
  if (key === 'funding') FUNDING_EXTREME_PCT = v;
  if (key === 'proximity') LEVEL_PROXIMITY_PCT = v;
  savePerpThresholds();
}

function classifyRSI(v) {
  if (v === null || isNaN(v)) return null;
  if (v >= RSI_OVERBOUGHT) return 'overbought';
  if (v <= RSI_OVERSOLD)   return 'oversold';
  return 'neutral';
}

async function scanRSIBatch(items, { concurrency = 5, onProgress } = {}) {
  let idx = 0, done = 0;
  const total = items.length;

  // Fetched ONCE per batch, not per item — one market-wide index, not a
  // per-symbol metric, and refetching it 40 times in a row would be pointless.
  const fearGreedValue = await getFearGreedValue().catch(() => null);

  async function worker() {
    while (idx < items.length) {
      const item = items[idx++];
      try {
        const [candles1h, closes8h, closes4h, closes2h] = await Promise.all([
          fetchPerpCandles(item, '1h'),
          fetchPerpCloses(item, '8h'),
          fetchPerpCloses(item, '4h'),
          fetchPerpCloses(item, '2h'),
        ]);
        const closes1h = candles1h.map(c => c.c);
        if (closes1h.length > 15) {
          const arr = TA.rsi(closes1h, 14);
          const last = arr[arr.length - 1];
          if (last !== null && !isNaN(last)) item.rsi = Math.round(last * 10) / 10;
        }
        if (closes4h.length > 15) {
          const arr4 = TA.rsi(closes4h, 14);
          const last4 = arr4[arr4.length - 1];
          if (last4 !== null && !isNaN(last4)) item.rsi4h = Math.round(last4 * 10) / 10;
        }
        // Confluence: both timeframes agreeing is a stronger signal than either alone.
        // One flashing overbought while the other is neutral/oversold is a divergence,
        // not a clean signal — worth flagging as its own state rather than picking a side.
        const c1 = classifyRSI(item.rsi), c4 = classifyRSI(item.rsi4h);
        if (c1 && c4) item.signal = (c1 === c4) ? c1 : 'divergent';
        else if (c1)  item.signal = c1;
        else if (c4)  item.signal = c4;

        // Placement/analysis timeframe check: 8h/4h/2h/1h RSI direction,
        // used for the MTF Alignment composite factor. Kept as its own
        // {8h,4h,2h,1h} map (not just a count) so the UI can show exactly
        // which timeframes agree and which don't, not just a tally.
        const rsiDirFromCloses = (closes) => {
          if (closes.length <= 15) return null;
          const arr = TA.rsi(closes, 14);
          const last = arr[arr.length-1];
          if (last === null || isNaN(last)) return null;
          if (last >= RSI_OVERBOUGHT) return -1;
          if (last <= RSI_OVERSOLD) return 1;
          return 0;
        };
        item.mtf = {
          '8h': rsiDirFromCloses(closes8h),
          '4h': rsiDirFromCloses(closes4h),
          '2h': rsiDirFromCloses(closes2h),
          '1h': rsiDirFromCloses(closes1h),
        };

        item.sr         = computeSupportResistance(candles1h);
        item.volProfile = computeVolumeProfile(candles1h);
        item.confluence = item.sr ? findConfluence(item) : null;

        if (item.source === 'CEX') {
          try { item.openInterest = await fetchCexOpenInterest(item.fetchSymbol); } catch (e) { /* leave null */ }
          try { item.longShortRatio = await fetchLongShortRatio(item.fetchSymbol); } catch (e) { item.longShortRatio = null; }
        }
        try { item.dailyTrend = await fetchDailyTrendContext(item); } catch (e) { item.dailyTrend = null; }
        item.fearGreedValue = fearGreedValue;
        // Composite runs last — depends on confluence + OI + every depth factor above.
        item.composite = computeCompositeSignal(item, candles1h);
        item.scannedAt = Date.now(); // freshness stamp — "actionable right now" needs to say how recent "now" actually is
        item.volatility = computeVolatilityRegime(candles1h);
        item.scanError = null;
      } catch (e) {
        // Don't swallow this — "pending forever with no explanation" is a
        // real usability failure. Record why so it's visible in the UI
        // instead of silently invisible.
        item.scanError = e?.message || String(e);
      }
      done++;
      if (onProgress) onProgress(done, total);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
}

function isFundingExtreme(p) { return Math.abs(p.fundingRate) >= FUNDING_EXTREME_PCT; }

// ── COMPOSITE SIGNAL — RSI alone is one input, not the whole picture ───────────
// Combines: RSI+structure confluence (already built), MACD momentum cross,
// Bollinger Band position, open-interest trend, and funding-rate direction
// into one bullish/bearish score. Each factor is independently weak (RSI
// alone gives false signals constantly); agreement across several is what
// actually separates a real setup from noise.
function computeCompositeSignal(item, candles1h) {
  if (!candles1h || candles1h.length < 30) return null;
  const closes = candles1h.map(c => c.c);
  const factors = []; // { name, direction: 1|-1|0, weight, detail }

  // 1. RSI + structure confluence — already computed, highest weight since
  //    it's the only factor that accounts for price level, not just momentum.
  if (item.confluence) {
    const dir = item.signal === 'oversold' ? 1 : item.signal === 'overbought' ? -1 : 0;
    factors.push({ name:'RSI+Structure', direction: dir, weight: 3, detail: `${item.signal} at ${item.confluence.type}` });
  } else if (item.signal === 'overbought' || item.signal === 'oversold') {
    const dir = item.signal === 'oversold' ? 1 : -1;
    factors.push({ name:'RSI', direction: dir, weight: 1, detail: `${item.signal}, no structure confirmation` });
  }

  // 2. MACD histogram — momentum direction and whether it's building or fading.
  const macd = TA.macd(closes);
  const hist = macd.histogram.filter(v => v !== null);
  if (hist.length >= 3) {
    const [h3,h2,h1] = hist.slice(-3);
    const rising = h1 > h2 && h2 > h3;
    const falling = h1 < h2 && h2 < h3;
    if (h1 > 0 && rising)       factors.push({ name:'MACD', direction: 1,  weight: 2, detail:'bullish momentum building' });
    else if (h1 < 0 && falling) factors.push({ name:'MACD', direction: -1, weight: 2, detail:'bearish momentum building' });
    else if (h1 > 0)            factors.push({ name:'MACD', direction: 1,  weight: 1, detail:'positive but fading' });
    else if (h1 < 0)            factors.push({ name:'MACD', direction: -1, weight: 1, detail:'negative but fading' });
  }

  // 3. Bollinger Band position — price outside the bands is a stretch, not
  //    just "high RSI"; independent confirmation of an extended move.
  const bb = TA.bollinger(closes);
  const lastClose = closes[closes.length-1];
  const bbUpper = bb.upper[bb.upper.length-1], bbLower = bb.lower[bb.lower.length-1];
  if (bbUpper && bbLower) {
    if (lastClose > bbUpper) factors.push({ name:'Bollinger', direction:-1, weight:1, detail:'price above upper band — stretched' });
    if (lastClose < bbLower) factors.push({ name:'Bollinger', direction: 1, weight:1, detail:'price below lower band — stretched' });
  }

  // 3b. TTM Squeeze — Bollinger contracted inside Keltner, i.e. volatility
  // has compressed to the point a real move is historically overdue.
  // `on` alone isn't directional (that's why it's a badge, not a factor —
  // see item.squeezeOn below); `fired` (just released this bar) IS the
  // directional entry trigger most squeeze strategies actually wait for.
  if (candles1h.length >= 25) {
    const sq = TA.squeeze(candles1h);
    const li = candles1h.length - 1;
    item.squeezeOn = sq.on[li] === true;
    item.squeezeMomentum = sq.momentum[li];
    if (sq.fired[li]) {
      const dir = sq.momentum[li] != null && sq.momentum[li] < 0 ? -1 : 1;
      factors.push({ name:'Squeeze Fired', direction: dir, weight: 2, detail: `volatility just expanded ${dir>0?'bullish':'bearish'} out of compression` });
    }
  }

  // 4. Open interest trend vs price trend — rising OI + rising price confirms
  //    a real trend (new money entering); rising OI + falling price often
  //    means shorts are building, a different setup than "just oversold".
  if (item.openInterest !== null && item.openInterest !== undefined) {
    const priceChg = ((closes[closes.length-1] - closes[Math.max(0,closes.length-24)]) / closes[Math.max(0,closes.length-24)]) * 100;
    if (Math.abs(priceChg) > 1) {
      const trendDir = priceChg > 0 ? 1 : -1;
      factors.push({ name:'OI+Trend', direction: trendDir, weight: 1, detail: `OI present, price ${priceChg>0?'up':'down'} ${Math.abs(priceChg).toFixed(1)}% (24 bars)` });
    }
  }

  // 5. Funding direction — persistent positive funding = longs paying
  //    shorts (crowded long bias); persistent negative = crowded short.
  //    Direction here is contrarian: extreme funding tends to mean-revert.
  if (isFundingExtreme(item)) {
    factors.push({ name:'Funding', direction: item.fundingRate > 0 ? -1 : 1, weight: 1, detail: `extreme ${item.fundingRate>0?'positive':'negative'} funding, contrarian` });
  }

  // 6. Long/Short account ratio — DIFFERENT data than funding (positioning,
  //    not cost-of-position). Extreme skew is contrarian for the same reason
  //    funding is: a crowded trade has more people left to unwind than to add.
  if (item.longShortRatio !== null && item.longShortRatio !== undefined) {
    if (item.longShortRatio >= 2.2)      factors.push({ name:'L/S Ratio', direction:-1, weight:1, detail:`${item.longShortRatio.toFixed(2)}:1 long-heavy, contrarian` });
    else if (item.longShortRatio <= 0.5) factors.push({ name:'L/S Ratio', direction: 1, weight:1, detail:`${item.longShortRatio.toFixed(2)}:1 short-heavy, contrarian` });
  }

  // 7. Daily trend context — a 1h RSI extreme reads differently depending on
  //    whether the higher timeframe agrees. Weighted like MACD (2), since
  //    trend context is a real independent read, not just a tiebreaker.
  if (item.dailyTrend) {
    const dir = item.dailyTrend.aboveEma && item.dailyTrend.slopeUp ? 1
              : !item.dailyTrend.aboveEma && !item.dailyTrend.slopeUp ? -1
              : 0; // mixed (above EMA but sloping down, etc.) — no clear daily bias, don't force one
    if (dir !== 0) {
      factors.push({ name:'Daily Trend', direction: dir, weight: 2, detail: `${dir>0?'above':'below'} 50d EMA, sloping ${item.dailyTrend.slopeUp?'up':'down'} (${item.dailyTrend.priceVsEmaPct>=0?'+':''}${item.dailyTrend.priceVsEmaPct.toFixed(1)}%)` });
    }
  }

  // 8. Stochastic RSI — faster/more sensitive than plain RSI. Plain RSI says
  //    "how extended is this"; StochRSI's %K crossing back over %D from an
  //    extreme is closer to "is the extension actually turning now". Two
  //    different questions, so it's its own factor rather than folded into #1.
  const stoch = TA.stochRsi(closes);
  const kLast = stoch.k[stoch.k.length-1], kPrev = stoch.k[stoch.k.length-2];
  const dLast = stoch.d[stoch.d.length-1], dPrev = stoch.d[stoch.d.length-2];
  if (kLast!==null && kPrev!==null && dLast!==null && dPrev!==null) {
    const crossedUp   = kPrev <= dPrev && kLast > dLast && kLast < 30;
    const crossedDown = kPrev >= dPrev && kLast < dLast && kLast > 70;
    if (crossedUp)        factors.push({ name:'StochRSI', direction: 1, weight:2, detail:`%K crossed up through %D from oversold (${kLast.toFixed(0)})` });
    else if (crossedDown) factors.push({ name:'StochRSI', direction:-1, weight:2, detail:`%K crossed down through %D from overbought (${kLast.toFixed(0)})` });
  }

  // 9. Volume confirmation — an RSI/structure signal on below-average volume
  //    is a weak-conviction move; the same signal on a volume spike is a
  //    different, more trustworthy thing. Only fires when volume is actually
  //    elevated (silence on quiet volume, rather than treating "normal" as a
  //    directional vote).
  const vols = candles1h.map(c => c.v).filter(v => v > 0);
  if (vols.length >= 20) {
    const avgVol = vols.slice(-20,-1).reduce((s,v)=>s+v,0)/19;
    const lastVol = vols[vols.length-1];
    const lastCandle = candles1h[candles1h.length-1];
    if (avgVol > 0 && lastVol / avgVol >= 1.5) {
      const candleDir = lastCandle.c >= lastCandle.o ? 1 : -1;
      factors.push({ name:'Volume', direction: candleDir, weight:1, detail:`${(lastVol/avgVol).toFixed(1)}x average volume, confirms ${candleDir>0?'up':'down'} move` });
    }
  }

  // 10. Sentiment — crypto-market-wide Fear & Greed Index. Contrarian at
  //     extremes, same family as funding/L-S ratio but sourced from
  //     aggregate market behavior instead of derivatives positioning.
  if (item.fearGreedValue !== null && item.fearGreedValue !== undefined) {
    if (item.fearGreedValue <= 20)      factors.push({ name:'Sentiment', direction: 1, weight:1, detail:`Extreme Fear (${item.fearGreedValue}), contrarian` });
    else if (item.fearGreedValue >= 80) factors.push({ name:'Sentiment', direction:-1, weight:1, detail:`Extreme Greed (${item.fearGreedValue}), contrarian` });
  }

  // 11. Multi-timeframe alignment (8h/4h/2h/1h) — the placement/analysis
  //     check: does the higher-timeframe RSI structure actually agree across
  //     the timeframes you'd use to decide direction, not just one of them?
  if (item.mtf) {
    const dirs = Object.values(item.mtf).filter(v => v !== null);
    const bullCount = dirs.filter(d => d === 1).length;
    const bearCount = dirs.filter(d => d === -1).length;
    if (dirs.length >= 3 && bullCount >= 3)      factors.push({ name:'MTF Alignment', direction: 1, weight:3, detail:`${bullCount}/${dirs.length} of 8h/4h/2h/1h agree bullish` });
    else if (dirs.length >= 3 && bearCount >= 3) factors.push({ name:'MTF Alignment', direction:-1, weight:3, detail:`${bearCount}/${dirs.length} of 8h/4h/2h/1h agree bearish` });
  }

  // 12. Advanced TA suite — SMC/ICT structure (BOS/CHoCH, order blocks,
  //     liquidity sweeps), Wyckoff (spring/UTAD, effort-vs-result), Ichimoku
  //     cloud+TK, Fibonacci/rule-checked Elliott wave, harmonic XABCD
  //     patterns. Pure functions of candles1h already fetched above — no
  //     extra network calls, safe to run on every scan. Wrapped in try/catch
  //     so a bug in one of six independent frameworks can never take down
  //     the whole composite score.
  try {
    const advResult = AdvancedTA.analyzeSync(candles1h);
    item.advancedTA = advResult; // stashed for the Advanced TA panel to reuse without recomputing
    AdvancedTA.toFactors(advResult).forEach(f => factors.push(f));
  } catch (e) {
    console.warn('[AdvancedTA] factor computation failed for', item.symbol, e.message);
  }

  // 13. Extended indicator library — ADX/DI (is there even a trend worth
  //     trusting the rest of these factors on), SuperTrend (clean
  //     directional flip), MFI (volume-weighted RSI — different from the
  //     RSI+Structure factor above since it's volume, not just price,
  //     driving the read), and CMF (does volume actually confirm the
  //     current price direction). Deliberately conservative weights: these
  //     mostly overlap conceptually with RSI/MACD/BB already in the
  //     composite, so they're included as confirmation, not as new
  //     independent votes carrying full weight.
  try {
    if (candles1h.length >= 30) {
      const adxR = TA.adx(candles1h);
      const li = candles1h.length - 1;
      if (adxR.adx[li] != null && adxR.adx[li] >= 25 && adxR.plusDI[li] != null && adxR.minusDI[li] != null) {
        factors.push({ name:'ADX/DI', direction: adxR.plusDI[li] > adxR.minusDI[li] ? 1 : -1, weight: 2, detail: `ADX ${adxR.adx[li].toFixed(0)}, ${adxR.plusDI[li]>adxR.minusDI[li]?'+DI':'-DI'} leading` });
      }
      const stR = TA.superTrend(candles1h);
      if (stR.trend[li] != null && stR.trend[li-1] != null) {
        const flipped = stR.trend[li] !== stR.trend[li-1];
        factors.push({ name:'SuperTrend', direction: stR.trend[li], weight: flipped ? 2 : 1, detail: flipped ? `just flipped ${stR.trend[li]===1?'bullish':'bearish'}` : `${stR.trend[li]===1?'bullish':'bearish'} continuation` });
      }
      const mfiArr = TA.mfi(candles1h);
      if (mfiArr[li] != null) {
        if (mfiArr[li] < 20) factors.push({ name:'MFI', direction: 1, weight: 1, detail: `${mfiArr[li].toFixed(0)}, volume-weighted oversold` });
        else if (mfiArr[li] > 80) factors.push({ name:'MFI', direction: -1, weight: 1, detail: `${mfiArr[li].toFixed(0)}, volume-weighted overbought` });
      }
      const cmfArr = TA.cmf(candles1h);
      if (cmfArr[li] != null && Math.abs(cmfArr[li]) > 0.1) {
        factors.push({ name:'CMF', direction: cmfArr[li] > 0 ? 1 : -1, weight: 1, detail: `${cmfArr[li].toFixed(2)}, volume ${cmfArr[li]>0?'accumulating':'distributing'}` });
      }
    }
  } catch (e) {
    console.warn('[ExtendedIndicators] factor computation failed for', item.symbol, e.message);
  }

  if (!factors.length) return null;
  const totalWeight = factors.reduce((s,f)=>s+f.weight,0);
  const score = factors.reduce((s,f)=>s+f.direction*f.weight,0) / totalWeight; // -1..+1
  const agreeing = factors.filter(f => Math.sign(f.direction) === Math.sign(score) && f.direction !== 0).length;

  let label;
  if (score >= 0.5 && agreeing >= 3)       label = 'strong_bullish';
  else if (score >= 0.25)                  label = 'bullish';
  else if (score <= -0.5 && agreeing >= 3) label = 'strong_bearish';
  else if (score <= -0.25)                 label = 'bearish';
  else                                      label = 'mixed';

  return { score: Math.round(score*100)/100, label, factors, agreeing, totalFactors: factors.length };
}
const COMPOSITE_META = {
  strong_bullish: { text:'▲▲ STRONG BULL', color:'var(--green)' },
  bullish:        { text:'▲ Bullish',      color:'var(--green)' },
  mixed:          { text:'— Mixed',        color:'var(--muted2)' },
  bearish:        { text:'▼ Bearish',      color:'var(--red)' },
  strong_bearish: { text:'▼▼ STRONG BEAR', color:'var(--red)' },
};

// ── SENTIMENT CHECK — Crypto Fear & Greed Index, cached market-wide ────────────
// One index covers the whole crypto market, not per-symbol — fetched once
// and reused across every item's composite calc rather than re-fetched per
// symbol. Contrarian at extremes, same logic family as funding/L-S ratio but
// from an entirely different data source (aggregate market psychology, not
// derivatives positioning).
let _fearGreedCache = null, _fearGreedCacheTime = 0;
const FEAR_GREED_TTL = 30 * 60 * 1000; // updates daily anyway — 30min cache is plenty
async function getFearGreedValue() {
  if (_fearGreedCache !== null && Date.now() - _fearGreedCacheTime < FEAR_GREED_TTL) return _fearGreedCache;
  try {
    const data = await apiFetch('https://api.alternative.me/fng/?limit=1');
    const val = safeNum(data?.data?.[0]?.value);
    _fearGreedCache = val > 0 ? val : null;
    _fearGreedCacheTime = Date.now();
    return _fearGreedCache;
  } catch (e) { return _fearGreedCache; /* stale-but-present beats nothing */ }
}


// ── VOLATILITY REGIME — context, not a directional vote ─────────────────────────
// Expanding vs contracting ATR doesn't say which way price is going, so it
// deliberately does NOT enter the composite factor voting above. What it
// does tell you: whether momentum signals (MACD, trend) are firing in a
// genuinely trending environment, or whether RSI extremes are more likely
// to be range-bound chop that reverts without a real breakout. Shown as
// context alongside the factors, not folded into the score.
function computeVolatilityRegime(candles) {
  // ATR(14) needs 13 warmup bars before it produces any value, and this
  // needs 20 valid (post-warmup) ATR readings to compare recent-vs-baseline
  // — so the real minimum is 14+20=34, not just "some candles". Matters
  // more than it used to: newly-listed perps (auto-pinned and scanned
  // immediately now) may genuinely have under 34 hours of history, and this
  // should say "not enough data yet" rather than silently return junk.
  if (candles.length < 34) return null;
  const atr = TA.atr(candles, 14).filter(v => v !== null);
  if (atr.length < 20) return null;
  const recent   = atr.slice(-5).reduce((s,v)=>s+v,0)/5;
  const baseline = atr.slice(-20,-5).reduce((s,v)=>s+v,0)/15;
  if (baseline <= 0) return null;
  const ratio = recent / baseline;
  if (ratio >= 1.3) return { regime:'expanding',   ratio, label:'Volatility expanding — moves more likely to follow through' };
  if (ratio <= 0.7) return { regime:'contracting', ratio, label:'Volatility contracting — RSI extremes more prone to chop/reversion' };
  return { regime:'stable', ratio, label:'Volatility stable' };
}

// ── SUPPORT / RESISTANCE (fractal swing points, clustered) ─────────────────────
// A candle at index i is a swing high if its high is the max within a small
// window on both sides — the standard "fractal" definition, nothing exotic.
// Nearby swing points get merged into one level (price clusters, not every
// individual wick) because a raw list of swing points is noise; clustered
// levels are what "support/resistance" actually means to a trader.
function findSwingPoints(candles, lookback = 3) {
  const highs = [], lows = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    const windowSlice = candles.slice(i - lookback, i + lookback + 1);
    const h = candles[i].h, l = candles[i].l;
    if (h === Math.max(...windowSlice.map(c => c.h))) highs.push(h);
    if (l === Math.min(...windowSlice.map(c => c.l))) lows.push(l);
  }
  return { highs, lows };
}
function clusterLevels(values, tolerancePct = 0.3) {
  if (!values.length) return [];
  const sorted = [...values].sort((a,b) => a-b);
  const clusters = [];
  let current = [sorted[0]];
  for (let i = 1; i < sorted.length; i++) {
    const last = current[current.length - 1];
    if (((sorted[i] - last) / last) * 100 <= tolerancePct) current.push(sorted[i]);
    else { clusters.push(current); current = [sorted[i]]; }
  }
  clusters.push(current);
  // A level's strength is how many swing points clustered into it (more
  // touches = more significant) — sort strongest first.
  return clusters
    .map(c => ({ price: c.reduce((s,v)=>s+v,0)/c.length, touches: c.length }))
    .sort((a,b) => b.touches - a.touches);
}
function computeSupportResistance(candles) {
  if (candles.length < 20) return null;
  const { highs, lows } = findSwingPoints(candles);
  const resistance = clusterLevels(highs).slice(0, 4);
  const support    = clusterLevels(lows).slice(0, 4);
  return { support, resistance };
}

// ── VOLUME PROFILE (POC / value area) ───────────────────────────────────────────
// Buckets traded volume into price bins across the lookback window. POC =
// price level where the most volume actually traded — often a stronger
// magnet/level than swing-high/low S/R because it reflects where positions
// actually built up, not just where price briefly touched.
function computeVolumeProfile(candles, bins = 24) {
  if (candles.length < 10) return null;
  const lo = Math.min(...candles.map(c => c.l));
  const hi = Math.max(...candles.map(c => c.h));
  if (!(hi > lo)) return null;
  const binSize = (hi - lo) / bins;
  const volByBin = new Array(bins).fill(0);
  candles.forEach(c => {
    // Approximate: spread each candle's volume evenly across the bins its
    // range touches, rather than dumping it all on the close. Cheap and
    // good enough for "where did volume concentrate", not meant to be a
    // tick-accurate reconstruction.
    const startBin = Math.max(0, Math.min(bins-1, Math.floor((c.l - lo) / binSize)));
    const endBin   = Math.max(0, Math.min(bins-1, Math.floor((c.h - lo) / binSize)));
    const span = endBin - startBin + 1;
    for (let b = startBin; b <= endBin; b++) volByBin[b] += c.v / span;
  });
  let pocBin = 0;
  for (let b = 1; b < bins; b++) if (volByBin[b] > volByBin[pocBin]) pocBin = b;
  const poc = lo + (pocBin + 0.5) * binSize;

  // Value area: expand outward from POC until ~70% of total volume is covered.
  const totalVol = volByBin.reduce((s,v)=>s+v,0);
  let covered = volByBin[pocBin], lo_i = pocBin, hi_i = pocBin;
  while (covered / totalVol < 0.70 && (lo_i > 0 || hi_i < bins-1)) {
    const nextLo = lo_i > 0 ? volByBin[lo_i-1] : -1;
    const nextHi = hi_i < bins-1 ? volByBin[hi_i+1] : -1;
    if (nextHi >= nextLo) { hi_i++; covered += volByBin[hi_i]; }
    else                  { lo_i--; covered += volByBin[lo_i]; }
  }
  return {
    poc,
    valueAreaLow:  lo + lo_i * binSize,
    valueAreaHigh: lo + (hi_i + 1) * binSize,
  };
}

// Ties an RSI extreme to whether price is currently sitting near a real S/R
// level or the volume-profile POC — this is the actual point of the feature:
// an isolated RSI extreme and one confirmed by structure are different signals.
const LEVEL_PROXIMITY_PCT_DEFAULT = 0.5;
let LEVEL_PROXIMITY_PCT = LEVEL_PROXIMITY_PCT_DEFAULT;
(function(){ try { const s = localStorage.getItem('nexus_perp_thresholds'); if (s) { const t=JSON.parse(s); if (t.proximity!==undefined) LEVEL_PROXIMITY_PCT=t.proximity; } } catch(e){} })();
function findConfluence(item) {
  if (!item.sr || !item.signal || item.signal === 'neutral') return null;
  const price = item.price;
  const candidates = [
    ...item.sr.support.map(l => ({ type:'support', ...l })),
    ...item.sr.resistance.map(l => ({ type:'resistance', ...l })),
  ];
  if (item.volProfile?.poc) candidates.push({ type:'poc', price: item.volProfile.poc, touches: 1 });

  let nearest = null;
  candidates.forEach(l => {
    const distPct = Math.abs((price - l.price) / l.price) * 100;
    if (distPct <= LEVEL_PROXIMITY_PCT && (!nearest || distPct < nearest.distPct)) {
      nearest = { ...l, distPct };
    }
  });
  if (!nearest) return null;

  // Confluence only counts as high-confidence when the direction makes sense:
  // overbought near resistance/POC (rejection zone), oversold near support/POC.
  const meaningful =
    (item.signal === 'overbought' && (nearest.type === 'resistance' || nearest.type === 'poc')) ||
    (item.signal === 'oversold'   && (nearest.type === 'support'    || nearest.type === 'poc'));
  return meaningful ? nearest : null;
}

// ── ORCHESTRATION ───────────────────────────────────────────────────────────────
window._perpsAll = [];
let _perpsLoading = false;
const PERPS_AUTO_SCAN_N = 40; // auto-RSI-scan top N by volume on load; rest via "Scan All"

// ── PINNED PERPS ─────────────────────────────────────────────────────────────
// Symbols the user (or the new-listing detector) wants scanned every cycle
// regardless of volume rank. Without this, a brand-new low-volume listing —
// exactly the thing worth watching — falls out of the top-N scan set
// immediately and never gets a composite score.
let _pinnedPerps = new Set();
(function(){ try { const s = localStorage.getItem('nexus_pinned_perps'); if (s) _pinnedPerps = new Set(JSON.parse(s)); } catch(e){} })();
function savePinnedPerps() { try { localStorage.setItem('nexus_pinned_perps', JSON.stringify([..._pinnedPerps])); } catch(e){} }
function togglePinPerp(symbol) {
  if (_pinnedPerps.has(symbol)) _pinnedPerps.delete(symbol);
  else _pinnedPerps.add(symbol);
  savePinnedPerps();
  renderPerpsTable();
}
function buildScanList(all, autoScanN) {
  const pinnedItems = all.filter(p => _pinnedPerps.has(p.symbol));
  const topByVolume  = all.slice(0, autoScanN);
  const seen = new Set();
  return [...pinnedItems, ...topByVolume].filter(p => {
    const key = `${p.symbol}:${p.source}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}

async function loadAllPerps() {
  if (_perpsLoading) return;
  _perpsLoading = true;
  renderPerpsStatus('Loading perpetuals — Binance Futures (CEX) + Hyperliquid (DEX)…');
  renderPerpsTable();

  const [cexR, dexR, bybitR] = await Promise.allSettled([fetchCexPerps(), fetchDexPerps(), fetchBybitPerps()]);
  const cex = cexR.status === 'fulfilled' ? cexR.value : [];
  const dex = dexR.status === 'fulfilled' ? dexR.value : [];
  const bybitMap = bybitR.status === 'fulfilled' ? bybitR.value : {};
  const sourceErrors = [];
  if (cexR.status === 'rejected')   { console.warn('[Perps] CEX (Binance) fetch failed:', cexR.reason?.message); sourceErrors.push(`Binance: ${cexR.reason?.message||'unknown error'}`); }
  if (dexR.status === 'rejected')   { console.warn('[Perps] DEX (Hyperliquid) fetch failed:', dexR.reason?.message); sourceErrors.push(`Hyperliquid: ${dexR.reason?.message||'unknown error'}`); }
  if (bybitR.status === 'rejected') { console.warn('[Perps] Cross-check (Bybit) fetch failed — proceeding without it:', bybitR.reason?.message); sourceErrors.push(`Bybit: ${bybitR.reason?.message||'unknown error'}`); }

  window._perpsAll = [...cex, ...dex].sort((a, b) => b.volume - a.volume);
  computeCrossExchangeData(window._perpsAll, bybitMap);
  const newlyListed = detectNewListings(cex, dex, bybitMap);
  newlyListed.forEach(item => _pinnedPerps.add(item.symbol)); // keep watching it on future cycles, not just this one
  if (newlyListed.length) savePinnedPerps();
  _perpsLoading = false;

  if (!window._perpsAll.length) {
    renderPerpsStatus(`Both perp sources unreachable right now — ${sourceErrors.join(' · ')}. If this persists across reloads, it's likely a network/CORS block from your browser or host, not the exchanges being down.`);
    renderPerpsTable();
    return;
  }

  renderPerpsTable();
  const top = buildScanList(window._perpsAll, PERPS_AUTO_SCAN_N);
  renderPerpsStatus(`Loaded ${window._perpsAll.length} perps (${cex.length} CEX · ${dex.length} DEX)${sourceErrors.length ? ' — '+sourceErrors.length+' source(s) failed: '+sourceErrors.join(' · ') : ''}${_pinnedPerps.size ? ` · ${_pinnedPerps.size} pinned` : ''}. Scanning RSI on top ${top.length}…`);
  await scanRSIBatch(top, { concurrency: 5, onProgress: (d, t) => renderPerpsStatus(`Scanning RSI… ${d}/${t}`) });
  renderPerpsTable();
  checkPerpAlerts(window._perpsAll);
  renderPerpsStatus(perpScanSummary(top, `${window._perpsAll.length} perps loaded · RSI scored on top ${top.length} (incl. pinned). Click "Scan Remaining" to score the rest.`));
}

async function scanAllPerpsRSI() {
  if (!window._perpsAll.length) { await loadAllPerps(); return; }
  const remaining = window._perpsAll.filter(p => p.rsi === null);
  if (!remaining.length) { renderPerpsStatus('RSI already scored for every loaded perp.'); return; }
  renderPerpsStatus(`Scanning RSI for remaining ${remaining.length} perps…`);
  await scanRSIBatch(remaining, { concurrency: 5, onProgress: (d, t) => renderPerpsStatus(`Scanning RSI… ${d}/${t} remaining`) });
  renderPerpsTable();
  checkPerpAlerts(window._perpsAll);
  renderPerpsStatus(perpScanSummary(remaining, `RSI scan complete — all ${window._perpsAll.length} loaded perps scored.`));
}

// Surfaces WHY items failed instead of leaving them silently stuck at
// "pending" — if fetches are failing (network, CORS, exchange down), this
// is where you'd actually find out.
function perpScanSummary(scannedItems, successMsg) {
  const failed = scannedItems.filter(p => p.scanError);
  if (!failed.length) return successMsg;
  const sample = failed[0].scanError;
  const allSameError = failed.every(p => p.scanError === sample);
  return `⚠ ${failed.length}/${scannedItems.length} symbols failed to scan${allSameError ? ` — likely a shared cause: "${sample}"` : ' — hover the ⚠ badge on a row for its specific error'}. ${scannedItems.length - failed.length} scored successfully.`;
}

// ── FILTER / SORT STATE ─────────────────────────────────────────────────────────
let _perpsFilter = { source: 'all', signal: 'all', search: '', sort: 'volume' };
function setPerpsSourceFilter(v) { _perpsFilter.source = v; renderPerpsTable(); }
function setPerpsSort(v)         { _perpsFilter.sort = v; renderPerpsTable(); }
function filterPerpsSearch(v)    { _perpsFilter.search = (v||'').trim().toUpperCase(); renderPerpsTable(); }
function setPerpsSignalFilter(v, btn) {
  _perpsFilter.signal = v; // 'all' | 'overbought' | 'oversold' | 'divergent' | 'extreme_funding' | 'squeeze'
  document.querySelectorAll('.perp-sig-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderPerpsTable();
}

function getFilteredPerps() {
  let list = window._perpsAll || [];
  if (_perpsFilter.source !== 'all') list = list.filter(p => p.source === _perpsFilter.source);
  if (_perpsFilter.signal === 'overbought') list = list.filter(p => p.signal === 'overbought');
  else if (_perpsFilter.signal === 'oversold') list = list.filter(p => p.signal === 'oversold');
  else if (_perpsFilter.signal === 'divergent') list = list.filter(p => p.signal === 'divergent');
  else if (_perpsFilter.signal === 'extreme_funding') list = list.filter(isFundingExtreme);
  else if (_perpsFilter.signal === 'squeeze') list = list.filter(p => p.squeezeOn);
  else if (_perpsFilter.signal === 'high_confidence') list = list.filter(p => !!p.confluence);
  else if (_perpsFilter.signal === 'pinned') list = list.filter(p => _pinnedPerps.has(p.symbol));
  if (_perpsFilter.search) list = list.filter(p => p.symbol.toUpperCase().includes(_perpsFilter.search));

  const sortFns = {
    volume:   (a,b) => b.volume - a.volume,
    funding:  (a,b) => Math.abs(b.fundingRate) - Math.abs(a.fundingRate),
    rsi_desc: (a,b) => (b.rsi ?? -1) - (a.rsi ?? -1),
    rsi_asc:  (a,b) => (a.rsi ?? 101) - (b.rsi ?? 101),
    chg:      (a,b) => b.chg24h - a.chg24h,
    composite:(a,b) => Math.abs(b.composite?.score ?? 0) - Math.abs(a.composite?.score ?? 0),
  };
  return [...list].sort(sortFns[_perpsFilter.sort] || sortFns.volume);
}

// ── RENDER ───────────────────────────────────────────────────────────────────────
function renderPerpsStatus(msg) {
  const el = document.getElementById('perpsStatus');
  if (el) el.textContent = msg;
}

function fmtVolUSD(v) {
  if (v >= 1e9) return '$' + (v/1e9).toFixed(2) + 'B';
  if (v >= 1e6) return '$' + (v/1e6).toFixed(2) + 'M';
  if (v >= 1e3) return '$' + (v/1e3).toFixed(1) + 'K';
  return '$' + fmtNum(v, 0);
}

function perpSignalBadge(p) {
  if (p.rsi === null && p.rsi4h === null) {
    if (p.scanError) return `<span class="perp-sig perp-sig-error" title="Scan failed: ${escAttr(p.scanError)}">⚠ error</span>`;
    return `<span class="perp-sig perp-sig-pending">— pending</span>`;
  }
  const r1 = p.rsi !== null ? p.rsi.toFixed(1) : '—';
  const r4 = p.rsi4h !== null ? p.rsi4h.toFixed(1) : '—';
  const conf = p.confluence ? ` <span class="perp-conf" title="Price within ${p.confluence.distPct.toFixed(2)}% of ${p.confluence.type === 'poc' ? 'volume POC' : p.confluence.type} at $${fmtNum(p.confluence.price, p.confluence.price<1?6:2)}${p.confluence.touches>1?' ('+p.confluence.touches+' touches)':''}">🎯</span>` : '';
  if (p.signal === 'overbought') return `<span class="perp-sig perp-sig-ob" title="1h ${r1} · 4h ${r4}">▲ OB ${r1}/${r4}</span>${conf}`;
  if (p.signal === 'oversold')   return `<span class="perp-sig perp-sig-os" title="1h ${r1} · 4h ${r4}">▼ OS ${r1}/${r4}</span>${conf}`;
  if (p.signal === 'divergent')  return `<span class="perp-sig perp-sig-div" title="1h ${r1} · 4h ${r4} — timeframes disagree">◆ DIV ${r1}/${r4}</span>`;
  return `<span class="perp-sig perp-sig-neut" title="1h ${r1} · 4h ${r4}">${r1}/${r4}</span>`;
}

function renderPerpsTable() {
  const body = document.getElementById('perpsBody');
  if (!body) return;

  const all = window._perpsAll || [];
  const counts = {
    total: all.length,
    ob: all.filter(p => p.signal === 'overbought').length,
    os: all.filter(p => p.signal === 'oversold').length,
    div: all.filter(p => p.signal === 'divergent').length,
    extreme: all.filter(isFundingExtreme).length,
    cex: all.filter(p => p.source === 'CEX').length,
    dex: all.filter(p => p.source === 'DEX').length,
  };
  const cEl = document.getElementById('perpsCounts');
  if (cEl) cEl.textContent = all.length
    ? `${counts.total} perps (${counts.cex} CEX · ${counts.dex} DEX) · ${counts.ob} OB · ${counts.os} OS · ${counts.div} divergent · ${counts.extreme} extreme funding`
    : 'No perps loaded yet';

  renderPerpsLeaderboard(all);

  const list = getFilteredPerps();
  if (!list.length) {
    body.innerHTML = `<div style="padding:32px;text-align:center;font-family:var(--mono);font-size:13px;color:var(--muted);">
      ${all.length ? 'No perps match this filter.' : 'Click <strong style="color:var(--text)">Load All Perps</strong> to pull CEX + DEX universes.'}</div>`;
    return;
  }

  body.innerHTML = list.map(p => `
    <div class="perp-row" style="cursor:pointer;" onclick="typeof openAssetChart==='function' && openAssetChart('${esc(p.symbol)}','${esc(p.symbol)} Perpetual','crypto')" title="Click to open chart with S/R + Volume Profile overlay">
      <span class="perp-src perp-src-${p.source.toLowerCase()}" title="${esc(p.exchange)}">${p.source}</span>
      <span class="perp-sym"><span onclick="event.stopPropagation();togglePinPerp('${esc(p.symbol)}')" title="${_pinnedPerps.has(p.symbol)?'Unpin — remove from always-scanned list':'Pin — always scan this symbol regardless of volume rank'}" style="cursor:pointer;margin-right:4px;">${_pinnedPerps.has(p.symbol)?'📌':'📍'}</span>${esc(p.symbol)}${isFundingExtreme(p) ? ' <span title="Extreme funding — crowded trade, mean-reversion risk">🔥</span>' : ''}${p.squeezeOn ? ` <span title="Volatility squeeze ON — Bollinger inside Keltner, compressed, watching for a breakout${p.squeezeMomentum!=null?` (momentum ${p.squeezeMomentum>=0?'+':''}${p.squeezeMomentum.toFixed(4)})`:''}">🌀</span>` : ''}${p.bybit?.flag ? ` <span title="Diverges from Bybit: price ${p.bybit.priceDivPct>=0?'+':''}${p.bybit.priceDivPct.toFixed(2)}% · funding ${p.bybit.fundingDivPct>=0?'+':''}${p.bybit.fundingDivPct.toFixed(3)}pp">🔀</span>` : ''}</span>
      <span class="r">$${fmtNum(p.price, p.price < 1 ? 6 : 2)}</span>
      <span class="r ${p.chg24h >= 0 ? 'up' : 'dn'}">${fmtPct(p.chg24h)}</span>
      <span class="r ${p.fundingRate >= 0 ? 'up' : 'dn'}">${p.fundingRate >= 0 ? '+' : ''}${p.fundingRate.toFixed(4)}%</span>
      <span class="r">${fmtVolUSD(p.volume)}</span>
      <span class="r">${perpSignalBadge(p)}</span>
      <span class="r">${compositeBadge(p)}</span>
    </div>`).join('');
}

function compositeBadge(p) {
  if (!p.composite) return `<span class="perp-sig perp-sig-pending">—</span>`;
  const meta = COMPOSITE_META[p.composite.label];
  const tooltip = p.composite.factors.map(f => `${f.name}: ${f.detail}`).join(' · ');
  return `<span class="perp-sig" style="color:${meta.color};background:${meta.color}1a;" title="${escAttr(tooltip)} (${p.composite.agreeing}/${p.composite.totalFactors} factors agree)">${meta.text}</span>`;
}

// ── PERP ALERTS — extreme funding & 🎯 confluence signals, pushed not polled ────
// Reuses the same toast/Notification/Telegram pattern as macroNews.js's alert
// system rather than inventing a second one. Dedup is per (symbol, signal
// type) with a cooldown, not per-poll — otherwise a symbol sitting at
// resistance for an hour would re-alert every scan cycle.
let _perpAlertConfig = { enabled: true, onConfluence: true, onExtremeFunding: true, onArb: true, onNewListing: true, arbThresholdPct: 0.4 };
(function(){ try { const s = localStorage.getItem('nexus_perp_alert_cfg'); if (s) _perpAlertConfig = { ..._perpAlertConfig, ...JSON.parse(s) }; } catch(e){} })();
function savePerpAlertConfig() { try { localStorage.setItem('nexus_perp_alert_cfg', JSON.stringify(_perpAlertConfig)); } catch(e){} }

let _perpAlertHistory = [];
(function(){ try { const s = localStorage.getItem('nexus_perp_alert_history'); if (s) _perpAlertHistory = JSON.parse(s); } catch(e){} })();
const _perpAlertCooldown = {}; // key -> last-fired timestamp
const PERP_ALERT_COOLDOWN_MS = 30 * 60 * 1000; // don't re-alert the same symbol+reason within 30min

function firePerpAlert(item, kind, detail) {
  const key = `${item.symbol}:${kind}`;
  const now = Date.now();
  if (_perpAlertCooldown[key] && now - _perpAlertCooldown[key] < PERP_ALERT_COOLDOWN_MS) return;
  _perpAlertCooldown[key] = now;

  const KIND_META = {
    confluence:      { icon:'🎯', label:'HIGH-CONFIDENCE SIGNAL', color:'#00d4aa' },
    extreme_funding: { icon:'🔥', label:'EXTREME FUNDING',        color:'#f0b90b' },
    arb:             { icon:'⚡', label:'ARBITRAGE SPREAD',       color:'#f0b90b' },
    new_listing:     { icon:'🆕', label:'NEW PERP LISTING',       color:'#0096ff' },
  };
  const meta = KIND_META[kind] || { icon:'●', label:kind, color:'#7a8ba8' };

  const toast = document.createElement('div');
  toast.style.cssText = `position:fixed;bottom:24px;right:24px;background:#1a2232;border:1px solid ${meta.color};border-radius:10px;padding:16px 20px;font-family:'IBM Plex Mono',monospace;font-size:12px;color:${meta.color};z-index:3000;max-width:340px;box-shadow:0 12px 40px rgba(0,0,0,.6);`;
  toast.innerHTML = `<div style="font-weight:700;margin-bottom:6px;font-size:13px;letter-spacing:.06em;">${meta.icon} ${meta.label} — ${esc(item.symbol)} (${item.source})</div>
    <div style="color:#eef0f6;font-size:13px;margin-bottom:4px;line-height:1.4;">${esc(detail)}</div>
    <div style="color:#5a6880;font-size:11px;">$${fmtNum(item.price, item.price<1?6:2)} · not trading advice, just a detected pattern</div>`;
  document.body.appendChild(toast);
  setTimeout(() => { toast.style.opacity='0'; toast.style.transition='opacity .5s'; setTimeout(()=>toast.remove(),500); }, 8000);

  if (typeof _pushOK !== 'undefined' && _pushOK && Notification.permission === 'granted') {
    new Notification(`NEXUS Perps: ${meta.label}`, { body: `${item.symbol} — ${detail}` });
  }
  if (typeof sendTelegram === 'function') {
    sendTelegram(`${meta.icon} <b>${meta.label}</b> — ${esc(item.symbol)} (${item.source})\n${esc(detail)}\n<i>$${fmtNum(item.price, item.price<1?6:2)}</i>`);
  }

  _perpAlertHistory.unshift({ symbol:item.symbol, source:item.source, kind, label:meta.label, detail, color:meta.color, price:item.price, ts: now });
  if (_perpAlertHistory.length > 100) _perpAlertHistory.length = 100;
  try { localStorage.setItem('nexus_perp_alert_history', JSON.stringify(_perpAlertHistory)); } catch(e){}
  renderPerpAlertHistory();
}

function checkPerpAlerts(items) {
  if (!_perpAlertConfig.enabled) return;
  items.forEach(item => {
    if (_perpAlertConfig.onConfluence && item.confluence) {
      const c = item.confluence;
      const levelDesc = c.type === 'poc' ? 'volume POC' : c.type;
      firePerpAlert(item, 'confluence',
        `RSI ${item.signal} confirmed at ${levelDesc} $${fmtNum(c.price, c.price<1?6:2)} (${c.distPct.toFixed(2)}% away${c.touches>1?', '+c.touches+' touches':''})`);
      logSignalForTracking(item);
    }
    if (_perpAlertConfig.onExtremeFunding && isFundingExtreme(item)) {
      firePerpAlert(item, 'extreme_funding',
        `Funding ${item.fundingRate>=0?'+':''}${item.fundingRate.toFixed(4)}% — crowded ${item.fundingRate>=0?'long':'short'}, mean-reversion risk`);
    }
  });
  (window._arbOpportunities || []).forEach(a => {
    if (_perpAlertConfig.onArb && a.spreadPct >= _perpAlertConfig.arbThresholdPct) {
      firePerpAlert({ symbol:a.symbol, source:`${a.exA.ex}/${a.exB.ex}`, price:a.exA.price }, 'arb',
        `${a.exA.ex} $${fmtNum(a.exA.price,2)} vs ${a.exB.ex} $${fmtNum(a.exB.price,2)} — ${a.spreadPct.toFixed(2)}% spread`);
    }
  });
}

function clearPerpAlertHistory() {
  _perpAlertHistory = [];
  try { localStorage.setItem('nexus_perp_alert_history', '[]'); } catch(e){}
  renderPerpAlertHistory();
}
function renderPerpAlertHistory() {
  const el = document.getElementById('perpAlertHistory');
  if (!el) return;
  if (!_perpAlertHistory.length) {
    el.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:8px 0;">No perp alerts fired yet this session.</div>`;
    return;
  }
  el.innerHTML = _perpAlertHistory.slice(0, 20).map(a => `
    <div class="mn-hist-row">
      <span class="mn-hist-badge" style="color:${a.color};border-color:${a.color};">${esc(a.symbol)}</span>
      <span class="mn-hist-title">${esc(a.detail)}</span>
      <span class="mn-hist-time">${new Date(a.ts).toLocaleTimeString()}</span>
    </div>`).join('');
}

function leaderRow(p, valueStr, valueClass) {
  return `<div class="perp-lead-row">
    <span class="perp-src perp-src-${p.source.toLowerCase()}">${p.source}</span>
    <span class="perp-sym">${esc(p.symbol)}</span>
    <span class="r ${valueClass||''}">${valueStr}</span>
  </div>`;
}
function renderPerpsLeaderboard(all) {
  const el = document.getElementById('perpsLeaderboard');
  if (!el) return;
  if (!all.length) { el.innerHTML = ''; return; }

  const withRsi = all.filter(p => p.rsi !== null);
  const gainers = [...all].sort((a,b)=>b.chg24h-a.chg24h).slice(0,5);
  const losers  = [...all].sort((a,b)=>a.chg24h-b.chg24h).slice(0,5);
  const fundingHot = [...all].sort((a,b)=>Math.abs(b.fundingRate)-Math.abs(a.fundingRate)).slice(0,5);
  const mostOB = withRsi.filter(p=>p.signal==='overbought').sort((a,b)=>b.rsi-a.rsi).slice(0,5);
  const mostOS = withRsi.filter(p=>p.signal==='oversold').sort((a,b)=>a.rsi-b.rsi).slice(0,5);
  const arbTop = (window._arbOpportunities || []).slice(0, 5);
  const highConfidence = withRsi.filter(p=>p.confluence).sort((a,b)=>a.confluence.distPct-b.confluence.distPct).slice(0,5);

  const col = (title, rows, empty) => `
    <div class="perp-lead-col">
      <div class="perp-lead-hdr">${title}</div>
      ${rows.length ? rows.join('') : `<div class="perp-lead-empty">${empty}</div>`}
    </div>`;

  el.innerHTML = `<div class="perp-lead-grid">
    ${col('▲ Top Gainers (24h)', gainers.map(p=>leaderRow(p, fmtPct(p.chg24h), 'up')), '—')}
    ${col('▼ Top Losers (24h)', losers.map(p=>leaderRow(p, fmtPct(p.chg24h), 'dn')), '—')}
    ${col('🔥 Extreme Funding', fundingHot.map(p=>leaderRow(p, (p.fundingRate>=0?'+':'')+p.fundingRate.toFixed(4)+'%', p.fundingRate>=0?'up':'dn')), '—')}
    ${col('▲ Most Overbought', mostOB.map(p=>leaderRow(p, p.rsi.toFixed(1))), 'None scanned yet')}
    ${col('▼ Most Oversold', mostOS.map(p=>leaderRow(p, p.rsi.toFixed(1))), 'None scanned yet')}
    ${col('🎯 High-Confidence (RSI + Level)', highConfidence.map(p=>leaderRow(p, p.confluence.type==='poc'?'@ POC':`@ ${p.confluence.type.slice(0,3)}`, p.signal==='oversold'?'up':'dn')), 'None scanned yet')}
    ${col('⚡ Arbitrage Spread', arbTop.map(a=>arbLeaderRow(a)), 'None found')}
  </div>`;
}
function arbLeaderRow(a) {
  return `<div class="perp-lead-row" title="${a.exA.ex} $${a.exA.price} vs ${a.exB.ex} $${a.exB.price} · funding spread ${a.fundingSpreadPp.toFixed(3)}pp">
    <span class="perp-src perp-src-arb">${a.exA.ex.slice(0,3)}/${a.exB.ex.slice(0,3)}</span>
    <span class="perp-sym">${esc(a.symbol)}</span>
    <span class="r up">${a.spreadPct.toFixed(2)}%</span>
  </div>`;
}

// ── SIGNAL TRACK RECORD ─────────────────────────────────────────────────────────
// Every time a 🎯 confluence signal fires, log its price and direction, then
// check back at fixed horizons (1h, 4h, 24h) to see whether price actually
// moved the predicted way. This is the honest version of "trust the signal":
// a visible win rate instead of a badge you're asked to take on faith.
const TRACK_HORIZONS_MS = { '1h': 3600e3, '4h': 4*3600e3, '24h': 24*3600e3 };
let _signalTrack = [];
(function(){ try { const s = localStorage.getItem('nexus_signal_track'); if (s) _signalTrack = JSON.parse(s); } catch(e){} })();
function saveSignalTrack() { try { localStorage.setItem('nexus_signal_track', JSON.stringify(_signalTrack.slice(-300))); } catch(e){} }

function logSignalForTracking(item) {
  if (!item.confluence) return;
  const key = `${item.symbol}:${item.source}`;
  // Don't log the same still-active signal repeatedly — one entry per
  // signal instance, not one per 5-minute poll it happens to still be true.
  const alreadyTracking = _signalTrack.some(t => t.key === key && !t.resolved && Date.now() - t.loggedAt < 6*3600e3);
  if (alreadyTracking) return;
  _signalTrack.push({
    key, symbol: item.symbol, source: item.source,
    direction: item.signal === 'oversold' ? 'up' : 'down', // predicted direction
    entryPrice: item.price,
    levelType: item.confluence.type,
    loggedAt: Date.now(),
    results: {}, // horizon -> { price, pctMove, correct }
    resolved: false,
  });
  saveSignalTrack();
}

// Called periodically — checks any tracked signal whose horizon has come due
// against the CURRENT price of that same item (from window._perpsAll), and
// records the outcome. Needs the symbol to still be in the loaded universe;
// if it's rolled off, that horizon just stays unresolved rather than guessing.
function updateSignalTrackOutcomes() {
  const now = Date.now();
  let changed = false;
  _signalTrack.forEach(t => {
    if (t.resolved) return;
    const live = (window._perpsAll || []).find(p => `${p.symbol}:${p.source}` === t.key);
    Object.entries(TRACK_HORIZONS_MS).forEach(([label, ms]) => {
      if (t.results[label] || now - t.loggedAt < ms) return;
      if (!live) return; // symbol not currently loaded — leave unresolved, don't fabricate a price
      const pctMove = ((live.price - t.entryPrice) / t.entryPrice) * 100;
      const correct = t.direction === 'up' ? pctMove > 0 : pctMove < 0;
      t.results[label] = { price: live.price, pctMove: Math.round(pctMove*100)/100, correct };
      changed = true;
    });
    if (t.results['24h']) t.resolved = true;
  });
  if (changed) { saveSignalTrack(); renderSignalTrackRecord(); }
}

function computeTrackRecordStats() {
  const withResults = _signalTrack.filter(t => Object.keys(t.results).length > 0);
  const byHorizon = {};
  Object.keys(TRACK_HORIZONS_MS).forEach(h => {
    const resolved = withResults.filter(t => t.results[h]);
    const wins = resolved.filter(t => t.results[h].correct).length;
    byHorizon[h] = { total: resolved.length, wins, winRatePct: resolved.length ? Math.round(wins/resolved.length*1000)/10 : null };
  });
  return { total: _signalTrack.length, byHorizon };
}

function renderSignalTrackRecord() {
  const el = document.getElementById('signalTrackRecord');
  if (!el) return;
  const stats = computeTrackRecordStats();
  const rows = Object.entries(stats.byHorizon).map(([h, s]) => `
    <div class="track-stat">
      <div class="track-stat-label">${h}</div>
      <div class="track-stat-val" style="color:${s.winRatePct===null?'var(--muted)':s.winRatePct>=50?'var(--green)':'var(--red)'};">${s.winRatePct===null?'—':s.winRatePct+'%'}</div>
      <div class="track-stat-n">${s.total} resolved</div>
    </div>`).join('');

  const recentRows = _signalTrack.slice(-15).reverse().map(t => {
    const r1=t.results['1h'], r4=t.results['4h'], r24=t.results['24h'];
    const fmt = r => r ? `<span style="color:${r.correct?'var(--green)':'var(--red)'};">${r.pctMove>=0?'+':''}${r.pctMove}%</span>` : '<span style="color:var(--muted);">pending</span>';
    return `<div class="track-row">
      <span class="perp-sym">${esc(t.symbol)}</span>
      <span style="font-family:var(--mono);font-size:10px;color:var(--muted);">${t.direction==='up'?'▲':'▼'} @ ${t.levelType}</span>
      <span class="r">${fmt(r1)}</span><span class="r">${fmt(r4)}</span><span class="r">${fmt(r24)}</span>
    </div>`;
  }).join('');

  el.innerHTML = `
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-bottom:10px;">
      ${stats.total} 🎯 signals logged this session. Not a backtest — this is forward-tracking of live signals only, starting from when this feature shipped. Small sample sizes will be noisy; read directionally, not as a guarantee.
    </div>
    <div style="display:flex;gap:16px;margin-bottom:14px;">${rows}</div>
    ${_signalTrack.length ? `<div class="track-head"><span>Symbol</span><span>Signal</span><span class="r">1h</span><span class="r">4h</span><span class="r">24h</span></div>${recentRows}` : `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">No 🎯 signals logged yet — they're logged automatically as they're detected during scans.</div>`}
  `;
}


async function refreshPerpSignals() {
  if (!window._perpsAll.length || _perpsLoading) return; // only runs after an initial manual load
  const top = buildScanList(window._perpsAll, PERPS_AUTO_SCAN_N);
  try { await scanRSIBatch(top, { concurrency: 5 }); } catch (e) { return; }
  checkPerpAlerts(window._perpsAll);
  updateSignalTrackOutcomes();
  renderPerpsTable();
  if (document.getElementById('tradeSignalsPanel')) renderTradeSignalsTab();
}
function startPerpAlertPolling() {
  setInterval(refreshPerpSignals, 5 * 60 * 1000); // re-scores top N every 5min so alerts fire even off-tab
  setInterval(checkForNewListings, 10 * 60 * 1000); // separate, cheaper cycle — just diffs universes, no RSI scan needed
}

async function checkForNewListings() {
  const [cexR, dexR, bybitR] = await Promise.allSettled([fetchCexPerps(), fetchDexPerps(), fetchBybitPerps()]);
  if (cexR.status !== 'fulfilled' && dexR.status !== 'fulfilled') return; // both down — nothing to diff against safely
  const newlyListed = detectNewListings(
    cexR.status === 'fulfilled' ? cexR.value : [],
    dexR.status === 'fulfilled' ? dexR.value : [],
    bybitR.status === 'fulfilled' ? bybitR.value : {},
  );
  if (!newlyListed.length) return;
  newlyListed.forEach(item => _pinnedPerps.add(item.symbol));
  savePinnedPerps();
  // Merge into window._perpsAll if not already present, then score immediately —
  // this is the actual fix: a new listing shouldn't wait for the next full
  // volume-ranked scan cycle to get a signal.
  newlyListed.forEach(item => {
    if (!window._perpsAll.some(p => p.symbol === item.symbol && p.source === item.source)) {
      window._perpsAll.push(item);
    }
  });
  try { await scanRSIBatch(newlyListed, { concurrency: 3 }); } catch (e) { /* leave unscored, next cycle retries */ }
  checkPerpAlerts(newlyListed);
  renderPerpsTable();
  if (document.getElementById('tradeSignalsPanel')) renderTradeSignalsTab();
}

// ── TRADE SIGNALS TAB — curated, actionable-right-now view ─────────────────────
// Not a new data source — this filters/re-presents what's already computed
// (composite score, confluence, funding, new listings) down to the subset
// that actually clears a real bar, with a visible timestamp so "right now"
// means something concrete. Shows the same factor breakdown as everywhere
// else — detected patterns with their reasoning, not a buy/sell directive.
function getActionableSignals() {
  const all = window._perpsAll || [];
  const strong = all
    .filter(p => p.composite && (p.composite.label === 'strong_bullish' || p.composite.label === 'strong_bearish'))
    .sort((a,b) => Math.abs(b.composite.score) - Math.abs(a.composite.score));
  return strong;
}
function tradeSignalFreshness(item) {
  if (!item.scannedAt) return 'never scanned';
  const s = Math.floor((Date.now() - item.scannedAt)/1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  return `${Math.floor(s/3600)}h ago`;
}
function renderTradeSignalsTab() {
  const el = document.getElementById('tradeSignalsPanel');
  if (!el) return;
  const strong = getActionableSignals();
  const extreme = (window._perpsAll || []).filter(isFundingExtreme).sort((a,b)=>Math.abs(b.fundingRate)-Math.abs(a.fundingRate)).slice(0,8);
  const arb = (window._arbOpportunities || []).slice(0, 8);

  const sigCards = strong.length ? strong.map(p => {
    const dir = p.composite.label === 'strong_bullish' ? { text:'LONG bias', color:'var(--green)', icon:'▲' } : { text:'SHORT bias', color:'var(--red)', icon:'▼' };
    return `<div class="ts-card" onclick="typeof openAssetChart==='function' && openAssetChart('${esc(p.symbol)}','${esc(p.symbol)} Perpetual','crypto')">
      <div class="ts-card-hdr">
        <span class="perp-src perp-src-${p.source.toLowerCase()}">${p.source}</span>
        <span class="perp-sym">${esc(p.symbol)}</span>
        <span style="color:${dir.color};font-family:var(--mono);font-weight:700;font-size:13px;">${dir.icon} ${dir.text}</span>
        <span style="margin-left:auto;font-family:var(--mono);font-size:10px;color:var(--muted);">${p.composite.agreeing}/${p.composite.totalFactors} factors · scanned ${tradeSignalFreshness(p)}</span>
      </div>
      ${p.volatility ? `<div style="font-family:var(--mono);font-size:10px;color:${p.volatility.regime==='expanding'?'var(--amber)':'var(--muted)'};margin-bottom:6px;">📊 ${esc(p.volatility.label)}</div>` : ''}
      <div class="ts-factors">
        ${p.composite.factors.map(f => `<span class="ts-factor" style="color:${f.direction>0?'var(--green)':f.direction<0?'var(--red)':'var(--muted)'};">${f.direction>0?'▲':f.direction<0?'▼':'·'} ${esc(f.name)}: ${esc(f.detail)}</span>`).join('')}
      </div>
      <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-top:6px;">Price $${fmtNum(p.price, p.price<1?6:2)} · funding ${p.fundingRate>=0?'+':''}${p.fundingRate.toFixed(4)}%</div>
    </div>`;
  }).join('') : `<div style="font-family:var(--mono);font-size:12px;color:var(--muted);padding:16px;text-align:center;">No signals currently clear the strong_bullish/strong_bearish bar (needs score ≥0.5 and 3+ agreeing factors). This is expected most of the time — real confluence across independent factors is supposed to be rare, not constant. Check back after the next scan, or lower your own bar by browsing the full Perps table instead.</div>`;

  el.innerHTML = `
    <div style="font-family:var(--mono);font-size:11px;color:var(--amber);background:rgba(245,166,35,.1);border:1px solid rgba(245,166,35,.3);border-radius:6px;padding:10px 14px;margin-bottom:16px;">
      ⚠ This is a filtered view of detected patterns and their reasoning — not a recommendation to enter a position. Every card shows exactly which factors fired and why; verify it makes sense to you before acting on it. Nothing here accounts for your risk tolerance, position sizing, or account size.
    </div>
    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;margin-bottom:10px;">⚡ Strong Composite Signals (${strong.length})</div>
    <div class="ts-grid">${sigCards}</div>

    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;margin:20px 0 10px;">🔥 Extreme Funding — Crowded Trades (${extreme.length})</div>
    ${extreme.length ? extreme.map(p => `<div class="perp-lead-row" style="padding:6px 0;" onclick="typeof openAssetChart==='function' && openAssetChart('${esc(p.symbol)}','${esc(p.symbol)} Perpetual','crypto')">
      <span class="perp-src perp-src-${p.source.toLowerCase()}">${p.source}</span>
      <span class="perp-sym">${esc(p.symbol)}</span>
      <span class="r ${p.fundingRate>=0?'up':'dn'}">${p.fundingRate>=0?'+':''}${p.fundingRate.toFixed(4)}%</span>
    </div>`).join('') : `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">None currently.</div>`}

    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;margin:20px 0 10px;">⚡ Arbitrage Spreads (${arb.length})</div>
    ${arb.length ? arb.map(a => arbLeaderRow(a)).join('') : `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">None currently.</div>`}

    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;margin:20px 0 10px;">🆕 New Launches</div>
    <div id="tsNewListings"></div>
  `;
  const tsTarget = document.getElementById('tsNewListings');
  if (tsTarget && _newListingsLog.length) {
    tsTarget.innerHTML = _newListingsLog.slice(0,10).map(l => `
      <div class="mn-hist-row" style="cursor:pointer;" onclick="typeof openAssetChart==='function' && openAssetChart('${esc(l.symbol)}','${esc(l.symbol)} Perpetual','crypto')">
        <span class="mn-hist-badge" style="color:#0096ff;border-color:#0096ff;">${esc(l.exchange)}</span>
        <span class="mn-hist-title">${esc(l.symbol)} — first seen at $${l.price ? fmtNum(l.price, l.price<1?6:2) : '?'}</span>
        <span class="mn-hist-time">${new Date(l.detectedAt).toLocaleString()}</span>
      </div>`).join('');
  } else if (tsTarget) {
    tsTarget.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">None detected yet.</div>`;
  }
}
