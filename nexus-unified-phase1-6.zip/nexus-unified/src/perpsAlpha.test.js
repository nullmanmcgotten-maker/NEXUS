'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { fetchMarketOverview, topLiquidSymbols } = require('./perpsAlpha');

function fakeTicker(symbol, { price = 100, changePct = 1, vol = 5_000_000 } = {}) {
  return {
    symbol, lastPrice: String(price), priceChangePercent: String(changePct),
    highPrice: String(price * 1.02), lowPrice: String(price * 0.98), quoteVolume: String(vol),
  };
}

test('perpsAlpha.fetchMarketOverview: keeps only USDT pairs, sorted by volume descending', async () => {
  const fakeFetch = async () => [
    fakeTicker('BTCUSDT', { vol: 900_000_000 }),
    fakeTicker('ETHBUSD', { vol: 500_000_000 }), // not USDT — excluded
    fakeTicker('SOLUSDT', { vol: 300_000_000 }),
    fakeTicker('ETHUSDT', { vol: 700_000_000 }),
  ];
  const overview = await fetchMarketOverview(250, fakeFetch);
  assert.deepEqual(overview.map((t) => t.symbol), ['BTC', 'ETH', 'SOL']);
  assert.ok(overview[0].volume24hrUsdt >= overview[1].volume24hrUsdt);
});

test('perpsAlpha.fetchMarketOverview: drops near-dead pairs below the liquidity floor', async () => {
  const fakeFetch = async () => [
    fakeTicker('BTCUSDT', { vol: 900_000_000 }),
    fakeTicker('DEADUSDT', { vol: 500 }), // effectively no volume
  ];
  const overview = await fetchMarketOverview(250, fakeFetch);
  assert.deepEqual(overview.map((t) => t.symbol), ['BTC']);
});

test('perpsAlpha.fetchMarketOverview: respects the limit parameter', async () => {
  const fakeFetch = async () => Array.from({ length: 10 }, (_, i) => fakeTicker(`COIN${i}USDT`, { vol: 10_000_000 - i * 100 }));
  const overview = await fetchMarketOverview(3, fakeFetch);
  assert.equal(overview.length, 3);
});

test('perpsAlpha.fetchMarketOverview: throws a clear error on an unexpected response shape', async () => {
  const fakeFetch = async () => ({ not: 'an array' });
  await assert.rejects(() => fetchMarketOverview(250, fakeFetch), /unexpected/i);
});

test('perpsAlpha.topLiquidSymbols: returns the top N bare tickers in order', () => {
  const overview = [{ symbol: 'BTC' }, { symbol: 'ETH' }, { symbol: 'SOL' }, { symbol: 'XRP' }];
  assert.deepEqual(topLiquidSymbols(overview, 2), ['BTC', 'ETH']);
});
