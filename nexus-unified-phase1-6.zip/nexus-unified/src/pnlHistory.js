/**
 * pnlHistory.js — Monthly P&L calendar grid + performance breakdown.
 * Uses localStorage portfolio snapshots from realtime.js.
 */
function renderPnlCalendar(){
  const el=document.getElementById('pnlCalendar');if(!el)return;
  const hist=getPortfolioCandles()||[];
  if(hist.length<2){el.innerHTML='<div style="font-family:var(--mono);font-size:13px;color:var(--muted);text-align:center;padding:24px;">Portfolio history accumulates over time (1 snapshot/minute). Come back after leaving the dashboard open for a while.</div>';return;}
  // Group by day
  const byDay={};
  hist.forEach((h,i)=>{
    if(i===0)return;
    const d=new Date(h.t),key=d.toISOString().split('T')[0];
    const prev=hist[i-1];
    if(!byDay[key])byDay[key]={open:prev.v,close:h.v,date:d};
    byDay[key].close=h.v;
  });
  const days=Object.entries(byDay).sort((a,b)=>a[0].localeCompare(b[0]));
  if(!days.length){el.innerHTML='<div style="font-family:var(--mono);font-size:13px;color:var(--muted);text-align:center;padding:24px;">Not enough data yet.</div>';return;}
  // Stats
  const rets=days.map(([,d])=>((d.close-d.open)/d.open*100));
  const wins=rets.filter(r=>r>0).length,losses=rets.filter(r=>r<0).length;
  const best=Math.max(...rets),worst=Math.min(...rets);
  const streak=calcStreak(rets);
  el.innerHTML=`
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px;">
      <div class="an-card"><div class="an-label">Win Days</div><div class="an-val up">${wins}</div></div>
      <div class="an-card"><div class="an-label">Loss Days</div><div class="an-val dn">${losses}</div></div>
      <div class="an-card"><div class="an-label">Best Day</div><div class="an-val up">+${best.toFixed(2)}%</div></div>
      <div class="an-card"><div class="an-label">Worst Day</div><div class="an-val dn">${worst.toFixed(2)}%</div></div>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:12px;">
      ${days.map(([date,d])=>{
        const ret=((d.close-d.open)/d.open*100);
        const isUp=ret>=0;
        const intensity=Math.min(Math.abs(ret)/3,1);
        const bg=isUp?`rgba(0,212,170,${0.15+intensity*0.7})`:`rgba(255,77,106,${0.15+intensity*0.7})`;
        return `<div style="width:32px;height:32px;border-radius:4px;background:${bg};display:flex;align-items:center;justify-content:center;cursor:default;font-family:var(--mono);font-size:8px;color:white;" title="${date}: ${isUp?'+':''}${ret.toFixed(2)}%">${new Date(date).getDate()}</div>`;
      }).join('')}
    </div>
    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">Current streak: <span style="color:${streak.n>0?'var(--green)':'var(--red)'};">${streak.n>0?'▲':'▼'} ${Math.abs(streak.n)} ${streak.n>0?'winning':'losing'} day${Math.abs(streak.n)!==1?'s':''}</span></div>`;
}
function calcStreak(rets){
  if(!rets.length)return{n:0};
  let n=rets[rets.length-1]>0?1:-1;
  for(let i=rets.length-2;i>=0;i--){
    if((rets[i]>0&&n>0)||(rets[i]<0&&n<0)){if(n>0)n++;else n--;}
    else break;
  }
  return{n};
}
