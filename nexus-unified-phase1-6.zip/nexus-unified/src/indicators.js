/**
 * indicators.js — Technical analysis engine (pure JS, zero dependencies)
 * EMA, SMA, RSI, MACD, Bollinger Bands, ATR, Signal Generator
 */

// Least-squares linear regression, returning the fitted value at the LAST
// point of `values` (i.e. where the regression line currently sits) — the
// standard way TTM Squeeze's momentum histogram is computed. Returns null
// if the window is too short or degenerate (zero variance in x, which
// can't happen here since x is just 0..n-1, but guarded anyway).
function linRegEndpoint(values) {
  const n = values.length;
  if (n < 2) return null;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < n; i++) {
    sumX += i; sumY += values[i]; sumXY += i * values[i]; sumXX += i * i;
  }
  const denom = n * sumXX - sumX * sumX;
  if (denom === 0) return null;
  const slope = (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  return slope * (n - 1) + intercept;
}

const TA = {
  ema(prices, period) {
    if (prices.length < period) return new Array(prices.length).fill(null);
    const k = 2/(period+1), result = new Array(prices.length).fill(null);
    let val = prices.slice(0,period).reduce((a,b)=>a+b,0)/period;
    result[period-1] = val;
    for (let i=period;i<prices.length;i++) { val=prices[i]*k+val*(1-k); result[i]=val; }
    return result;
  },
  sma(prices, period) {
    return prices.map((_,i) => {
      if (i<period-1) return null;
      return prices.slice(i-period+1,i+1).reduce((a,b)=>a+b,0)/period;
    });
  },
  rsi(prices, period=14) {
    const r=new Array(prices.length).fill(null);
    if (prices.length<period+1) return r;
    let g=0,l=0;
    for (let i=1;i<=period;i++) { const d=prices[i]-prices[i-1]; if(d>=0) g+=d; else l-=d; }
    let ag=g/period, al=l/period;
    r[period] = al===0?100:100-100/(1+ag/al);
    for (let i=period+1;i<prices.length;i++) {
      const d=prices[i]-prices[i-1];
      ag=(ag*(period-1)+Math.max(d,0))/period;
      al=(al*(period-1)+Math.max(-d,0))/period;
      r[i]=al===0?100:100-100/(1+ag/al);
    }
    return r;
  },
  // Stochastic RSI — applies the stochastic %K/%D formula to RSI values
  // themselves rather than price. More sensitive than plain RSI (faster to
  // hit 0/100), so it's read as a separate confirmation signal, not a
  // replacement — plain RSI for "is this extended", StochRSI for "is the
  // extension actually turning yet".
  stochRsi(prices, rsiPeriod=14, stochPeriod=14, smoothK=3, smoothD=3) {
    const rsiVals = this.rsi(prices, rsiPeriod);
    const n = prices.length;
    const rawK = new Array(n).fill(null);
    for (let i=0;i<n;i++) {
      if (rsiVals[i]===null) continue;
      const windowStart = Math.max(rsiPeriod, i-stochPeriod+1);
      const windowVals = [];
      for (let j=windowStart;j<=i;j++) if (rsiVals[j]!==null) windowVals.push(rsiVals[j]);
      if (windowVals.length < stochPeriod) continue;
      const lo = Math.min(...windowVals), hi = Math.max(...windowVals);
      rawK[i] = hi===lo ? 50 : ((rsiVals[i]-lo)/(hi-lo))*100;
    }
    const k = this.sma(rawK.map(v=>v===null?NaN:v), smoothK).map((v,i)=> (rawK[i]===null||isNaN(v))?null:v);
    const d = this.sma(k.map(v=>v===null?NaN:v), smoothD).map((v,i)=> (k[i]===null||isNaN(v))?null:v);
    return { k, d };
  },
  macd(prices, fast=12, slow=26, signal=9) {
    const ef=this.ema(prices,fast), es=this.ema(prices,slow);
    const ml=prices.map((_,i)=>ef[i]!==null&&es[i]!==null?ef[i]-es[i]:null);
    const valid=ml.filter(v=>v!==null);
    const rs=this.ema(valid,signal);
    let si=0;
    const sl=ml.map(v=>v!==null?(rs[si++]??null):null);
    const hist=ml.map((v,i)=>v!==null&&sl[i]!==null?v-sl[i]:null);
    return { macd:ml, signal:sl, histogram:hist };
  },
  bollinger(prices, period=20, std=2) {
    const mid=this.sma(prices,period), up=[], lo=[];
    prices.forEach((_,i)=>{
      if (i<period-1){up.push(null);lo.push(null);return;}
      const sl=prices.slice(i-period+1,i+1), m=mid[i];
      const sd=Math.sqrt(sl.reduce((s,v)=>s+(v-m)**2,0)/period);
      up.push(m+std*sd); lo.push(m-std*sd);
    });
    return {upper:up,middle:mid,lower:lo};
  },
  atr(candles, period=14) {
    const tr=candles.map((c,i)=>{
      if(i===0) return c.h-c.l;
      const p=candles[i-1].c;
      return Math.max(c.h-c.l,Math.abs(c.h-p),Math.abs(c.l-p));
    });
    return this.sma(tr,period);
  },
  // ── ADX / +DI / -DI (Wilder) — trend STRENGTH, direction-agnostic. Pairs
  // with the directional indicators above it: EMA cross tells you which way,
  // ADX tells you whether that "way" is a real trend worth trusting (>25) or
  // chop that will whipsaw any trend-following signal (<20).
  adx(candles, period=14) {
    const n = candles.length;
    const plusDM = new Array(n).fill(0), minusDM = new Array(n).fill(0), tr = new Array(n).fill(0);
    for (let i=1;i<n;i++) {
      const upMove = candles[i].h - candles[i-1].h, downMove = candles[i-1].l - candles[i].l;
      plusDM[i]  = (upMove>downMove && upMove>0)   ? upMove   : 0;
      minusDM[i] = (downMove>upMove && downMove>0) ? downMove : 0;
      const p = candles[i-1].c;
      tr[i] = Math.max(candles[i].h-candles[i].l, Math.abs(candles[i].h-p), Math.abs(candles[i].l-p));
    }
    // Wilder smoothing: seed with a straight sum over `period`, then
    // recursively decay-and-add (same recurrence RSI's ag/al use above).
    const wilderSmooth = (arr) => {
      const out = new Array(n).fill(null);
      if (n < period+1) return out;
      let sum = 0;
      for (let i=1;i<=period;i++) sum += arr[i];
      out[period] = sum;
      for (let i=period+1;i<n;i++) out[i] = out[i-1] - (out[i-1]/period) + arr[i];
      return out;
    };
    const smTR = wilderSmooth(tr), smPlusDM = wilderSmooth(plusDM), smMinusDM = wilderSmooth(minusDM);
    const plusDI = new Array(n).fill(null), minusDI = new Array(n).fill(null), dx = new Array(n).fill(null);
    for (let i=period;i<n;i++) {
      if (smTR[i]) {
        plusDI[i]  = 100 * smPlusDM[i]  / smTR[i];
        minusDI[i] = 100 * smMinusDM[i] / smTR[i];
        const sum = plusDI[i]+minusDI[i];
        dx[i] = sum ? 100 * Math.abs(plusDI[i]-minusDI[i]) / sum : 0;
      }
    }
    const adx = new Array(n).fill(null);
    const dxValid = dx.map((v,i)=>({v,i})).filter(x=>x.v!=null);
    if (dxValid.length >= period*2) {
      const startIdx = dxValid[period-1].i;
      let sum = 0; for (let k=0;k<period;k++) sum += dxValid[k].v;
      adx[startIdx] = sum/period;
      let prevIdx = startIdx;
      for (let k=period;k<dxValid.length;k++) {
        const { v, i } = dxValid[k];
        adx[i] = (adx[prevIdx]*(period-1) + v) / period;
        prevIdx = i;
      }
    }
    return { plusDI, minusDI, adx };
  },
  // ── CCI (Commodity Channel Index) — how far typical price has strayed from
  // its own recent mean, scaled by average deviation. ±100 = notable move,
  // ±200 = extreme; unlike RSI it isn't bounded, so it keeps signaling
  // strength through a sustained trend rather than pinning at 100.
  cci(candles, period=20) {
    const n = candles.length, tp = candles.map(c => (c.h+c.l+c.c)/3);
    const out = new Array(n).fill(null);
    for (let i=period-1;i<n;i++) {
      const win = tp.slice(i-period+1, i+1);
      const mean = win.reduce((a,b)=>a+b,0)/period;
      const meanDev = win.reduce((s,v)=>s+Math.abs(v-mean),0)/period;
      out[i] = meanDev ? (tp[i]-mean)/(0.015*meanDev) : 0;
    }
    return out;
  },
  // ── Williams %R — same inputs as Stochastic, inverted/rescaled to -100..0.
  // -80 or below = oversold, -20 or above = overbought. Reacts faster than
  // RSI to a fresh high/low, which is exactly the tradeoff: more sensitive,
  // more noise.
  williamsR(candles, period=14) {
    const n = candles.length, out = new Array(n).fill(null);
    for (let i=period-1;i<n;i++) {
      const win = candles.slice(i-period+1, i+1);
      const hh = Math.max(...win.map(c=>c.h)), ll = Math.min(...win.map(c=>c.l));
      out[i] = hh===ll ? -50 : ((hh-candles[i].c)/(hh-ll))*-100;
    }
    return out;
  },
  // ── OBV (On-Balance Volume) — running sum of volume signed by whether
  // price closed up or down that bar. The level itself is meaningless
  // (arbitrary starting point); what matters is its SLOPE relative to
  // price's slope — OBV rising while price chops sideways is accumulation
  // showing up before the breakout, OBV falling while price grinds up is
  // the classic bearish divergence warning.
  obv(candles) {
    const out = new Array(candles.length).fill(0);
    for (let i=1;i<candles.length;i++) {
      if (candles[i].c > candles[i-1].c)      out[i] = out[i-1] + (candles[i].v||0);
      else if (candles[i].c < candles[i-1].c) out[i] = out[i-1] - (candles[i].v||0);
      else                                     out[i] = out[i-1];
    }
    return out;
  },
  // ── MFI (Money Flow Index) — RSI's formula applied to volume-weighted
  // typical price instead of just price. Same 0-100 scale and 20/80
  // overbought/oversold reading as RSI, but a move RSI calls "oversold" on
  // thin volume and MFI calls "oversold" on heavy volume are different
  // situations — that's the whole point of running both.
  mfi(candles, period=14) {
    const n = candles.length, tp = candles.map(c => (c.h+c.l+c.c)/3);
    const rawFlow = tp.map((v,i) => v * (candles[i].v||0));
    const out = new Array(n).fill(null);
    for (let i=period;i<n;i++) {
      let pos = 0, neg = 0;
      for (let k=i-period+1;k<=i;k++) {
        if (tp[k] > tp[k-1]) pos += rawFlow[k];
        else if (tp[k] < tp[k-1]) neg += rawFlow[k];
      }
      out[i] = neg===0 ? 100 : 100 - 100/(1 + pos/neg);
    }
    return out;
  },
  // ── Parabolic SAR (Wilder) — trailing stop-and-reverse dots. Below price
  // in an uptrend (each dot a ratcheting trailing-stop level), above price
  // in a downtrend. The flip itself (dot jumps to the other side) is the
  // tradeable event, not the dot's position on any given bar.
  parabolicSar(candles, step=0.02, max=0.2) {
    const n = candles.length, sar = new Array(n).fill(null);
    if (n < 2) return sar;
    let bullish = candles[1].c >= candles[0].c;
    let ep = bullish ? candles[0].h : candles[0].l;
    let af = step;
    sar[0] = bullish ? candles[0].l : candles[0].h;
    for (let i=1;i<n;i++) {
      let prevSar = sar[i-1];
      let cur = prevSar + af*(ep-prevSar);
      if (bullish) {
        cur = Math.min(cur, candles[i-1].l, i>=2?candles[i-2].l:candles[i-1].l);
        if (candles[i].l < cur) { bullish=false; cur=ep; ep=candles[i].l; af=step; }
        else if (candles[i].h > ep) { ep=candles[i].h; af=Math.min(af+step,max); }
      } else {
        cur = Math.max(cur, candles[i-1].h, i>=2?candles[i-2].h:candles[i-1].h);
        if (candles[i].h > cur) { bullish=true; cur=ep; ep=candles[i].h; af=step; }
        else if (candles[i].l < ep) { ep=candles[i].l; af=Math.min(af+step,max); }
      }
      sar[i] = cur;
    }
    return sar;
  },
  // ── SuperTrend — ATR-band trend-follower; single flip-flopping line
  // instead of a channel, deliberately built to be a cleaner "long above /
  // short below" signal than raw Bollinger/Keltner bands.
  superTrend(candles, period=10, multiplier=3) {
    const atrVals = this.atr(candles, period);
    const n = candles.length;
    const upperBasic = candles.map((c,i)=> atrVals[i]!=null ? (c.h+c.l)/2 + multiplier*atrVals[i] : null);
    const lowerBasic = candles.map((c,i)=> atrVals[i]!=null ? (c.h+c.l)/2 - multiplier*atrVals[i] : null);
    const upperFinal = new Array(n).fill(null), lowerFinal = new Array(n).fill(null);
    const trend = new Array(n).fill(null); // 1 = up (line below price), -1 = down (line above price)
    for (let i=0;i<n;i++) {
      if (upperBasic[i]==null) continue;
      const prevUpper = upperFinal[i-1], prevLower = lowerFinal[i-1];
      upperFinal[i] = (prevUpper!=null && (upperBasic[i] < prevUpper || candles[i-1].c > prevUpper)) ? upperBasic[i] : (prevUpper ?? upperBasic[i]);
      lowerFinal[i] = (prevLower!=null && (lowerBasic[i] > prevLower || candles[i-1].c < prevLower)) ? lowerBasic[i] : (prevLower ?? lowerBasic[i]);
      if (trend[i-1] == null) trend[i] = candles[i].c <= upperFinal[i] ? -1 : 1;
      else if (trend[i-1]===1)  trend[i] = candles[i].c < lowerFinal[i] ? -1 : 1;
      else                       trend[i] = candles[i].c > upperFinal[i] ?  1 : -1;
    }
    const line = candles.map((_,i)=> trend[i]===1 ? lowerFinal[i] : upperFinal[i]);
    return { line, trend, upperFinal, lowerFinal };
  },
  // ── Keltner Channels — same "band around price" shape as Bollinger, but
  // width comes from ATR (volatility of true range) instead of stdev of
  // closes, so it reacts differently around gaps/wicks. Bollinger squeezing
  // inside Keltner is the standard "volatility contraction, breakout likely
  // soon" read (TTM Squeeze) — having both makes that check possible.
  keltner(candles, period=20, multiplier=2) {
    const closes = candles.map(c=>c.c);
    const mid = this.ema(closes, period);
    const atrVals = this.atr(candles, period);
    const upper = mid.map((m,i)=> (m!=null && atrVals[i]!=null) ? m + multiplier*atrVals[i] : null);
    const lower = mid.map((m,i)=> (m!=null && atrVals[i]!=null) ? m - multiplier*atrVals[i] : null);
    return { upper, middle: mid, lower };
  },
  // ── TTM Squeeze — the check the keltner() comment above flags as
  // "possible" but never implements: Bollinger Bands contracting to inside
  // the Keltner Channel means volatility has compressed to the point the
  // two different band types (stdev-based vs ATR-based) agree there's
  // almost no room left — historically the setup right before an expansion
  // move, in either direction. `on` alone isn't a trade signal (it doesn't
  // know which way), so this also reports which way the squeeze is likely
  // to release via a momentum value: a linear-regression estimate of how
  // far price sits above/below the midpoint of its own recent Donchian
  // range and SMA, the standard TTM Squeeze momentum histogram. Rising
  // histogram = building bullish pressure while still squeezed; falling =
  // bearish. `fired` is true only on the bar the squeeze just turned off
  // (the actual entry trigger most squeeze strategies wait for, not "still
  // squeezed" which can persist for many bars doing nothing).
  squeeze(candles, { bbPeriod = 20, bbMult = 2, kcPeriod = 20, kcMult = 1.5, momLength = 20 } = {}) {
    const closes = candles.map(c => c.c);
    const bb = this.bollinger(closes, bbPeriod, bbMult);
    const kc = this.keltner(candles, kcPeriod, kcMult);
    const donch = this.donchian(candles, momLength);
    const smaVals = this.sma(closes, momLength);
    const n = candles.length;

    const on = new Array(n).fill(null);
    const momentum = new Array(n).fill(null);
    for (let i = 0; i < n; i++) {
      if (bb.upper[i] == null || kc.upper[i] == null) continue;
      on[i] = bb.upper[i] < kc.upper[i] && bb.lower[i] > kc.lower[i];
    }
    for (let i = momLength - 1; i < n; i++) {
      if (donch.middle[i] == null || smaVals[i] == null) continue;
      const avgMid = (donch.middle[i] + smaVals[i]) / 2;
      const value = closes[i] - avgMid;
      // Linear-regression endpoint over the trailing window of `value`,
      // computed against the trailing `value` series itself (standard
      // definition) rather than raw closes, so it reflects deviation from
      // the range midpoint, not just price direction.
      const win = [];
      for (let j = i - momLength + 1; j <= i; j++) {
        if (donch.middle[j] == null || smaVals[j] == null) { win.push(null); continue; }
        win.push(closes[j] - (donch.middle[j] + smaVals[j]) / 2);
      }
      if (win.some(v => v == null)) continue;
      momentum[i] = linRegEndpoint(win) ?? value;
    }

    const fired = new Array(n).fill(false);
    for (let i = 1; i < n; i++) {
      if (on[i - 1] === true && on[i] === false) fired[i] = true;
    }

    return { on, momentum, fired };
  },
  // ── Donchian Channels — the simplest possible breakout definition: n-bar
  // highest-high / lowest-low. A close beyond either band is a mechanical
  // breakout signal (this is literally the original Turtle Trading system's
  // entry rule) with no smoothing to lag it.
  donchian(candles, period=20) {
    const n = candles.length, upper = new Array(n).fill(null), lower = new Array(n).fill(null), middle = new Array(n).fill(null);
    for (let i=period-1;i<n;i++) {
      const win = candles.slice(i-period+1,i+1);
      upper[i] = Math.max(...win.map(c=>c.h));
      lower[i] = Math.min(...win.map(c=>c.l));
      middle[i] = (upper[i]+lower[i])/2;
    }
    return { upper, middle, lower };
  },
  // ── Aroon — how many bars since the period's highest high / lowest low,
  // rescaled to 0-100. Both lines near 100 together = fresh highs AND lows
  // recently = choppy; one pinned near 100 while the other decays toward 0
  // = a clean trend. Purpose-built to catch "is this actually trending"
  // from a different angle than ADX (time-since-extreme vs. smoothed
  // directional movement).
  aroon(candles, period=25) {
    const n = candles.length, up = new Array(n).fill(null), down = new Array(n).fill(null);
    for (let i=period;i<n;i++) {
      const win = candles.slice(i-period, i+1);
      let hiIdx=0, loIdx=0, hiV=-Infinity, loV=Infinity;
      win.forEach((c,k)=>{ if(c.h>=hiV){hiV=c.h;hiIdx=k;} if(c.l<=loV){loV=c.l;loIdx=k;} });
      up[i]   = ((period - (period-hiIdx)) / period) * 100;
      down[i] = ((period - (period-loIdx)) / period) * 100;
    }
    return { up, down };
  },
  // ── CMF (Chaikin Money Flow) — volume-weighted read of where each bar
  // closed within its own high/low range, summed over the window. Positive
  // = closes skewing toward the top of their range on real volume
  // (accumulation), negative = the opposite — a volume-confirmation check
  // for whatever the price action alone appears to be doing.
  cmf(candles, period=20) {
    const n = candles.length, out = new Array(n).fill(null);
    for (let i=period-1;i<n;i++) {
      let mfvSum = 0, volSum = 0;
      for (let k=i-period+1;k<=i;k++) {
        const c = candles[k], range = c.h-c.l;
        const mfm = range ? ((c.c-c.l)-(c.h-c.c))/range : 0;
        mfvSum += mfm * (c.v||0);
        volSum += (c.v||0);
      }
      out[i] = volSum ? mfvSum/volSum : 0;
    }
    return out;
  },
  // ── ROC (Rate of Change) — plain %-change over n bars. The simplest
  // possible momentum readout, useful mainly as a fast-reacting confirmation
  // alongside slower oscillators like RSI/MACD.
  roc(prices, period=12) {
    return prices.map((p,i)=> i>=period ? ((p-prices[i-period])/prices[i-period])*100 : null);
  },
  generateSignals(closes, candles) {
    const signals=[];
    const rsi=this.rsi(closes,14), macdR=this.macd(closes);
    const bb=this.bollinger(closes,20);
    const e9=this.ema(closes,9), e21=this.ema(closes,21);
    const n=closes.length-1;
    if (n<26) return [{type:'info',text:'Need 26+ candles for full analysis'}];
    const rv=rsi[n], mv=macdR.macd[n], sv=macdR.signal[n];
    const hn=macdR.histogram[n], hp=macdR.histogram[n-1];
    const pr=closes[n], bu=bb.upper[n], bl=bb.lower[n];
    const e9n=e9[n], e21n=e21[n], e9p=e9[n-1], e21p=e21[n-1];

    if (rv<30)      signals.push({type:'buy', text:`RSI ${rv.toFixed(1)} — Oversold`});
    else if (rv>70) signals.push({type:'sell',text:`RSI ${rv.toFixed(1)} — Overbought`});
    else            signals.push({type:'neut',text:`RSI ${rv.toFixed(1)} — Neutral`});

    if (mv!==null&&sv!==null) {
      if (hn>0&&hp<=0)       signals.push({type:'buy', text:'MACD bullish crossover'});
      else if (hn<0&&hp>=0)  signals.push({type:'sell',text:'MACD bearish crossover'});
      else signals.push({type:'neut',text:`MACD ${hn>=0?'+':''}${hn?.toFixed(4)}`});
    }
    if (bu&&bl) {
      if (pr>bu)       signals.push({type:'sell',text:'Above upper Bollinger Band'});
      else if (pr<bl)  signals.push({type:'buy', text:'Below lower Bollinger Band'});
      else { const pct=((pr-bl)/(bu-bl)*100).toFixed(0); signals.push({type:'neut',text:`BB position: ${pct}%`}); }
    }
    if (e9n&&e21n&&e9p&&e21p) {
      if (e9n>e21n&&e9p<=e21p)      signals.push({type:'buy', text:'EMA 9 × EMA 21 — Golden cross'});
      else if (e9n<e21n&&e9p>=e21p) signals.push({type:'sell',text:'EMA 9 × EMA 21 — Death cross'});
      else signals.push({type:e9n>e21n?'buy':'sell',text:`EMA trend: ${e9n>e21n?'bullish':'bearish'}`});
    }
    // Momentum check
    const mom5 = ((closes[n]-closes[Math.max(0,n-5)])/closes[Math.max(0,n-5)]*100).toFixed(2);
    signals.push({type:+mom5>=0?'buy':'sell',text:`5-bar momentum: ${mom5}%`});

    // ── Extended indicators (need h/l/v, hence the `candles` param) ────────
    if (candles && candles.length >= 30) {
      const adxR = this.adx(candles);
      const adxV = adxR.adx[n], pdi = adxR.plusDI[n], mdi = adxR.minusDI[n];
      if (adxV!=null && pdi!=null && mdi!=null) {
        const strength = adxV>=40?'very strong':adxV>=25?'strong':adxV>=20?'developing':'weak/no trend';
        // ADX itself doesn't have a direction — it's read alongside which DI
        // is on top, not as its own buy/sell line.
        signals.push({type: adxV>=25 ? (pdi>mdi?'buy':'sell') : 'neut', text:`ADX ${adxV.toFixed(1)} (${strength}) — ${pdi>mdi?'+DI':'-DI'} leading`});
      }
      const cciV = this.cci(candles)[n];
      if (cciV!=null) {
        if (cciV>100)      signals.push({type:'sell',text:`CCI ${cciV.toFixed(0)} — Overbought`});
        else if (cciV<-100) signals.push({type:'buy', text:`CCI ${cciV.toFixed(0)} — Oversold`});
        else                signals.push({type:'neut',text:`CCI ${cciV.toFixed(0)} — Neutral`});
      }
      const wrV = this.williamsR(candles)[n];
      if (wrV!=null) {
        if (wrV<=-80)      signals.push({type:'buy', text:`Williams %R ${wrV.toFixed(0)} — Oversold`});
        else if (wrV>=-20) signals.push({type:'sell',text:`Williams %R ${wrV.toFixed(0)} — Overbought`});
      }
      const mfiV = this.mfi(candles)[n];
      if (mfiV!=null) {
        if (mfiV<20)      signals.push({type:'buy', text:`MFI ${mfiV.toFixed(1)} — Oversold (volume-weighted)`});
        else if (mfiV>80) signals.push({type:'sell',text:`MFI ${mfiV.toFixed(1)} — Overbought (volume-weighted)`});
      }
      const stR = this.superTrend(candles);
      if (stR.trend[n]!=null && stR.trend[n-1]!=null) {
        if (stR.trend[n]===1 && stR.trend[n-1]===-1)       signals.push({type:'buy', text:'SuperTrend flipped bullish'});
        else if (stR.trend[n]===-1 && stR.trend[n-1]===1)  signals.push({type:'sell',text:'SuperTrend flipped bearish'});
        else signals.push({type: stR.trend[n]===1?'buy':'sell', text:`SuperTrend: ${stR.trend[n]===1?'bullish':'bearish'} (line ${stR.line[n]?.toFixed(4)})`});
      }
      // OBV/price divergence over the last 15 bars: price makes a higher
      // high while OBV doesn't (or vice versa) is a genuine volume/price
      // disagreement, distinct from anything RSI/MACD already flag.
      const obvArr = this.obv(candles);
      const lookback = Math.min(15, n);
      if (lookback >= 5) {
        const priceSlope = closes[n] - closes[n-lookback];
        const obvSlope = obvArr[n] - obvArr[n-lookback];
        if (priceSlope>0 && obvSlope<0)      signals.push({type:'sell',text:'OBV/price divergence — price up, volume flow down'});
        else if (priceSlope<0 && obvSlope>0) signals.push({type:'buy', text:'OBV/price divergence — price down, volume flow up'});
      }
      // TTM Squeeze — see squeeze()'s header comment. `on` itself is a
      // 'neut' info line (it's a volatility state, not a direction); the
      // momentum histogram's sign is what's directional, and only reported
      // as buy/sell when the squeeze has just fired (released) this bar —
      // that's the actual entry trigger, not "still coiled".
      if (candles.length >= 25) {
        const sq = this.squeeze(candles);
        if (sq.on[n] === true) {
          signals.push({type:'neut', text:`Squeeze ON — volatility compressed, watching for breakout${sq.momentum[n]!=null ? ` (momentum ${sq.momentum[n]>=0?'+':''}${sq.momentum[n].toFixed(4)})` : ''}`});
        } else if (sq.fired[n]) {
          const dir = sq.momentum[n] != null && sq.momentum[n] < 0 ? 'sell' : 'buy';
          signals.push({type: dir, text:`Squeeze FIRED ${dir==='buy'?'bullish':'bearish'} — volatility just expanded out of compression`});
        }
      }
    }

    const buys=signals.filter(s=>s.type==='buy').length;
    const sells=signals.filter(s=>s.type==='sell').length;
    const bias=buys>sells?'BULLISH':sells>buys?'BEARISH':'NEUTRAL';
    const bc=buys>sells?'green':sells>buys?'red':'amber';
    signals.unshift({type:bc,text:`Bias: ${bias}  (${buys} bullish · ${sells} bearish signals)`,bold:true});
    return signals;
  },
};

// Dual export: stays a plain global `TA` for the browser <script> tag (no
// change to existing behavior there), but also usable via require('./indicators')
// from Node — needed by signalEngine/taSignalSource.js, which runs server-side.
if (typeof module !== 'undefined' && module.exports) module.exports = TA;
