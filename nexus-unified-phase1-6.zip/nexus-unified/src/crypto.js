/**
 * crypto.js — Binance WebSocket for real-time crypto.
 * Also polls Binance REST for initial prices on load.
 */
const BMAP = {
  'BTCUSDT':'BTC','ETHUSDT':'ETH','SOLUSDT':'SOL','DOGEUSDT':'DOGE',
  'XRPUSDT':'XRP','BNBUSDT':'BNB','ADAUSDT':'ADA','AVAXUSDT':'AVAX',
  'DOTUSDT':'DOT','MATICUSDT':'MATIC','LTCUSDT':'LTC','LINKUSDT':'LINK',
};
const SYM_STREAM = Object.fromEntries(
  Object.entries(BMAP).map(([k,v]) => [v, k.toLowerCase()+'@miniTicker'])
);

let _ws=null, _wsOK=false, _wsTimer=null;

// Fetch initial snapshot via Binance REST on startup
async function fetchInitialCryptoPrices() {
  const cryptoPos = [...positions, ...watchlist].filter(p => p.type==='crypto');
  if (!cryptoPos.length) return;
  const syms = [...new Set(cryptoPos.map(p => p.sym+'USDT'))];
  try {
    const tickers = await fetch(
      `https://api.binance.com/api/v3/ticker/24hr?symbols=${encodeURIComponent(JSON.stringify(syms))}`
    ).then(r => r.json());

    tickers.forEach(t => {
      const sym = BMAP[t.symbol];
      if (!sym) return;
      const price = safeNum(t.lastPrice), chg = safeNum(t.priceChangePercent);
      [...positions,...watchlist].filter(x=>x.sym===sym&&x.type==='crypto').forEach(x=>{
        x.price = price; x.chg = parseFloat(chg.toFixed(2));
        if (!window._priceHistory[sym]) window._priceHistory[sym]=[];
        window._priceHistory[sym].push({t:Date.now(),p:price});
      });
    });
    console.log(`[Crypto] Initial prices: ${tickers.length} symbols`);
    updateAll();
  } catch(e) {
    console.warn('[Crypto] Initial fetch failed:', e.message);
  }
}

function getStreams() {
  const s = new Set();
  [...positions,...watchlist].filter(p=>p.type==='crypto').forEach(p=>{
    const st = SYM_STREAM[p.sym]; if(st) s.add(st);
  });
  return [...s];
}

function connectBinanceWS() {
  const streams = getStreams();
  if (!streams.length) { updateCryptoStatus('○ No crypto','var(--muted)'); return; }
  if (_ws) { _ws.onclose=null; _ws.close(); }

  _ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams.join('/')}`);

  _ws.onopen = () => {
    _wsOK = true;
    updateCryptoStatus('● WS LIVE','var(--green)');
    console.log('[Binance WS] Connected —', streams.length, 'streams');
  };

  _ws.onmessage = ({data}) => {
    try {
      const d = (JSON.parse(data).data || JSON.parse(data));
      if (!d?.s) return;
      const sym=BMAP[d.s]; if(!sym) return;
      const price=safeNum(d.c), chg=safeNum(d.P);
      if (!price) return;
      [...positions,...watchlist].filter(x=>x.sym===sym&&x.type==='crypto').forEach(x=>{
        if(!window._priceHistory[sym]) window._priceHistory[sym]=[];
        window._priceHistory[sym].push({t:Date.now(),p:price});
        if(window._priceHistory[sym].length>500) window._priceHistory[sym].shift();
        x.price=price; x.chg=parseFloat(chg.toFixed(2));
      });
      updateAll();
    } catch(e){}
  };

  _ws.onerror = () => { _wsOK=false; updateCryptoStatus('⚠ WS Error','var(--red)'); };
  _ws.onclose = () => {
    _wsOK=false; updateCryptoStatus('○ Reconnecting…','var(--amber)');
    clearTimeout(_wsTimer); _wsTimer=setTimeout(connectBinanceWS,5000);
  };
}

function updateCryptoStatus(text,color) {
  const el=document.getElementById('cryptoStatus'); if(el){el.textContent=text;el.style.color=color;}
}

function startCryptoWS() {
  fetchInitialCryptoPrices().then(() => connectBinanceWS());
}
function refreshCryptoWS() { if(_wsOK) connectBinanceWS(); }

// Used by the tab-visibility-recovery hook in main.js: force a reconnect
// only when the socket is actually down. Distinct from refreshCryptoWS()
// above (which re-subscribes an already-healthy connection to a changed
// symbol list, and deliberately no-ops when disconnected since the pending
// onclose reconnect timer will pick up the new list anyway) — here we want
// the opposite: skip if already fine, act immediately if not, rather than
// waiting on a timer that browsers throttle heavily in backgrounded tabs.
function ensureCryptoWSConnected() { if (!_wsOK) connectBinanceWS(); }
