/**
 * cockpit.js — Trade Cockpit: analyze a symbol, size a position against your
 * own account risk, and send it to your portfolio — all in one place instead
 * of hopping between Charts, Position Sizer, and Overview.
 *
 * Deliberately reuses existing building blocks rather than inventing new
 * scoring or data paths:
 *   - price data: the same fetchBinanceKlines / fetchYahooOHLC / fetchForexOHLC
 *     wrappers assetChart.js already uses for the Charts & TA tab
 *   - signals: TA.generateSignals(closes, candles) — the exact function that
 *     powers the per-symbol chart panel's signal list
 *   - sizing math: plain fixed-fractional risk sizing (risk% × portfolio ÷
 *     per-unit stop distance) — the same idea as the existing Position Sizer
 *     in Expert Tools, just wired directly to a specific symbol/entry/stop
 *   - portfolio write: the existing addPosition() in portfolio.js, extended
 *     with an optional override param so this doesn't duplicate that logic
 */
let _cockpitCandles = null, _cockpitAsset = null;

function setCockpitStatus(msg, isWarn) {
  const el = document.getElementById('cockpitStatus');
  if (el) { el.textContent = msg; el.style.color = isWarn ? 'var(--amber)' : 'var(--muted)'; }
}

async function analyzeCockpitSymbol() {
  const type = document.getElementById('cockpitType')?.value;
  const raw = document.getElementById('cockpitSymbol')?.value.trim();
  if (!raw) { setCockpitStatus('Enter a symbol first.', true); return; }
  const sym = raw.toUpperCase();

  document.getElementById('cockpitResults').style.display = 'none';
  setCockpitStatus(`Fetching live data for ${sym}…`, false);

  let candles = null;
  try {
    if (type === 'crypto')      candles = await fetchBinanceKlines(sym.replace('/', ''), '1h', 150);
    else if (type === 'stock')  candles = await fetchYahooOHLC(sym, '1h');
    else if (type === 'forex')  candles = await fetchForexOHLC(sym.replace('/', ''), 30);
  } catch (e) { candles = null; }

  if (!candles || candles.length < 20) {
    setCockpitStatus(
      `⚠ Could not load enough data for ${sym}. Check the symbol${type === 'forex' ? ' (e.g. EURUSD)' : ''} and try again — ` +
      `this reads from the same live feeds as the rest of the app, so a rate-limited/unreachable source is the likely cause, not a bad symbol.`,
      true
    );
    return;
  }

  _cockpitCandles = candles;
  _cockpitAsset = { sym, type };
  renderCockpitAnalysis(sym, type, candles);
}

function renderCockpitAnalysis(sym, type, candles) {
  const closes = candles.map(c => safeNum(c.c));
  const last = closes[closes.length - 1];
  const first = closes[0];
  const chgPct = ((last - first) / first) * 100;
  const atrArr = TA.atr(candles, 14).filter(Boolean);
  const atr = atrArr.length ? atrArr[atrArr.length - 1] : 0;
  const signals = TA.generateSignals(closes, candles);

  // Tally the SAME signal list shown below into a rough bias label — not a
  // separate scoring system, just a summary of what's already displayed.
  let score = 0;
  signals.forEach(s => { const w = s.bold ? 2 : 1; if (s.type === 'buy') score += w; else if (s.type === 'sell') score -= w; });
  const bias = score >= 3 ? { label: 'STRONG BUY', cls: 'badge-green' }
             : score >= 1 ? { label: 'BUY', cls: 'badge-green' }
             : score <= -3 ? { label: 'STRONG SELL', cls: 'badge-red' }
             : score <= -1 ? { label: 'SELL', cls: 'badge-red' }
             : { label: 'NEUTRAL', cls: '' };

  const biasBadge = document.getElementById('cockpitBiasBadge');
  if (biasBadge) { biasBadge.textContent = bias.label; biasBadge.className = 'badge ' + (bias.cls || ''); }

  const priceStr = last >= 1 ? '$' + fmtNum(last, 2) : '$' + last.toFixed(5);
  const metaEl = document.getElementById('cockpitPriceMeta');
  if (metaEl) metaEl.innerHTML = `
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
      <span style="font-family:var(--mono);font-size:22px;font-weight:700;color:${chgPct >= 0 ? 'var(--green)' : 'var(--red)'};">
        ${priceStr} ${chgPct >= 0 ? '▲' : '▼'}${Math.abs(chgPct).toFixed(2)}%
      </span>
      <span style="font-family:var(--mono);font-size:11px;color:var(--muted);">ATR ${atr >= 1 ? '$' + atr.toFixed(2) : '$' + atr.toFixed(5)} · ${candles.length} bars</span>
    </div>`;

  const C = { buy: 'var(--green)', sell: 'var(--red)', neut: 'var(--muted)', green: 'var(--green)', red: 'var(--red)', amber: 'var(--amber)', info: 'var(--muted)' };
  const listEl = document.getElementById('cockpitSignalList');
  if (listEl) listEl.innerHTML = signals.length
    ? signals.map(s => `
        <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border);color:${C[s.type] || 'var(--muted)'};${s.bold ? 'font-weight:700;' : ''}font-size:12px;font-family:var(--mono);">
          <span style="width:14px;">${s.type === 'buy' ? '▲' : s.type === 'sell' ? '▼' : '●'}</span><span>${esc(s.text)}</span>
        </div>`).join('')
    : `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">No clear signals right now — that's expected most of the time, not an error.</div>`;

  // Pre-fill the trade ticket with sane starting defaults. Entry = last price;
  // suggested stop = 1.5x ATR against the prevailing bias. Both stay fully
  // editable — this is a starting point, never a forced value.
  const suggestLong = score >= 0;
  const suggestedStop = atr > 0 ? (suggestLong ? last - atr * 1.5 : last + atr * 1.5) : null;
  const entryEl = document.getElementById('cockpitEntry');
  const stopEl = document.getElementById('cockpitStop');
  if (entryEl) entryEl.value = last;
  if (stopEl) stopEl.value = suggestedStop !== null ? Number(suggestedStop.toFixed(last >= 1 ? 2 : 6)) : '';
  const hintEl = document.getElementById('cockpitStopHint');
  if (hintEl) hintEl.textContent = suggestedStop !== null
    ? `Suggested stop: 1.5× ATR ${suggestLong ? 'below' : 'above'} entry, based on the bias above — edit freely.`
    : 'Not enough data for an ATR-based stop suggestion — set one manually.';

  calcCockpitSize();
  document.getElementById('cockpitResults').style.display = 'block';
  setCockpitStatus(`Live data as of ${new Date().toLocaleTimeString()}.`, false);
}

function calcCockpitSize() {
  const entry = safeNum(document.getElementById('cockpitEntry')?.value);
  const stop = safeNum(document.getElementById('cockpitStop')?.value);
  const riskPct = safeNum(document.getElementById('cockpitRiskPct')?.value);
  const el = document.getElementById('cockpitSizeResult');
  if (!el) return;

  if (!entry || !stop || entry === stop || riskPct <= 0) {
    el.innerHTML = '<div class="expert-result"><div style="font-family:var(--mono);font-size:11px;color:var(--muted);">Enter entry, stop and risk % to size the position.</div></div>';
    return;
  }

  const portfolioValue = (typeof totalPortfolioValue === 'function' ? totalPortfolioValue() : 0) || 0;
  const riskAmount = portfolioValue * (riskPct / 100);
  const perUnitRisk = Math.abs(entry - stop);
  const qty = perUnitRisk > 0 ? riskAmount / perUnitRisk : 0;
  const notional = qty * entry;

  const qtyEl = document.getElementById('cockpitQty');
  if (qtyEl) qtyEl.value = qty ? Number(qty.toFixed(qty < 1 ? 6 : 2)) : '';

  el.innerHTML = `
    <div class="expert-result">
      <div class="expert-result-row"><span>Risking</span><span style="font-weight:700;">${fmtMoney(riskAmount)} (${riskPct}% of ${fmtMoney(portfolioValue)})</span></div>
      <div class="expert-result-row"><span>Per-unit risk</span><span>${perUnitRisk >= 1 ? '$' + perUnitRisk.toFixed(2) : '$' + perUnitRisk.toFixed(5)}</span></div>
      <div class="expert-result-row"><span>Suggested size</span><span style="color:var(--accent);font-weight:700;">${qty ? fmtNum(qty, qty < 1 ? 6 : 2) : '—'} units (${fmtMoney(notional)} notional)</span></div>
    </div>`;
}

function sendCockpitToPortfolio() {
  if (!_cockpitAsset) { alert('Analyze a symbol first.'); return; }
  const { type, sym } = _cockpitAsset;
  const qty = safeNum(document.getElementById('cockpitQty')?.value);
  const price = safeNum(document.getElementById('cockpitEntry')?.value);
  if (!qty || qty <= 0 || !price || price <= 0) { alert('Set a valid quantity and entry price first.'); return; }
  addPosition({ type, sym, qty, price });
  setCockpitStatus(`Added ${fmtNum(qty, qty < 1 ? 6 : 2)} ${sym} @ ${price >= 1 ? '$' + price.toFixed(2) : '$' + price.toFixed(5)} to your portfolio.`, false);
}

function openCockpitFullChart() {
  if (!_cockpitAsset || typeof openAssetChart !== 'function') return;
  openAssetChart(_cockpitAsset.sym, _cockpitAsset.sym, _cockpitAsset.type);
}
