'use strict';

/**
 * sizing.js — turns store.getStats() (real resolved win/loss history) into
 * a suggested position size for a proposal, instead of always suggesting
 * the same size regardless of whether a coin/strategy is actually working.
 *
 * This does NOT replace TonyBot's own portfolio-heat / daily-loss-cap
 * gating in bridge.py — that check runs independently, after approval,
 * against your live account state, and stays the final word. This only
 * makes Nexus's own *suggestion* smarter, using the same Kelly Criterion
 * formula as the manual calculator in expert.js (calcKelly()), applied to
 * this coin (or, once available, this whole strategy's) actual resolved
 * trades — but only once there's enough of a sample to trust the inputs.
 *
 * Built directly from the trade-history finding that a 45% win rate was
 * still roughly breakeven: win rate alone doesn't tell you the right size,
 * expectancy (win rate AND win/loss ratio together) does. Below
 * `minTradesForKelly` resolved trades, this deliberately falls back to a
 * flat conservative size rather than computing a Kelly fraction off a
 * handful of trades and presenting noise as an edge.
 */

const DEFAULTS = {
  method: 'kelly',        // 'kelly' | 'fixed' — 'fixed' always uses fixedSizePct
  fixedSizePct: 2,         // % of portfolio when falling back / method='fixed'
  minTradesForKelly: 20,   // don't trust win-rate/ratio below this sample size
  kellyFraction: 0.5,      // half-Kelly — same default the UI calculator recommends
  maxSizePct: 5,           // hard ceiling regardless of what Kelly says
  minSizePct: 0.5,         // floor so a barely-positive edge doesn't round to ~0
};

/**
 * @param {{n:number, winRate:number|null, avgWinPct:number|null, avgLossPct:number|null}|null} stats
 *   Output of store.getStats(), already narrowed to whatever slice the
 *   caller considers relevant (e.g. this coin + source).
 * @param {object} [opts] - overrides for DEFAULTS
 * @returns {{sizePct:number, method:'kelly'|'fixed', rationale:string, skip:boolean}}
 *   skip=true means the computed edge is negative with a big-enough sample
 *   to trust it — the caller should not propose this trade at all, rather
 *   than proposing it at a token size.
 */
function computeSize(stats, opts) {
  const cfg = Object.assign({}, DEFAULTS, opts || {});

  const insufficientSample = !stats || stats.n < cfg.minTradesForKelly;
  if (cfg.method === 'fixed' || insufficientSample) {
    return {
      sizePct: cfg.fixedSizePct,
      method: 'fixed',
      rationale: insufficientSample
        ? `fixed ${cfg.fixedSizePct}% — only ${stats ? stats.n : 0}/${cfg.minTradesForKelly} resolved trades so far, not enough to trust a Kelly estimate`
        : `fixed ${cfg.fixedSizePct}% (sizing.method=fixed)`,
      skip: false,
    };
  }

  const { winRate, avgWinPct, avgLossPct } = stats;
  // avgLossPct comes out of store.getStats' pctMove as a negative number —
  // the ratio needs its magnitude.
  const lossMag = Math.abs(avgLossPct);
  if (!winRate || !avgWinPct || !lossMag) {
    return {
      sizePct: cfg.fixedSizePct,
      method: 'fixed',
      rationale: 'fixed fallback — resolved trades exist but win or loss magnitude is zero/missing, can\u2019t form a ratio',
      skip: false,
    };
  }

  const b = avgWinPct / lossMag; // win/loss ratio ("payoff ratio")
  const fullKelly = winRate - (1 - winRate) / b; // fraction of bankroll; can be negative

  if (fullKelly <= 0) {
    return {
      sizePct: 0,
      method: 'kelly',
      rationale: `Kelly edge is negative on ${stats.n} resolved trades (win rate ${(winRate * 100).toFixed(0)}%, win/loss ratio ${b.toFixed(2)}) \u2014 skip rather than size it small`,
      skip: true,
    };
  }

  const raw = fullKelly * cfg.kellyFraction * 100;
  const sizePct = Math.max(cfg.minSizePct, Math.min(cfg.maxSizePct, raw));
  return {
    sizePct,
    method: 'kelly',
    rationale: `half-Kelly on ${stats.n} resolved trades: win rate ${(winRate * 100).toFixed(0)}%, win/loss ratio ${b.toFixed(2)} \u2192 ${raw.toFixed(1)}%, capped to ${sizePct.toFixed(1)}%`,
    skip: false,
  };
}

module.exports = { computeSize, DEFAULTS };
