'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { open: openStore } = require('./store');
const { TaSignalSource, DEFAULTS } = require('./taSignalSource');
const sizing = require('./sizing');

function tmpDb() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'tasig-')), 'test.db');
}

function mkSig(coin, createdAt, overrides = {}) {
  return Object.assign({
    channelId: 'nexus-ta', channelName: 'Nexus TA Engine', messageId: createdAt,
    coin, pair: `${coin}/USDT`, direction: 'SHORT', entryMin: 1, entryMax: 1,
    takeProfits: [0.9], stopLoss: 1.1, leverage: 5, timeframe: '1h',
    confidence: 0.5, breakdown: [], rawText: 'test', createdAt, source: 'nexus_ta',
  }, overrides);
}

test('store: lastForCoin returns the most recent signal for that coin only', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  store.saveSignal(mkSig('BTC', now - 1000));
  const id2 = store.saveSignal(mkSig('BTC', now));
  store.saveSignal(mkSig('ETH', now));
  const last = store.lastForCoin('BTC');
  assert.equal(last.id, id2);
  store.close();
});

test('store: recentRejectionStreak counts consecutive rejected/failed from most recent, stops at first non-match', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const id1 = store.saveSignal(mkSig('LSK', now - 3000));
  store.setStatus(id1, 'executed', 'ok'); // oldest: a win/execution, breaks the streak going forward in time
  const id2 = store.saveSignal(mkSig('LSK', now - 2000));
  store.setStatus(id2, 'rejected', 'no');
  const id3 = store.saveSignal(mkSig('LSK', now - 1000));
  store.setStatus(id3, 'failed', 'risk gate');
  // Most recent two are rejected/failed; the one before that was executed -> streak should be 2, not 3.
  assert.equal(store.recentRejectionStreak('LSK', now - 24 * 3600 * 1000, 5), 2);
  store.close();
});

test('TaSignalSource: cooldown blocks a coin signaled moments ago', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  store.saveSignal(mkSig('SOL', now - 60 * 1000)); // 1 min ago
  const ta = new TaSignalSource(store, null, () => {}, { enabled: true, symbols: ['SOL'], cooldownMs: 45 * 60 * 1000 });
  const reason = ta._isCoolingDown('SOL');
  assert.match(reason, /cooldown/);
  store.close();
});

test('TaSignalSource: no cooldown once enough time has passed', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  store.saveSignal(mkSig('SOL', now - 3 * 60 * 60 * 1000)); // 3h ago
  const ta = new TaSignalSource(store, null, () => {}, { enabled: true, symbols: ['SOL'], cooldownMs: 45 * 60 * 1000 });
  assert.equal(ta._isCoolingDown('SOL'), null);
  store.close();
});

test('TaSignalSource: loss-streak breaker pauses a coin after threshold consecutive rejections/failures', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  for (let i = 0; i < 3; i++) {
    const id = store.saveSignal(mkSig('LSK', now - (3 - i) * 60 * 60 * 1000));
    store.setStatus(id, i % 2 === 0 ? 'rejected' : 'failed', 'test');
  }
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['LSK'], cooldownMs: 0, streakThreshold: 3,
    streakLookbackMs: 24 * 3600 * 1000, streakCooldownMs: 24 * 3600 * 1000,
  });
  const reason = ta._isCoolingDown('LSK');
  assert.match(reason, /paused/);
  store.close();
});

function resolveTrade(store, coin, { direction = 'LONG', entry = 100, outcome, outcomePrice, createdAt }) {
  const id = store.saveSignal(mkSig(coin, createdAt, { direction, entryMin: entry, entryMax: entry }));
  store.setStatus(id, 'executed', 'test');
  store.resolveOutcome(id, outcome, outcomePrice);
  return id;
}

test('TaSignalSource: sizing config merges partial overrides one level deep instead of dropping defaults', () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['BTC'], sizing: { minTradesForKelly: 5 },
  });
  assert.equal(ta.cfg.sizing.minTradesForKelly, 5); // overridden
  assert.equal(ta.cfg.sizing.method, sizing.DEFAULTS.method); // default preserved
  assert.equal(ta.cfg.sizing.maxSizePct, sizing.DEFAULTS.maxSizePct); // default preserved
  store.close();
});

test('TaSignalSource: _relevantStats uses per-coin stats once that coin has enough resolved trades', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['SOL'], sizing: { minTradesForKelly: 3 },
  });
  for (let i = 0; i < 3; i++) {
    resolveTrade(store, 'SOL', { direction: 'LONG', entry: 100, outcome: 'win', outcomePrice: 104, createdAt: now - i * 1000 });
  }
  const stats = ta._relevantStats('SOL');
  assert.equal(stats.n, 3);
  store.close();
});

test('TaSignalSource: _relevantStats falls back to source-wide stats when the coin sample is too small', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['ETH'], sizing: { minTradesForKelly: 5 },
  });
  // Only 1 resolved ETH trade — not enough on its own.
  resolveTrade(store, 'ETH', { direction: 'LONG', entry: 100, outcome: 'win', outcomePrice: 103, createdAt: now });
  // But plenty of resolved trades for the strategy overall, on other coins.
  for (let i = 0; i < 5; i++) {
    resolveTrade(store, 'BTC', { direction: 'LONG', entry: 100, outcome: 'win', outcomePrice: 102, createdAt: now - i * 1000 });
  }
  const stats = ta._relevantStats('ETH');
  assert.equal(stats.n, 6); // fell back to the source-wide (ETH + BTC) slice
  store.close();
});

test('TaSignalSource: _isOverVolumeLimit blocks a coin once its per-coin daily cap is reached', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['SOL'], limits: { maxProposalsPerCoinPerDay: 2, maxProposalsPerDayTotal: 100 },
  });
  store.saveSignal(mkSig('SOL', now - 1000));
  store.saveSignal(mkSig('SOL', now - 500));
  const reason = ta._isOverVolumeLimit('SOL');
  assert.ok(reason);
  assert.match(reason, /2\/2/);
  store.close();
});

test('TaSignalSource: _isOverVolumeLimit blocks ANY coin once the total daily cap is reached', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['SOL', 'ETH'], limits: { maxProposalsPerCoinPerDay: 100, maxProposalsPerDayTotal: 2 },
  });
  store.saveSignal(mkSig('SOL', now - 1000));
  store.saveSignal(mkSig('ETH', now - 500));
  const reason = ta._isOverVolumeLimit('BTC'); // a THIRD, different coin — total cap still applies
  assert.ok(reason);
  assert.match(reason, /2\/2 total/);
  store.close();
});

test('TaSignalSource: _isOverVolumeLimit allows scanning when under both caps', () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['SOL'], limits: { maxProposalsPerCoinPerDay: 3, maxProposalsPerDayTotal: 10 },
  });
  assert.equal(ta._isOverVolumeLimit('SOL'), null);
  store.close();
});

test('TaSignalSource: limits config merges partial overrides one level deep instead of dropping defaults', () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['SOL'], limits: { maxProposalsPerCoinPerDay: 1 },
  });
  assert.equal(ta.cfg.limits.maxProposalsPerCoinPerDay, 1); // overridden
  assert.equal(ta.cfg.limits.maxProposalsPerDayTotal, DEFAULTS.limits.maxProposalsPerDayTotal); // default preserved
  store.close();
});

test('TaSignalSource: activeSymbols() combines static symbols with auto-discovered ones, deduped', () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, { enabled: true, symbols: ['btc', 'ETH'] });
  ta._discoveredSymbols = ['ETH', 'SOL']; // simulate a prior discovery refresh
  const active = ta.activeSymbols();
  assert.deepEqual(new Set(active), new Set(['BTC', 'ETH', 'SOL'])); // uppercased + deduped
  store.close();
});

test('TaSignalSource: _refreshDiscoveredSymbols is a no-op when autoDiscover is disabled (default)', async () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, { enabled: true, symbols: ['BTC'] });
  let called = false;
  await ta._refreshDiscoveredSymbols(async () => { called = true; return []; });
  assert.equal(called, false);
  assert.deepEqual(ta._discoveredSymbols, []);
  store.close();
});

test('TaSignalSource: _refreshDiscoveredSymbols pulls the top-N liquid list when enabled', async () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: [], autoDiscover: { enabled: true, topN: 3 },
  });
  const fakeOverview = async () => [{ symbol: 'BTC' }, { symbol: 'ETH' }, { symbol: 'SOL' }, { symbol: 'XRP' }];
  await ta._refreshDiscoveredSymbols(fakeOverview);
  assert.deepEqual(ta._discoveredSymbols, ['BTC', 'ETH', 'SOL']);
  store.close();
});

test('TaSignalSource: _refreshDiscoveredSymbols keeps the previous list if the refresh call fails', async () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: [], autoDiscover: { enabled: true, topN: 3, refreshMs: 0 },
  });
  ta._discoveredSymbols = ['BTC', 'ETH'];
  ta._lastDiscoveryAt = 0; // force it to be due for refresh
  await ta._refreshDiscoveredSymbols(async () => { throw new Error('network down'); });
  assert.deepEqual(ta._discoveredSymbols, ['BTC', 'ETH']); // unchanged, not wiped to []
  store.close();
});

test('TaSignalSource: _refreshDiscoveredSymbols does not re-fetch before refreshMs has elapsed', async () => {
  const store = openStore(tmpDb());
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: [], autoDiscover: { enabled: true, topN: 3, refreshMs: 60 * 60 * 1000 },
  });
  let calls = 0;
  const fakeOverview = async () => { calls++; return [{ symbol: 'BTC' }]; };
  await ta._refreshDiscoveredSymbols(fakeOverview);
  await ta._refreshDiscoveredSymbols(fakeOverview);
  assert.equal(calls, 1); // second call was within refreshMs, skipped
  store.close();
});

test('TaSignalSource: a coin with a healthy history (below streak threshold) is not paused', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  const idA = store.saveSignal(mkSig('ETH', now - 5 * 3600 * 1000));
  store.setStatus(idA, 'rejected', 'test');
  const idB = store.saveSignal(mkSig('ETH', now - 4 * 3600 * 1000));
  store.setStatus(idB, 'executed', 'test'); // breaks the streak
  const ta = new TaSignalSource(store, null, () => {}, {
    enabled: true, symbols: ['ETH'], cooldownMs: 0, streakThreshold: 3,
  });
  assert.equal(ta._isCoolingDown('ETH'), null);
  store.close();
});
