'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { evaluateCandles } = require('./taSignalSource');
const { runBacktest, compareVariants } = require('./taBacktest');

const HOUR = 3600 * 1000;

/**
 * A synthetic uptrend with a small sine-wave wobble layered on top of a
 * steady climb. A perfectly straight compounding climb pegs RSI/CCI/
 * Williams%R/MFI all at "overbought" simultaneously, which cancels out
 * the bullish EMA/momentum/ADX/SuperTrend reads and nets to zero signal
 * agreement — the wobble avoids that degenerate case while keeping a
 * clear, real uptrend (confirmed net-bullish signal set below).
 */
function genUptrend(n, { startPrice = 100, stepPct = 0.006, startT = 0, waveAmp = 0.01, wavePeriod = 7 } = {}) {
  const candles = [];
  let base = startPrice;
  let prevClose = startPrice;
  for (let i = 0; i < n; i++) {
    base = base * (1 + stepPct);
    const wobble = 1 + waveAmp * Math.sin((i / wavePeriod) * 2 * Math.PI);
    const close = base * wobble;
    const open = prevClose;
    const high = Math.max(open, close) * 1.002;
    const low = Math.min(open, close) * 0.998;
    candles.push({ t: startT + i * HOUR, o: open, h: high, l: low, c: close, v: 1000 + Math.abs(Math.sin(i)) * 200 });
    prevClose = close;
  }
  return candles;
}

const LENIENT_CFG = { minNetConfluence: 1, minAdx: 0, atrStopMult: 1.5, atrTpMult: 3.0, cooldownMs: 0 };

test('taBacktest: a clear uptrend produces at least one LONG candidate via evaluateCandles', () => {
  const candles = genUptrend(60);
  const candidate = evaluateCandles(candles.slice(0, 45), LENIENT_CFG);
  assert.ok(candidate, 'expected a candidate signal on a clear uptrend with lenient thresholds');
  assert.equal(candidate.direction, 'LONG');
  assert.ok(candidate.takeProfit > candidate.price);
  assert.ok(candidate.stopLoss < candidate.price);
});

test('taBacktest: runBacktest resolves a trade as a win when price later touches takeProfit', () => {
  const base = genUptrend(45);
  const candidate = evaluateCandles(base, LENIENT_CFG);
  assert.ok(candidate);

  // Append a candle that clearly touches takeProfit without also touching
  // stopLoss, so the outcome is unambiguous.
  const winBar = {
    t: base[base.length - 1].t + HOUR,
    o: candidate.price, h: candidate.takeProfit * 1.001, l: candidate.price * 0.999,
    c: candidate.takeProfit, v: 1000,
  };
  const full = base.concat([winBar]);

  const { trades, stats } = runBacktest(full, LENIENT_CFG, 30);
  assert.ok(trades.length >= 1, 'expected at least one trade to be recorded');
  const t = trades.find((tr) => tr.outcome === 'win');
  assert.ok(t, 'expected at least one winning trade');
  assert.ok(t.pctMove > 0);
  assert.equal(stats.n, trades.filter((tr) => tr.outcome !== 'open').length);
});

test('taBacktest: a trade with no future candles to resolve it is left "open", not counted as win/loss', () => {
  const candles = genUptrend(45);
  const { trades, stats } = runBacktest(candles, LENIENT_CFG, 30);
  // The most recent possible signal (if any fired at the very last usable
  // bar) has no future bars to resolve against.
  const lastTrade = trades[trades.length - 1];
  if (lastTrade && lastTrade.barIndex === candles.length - 1) {
    assert.equal(lastTrade.outcome, 'open');
  }
  assert.equal(stats.n + stats.openCount, trades.length);
});

test('taBacktest: cooldown prevents two recorded trades closer together than cooldownMs', () => {
  const candles = genUptrend(80);
  const cfg = Object.assign({}, LENIENT_CFG, { cooldownMs: 10 * HOUR });
  const { trades } = runBacktest(candles, cfg, 30);
  for (let i = 1; i < trades.length; i++) {
    const gap = trades[i].t - trades[i - 1].t;
    assert.ok(gap >= cfg.cooldownMs, `expected >= ${cfg.cooldownMs}ms between trades, got ${gap}ms`);
  }
});

test('taBacktest: a bar touching both stopLoss and takeProfit resolves as a loss (conservative tie-break)', () => {
  const base = genUptrend(45);
  const candidate = evaluateCandles(base, LENIENT_CFG);
  assert.ok(candidate);

  const ambiguousBar = {
    t: base[base.length - 1].t + HOUR,
    o: candidate.price,
    h: candidate.takeProfit * 1.001, // touches TP
    l: candidate.stopLoss * 0.999,   // AND touches SL in the same bar
    c: candidate.price, v: 1000,
  };
  const full = base.concat([ambiguousBar]);
  const { trades } = runBacktest(full, LENIENT_CFG, 30);
  const resolvedAtAmbiguousBar = trades.find((t) => t.barIndex === base.length - 1);
  assert.ok(resolvedAtAmbiguousBar);
  assert.equal(resolvedAtAmbiguousBar.outcome, 'loss');
});

test('taBacktest: compareVariants runs multiple cfgs over the same candles and labels results', () => {
  const candles = genUptrend(60);
  const variants = [
    { label: 'lenient', cfg: LENIENT_CFG },
    { label: 'strict', cfg: Object.assign({}, LENIENT_CFG, { minNetConfluence: 8, minAdx: 60 }) },
  ];
  const results = compareVariants(candles, variants, 30);
  assert.equal(results.length, 2);
  assert.equal(results[0].label, 'lenient');
  assert.equal(results[1].label, 'strict');
  // A much stricter threshold should never produce more trades than the lenient one.
  assert.ok(results[1].tradeCount <= results[0].tradeCount);
});

test('taBacktest: no candidates ever fire under an impossible threshold', () => {
  const candles = genUptrend(60);
  const impossible = Object.assign({}, LENIENT_CFG, { minNetConfluence: 999 });
  const { trades, stats } = runBacktest(candles, impossible, 30);
  assert.equal(trades.length, 0);
  assert.equal(stats.n, 0);
  assert.equal(stats.winRate, null);
});
