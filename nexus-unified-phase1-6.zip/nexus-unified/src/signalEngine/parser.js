/**
 * parser.js — ported from signalbot/internal/parser/parser.go
 *
 * Turns a raw Telegram message into a scored, structured signal. Zero
 * Telegram dependencies — testable with plain strings (see parser.test.js).
 */
'use strict';

const { normalize } = require('./normalize');
const {
  extractPair, extractDirection, extractEntry,
  extractTakeProfits, extractStopLoss, extractLeverage, extractTimeframe,
} = require('./extract');
const { score } = require('./classify');

/**
 * @param {{channelId:string|number, channelName:string, messageId:number, text:string, postedAt:number}} raw
 * @param {import('./classify').Classifier} classifier
 * @returns {{signal:object|null, reason:string, cand:object}}
 */
function parseMessage(raw, classifier) {
  const norm = normalize(raw.text);

  if (classifier.isExcluded(norm.cleaned)) {
    return { signal: null, reason: 'excluded', cand: null };
  }

  const { coin, pair, ok: hasCoin } = extractPair(norm.cleaned);
  const { min: entryMin, max: entryMax, ok: hasEntry } = extractEntry(norm.cleaned);
  const takeProfits = extractTakeProfits(norm.cleaned);
  const { value: stopLoss, ok: hasSL } = extractStopLoss(norm.cleaned);
  const direction = extractDirection(norm.cleaned);
  const leverage = extractLeverage(norm.cleaned);
  const timeframe = extractTimeframe(norm.cleaned);

  const cand = {
    coin, pair, direction,
    entryMin, entryMax, takeProfits,
    stopLoss, stopLossOk: hasSL,
    leverage, timeframe,
  };
  const { confidence, breakdown } = score(cand, hasCoin, hasEntry, takeProfits.length > 0, hasSL);
  cand.confidence = confidence;
  cand.breakdown = breakdown;

  if (!classifier.passes(confidence)) {
    return { signal: null, reason: 'low_confidence', cand };
  }

  const signal = {
    coin, pair, direction,
    entryMin, entryMax, takeProfits,
    stopLoss,
    leverage, timeframe,
    confidence, breakdown,
    rawText: norm.cleaned,
    language: norm.language,
    channelId: raw.channelId,
    channelName: raw.channelName,
    messageId: raw.messageId,
    postedAt: raw.postedAt,
    createdAt: Date.now(),
  };
  return { signal, reason: '', cand };
}

module.exports = { parseMessage };
