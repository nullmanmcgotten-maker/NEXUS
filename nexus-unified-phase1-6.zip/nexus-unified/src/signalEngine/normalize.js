/**
 * normalize.js — ported from signalbot/internal/parser/normalize.go
 *
 * Cleans raw message text before any pattern matching happens. Keeps the
 * original casing in `cleaned` (extractors do their own case-insensitive
 * matching) — normalization should never throw away information extraction
 * needs.
 */
'use strict';

// Emoji / pictographic ranges that actually show up in Telegram trading-signal
// spam. Not a full Unicode emoji database — a pragmatic range filter, same
// scope as the Go original.
function isEmojiCodepoint(cp) {
  if (cp >= 0x1f300 && cp <= 0x1faff) return true; // misc symbols, emoticons, transport, supplemental
  if (cp >= 0x2600 && cp <= 0x27bf) return true;   // misc symbols & dingbats (☀ ✅ ❌ etc.)
  if (cp >= 0x2190 && cp <= 0x21ff) return true;   // arrows (➡ style separators)
  if (cp === 0xfe0f || cp === 0x200d) return true; // variation selector, zero-width joiner
  if (cp >= 0x1f1e6 && cp <= 0x1f1ff) return true; // regional indicators (flag emoji)
  return false;
}

function stripEmoji(s) {
  let out = '';
  for (const ch of s) { // for..of iterates by codepoint, not UTF-16 unit — matters for surrogate pairs
    const cp = ch.codePointAt(0);
    if (isEmojiCodepoint(cp)) continue;
    out += ch;
  }
  return out;
}

function collapseWhitespace(s) {
  return s.split(/\s+/).filter(Boolean).join(' ');
}

// Deliberately simple: flags messages that are mostly non-Latin script so
// they can be routed differently (e.g. skipped, logged for review) instead
// of silently mis-parsed by Latin-only regex extractors.
const LATIN_RE = /\p{Script=Latin}/u;
const LETTER_RE = /\p{L}/u;
function detectLanguageHeuristic(s) {
  let latin = 0, other = 0;
  for (const ch of s) {
    if (LATIN_RE.test(ch)) latin++;
    else if (LETTER_RE.test(ch)) other++;
  }
  return other > latin ? 'other' : 'en';
}

/** @returns {{cleaned: string, language: 'en'|'other'}} */
function normalize(text) {
  const stripped = stripEmoji(text || '');
  const collapsed = collapseWhitespace(stripped);
  return {
    cleaned: collapsed.trim(),
    language: detectLanguageHeuristic(collapsed),
  };
}

module.exports = { normalize, stripEmoji, collapseWhitespace, detectLanguageHeuristic };
