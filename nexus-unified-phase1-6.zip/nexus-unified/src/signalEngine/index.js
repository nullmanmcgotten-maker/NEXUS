/**
 * index.js — bootstraps the signal engine as an in-process module of the
 * unified Nexus server (see ../../server.js). This replaces signalbot's
 * standalone `cmd/signalbot/main.go` — same pipeline, one process instead
 * of two.
 *
 * If `signalEngine.enabled` is false or missing in config.json, `start()`
 * does nothing and getRecentSignals()/getHealth() report that plainly —
 * the rest of Nexus works exactly as before with no signal engine running.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const configMod = require('./config');
const { Classifier } = require('./classify');
const { parseMessage } = require('./parser');
const { open: openStore } = require('./store');
const { TelegramBotNotifier } = require('./notifier');
const { ApprovalBot } = require('./approvalBot');
const { Pipeline } = require('./pipeline');
const { TaSignalSource } = require('./taSignalSource');
const { OutcomeResolver } = require('./outcomeResolver');

function makeLogger(prefix) {
  return (level, msg, meta) => {
    const line = `[${prefix}] ${level.toUpperCase()} ${msg}`;
    if (level === 'error') console.error(line, meta || '');
    else if (level === 'debug') { /* quiet by default */ }
    else console.log(line, meta || '');
  };
}

class SignalEngine {
  constructor() {
    this.enabled = false;
    this.store = null;
    this.pipeline = null;
    this.listener = null;
    this.pruneTimer = null;
    this.startedAt = null;
    this.lastError = null;
  }

  /** @param {string} configPath */
  async start(configPath) {
    const log = makeLogger('signalEngine');
    let cfg;
    try {
      cfg = configMod.load(configPath);
    } catch (e) {
      this.lastError = e.message;
      log('error', 'config load failed, signal engine staying off', { err: e.message });
      return;
    }

    if (!cfg.signalEngine.enabled) {
      log('info', 'signalEngine.enabled is false in config.json — skipping (rest of Nexus runs normally)');
      return;
    }

    this.store = openStore(cfg.storage.sqlitePath);
    const classifier = new Classifier(cfg.filters.excludePatterns, cfg.filters.minConfidence);

    let notifier = null;
    let approvalBot = null;
    if (cfg.notification.botToken && cfg.notification.chatId) {
      notifier = new TelegramBotNotifier(cfg.notification.botToken, cfg.notification.chatId);
      // Same bot token/chat as the plain notifier, but with Approve/Reject
      // buttons — this is the gate TonyBot's execution bridge waits on, so
      // it's on whenever credentials are configured (set
      // signalEngine.autoExecute=false in config.json — the default — to
      // keep it required; see config.js).
      if (cfg.signalEngine.approvalRequired !== false) {
        approvalBot = new ApprovalBot(cfg.notification.botToken, cfg.notification.chatId, this.store, log);
        approvalBot.start();
      }
    } else {
      log('info', 'no notification.botToken/chatId configured — signals will be saved and shown in-app, but no push alert or approval prompt will be sent');
    }
    this.approvalBot = approvalBot;

    this.pipeline = new Pipeline(parseMessage, classifier, this.store, notifier, log, approvalBot);

    // Nexus's own TA-generated proposals — independent of whether channel
    // watching (below) is configured at all. Shares the same store and the
    // same approvalBot, so a Nexus-detected setup gets the identical
    // Telegram Approve/Reject tap and bridge.py execution path as a
    // Telegram-parsed one.
    this.taSource = new TaSignalSource(this.store, approvalBot, log, cfg.signalEngine.taSource);
    this.taSource.start();

    // Tracks whether executed trades (any source) actually win or lose —
    // see outcomeResolver.js. Runs regardless of taSource/channel config,
    // as long as the engine itself is enabled, since it can also resolve
    // Telegram-sourced trades the bridge executed.
    this.outcomeResolver = new OutcomeResolver(this.store, log, cfg.signalEngine.outcomeResolver, undefined, notifier);
    this.outcomeResolver.start();

    // Prune the dedup table on a daily interval, matching the Go version's
    // retain_processed_days behavior. Signal audit rows are never pruned.
    const retainMs = cfg.storage.retainProcessedDays * 24 * 60 * 60 * 1000;
    this.pruneTimer = setInterval(() => {
      try {
        const n = this.store.pruneProcessed(retainMs);
        if (n) log('info', 'pruned processed-message rows', { count: n });
      } catch (e) {
        log('error', 'prune failed', { err: e.message });
      }
    }, 24 * 60 * 60 * 1000);
    this.pruneTimer.unref?.();

    if (!cfg.channels.length) {
      // No channels configured — skip the MTProto channel listener entirely.
      // taSource (started above) can still run on its own; the engine is
      // "enabled" in the sense that at least one signal source is live.
      this.enabled = this.taSource.cfg.enabled;
      this.startedAt = Date.now();
      log('info', 'no channels configured — Telegram channel watching skipped', { taSourceEnabled: this.taSource.cfg.enabled });
      return;
    }

    const sessionPath = path.resolve(cfg.telegram.sessionFile);
    let sessionString = '';
    try { sessionString = fs.readFileSync(sessionPath, 'utf8').trim(); } catch (e) { /* first run, no session yet */ }

    try {
      const { startListener } = require('./ingest'); // lazy: only needed when actually enabled
      this.listener = await startListener({
        apiId: cfg.telegram.apiId,
        apiHash: cfg.telegram.apiHash,
        sessionString,
        channels: cfg.channels,
        onSession: (s) => { try { fs.writeFileSync(sessionPath, s); } catch (e) { log('error', 'save session failed', { err: e.message }); } },
        pipeline: this.pipeline,
        log,
      });
      this.enabled = true;
      this.startedAt = Date.now();
      log('info', 'signal engine running', { channels: cfg.channels.length });
    } catch (e) {
      this.lastError = e.message;
      log('error', 'failed to start telegram listener — signal engine staying off', { err: e.message });
    }
  }

  async stop() {
    if (this.pruneTimer) clearInterval(this.pruneTimer);
    if (this.taSource) this.taSource.stop();
    if (this.outcomeResolver) this.outcomeResolver.stop();
    if (this.approvalBot) this.approvalBot.stop();
    if (this.listener) await this.listener.stop();
    if (this.store) this.store.close();
  }

  /** Real performance stats — see store.getStats(). Exposed for a future
   *  dashboard tab or CLI report; e.g. getPerformance({source:'nexus_ta'})
   *  vs getPerformance({source:'telegram'}) to compare the two signal
   *  sources head to head on the metric that actually matters. */
  getPerformance(opts) {
    if (!this.store) return null;
    return this.store.getStats(opts || {});
  }

  getRecentSignals(limit) {
    if (!this.store) return [];
    return this.store.recentSignals(limit);
  }

  getHealth() {
    return {
      status: 'ok',
      signalEngineEnabled: this.enabled,
      startedAt: this.startedAt,
      lastError: this.lastError,
    };
  }
}

module.exports = { SignalEngine };
