'use strict';

/**
 * taBacktest.js — replays taSignalSource's exact decision logic
 * (evaluateCandles(), plus a real cooldown) against historical candles,
 * so you can see what it *would* have proposed for a coin before turning
 * it loose live, and compare thresholds (minNetConfluence, minAdx)
 * against each other on the same data.
 *
 * This is deliberately separate from the general-purpose backtester.js —
 * that one backtests hand-picked strategies (EMA cross, RSI reversal,
 * etc.) against a symbol. This one backtests THIS specific signal
 * source's actual live decision function, so there's no risk of the
 * backtest and the live scanner quietly disagreeing about what counts as
 * a signal.
 *
 * Resolution logic: once a candidate fires at bar i, walk forward through
 * subsequent candles checking high/low against takeProfit/stopLoss —
 * whichever is touched first resolves the trade as win/loss (same
 * first-touch approach outcomeResolver.js uses live against real prices).
 * If neither is touched before the data runs out, the trade is left
 * 'open' and excluded from win-rate stats (it's not a loss, it's unknown
 * — including it either way would misstate the result).
 *
 * No network calls here — candles are passed in already fetched (e.g. via
 * fetchPerpKlines from taSignalSource.js, once you have internet access
 * in your own environment; this sandbox has none, hence the synthetic
 * data in taBacktest.test.js).
 */

const { evaluateCandles } = require('./taSignalSource');

/**
 * @param {Array<{t:number,o:number,h:number,l:number,c:number,v:number}>} candles
 *   Historical candles, oldest first, for ONE symbol/timeframe.
 * @param {object} cfg - same shape as taSignalSource's cfg: minNetConfluence,
 *   minAdx, atrStopMult, atrTpMult, cooldownMs. Sizing/leverage fields are
 *   irrelevant here (backtest reports trade quality, not position sizing).
 * @param {number} [warmup=30] - minimum candles of history required before
 *   evaluateCandles() is called at all (indicator warm-up period).
 * @returns {{trades: Array<object>, stats: {n:number, winRate:number|null,
 *   avgWinPct:number|null, avgLossPct:number|null, expectancyPct:number|null,
 *   openCount:number}}}
 */
function runBacktest(candles, cfg, warmup = 30) {
  const trades = [];
  let lastSignalT = -Infinity;
  const cooldownMs = cfg.cooldownMs != null ? cfg.cooldownMs : 0;

  for (let i = warmup; i < candles.length; i++) {
    const window = candles.slice(0, i + 1); // everything up to and including bar i — no lookahead
    const now = candles[i].t;
    if (now - lastSignalT < cooldownMs) continue;

    const candidate = evaluateCandles(window, cfg);
    if (!candidate) continue;

    const { direction, price, stopLoss, takeProfit } = candidate;
    let outcome = 'open';
    let outcomePrice = null;
    let barsHeld = 0;

    for (let j = i + 1; j < candles.length; j++) {
      const bar = candles[j];
      barsHeld = j - i;
      const hitSL = direction === 'LONG' ? bar.l <= stopLoss : bar.h >= stopLoss;
      const hitTP = direction === 'LONG' ? bar.h >= takeProfit : bar.l <= takeProfit;
      // If a single bar's range spans both levels, we can't know which was
      // touched first from OHLC alone — conservatively count it as the
      // loss (stop-loss), matching outcomeResolver.js's own documented
      // approach for the same ambiguity.
      if (hitSL && hitTP) { outcome = 'loss'; outcomePrice = stopLoss; break; }
      if (hitSL) { outcome = 'loss'; outcomePrice = stopLoss; break; }
      if (hitTP) { outcome = 'win'; outcomePrice = takeProfit; break; }
    }

    const pctMove = (() => {
      if (outcome === 'open') return null;
      const raw = (outcomePrice - price) / price;
      return direction === 'SHORT' ? -raw * 100 : raw * 100;
    })();

    trades.push({
      barIndex: i, t: now, coin: cfg.coin || null, direction, entry: price,
      stopLoss, takeProfit, outcome, outcomePrice, pctMove, barsHeld,
      confidence: candidate.confidence, adx: candidate.adxVal,
    });
    lastSignalT = now;
  }

  const resolved = trades.filter((t) => t.outcome !== 'open');
  const wins = resolved.filter((t) => t.outcome === 'win').map((t) => t.pctMove);
  const losses = resolved.filter((t) => t.outcome === 'loss').map((t) => t.pctMove);
  const n = resolved.length;
  const winRate = n ? wins.length / n : null;
  const avgWinPct = wins.length ? wins.reduce((a, b) => a + b, 0) / wins.length : null;
  const avgLossPct = losses.length ? losses.reduce((a, b) => a + b, 0) / losses.length : null;
  const expectancyPct = n && winRate !== null
    ? winRate * (avgWinPct || 0) + (1 - winRate) * (avgLossPct || 0)
    : null;

  return {
    trades,
    stats: { n, winRate, avgWinPct, avgLossPct, expectancyPct, openCount: trades.length - n },
  };
}

/**
 * Convenience wrapper: run the same candles through several cfg variants
 * (e.g. different minNetConfluence/minAdx) so you can compare tradeoffs
 * side by side before picking values for the live config.
 *
 * @param {Array<object>} candles
 * @param {Array<{label:string, cfg:object}>} variants
 * @param {number} [warmup]
 * @returns {Array<{label:string, stats:object, tradeCount:number}>}
 */
function compareVariants(candles, variants, warmup = 30) {
  return variants.map(({ label, cfg }) => {
    const { trades, stats } = runBacktest(candles, cfg, warmup);
    return { label, stats, tradeCount: trades.length };
  });
}

module.exports = { runBacktest, compareVariants };
