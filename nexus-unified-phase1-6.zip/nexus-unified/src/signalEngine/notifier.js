/**
 * notifier.js — ported from signalbot/internal/notifier/{notifier,format}.go
 *
 * Sends a formatted alert to a personal chat via the Telegram Bot API.
 * Retries transient failures and honors Telegram's 429 `retry_after` hint
 * instead of dropping the alert on the first hiccup. Uses Node's built-in
 * https module — same style as the rest of server.js, no extra dependency.
 */
'use strict';

const https = require('https');

const SPECIAL_MDV2 = '_*[]()~`>#+-=|{}.!';

function escapeMarkdownV2(s) {
  let out = '';
  for (const ch of String(s)) {
    if (SPECIAL_MDV2.includes(ch)) out += '\\';
    out += ch;
  }
  return out;
}

function formatFloat(n) {
  if (n === null || n === undefined) return escapeMarkdownV2('—');
  // Mirrors Go's strconv.FormatFloat(f, 'f', -1, 64): shortest exact decimal.
  return escapeMarkdownV2(String(n));
}

/** @param {object} sig - a signal object as produced by parser.js */
function formatSignal(sig) {
  const lines = [];
  lines.push('🚨 *SIGNAL DETECTED*');
  lines.push(`📡 Channel: ${escapeMarkdownV2(sig.channelName || 'unknown')}`);
  lines.push(`⏰ ${escapeMarkdownV2(new Date().toISOString().replace('T', ' ').slice(0, 19))} UTC`);
  lines.push(`📊 Confidence: ${escapeMarkdownV2(Math.round(sig.confidence * 100))}%`);
  lines.push('');
  lines.push(`🪙 Pair: *${escapeMarkdownV2(sig.pair)}*`);
  if (sig.direction) lines.push(`📈 Direction: *${escapeMarkdownV2(sig.direction)}*`);

  if (sig.entryMin === sig.entryMax) {
    lines.push(`💰 Entry: ${formatFloat(sig.entryMin)}`);
  } else {
    lines.push(`💰 Entry: ${formatFloat(sig.entryMin)} \\- ${formatFloat(sig.entryMax)}`);
  }

  if (sig.takeProfits && sig.takeProfits.length) {
    const parts = sig.takeProfits.map((tp, i) => `TP${i + 1} ${formatFloat(tp)}`);
    lines.push(`🎯 Targets: ${parts.join(' \\| ')}`);
  }

  lines.push(`🛑 Stop Loss: ${formatFloat(sig.stopLoss)}`);
  if (sig.leverage > 0) lines.push(`⚡ Leverage: ${sig.leverage}x`);
  if (sig.timeframe) lines.push(`⏱ Timeframe: ${escapeMarkdownV2(sig.timeframe)}`);
  if (sig.sizePct != null) {
    lines.push(`📐 Suggested size: ${escapeMarkdownV2(sig.sizePct.toFixed(1))}% \\(${escapeMarkdownV2(sig.sizeMethod || '?')}\\)`);
    if (sig.sizeRationale) lines.push(`   ${escapeMarkdownV2(sig.sizeRationale)}`);
  }

  let preview = sig.rawText || '';
  if (preview.length > 300) preview = preview.slice(0, 300) + '…';
  lines.push('');
  lines.push(`📝 Raw:\n${escapeMarkdownV2(preview)}`);

  return lines.join('\n');
}

function backoffMs(attempt) {
  const base = Math.min(1000 * 2 ** Math.max(attempt - 1, 0), 15000);
  return base;
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

class TelegramBotNotifier {
  constructor(botToken, chatId, { maxRetries = 3, timeoutMs = 10000 } = {}) {
    this.botToken = botToken;
    this.chatId = chatId;
    this.maxRetries = maxRetries;
    this.timeoutMs = timeoutMs;
  }

  _post(payload) {
    const body = JSON.stringify(payload);
    return new Promise((resolve, reject) => {
      const req = https.request(
        `https://api.telegram.org/bot${this.botToken}/sendMessage`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
          timeout: this.timeoutMs,
        },
        (res) => {
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            let parsed = {};
            try { parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* leave {} */ }
            resolve({ status: res.statusCode, parsed });
          });
        }
      );
      req.on('timeout', () => req.destroy(new Error('timeout')));
      req.on('error', reject);
      req.write(body);
      req.end();
    });
  }

  async send(text) {
    let lastErr;
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      if (attempt > 0) await sleep(backoffMs(attempt));

      let status, parsed;
      try {
        ({ status, parsed } = await this._post({ chat_id: this.chatId, text, parse_mode: 'MarkdownV2' }));
      } catch (e) {
        lastErr = new Error(`bot api request: ${e.message}`);
        continue;
      }

      if (status === 200 && parsed && parsed.ok) return;

      if (status === 429 && parsed && parsed.parameters && parsed.parameters.retry_after > 0) {
        await sleep(parsed.parameters.retry_after * 1000);
        lastErr = new Error(`rate limited, retried after ${parsed.parameters.retry_after}s`);
        continue;
      }

      lastErr = new Error(`bot api returned status=${status} description=${(parsed && parsed.description) || ''}`);
    }
    throw new Error(`send message failed after ${this.maxRetries + 1} attempts: ${lastErr && lastErr.message}`);
  }
}

module.exports = { TelegramBotNotifier, formatSignal, escapeMarkdownV2, formatFloat };
