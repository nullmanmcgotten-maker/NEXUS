'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const configMod = require('./config');
const { Classifier } = require('./classify');
const { parseMessage } = require('./parser');
const { open: openStore } = require('./store');
const { Pipeline } = require('./pipeline');

test('config.load accepts enabled:true with no channels and no taSource (nothing to validate yet)', () => {
  // Channel watching (MTProto login) is only required once you actually
  // list channels to watch — see config.js's `wantsChannelWatching`. An
  // engine that's "enabled" but configured for neither channel-parsing nor
  // taSource is a valid, if inert, config.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sigcfg-'));
  const p = path.join(dir, 'config.json');
  fs.writeFileSync(p, JSON.stringify({ signalEngine: { enabled: true } }));
  const cfg = configMod.load(p);
  assert.equal(cfg.channels.length, 0);
  assert.equal(cfg.signalEngine.taSource.enabled, false);
});

test('config.load rejects channels configured without telegram apiId/apiHash', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sigcfg-'));
  const p = path.join(dir, 'config.json');
  fs.writeFileSync(p, JSON.stringify({ signalEngine: { enabled: true }, channels: ['some_channel'] }));
  assert.throws(() => configMod.load(p), /telegram\.apiId is required/);
});

test('config.load rejects taSource.enabled without symbols or notification creds', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sigcfg-'));
  const p = path.join(dir, 'config.json');
  fs.writeFileSync(p, JSON.stringify({ signalEngine: { enabled: true, taSource: { enabled: true } } }));
  assert.throws(() => configMod.load(p), /taSource\.symbols/);
});

test('config.load accepts taSource-only setup with no channels and no telegram login', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sigcfg-'));
  const p = path.join(dir, 'config.json');
  fs.writeFileSync(p, JSON.stringify({
    signalEngine: { enabled: true, taSource: { enabled: true, symbols: ['SOL'] } },
    notification: { botToken: 'x', chatId: 1 },
  }));
  const cfg = configMod.load(p);
  assert.equal(cfg.signalEngine.taSource.enabled, true);
  assert.deepEqual(cfg.signalEngine.taSource.symbols, ['SOL']);
});

test('config.load accepts a minimal disabled config', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sigcfg-'));
  const p = path.join(dir, 'config.json');
  fs.writeFileSync(p, JSON.stringify({}));
  const cfg = configMod.load(p);
  assert.equal(cfg.signalEngine.enabled, false);
  assert.equal(cfg.filters.minConfidence, 0.8);
});

test('pipeline: end-to-end message -> dedup -> parse -> store, no notifier', async () => {
  const dbPath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sigdb-')), 'test.db');
  const store = openStore(dbPath);
  const classifier = new Classifier(['premium|dm now'], 0.8);
  const logs = [];
  const pipeline = new Pipeline(parseMessage, classifier, store, null, (lvl, msg) => logs.push([lvl, msg]));

  const raw = {
    channelId: 'chan1',
    channelName: 'testchannel',
    messageId: 42,
    text: 'BTC/USDT LONG\nEntry: 60000\nTP1: 62000\nTP2: 64000\nStop Loss: 58500\nLeverage: 5x',
    postedAt: Date.now(),
  };

  await pipeline.handle(raw);
  const recent = store.recentSignals(10);
  assert.equal(recent.length, 1);
  assert.equal(recent[0].coin, 'BTC');
  assert.equal(recent[0].direction, 'LONG');
  assert.ok(recent[0].confidence >= 0.8);
  assert.ok(Array.isArray(recent[0].breakdown) && recent[0].breakdown.length > 0);

  // Second delivery of the exact same (channel, messageId) must be deduped,
  // not saved twice — this is the bug the original in-memory-map sketch had
  // on every restart.
  await pipeline.handle(raw);
  assert.equal(store.recentSignals(10).length, 1, 'duplicate message must not produce a second saved signal');

  store.close();
});

test('pipeline: excluded/low-confidence messages are never saved', async () => {
  const dbPath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sigdb-')), 'test.db');
  const store = openStore(dbPath);
  const classifier = new Classifier(['premium|dm now'], 0.8);
  const pipeline = new Pipeline(parseMessage, classifier, store, null, () => {});

  await pipeline.handle({ channelId: 'c', channelName: 'c', messageId: 1, text: 'join our PREMIUM DM NOW', postedAt: Date.now() });
  await pipeline.handle({ channelId: 'c', channelName: 'c', messageId: 2, text: 'ETH looking bullish today', postedAt: Date.now() });

  assert.equal(store.recentSignals(10).length, 0);
  store.close();
});
