/**
 * approvalBot.js — the human-in-the-loop gate between a parsed signal and
 * TonyBot's execution bridge.
 *
 * Every signal the pipeline saves is posted here as a Telegram message with
 * two inline buttons: Approve / Reject. Nothing else can move a signal out
 * of status='pending' — see store.js. TonyBot's bridge.py polls only for
 * status='approved' rows, so an order can never reach the exchange without
 * this tap happening first.
 *
 * Uses long polling (getUpdates), not a webhook — no public URL/HTTPS
 * endpoint required, works fine from a home machine or VPS with only
 * outbound internet.
 */
'use strict';

const https = require('https');
const { formatSignal, escapeMarkdownV2 } = require('./notifier');

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

function apiCall(botToken, method, payload, timeoutMs = 10000) {
  const body = JSON.stringify(payload || {});
  return new Promise((resolve, reject) => {
    const req = https.request(
      `https://api.telegram.org/bot${botToken}/${method}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
        timeout: timeoutMs,
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          let parsed = {};
          try { parsed = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { /* leave {} */ }
          resolve({ status: res.statusCode, parsed });
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

class ApprovalBot {
  /**
   * @param {string} botToken
   * @param {number|string} chatId - only callbacks from this chat are honored;
   *   protects against a stranger who discovers the bot's username acting on your signals.
   * @param {import('./store').Store} store
   * @param {(level:string,msg:string,meta?:object)=>void} log
   */
  constructor(botToken, chatId, store, log) {
    this.botToken = botToken;
    this.chatId = String(chatId);
    this.store = store;
    this.log = log || (() => {});
    this._offset = 0;
    this._polling = false;
    this._pollTimer = null;
  }

  async sendApprovalRequest(id, sig) {
    const text = formatSignal(sig) + '\n\n👉 *Approve to let TonyBot size and place this trade\\.*';
    const keyboard = {
      inline_keyboard: [[
        { text: '✅ Approve', callback_data: `approve:${id}` },
        { text: '❌ Reject', callback_data: `reject:${id}` },
      ]],
    };
    const { status, parsed } = await apiCall(this.botToken, 'sendMessage', {
      chat_id: this.chatId,
      text,
      parse_mode: 'MarkdownV2',
      reply_markup: keyboard,
    });
    if (status === 200 && parsed && parsed.ok) {
      this.store.setApprovalMessageId(id, parsed.result.message_id);
    } else {
      this.log('error', 'approval prompt send failed', { id, status, description: parsed && parsed.description });
    }
  }

  async _editToDecision(msgId, decisionLabel, sig) {
    const text = formatSignal(sig) + `\n\n${decisionLabel}`;
    await apiCall(this.botToken, 'editMessageText', {
      chat_id: this.chatId,
      message_id: msgId,
      text,
      parse_mode: 'MarkdownV2',
    });
  }

  async _handleCallback(cb) {
    const from = String(cb.from && cb.from.id);
    const data = cb.data || '';
    const [action, idStr] = data.split(':');
    const id = Number(idStr);

    // Only the configured chat can approve/reject — an approval tap from
    // anyone else is ignored (but still acked so Telegram stops retrying it).
    if (String(cb.message && cb.message.chat && cb.message.chat.id) !== this.chatId) {
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id, text: 'Not authorized.' });
      return;
    }

    const sig = this.store.getById(id);
    if (!sig) {
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id, text: 'Signal not found.' });
      return;
    }
    if (sig.status !== 'pending') {
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id, text: `Already ${sig.status}.` });
      return;
    }

    if (action === 'approve') {
      this.store.setStatus(id, 'approved', `approved by chat ${from}`);
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id, text: 'Approved ✅' });
      await this._editToDecision(cb.message.message_id, `✅ *APPROVED* \\— queued for TonyBot`, sig);
      this.log('info', 'signal approved', { id, coin: sig.coin });
    } else if (action === 'reject') {
      this.store.setStatus(id, 'rejected', `rejected by chat ${from}`);
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id, text: 'Rejected ❌' });
      await this._editToDecision(cb.message.message_id, `❌ *REJECTED*`, sig);
      this.log('info', 'signal rejected', { id, coin: sig.coin });
    } else {
      await apiCall(this.botToken, 'answerCallbackQuery', { callback_query_id: cb.id });
    }
  }

  async _pollOnce() {
    const { status, parsed } = await apiCall(this.botToken, 'getUpdates', {
      offset: this._offset,
      timeout: 25,
      allowed_updates: ['callback_query'],
    }, 30000);
    if (status !== 200 || !parsed || !parsed.ok) return;
    for (const update of parsed.result) {
      this._offset = update.update_id + 1;
      if (update.callback_query) {
        try {
          await this._handleCallback(update.callback_query);
        } catch (e) {
          this.log('error', 'callback handling failed', { err: e.message });
        }
      }
    }
  }

  start() {
    this._polling = true;
    const loop = async () => {
      while (this._polling) {
        try {
          await this._pollOnce();
        } catch (e) {
          this.log('error', 'approval bot poll failed', { err: e.message });
          await sleep(3000);
        }
      }
    };
    loop();
    this.log('info', 'approval bot polling started');
  }

  stop() {
    this._polling = false;
  }
}

module.exports = { ApprovalBot };
