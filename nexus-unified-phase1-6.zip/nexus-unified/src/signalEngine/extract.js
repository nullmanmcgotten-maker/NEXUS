/**
 * extract.js — ported from signalbot/internal/parser/extract.go
 *
 * Every extractor returns an explicit "found" flag alongside its value, so
 * a legitimate zero (e.g. an entry price that really is 0.0000x for a low-cap
 * coin) is never confused with "field not present" — the bug called out in
 * the original sketch this project replaced.
 */
'use strict';

// Guards the pair regex from matching plain English words that happen to be
// 2-10 uppercase letters ("LONG", "ATH", "USD") — the original sketch's
// biggest source of false positives. No wildcard fallback: a pair only
// counts if it's BASE/QUOTE against a *known* quote asset.
// Extra guard found while porting this from the Go original: matching the
// base token case-insensitively means a filler word directly in front of a
// bare "USD"/"ETH" mention ("the price of USD", "cash or ETH") reads as a
// BASE/QUOTE pair — e.g. "of USD" -> base "OF". Real tickers are essentially
// never common function words, so block the short list that actually
// collides with the regex shape (2-3 letters, immediately before a quote
// asset word).
const COMMON_WORD_BASES = new Set([
  'OF', 'TO', 'IN', 'ON', 'AT', 'IS', 'IT', 'BE', 'AS', 'OR', 'AN', 'IF',
  'SO', 'NO', 'WE', 'MY', 'ME', 'US', 'DO', 'GO', 'BY',
  'THE', 'ARE', 'WAS', 'FOR', 'AND', 'BUT', 'NOT', 'ALL', 'CAN', 'HAS',
  'HAD', 'HOW', 'ITS', 'MAY', 'OUR', 'OUT', 'SEE', 'WHO', 'GET', 'USE',
  'YOU', 'HIS', 'HER', 'ONE', 'TWO', 'NEW', 'OLD', 'ANY', 'PER',
]);

const pairRe = /\b([A-Z0-9]{2,10})[\/\-_\s]?(USDT|USD|BUSD|USDC|BTC|ETH)\b/i;
const directionRe = /\b(long|short|buy|sell)\b/i;
const entryZoneRe = /entry\s*(?:zone|range)?\s*[:=]?\s*\$?([\d.]+)\s*(?:-|to|–)\s*\$?([\d.]+)/i;
const entrySingleRe = /(?:entry|enter)\s*(?:price)?\s*[:=]?\s*\$?([\d.]+)\b/i;
const tpLabeledRe = /(?:tp\s*\d*|target\s*\d*)\s*[:=]?\s*\$?([\d.]+)/gi;
const tpListRe = /(?:take\s*profits?|targets?)\s*[:=]?\s*([\d.,\s\-–]+)/i;
const numListRe = /[\d.]+/g;
const stopLossRe = /(?:stop\s*loss|stoploss|sl)\s*[:=]?\s*\$?([\d.]+)\b/i;
const leverageRe = /leverage\s*[:=]?\s*(\d{1,3})\s*x?\b/i;
const timeframeRe = /\b(\d{1,3})\s*(min(?:ute)?s?|h(?:our)?s?|d(?:ay)?s?|w(?:eek)?s?)\b/i;

function extractPair(text) {
  const m = pairRe.exec(text);
  if (!m) return { coin: '', pair: '', ok: false };
  const base = m[1].toUpperCase();
  const quote = m[2].toUpperCase();
  // NOTE: an earlier version of this guard (ported faithfully from the Go
  // original) also rejected whenever the base token was itself in
  // KNOWN_QUOTES — which silently rejects BTC/USDT and ETH/USDT, arguably
  // the two most heavily-traded pairs in crypto, since BTC/ETH are also
  // valid quote assets elsewhere (e.g. ETH/BTC). Caught by the test suite
  // (see parser.test.js/integration.test.js) before this shipped. The only
  // thing that actually needs blocking is base === quote (e.g. "USD/USD"),
  // which the regex itself can't produce meaningfully anyway, and common
  // filler words, handled by COMMON_WORD_BASES above.
  if (base === quote || COMMON_WORD_BASES.has(base)) {
    return { coin: '', pair: '', ok: false };
  }
  return { coin: base, pair: `${base}/${quote}`, ok: true };
}

function extractDirection(text) {
  const m = directionRe.exec(text);
  if (!m) return '';
  const w = m[1].toLowerCase();
  if (w === 'long' || w === 'buy') return 'LONG';
  if (w === 'short' || w === 'sell') return 'SHORT';
  return '';
}

function extractEntry(text) {
  let m = entryZoneRe.exec(text);
  if (m) {
    let a = parseFloat(m[1]), b = parseFloat(m[2]);
    if (Number.isFinite(a) && Number.isFinite(b)) {
      if (a > b) [a, b] = [b, a];
      return { min: a, max: b, ok: true };
    }
  }
  m = entrySingleRe.exec(text);
  if (m) {
    const v = parseFloat(m[1]);
    if (Number.isFinite(v)) return { min: v, max: v, ok: true };
  }
  return { min: 0, max: 0, ok: false };
}

function extractTakeProfits(text) {
  const out = [];
  const seen = new Set();
  const add = (v) => { if (!seen.has(v)) { seen.add(v); out.push(v); } };

  for (const m of text.matchAll(tpLabeledRe)) {
    const v = parseFloat(m[1]);
    if (Number.isFinite(v)) add(v);
  }
  if (out.length === 0) {
    const m = tpListRe.exec(text);
    if (m) {
      for (const n of m[1].match(numListRe) || []) {
        const v = parseFloat(n);
        if (Number.isFinite(v)) add(v);
      }
    }
  }
  return out;
}

function extractStopLoss(text) {
  const m = stopLossRe.exec(text);
  if (!m) return { value: 0, ok: false };
  const v = parseFloat(m[1]);
  if (!Number.isFinite(v)) return { value: 0, ok: false };
  return { value: v, ok: true };
}

function extractLeverage(text) {
  const m = leverageRe.exec(text);
  if (!m) return 0;
  const v = parseInt(m[1], 10);
  return Number.isFinite(v) ? v : 0;
}

function extractTimeframe(text) {
  const m = timeframeRe.exec(text);
  return m ? m[0].trim() : '';
}

module.exports = {
  extractPair, extractDirection, extractEntry,
  extractTakeProfits, extractStopLoss, extractLeverage, extractTimeframe,
};
