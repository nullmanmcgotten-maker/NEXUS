/**
 * pipeline.js — ported from signalbot/internal/pipeline/pipeline.go
 *
 * One function per incoming message: dedup check -> parse -> persist ->
 * ask for approval. Never throws back to the caller — a single bad message
 * must not stop the ingest loop from processing the next one; failures are
 * logged.
 *
 * Save happens BEFORE the approval prompt is sent (unlike the original
 * notify-then-save order) because the approval message's callback_data
 * needs the row's id to know which signal a tap refers to.
 */
'use strict';

const { formatSignal } = require('./notifier');

class Pipeline {
  /**
   * @param {import('./parser')['parseMessage']} parseMessage
   * @param {import('./classify').Classifier} classifier
   * @param {import('./store').Store} store
   * @param {import('./notifier').TelegramBotNotifier|null} notifier - plain push notification (optional, informational only)
   * @param {(level:string, msg:string, meta?:object)=>void} log
   * @param {import('./approvalBot').ApprovalBot|null} approvalBot - if set, every saved signal is
   *   routed here for a human Approve/Reject tap instead of (or alongside) the plain notifier
   */
  constructor(parseMessage, classifier, store, notifier, log, approvalBot) {
    this.parseMessage = parseMessage;
    this.classifier = classifier;
    this.store = store;
    this.notifier = notifier;
    this.approvalBot = approvalBot || null;
    this.log = log || (() => {});
  }

  /** @param {{channelId, channelName, messageId, text, postedAt}} raw */
  async handle(raw) {
    let seen;
    try {
      seen = this.store.seen(raw.channelId, raw.messageId);
    } catch (e) {
      this.log('error', 'dedup check failed', { err: e.message });
      return; // fail closed: better to skip than risk a duplicate alert
    }
    if (seen) return;

    // Mark seen before anything else. If notification fails downstream we
    // deliberately don't retry-forever on the next message from the same
    // channel; the audit row still exists to catch a real bug in the logs.
    try {
      this.store.markSeen(raw.channelId, raw.messageId);
    } catch (e) {
      this.log('error', 'mark seen failed', { err: e.message });
    }

    const result = this.parseMessage(raw, this.classifier);
    if (!result.signal) {
      if (result.reason === 'low_confidence') {
        this.log('debug', 'rejected: incomplete setup', { candidate: result.cand });
      }
      return;
    }

    let id;
    try {
      id = this.store.saveSignal(result.signal);
    } catch (e) {
      this.log('error', 'save signal failed', { err: e.message });
      return; // no id, nothing to approve — bail out
    }
    this.log('info', 'signal saved', { id, coin: result.signal.coin, confidence: result.signal.confidence });

    if (this.approvalBot) {
      try {
        await this.approvalBot.sendApprovalRequest(id, result.signal);
      } catch (e) {
        this.log('error', 'approval prompt failed', { id, err: e.message });
      }
    } else if (this.notifier) {
      // No approval bot configured — fall back to a plain informational push.
      try {
        await this.notifier.send(formatSignal(result.signal));
      } catch (e) {
        this.log('error', 'notification failed', { err: e.message, coin: result.signal.coin });
      }
    }
  }
}

module.exports = { Pipeline };
