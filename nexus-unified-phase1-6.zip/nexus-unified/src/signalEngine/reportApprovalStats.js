#!/usr/bin/env node
'use strict';

/**
 * CLI: prints approval-rate-by-confidence-bucket, using store.
 * approvalStatsByConfidence(). Answers a specific question: are you (or
 * the risk gate) actually approving high-confluence proposals more than
 * low-confluence ones, or approving roughly everything regardless of
 * score — in which case the confidence score isn't doing anything for you
 * and the real fix is upstream (thresholds), not this report.
 *
 * Usage:
 *   node src/signalEngine/reportApprovalStats.js [path/to/signals.db] [source]
 * Defaults: ./signals.db (or config.json's storage.sqlitePath if present), source=nexus_ta
 */

const fs = require('fs');
const path = require('path');
const { open: openStore } = require('./store');

function resolveDbPath(arg) {
  if (arg) return arg;
  try {
    const cfg = JSON.parse(fs.readFileSync(path.resolve(__dirname, '../../config.json'), 'utf8'));
    if (cfg.storage && cfg.storage.sqlitePath) return cfg.storage.sqlitePath;
  } catch (e) { /* fall through to default */ }
  return './signals.db';
}

function main() {
  const [dbArg, sourceArg] = process.argv.slice(2);
  const dbPath = resolveDbPath(dbArg);
  const source = sourceArg || 'nexus_ta';

  const store = openStore(dbPath);
  const buckets = store.approvalStatsByConfidence({ source, bucketSize: 0.2 });
  store.close();

  if (!buckets.length) {
    console.log(`No decided (approved/rejected/executed/failed) ${source} proposals found in ${dbPath} yet.`);
    return;
  }

  console.log(`Approval rate by confidence bucket — source=${source}, db=${dbPath}\n`);
  console.log('bucket'.padEnd(12), 'total'.padStart(6), 'approved'.padStart(9), 'rate'.padStart(6));
  for (const b of buckets) {
    const rate = b.approvalRate !== null ? (b.approvalRate * 100).toFixed(0) + '%' : '—';
    console.log(
      `${b.bucket}-${(parseFloat(b.bucket) + 0.2).toFixed(1)}`.padEnd(12),
      String(b.total).padStart(6),
      String(b.approvedOrExecuted).padStart(9),
      rate.padStart(6)
    );
  }
  console.log('\nIf low-confidence buckets have a similar or higher approval rate than high-confidence');
  console.log('ones, the confidence score is not actually filtering anything for you in practice —');
  console.log('worth tightening minNetConfluence/minAdx rather than trusting the score as a gate.');
}

main();
