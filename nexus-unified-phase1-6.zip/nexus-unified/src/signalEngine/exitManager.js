'use strict';

/**
 * exitManager.js — pure functions for the "should this trade's stop move
 * to breakeven" decision, and the R-multiple math behind it. No store, no
 * network, no side effects — outcomeResolver.js is the only caller that
 * actually acts on these (it has the store and the live candle feed).
 *
 * Why breakeven-at-partial-progress: the original trade-history review
 * found average loss size eating average win size (45% win rate, roughly
 * breakeven net) — some fraction of those losses were very likely trades
 * that moved meaningfully in your favor and then fully round-tripped back
 * through entry into a full stop-out. Moving the stop to (roughly)
 * breakeven once a trade has covered `triggerR` of its own initial risk
 * turns a full loss into a scratch in that specific case, without
 * touching trades that never had that cushion in the first place.
 *
 * This does NOT move your real exchange stop-loss order — this sandbox
 * has no execution access (TonyBot's bridge.py isn't part of this repo).
 * It updates Nexus's own tracking (store.updateStopLoss) and, if a
 * notifier is wired up, pushes you a Telegram message telling you to move
 * it yourself. See outcomeResolver.js for how it's used.
 */

const DEFAULTS = {
  enabled: true,
  triggerR: 0.5,     // move to breakeven once price has covered this fraction of the initial risk
  feeBufferPct: 0.001, // 0.1% cushion beyond exact entry, so a breakeven stop isn't a guaranteed tiny loss after fees
};

function initialRiskDistance(entry, stopLoss) {
  if (!entry || !stopLoss) return null;
  return Math.abs(entry - stopLoss);
}

/** How many multiples of the ORIGINAL initial risk the current price
 *  represents, signed so favorable movement is positive regardless of
 *  direction. Returns null if risk distance is unknown/zero. */
function unrealizedR(direction, entry, stopLoss, currentPrice) {
  const risk = initialRiskDistance(entry, stopLoss);
  if (!risk) return null;
  const dir = (direction || '').toUpperCase();
  const moveDist = (dir === 'SHORT' || dir === 'SELL') ? entry - currentPrice : currentPrice - entry;
  return moveDist / risk;
}

/** The new stop price to use once breakeven triggers — entry plus a small
 *  fee/slippage buffer in the trade's favor, not exactly entry, so a
 *  "breakeven" exit doesn't quietly still lose money to fees. */
function breakevenStopPrice(direction, entry, feeBufferPct = DEFAULTS.feeBufferPct) {
  const dir = (direction || '').toUpperCase();
  return (dir === 'SHORT' || dir === 'SELL') ? entry * (1 - feeBufferPct) : entry * (1 + feeBufferPct);
}

/**
 * @param {{direction:string, entry:number, stopLoss:number, currentPrice:number}} trade
 *   `stopLoss` here must be the ORIGINAL stop (initial risk basis), not a
 *   stop already moved to breakeven on a prior check.
 * @param {object} [opts] - overrides for DEFAULTS
 * @returns {{trigger:boolean, r:number|null, newStop:number|null}}
 */
function checkBreakeven(trade, opts) {
  const cfg = Object.assign({}, DEFAULTS, opts || {});
  if (!cfg.enabled) return { trigger: false, r: null, newStop: null };

  const r = unrealizedR(trade.direction, trade.entry, trade.stopLoss, trade.currentPrice);
  if (r === null || r < cfg.triggerR) return { trigger: false, r, newStop: null };

  return { trigger: true, r, newStop: breakevenStopPrice(trade.direction, trade.entry, cfg.feeBufferPct) };
}

module.exports = { DEFAULTS, initialRiskDistance, unrealizedR, breakevenStopPrice, checkBreakeven };
