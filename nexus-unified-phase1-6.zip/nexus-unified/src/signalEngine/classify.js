/**
 * classify.js — ported from signalbot/internal/parser/classify.go, extended
 * with a `breakdown` array so the UI can show *why* a signal scored the way
 * it did instead of just a bare percentage — this is the "make sure the
 * user understands the signal" piece.
 *
 * Two separate mechanisms, on purpose:
 *  1. Hard excludes — obvious noise (ads, "target hit" posts, chit-chat).
 *     A match is a reject, full stop, regardless of what numbers appear.
 *  2. Confidence score — required fields (coin, entry, >=1 TP, stop-loss)
 *     each worth 0.22 (0.88 total); direction/leverage/timeframe/multiple-TP
 *     add small corroborating bonuses, capped at 1.0.
 */
'use strict';

class Classifier {
  constructor(excludePatterns, minConfidence) {
    this.excludeRes = (excludePatterns || []).map((p) => new RegExp(p, 'i'));
    this.minConfidence = minConfidence > 0 ? minConfidence : 0.8;
  }

  isExcluded(text) {
    return this.excludeRes.some((re) => re.test(text));
  }

  passes(confidence) {
    return confidence >= this.minConfidence;
  }
}

const REQUIRED_WEIGHT = 0.22;

/**
 * @returns {{confidence: number, breakdown: Array<{label:string, found:boolean, weight:number}>}}
 */
function score(cand, hasCoin, hasEntry, hasTP, hasSL) {
  const breakdown = [
    { label: 'Coin/pair identified', found: hasCoin, weight: REQUIRED_WEIGHT },
    { label: 'Entry price given', found: hasEntry, weight: REQUIRED_WEIGHT },
    { label: 'Take-profit target given', found: hasTP, weight: REQUIRED_WEIGHT },
    { label: 'Stop-loss given', found: hasSL, weight: REQUIRED_WEIGHT },
    { label: 'Direction (long/short) stated', found: !!cand.direction, weight: 0.06 },
    { label: 'Leverage specified', found: cand.leverage > 0, weight: 0.03 },
    { label: 'Timeframe specified', found: !!cand.timeframe, weight: 0.03 },
    { label: 'Multiple take-profit targets', found: cand.takeProfits.length > 1, weight: 0.04 },
  ];
  let s = 0;
  for (const b of breakdown) if (b.found) s += b.weight;
  return { confidence: Math.min(s, 1), breakdown };
}

module.exports = { Classifier, score, REQUIRED_WEIGHT };
