'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { computeSize, DEFAULTS } = require('./sizing');

test('sizing: falls back to fixed size when there are too few resolved trades', () => {
  const stats = { n: 5, winRate: 0.6, avgWinPct: 3, avgLossPct: -2 };
  const res = computeSize(stats, { minTradesForKelly: 20, fixedSizePct: 2 });
  assert.equal(res.method, 'fixed');
  assert.equal(res.sizePct, 2);
  assert.equal(res.skip, false);
  assert.match(res.rationale, /5\/20/);
});

test('sizing: falls back to fixed size when stats are null', () => {
  const res = computeSize(null, { fixedSizePct: 1.5 });
  assert.equal(res.method, 'fixed');
  assert.equal(res.sizePct, 1.5);
});

test('sizing: method="fixed" always uses fixedSizePct even with plenty of data', () => {
  const stats = { n: 100, winRate: 0.7, avgWinPct: 4, avgLossPct: -2 };
  const res = computeSize(stats, { method: 'fixed', fixedSizePct: 3 });
  assert.equal(res.method, 'fixed');
  assert.equal(res.sizePct, 3);
});

test('sizing: computes half-Kelly size with a real positive edge, capped at maxSizePct', () => {
  // win rate 60%, win/loss ratio 2:1 -> full Kelly = 0.6 - 0.4/2 = 0.4 (40%)
  // half-Kelly = 20%, capped down to maxSizePct
  const stats = { n: 50, winRate: 0.6, avgWinPct: 4, avgLossPct: -2 };
  const res = computeSize(stats, { minTradesForKelly: 20, kellyFraction: 0.5, maxSizePct: 5, minSizePct: 0.5 });
  assert.equal(res.method, 'kelly');
  assert.equal(res.skip, false);
  assert.equal(res.sizePct, 5); // hit the ceiling
});

test('sizing: a small positive edge is not floored to zero', () => {
  // win rate 40%, win/loss ratio 2:1 -> full Kelly = 0.4 - 0.6/2 = 0.1 (10%)
  // half-Kelly = 5% -> within bounds already
  const stats = { n: 50, winRate: 0.4, avgWinPct: 4, avgLossPct: -2 };
  const res = computeSize(stats, { minTradesForKelly: 20, kellyFraction: 0.5, maxSizePct: 5, minSizePct: 0.5 });
  assert.equal(res.method, 'kelly');
  assert.ok(res.sizePct >= 0.5);
});

test('sizing: negative edge is skipped, not sized small', () => {
  // win rate 30%, win/loss ratio 1.5:1 -> full Kelly = 0.3 - 0.7/1.5 = -0.167 (negative)
  const stats = { n: 50, winRate: 0.3, avgWinPct: 3, avgLossPct: -2 };
  const res = computeSize(stats, { minTradesForKelly: 20 });
  assert.equal(res.skip, true);
  assert.equal(res.sizePct, 0);
  assert.match(res.rationale, /negative/);
});

test('sizing: missing win or loss magnitude falls back to fixed instead of dividing by zero', () => {
  const stats = { n: 50, winRate: 0.5, avgWinPct: 0, avgLossPct: 0 };
  const res = computeSize(stats, { minTradesForKelly: 20, fixedSizePct: 2 });
  assert.equal(res.method, 'fixed');
  assert.equal(res.sizePct, 2);
});

test('sizing: DEFAULTS are exported and sane', () => {
  assert.equal(DEFAULTS.method, 'kelly');
  assert.ok(DEFAULTS.maxSizePct > DEFAULTS.minSizePct);
});
