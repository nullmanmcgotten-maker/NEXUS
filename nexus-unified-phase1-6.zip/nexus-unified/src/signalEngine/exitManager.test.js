'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { unrealizedR, breakevenStopPrice, checkBreakeven, initialRiskDistance } = require('./exitManager');

test('exitManager: initialRiskDistance is the absolute entry-to-stop distance', () => {
  assert.equal(initialRiskDistance(100, 90), 10);
  assert.equal(initialRiskDistance(100, 110), 10);
  assert.equal(initialRiskDistance(100, 0), null);
});

test('exitManager: unrealizedR is positive when a LONG has moved favorably', () => {
  // entry 100, stop 90 -> risk 10. price at 105 -> 0.5R in favor
  const r = unrealizedR('LONG', 100, 90, 105);
  assert.ok(Math.abs(r - 0.5) < 1e-9);
});

test('exitManager: unrealizedR is positive when a SHORT has moved favorably', () => {
  // entry 100, stop 110 -> risk 10. price at 95 -> 0.5R in favor for a short
  const r = unrealizedR('SHORT', 100, 110, 95);
  assert.ok(Math.abs(r - 0.5) < 1e-9);
});

test('exitManager: unrealizedR is negative when price has moved against the trade', () => {
  const r = unrealizedR('LONG', 100, 90, 95);
  assert.ok(r < 0);
});

test('exitManager: unrealizedR returns null when risk distance is zero/unknown', () => {
  assert.equal(unrealizedR('LONG', 100, 100, 105), null);
});

test('exitManager: breakevenStopPrice adds a fee buffer in the trade\'s favor', () => {
  const longStop = breakevenStopPrice('LONG', 100, 0.001);
  assert.ok(longStop > 100);
  const shortStop = breakevenStopPrice('SHORT', 100, 0.001);
  assert.ok(shortStop < 100);
});

test('exitManager: checkBreakeven does not trigger below triggerR', () => {
  const res = checkBreakeven({ direction: 'LONG', entry: 100, stopLoss: 90, currentPrice: 102 }, { triggerR: 0.5, enabled: true });
  assert.equal(res.trigger, false);
  assert.equal(res.newStop, null);
});

test('exitManager: checkBreakeven triggers at/above triggerR and returns a favorable new stop', () => {
  const res = checkBreakeven({ direction: 'LONG', entry: 100, stopLoss: 90, currentPrice: 106 }, { triggerR: 0.5, enabled: true, feeBufferPct: 0.001 });
  assert.equal(res.trigger, true);
  assert.ok(res.newStop > 100); // above raw entry, not below
  assert.ok(res.r >= 0.5);
});

test('exitManager: checkBreakeven is a no-op when disabled', () => {
  const res = checkBreakeven({ direction: 'LONG', entry: 100, stopLoss: 90, currentPrice: 200 }, { enabled: false });
  assert.equal(res.trigger, false);
});

test('exitManager: checkBreakeven works symmetrically for SHORT trades', () => {
  const res = checkBreakeven({ direction: 'SHORT', entry: 100, stopLoss: 110, currentPrice: 94 }, { triggerR: 0.5, enabled: true, feeBufferPct: 0.001 });
  assert.equal(res.trigger, true);
  assert.ok(res.newStop < 100); // below raw entry, favorable for a short
});
