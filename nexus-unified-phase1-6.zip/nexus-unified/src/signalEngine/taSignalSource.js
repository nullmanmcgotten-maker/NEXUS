/**
 * taSignalSource.js — makes Nexus's OWN technical-analysis engine
 * (indicators.js) a signal source, not just a passive cross-check against
 * Telegram calls.
 *
 * Previously: indicators.js's bias only ever showed up as a badge on a
 * chart you had to be looking at. This module puts it through the exact
 * same pipe everything else uses — store.saveSignal() as status='pending',
 * then approvalBot.sendApprovalRequest() — so a Nexus-detected setup gets
 * the same Telegram Approve/Reject tap, and on approval, the same
 * bridge.py -> TonyBot risk-gated execution. Nothing here places a trade;
 * it only ever proposes one.
 *
 * Built directly from a review of ~40 of the user's own closed perp trades:
 *   - 45% win rate, roughly breakeven net, but concentrated losses on a
 *     handful of symbols (worst: repeated same-direction re-entries into a
 *     losing symbol within minutes/hours of the last loss — a revenge-
 *     trading pattern, not a strategy).
 *   - Shorts underperformed longs badly in that sample.
 *   - A cluster of sub-15-minute trades that were mostly small losses —
 *     consistent with re-entering on noise rather than a resolved setup.
 * None of this proves a symbol or direction is "bad" going forward (n=40,
 * survivorship of a screenshot period) — so instead of hard-coding
 * "never short" rules, this module adds general circuit breakers that
 * would have caught the specific damage pattern either way:
 *   1. Per-coin cooldown — can't re-signal a symbol within `cooldownMs` of
 *      its last signal, win, loss, or otherwise. Kills rapid re-entry chop.
 *   2. Loss/rejection-streak breaker — N rejected/failed decisions in a row
 *      for a coin (within `lookbackMs`) pauses new signals on that coin for
 *      `streakCooldownMs`. Kills "keep trying the same losing idea."
 *   3. Leverage is capped at `maxLeverage` regardless of what looks
 *      attractive on the chart — TonyBot's own risk engine defaults to 10x
 *      max; this keeps the *suggestion* consistent with that instead of
 *      proposing 20x and letting the bridge silently reject it later.
 */
'use strict';

const TA = require('../indicators');
const sizing = require('./sizing');
const perpsAlpha = require('../perpsAlpha');
const { fetchJson: httpsGetJson } = require('../httpJson');

/** Binance USDⓈ-M perp klines — matches the "Perp" instruments in the
 *  screenshots this module was designed against. `symbol` is a bare coin
 *  ticker, e.g. "SOL"; converted to the USDT perp pair. */
async function fetchPerpKlines(symbol, interval = '1h', limit = 150) {
  const pair = `${symbol.toUpperCase()}USDT`;
  const url = `https://fapi.binance.com/fapi/v1/klines?symbol=${pair}&interval=${interval}&limit=${limit}`;
  const raw = await httpsGetJson(url);
  if (!Array.isArray(raw)) throw new Error(raw && raw.msg ? raw.msg : 'unexpected klines response');
  return raw.map((k) => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
}

/**
 * evaluateCandles() — the entire "would this set of candles produce a
 * trade proposal" decision, with no I/O, no store, no Telegram. Pulled out
 * of _scanOne() so the live scanner and taBacktest.js run byte-for-byte
 * the same confluence/ADX/ATR logic — a backtest that quietly drifts from
 * what actually runs live is worse than no backtest at all.
 *
 * @param {Array<{t:number,o:number,h:number,l:number,c:number,v:number}>} candles
 * @param {object} cfg - needs minNetConfluence, minAdx, atrStopMult, atrTpMult
 * @returns {null | {direction:'LONG'|'SHORT', price:number, stopLoss:number,
 *   takeProfit:number, confidence:number, adxVal:number|null, buys:number,
 *   sells:number, breakdown:string[]}}
 */
function evaluateCandles(candles, cfg) {
  if (!candles || candles.length < 30) return null;

  const closes = candles.map((c) => c.c);
  const signals = TA.generateSignals(closes, candles);
  const buys = signals.filter((s) => s.type === 'buy').length;
  const sells = signals.filter((s) => s.type === 'sell').length;
  const net = buys - sells;

  if (Math.abs(net) < cfg.minNetConfluence) return null; // not enough agreement to propose anything

  const adxLine = signals.find((s) => s.text.startsWith('ADX'));
  const adxMatch = adxLine && adxLine.text.match(/ADX ([\d.]+)/);
  const adxVal = adxMatch ? parseFloat(adxMatch[1]) : null;
  if (adxVal !== null && adxVal < cfg.minAdx) return null; // trend too weak to trust a directional call

  const direction = net > 0 ? 'LONG' : 'SHORT';
  const atrArr = TA.atr(candles, 14);
  const atrVal = atrArr[atrArr.length - 1];
  const price = closes[closes.length - 1];
  if (!atrVal || !price) return null;

  const stopLoss = direction === 'LONG' ? price - atrVal * cfg.atrStopMult : price + atrVal * cfg.atrStopMult;
  const takeProfit = direction === 'LONG' ? price + atrVal * cfg.atrTpMult : price - atrVal * cfg.atrTpMult;

  // Confidence: how much of the signal set agrees, nudged up slightly for
  // a strong trend read (ADX). Deliberately conservative — this is a
  // heuristic score, not a win-probability; see signalConfluence.js's
  // header comment for why "agreement" and "confirmation" aren't the same
  // claim.
  const total = buys + sells + signals.filter((s) => s.type === 'neut').length;
  let confidence = total > 0 ? Math.abs(net) / total : 0;
  if (adxVal !== null && adxVal >= 40) confidence = Math.min(1, confidence + 0.1);
  confidence = Math.max(0, Math.min(1, confidence));

  const breakdown = signals.filter((s) => s.type === 'buy' || s.type === 'sell').map((s) => s.text);

  return { direction, price, stopLoss, takeProfit, confidence, adxVal, buys, sells, breakdown };
}

const DEFAULTS = {
  enabled: false,
  symbols: [],               // e.g. ["SOL", "ETH", "BTC"] — bare tickers
  timeframe: '1h',
  scanIntervalMs: 5 * 60 * 1000,   // 5 min between scans
  minNetConfluence: 3,             // |buys - sells| from generateSignals(), matches TonyBot's MIN_SIGNAL_CONSENSUS
  minAdx: 20,                      // don't propose a directional trade into a no-trend/choppy tape
  atrStopMult: 1.5,
  atrTpMult: 3.0,                  // ~2:1 reward:risk before fees
  maxLeverage: 10,                 // matches TonyBot's .env.example MAX_LEVERAGE default
  suggestLeverage: 5,
  cooldownMs: 45 * 60 * 1000,      // 45 min — no re-signal on the same coin sooner than this
  streakLookbackMs: 24 * 60 * 60 * 1000, // 24h window for the loss-streak check
  streakThreshold: 3,              // 3 rejected/failed in a row on a coin -> pause it
  streakCooldownMs: 24 * 60 * 60 * 1000, // pause that coin for 24h once tripped
  sizing: sizing.DEFAULTS,         // see sizing.js — Kelly/fixed position-size suggestion
  limits: {                        // volume friction — separate from cooldown/streak, which are reactive
    maxProposalsPerCoinPerDay: 3,  // hard cap regardless of how many "valid" setups fire on one coin in a day
    maxProposalsPerDayTotal: 10,   // hard cap across all coins combined
  },
  autoDiscover: {                  // supplements the static `symbols` list — was: hardcoded to a few majors
    enabled: false,                // opt-in: off preserves the exact old fixed-list behavior
    topN: 15,                      // scan this many of the most liquid USDT perps, by 24h quote volume
    refreshMs: 30 * 60 * 1000,     // how often to re-pull the liquidity ranking
  },
};

class TaSignalSource {
  /**
   * @param {import('./store').Store} store
   * @param {import('./approvalBot').ApprovalBot|null} approvalBot
   * @param {(level:string,msg:string,meta?:object)=>void} log
   * @param {object} opts - overrides for DEFAULTS, typically from config.json's signalEngine.taSource
   */
  constructor(store, approvalBot, log, opts) {
    this.store = store;
    this.approvalBot = approvalBot;
    this.log = log || (() => {});
    this.cfg = Object.assign({}, DEFAULTS, opts || {});
    // sizing is a nested config block — merge it one level deep so a
    // partial override (e.g. just { minTradesForKelly: 10 }) doesn't wipe
    // out the rest of sizing.DEFAULTS.
    this.cfg.sizing = Object.assign({}, sizing.DEFAULTS, (opts && opts.sizing) || {});
    this.cfg.limits = Object.assign({}, DEFAULTS.limits, (opts && opts.limits) || {});
    this.cfg.autoDiscover = Object.assign({}, DEFAULTS.autoDiscover, (opts && opts.autoDiscover) || {});
    this._discoveredSymbols = [];
    this._lastDiscoveryAt = 0;
    this._timer = null;
  }

  /** Static `symbols` (always scanned) plus, when autoDiscover is on, the
   *  most recently discovered liquid perps — deduped, uppercased. This
   *  replaces the old fixed 3-symbol coverage without removing the
   *  ability to pin specific coins you always want scanned regardless of
   *  whether they're currently in the top-N by volume. */
  activeSymbols() {
    const staticSyms = (this.cfg.symbols || []).map((s) => s.toUpperCase());
    return Array.from(new Set([...staticSyms, ...this._discoveredSymbols]));
  }

  /** Refreshes the auto-discovered liquid-perp list from perpsAlpha's
   *  market overview (one Binance ticker/24hr call regardless of universe
   *  size). Rate-limited by `refreshMs` — this does not hit the network
   *  on every scan cycle. On failure, keeps whatever list it already had
   *  rather than falling back to zero discovered symbols for one cycle. */
  async _refreshDiscoveredSymbols(fetchOverviewFn = perpsAlpha.fetchMarketOverview) {
    if (!this.cfg.autoDiscover.enabled) return;
    const now = Date.now();
    if (this._discoveredSymbols.length && now - this._lastDiscoveryAt < this.cfg.autoDiscover.refreshMs) return;
    try {
      const overview = await fetchOverviewFn(Math.max(this.cfg.autoDiscover.topN, 50));
      this._discoveredSymbols = perpsAlpha.topLiquidSymbols(overview, this.cfg.autoDiscover.topN);
      this._lastDiscoveryAt = now;
      this.log('info', 'refreshed auto-discovered liquid perp list', { count: this._discoveredSymbols.length, symbols: this._discoveredSymbols });
    } catch (e) {
      this.log('error', 'auto-discovery refresh failed, keeping previous list', { err: e.message, previousCount: this._discoveredSymbols.length });
    }
  }

  start() {
    if (!this.cfg.enabled) {
      this.log('info', 'taSource.enabled is false — Nexus TA will not generate its own trade proposals');
      return;
    }
    if (!this.cfg.symbols.length && !this.cfg.autoDiscover.enabled) {
      this.log('info', 'taSource has no symbols configured and autoDiscover is off — nothing to scan');
      return;
    }
    this.log('info', 'starting Nexus TA signal source', {
      symbols: this.cfg.symbols, autoDiscover: this.cfg.autoDiscover.enabled, intervalMs: this.cfg.scanIntervalMs,
    });
    this._runCycle(); // don't wait a full interval for the first scan
    this._timer = setInterval(() => this._runCycle(), this.cfg.scanIntervalMs);
    this._timer.unref?.();
  }

  stop() {
    if (this._timer) clearInterval(this._timer);
  }

  async _runCycle() {
    if (this.cfg.autoDiscover.enabled) await this._refreshDiscoveredSymbols();
    for (const symbol of this.activeSymbols()) {
      try {
        await this._scanOne(symbol);
      } catch (e) {
        this.log('error', 'taSource scan failed', { symbol, err: e.message });
      }
    }
  }

  /** True if this coin is currently cooling down (recent signal, tripped
   *  approval-flow rejection streak, or — the stronger check — a tripped
   *  real losing streak once enough trades have resolved). */
  _isCoolingDown(coin) {
    const now = Date.now();
    const last = this.store.lastForCoin(coin);
    if (last && now - last.createdAt < this.cfg.cooldownMs) {
      return `cooldown: last signal ${Math.round((now - last.createdAt) / 60000)}m ago`;
    }

    const lossStreak = this.store.recentLossStreak(coin, now - this.cfg.streakLookbackMs, this.cfg.streakThreshold + 2);
    if (lossStreak >= this.cfg.streakThreshold && last && now - last.createdAt < this.cfg.streakCooldownMs) {
      return `paused: ${lossStreak} REAL losses in a row on ${coin} (price hit stop-loss)`;
    }

    const rejectStreak = this.store.recentRejectionStreak(coin, now - this.cfg.streakLookbackMs, this.cfg.streakThreshold + 2);
    if (rejectStreak >= this.cfg.streakThreshold && last && now - last.createdAt < this.cfg.streakCooldownMs) {
      return `paused: ${rejectStreak} rejected/failed signals in a row on ${coin}`;
    }
    return null;
  }

  /** Picks the most trustworthy stats slice available for sizing this
   *  proposal: prefer this exact coin's resolved history once it has
   *  enough trades to size Kelly off of; otherwise fall back to the
   *  whole nexus_ta strategy's history (still a real, checkable sample,
   *  just less coin-specific); computeSize() falls back to a fixed size
   *  itself if neither slice clears minTradesForKelly. */
  _relevantStats(coin) {
    const perCoin = this.store.getStats({ source: 'nexus_ta', coin });
    if (perCoin.n >= this.cfg.sizing.minTradesForKelly) return perCoin;
    const perSource = this.store.getStats({ source: 'nexus_ta' });
    if (perSource.n >= this.cfg.sizing.minTradesForKelly) return perSource;
    return perCoin.n >= perSource.n ? perCoin : perSource;
  }

  /** Volume friction, independent of cooldown/streak: those two react to
   *  rejections/losses after the fact, this caps raw proposal COUNT so a
   *  volatile day can't flood you with taps regardless of how "valid" each
   *  individual setup looks in isolation — directly targeting the
   *  sub-15-minute trade cluster from the original trade review, which
   *  looked like volume/fatigue as much as any one bad signal. */
  _isOverVolumeLimit(coin) {
    const now = Date.now();
    const dayAgo = now - 24 * 60 * 60 * 1000;
    const perCoin = this.store.countSince({ source: 'nexus_ta', coin, sinceTs: dayAgo });
    if (perCoin >= this.cfg.limits.maxProposalsPerCoinPerDay) {
      return `${perCoin}/${this.cfg.limits.maxProposalsPerCoinPerDay} proposals already sent for ${coin} in the last 24h`;
    }
    const total = this.store.countSince({ source: 'nexus_ta', sinceTs: dayAgo });
    if (total >= this.cfg.limits.maxProposalsPerDayTotal) {
      return `${total}/${this.cfg.limits.maxProposalsPerDayTotal} total proposals already sent in the last 24h`;
    }
    return null;
  }

  async _scanOne(symbol) {
    const coin = symbol.toUpperCase();
    const cooldown = this._isCoolingDown(coin);
    if (cooldown) {
      this.log('debug', 'skipping, on cooldown', { coin, reason: cooldown });
      return;
    }

    const overLimit = this._isOverVolumeLimit(coin);
    if (overLimit) {
      this.log('info', 'skipping, daily proposal volume cap reached', { coin, reason: overLimit });
      return;
    }

    const candles = await fetchPerpKlines(coin, this.cfg.timeframe, 150);
    const candidate = evaluateCandles(candles, this.cfg);
    if (!candidate) return;
    const { direction, price, stopLoss, takeProfit, confidence, adxVal, buys, sells, breakdown } = candidate;

    const leverage = Math.min(this.cfg.suggestLeverage, this.cfg.maxLeverage);

    const stats = this._relevantStats(coin);
    const sized = sizing.computeSize(stats, this.cfg.sizing);
    if (sized.skip) {
      this.log('info', 'skipping proposal — negative edge per resolved-trade stats', { coin, rationale: sized.rationale });
      return;
    }

    const sig = {
      channelId: 'nexus-ta',
      channelName: 'Nexus TA Engine',
      messageId: Date.now(), // synthetic, unique enough alongside coin+created_at for audit purposes
      coin,
      pair: `${coin}/USDT`,
      direction,
      entryMin: price,
      entryMax: price,
      takeProfits: [takeProfit],
      stopLoss,
      leverage,
      timeframe: this.cfg.timeframe,
      confidence,
      breakdown,
      rawText: `Auto-generated from Nexus indicators.js: ${buys} bullish / ${sells} bearish signals` +
        (adxVal !== null ? `, ADX ${adxVal.toFixed(1)}` : '') + '.',
      createdAt: Date.now(),
      source: 'nexus_ta',
      sizePct: sized.sizePct,
      sizeMethod: sized.method,
      sizeRationale: sized.rationale,
    };

    let id;
    try {
      id = this.store.saveSignal(sig);
    } catch (e) {
      this.log('error', 'taSource save failed', { coin, err: e.message });
      return;
    }
    this.log('info', 'nexus_ta signal saved', { id, coin, direction, confidence: confidence.toFixed(2) });

    if (this.approvalBot) {
      try {
        await this.approvalBot.sendApprovalRequest(id, sig);
      } catch (e) {
        this.log('error', 'taSource approval prompt failed', { id, err: e.message });
      }
    }
  }
}

module.exports = { TaSignalSource, fetchPerpKlines, evaluateCandles, DEFAULTS };
