#!/usr/bin/env node
'use strict';

/**
 * CLI: fetches real historical perp klines for a symbol and runs
 * taBacktest.js against them with a few threshold variants, so you can
 * see what your actual traded coins' history would have produced before
 * turning taSource loose live.
 *
 * Needs internet access (hits Binance's public klines endpoint) — this
 * sandbox has none, so this script is untested end-to-end here; the logic
 * it calls (evaluateCandles/runBacktest/compareVariants) IS unit-tested
 * with synthetic data in taBacktest.test.js.
 *
 * Usage:
 *   node src/signalEngine/runTaBacktest.js SOL 1h 500
 *   node src/signalEngine/runTaBacktest.js LSK 4h 300
 *
 * Args: SYMBOL (bare ticker) [TIMEFRAME=1h] [LIMIT=500, max 1500 per Binance]
 */

const { fetchPerpKlines, DEFAULTS: TA_DEFAULTS } = require('./taSignalSource');
const { compareVariants } = require('./taBacktest');

async function main() {
  const [symbol, timeframe = '1h', limitArg] = process.argv.slice(2);
  if (!symbol) {
    console.error('Usage: node runTaBacktest.js SYMBOL [TIMEFRAME=1h] [LIMIT=500]');
    process.exit(1);
  }
  const limit = Math.min(1500, parseInt(limitArg, 10) || 500);

  console.log(`Fetching ${limit} ${timeframe} candles for ${symbol.toUpperCase()}USDT perp...`);
  const candles = await fetchPerpKlines(symbol, timeframe, limit);
  console.log(`Got ${candles.length} candles, ${new Date(candles[0].t).toISOString()} -> ${new Date(candles[candles.length - 1].t).toISOString()}\n`);

  const base = {
    atrStopMult: TA_DEFAULTS.atrStopMult,
    atrTpMult: TA_DEFAULTS.atrTpMult,
    cooldownMs: TA_DEFAULTS.cooldownMs,
  };

  const variants = [
    { label: 'current default (confluence>=3, ADX>=20)', cfg: Object.assign({}, base, { minNetConfluence: 3, minAdx: 20 }) },
    { label: 'looser (confluence>=2, ADX>=15)', cfg: Object.assign({}, base, { minNetConfluence: 2, minAdx: 15 }) },
    { label: 'stricter (confluence>=4, ADX>=25)', cfg: Object.assign({}, base, { minNetConfluence: 4, minAdx: 25 }) },
    { label: 'very strict (confluence>=5, ADX>=30)', cfg: Object.assign({}, base, { minNetConfluence: 5, minAdx: 30 }) },
  ];

  const results = compareVariants(candles, variants);

  console.log('label'.padEnd(42), 'trades'.padStart(7), 'resolved'.padStart(9), 'winRate'.padStart(8), 'expectancy%'.padStart(12));
  for (const r of results) {
    const s = r.stats;
    const winRate = s.winRate !== null ? (s.winRate * 100).toFixed(0) + '%' : '—';
    const exp = s.expectancyPct !== null ? s.expectancyPct.toFixed(2) : '—';
    console.log(
      r.label.padEnd(42),
      String(r.tradeCount).padStart(7),
      String(s.n).padStart(9),
      winRate.padStart(8),
      exp.padStart(12)
    );
  }
  console.log('\n"resolved" excludes trades still open at the end of the fetched history.');
  console.log('This backtests taSignalSource\'s own decision logic only — it is not a general strategy backtester (see backtester.js for that), and past candles are not a promise about future ones.');
}

main().catch((e) => {
  console.error('backtest failed:', e.message);
  process.exit(1);
});
