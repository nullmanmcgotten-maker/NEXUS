'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Classifier } = require('./classify');
const { parseMessage } = require('./parser');
const { extractPair } = require('./extract');

function classifier(minConfidence = 0.8) {
  return new Classifier([
    '(?i)admin|announcement|welcome|rules'.replace('(?i)', ''),
    'target.*(hit|achieved|secured)',
    'premium|dm now|join vip',
    'good morning|how are you',
  ], minConfidence);
}

test('complete setup parses with high confidence', () => {
  const msg = { text: `
    🚀 STORJ/USDT LONG
    Entry Zone: 0.320 - 0.335
    TP1: 0.350
    TP2: 0.370
    TP3: 0.400
    Stop Loss: 0.300
    Leverage: 10x
    Timeframe: 4h
  ` };
  const res = parseMessage(msg, classifier(0.8));
  assert.ok(res.signal, `expected a signal, got reject reason=${res.reason}`);
  assert.equal(res.signal.coin, 'STORJ');
  assert.equal(res.signal.direction, 'LONG');
  assert.equal(res.signal.takeProfits.length, 3);
  assert.equal(res.signal.stopLoss, 0.3);
  assert.ok(res.signal.confidence >= 0.8);
});

test('rejects promo/VIP spam', () => {
  const msg = { text: '🔥 Join our PREMIUM VIP group now for 90% winrate signals! DM now!' };
  const res = parseMessage(msg, classifier(0.8));
  assert.equal(res.signal, null);
  assert.equal(res.reason, 'excluded');
});

test('rejects target-hit celebration post', () => {
  const msg = { text: 'BTC/USDT target 2 hit! +45% profit secured 🎉' };
  const res = parseMessage(msg, classifier(0.8));
  assert.equal(res.signal, null);
});

test('rejects incomplete setup (chatter with a coin mention)', () => {
  const msg = { text: 'ETH looking bullish today, might long soon if it breaks resistance' };
  const res = parseMessage(msg, classifier(0.8));
  assert.equal(res.signal, null);
  assert.equal(res.reason, 'low_confidence');
});

test('rejects plain chatter', () => {
  const msg = { text: 'Good morning everyone! How are you all doing today?' };
  const res = parseMessage(msg, classifier(0.8));
  assert.equal(res.signal, null);
});

test('extractPair rejects plain fiat mentions (no wildcard fallback)', () => {
  const { ok } = extractPair('the price of USD is going up');
  assert.equal(ok, false);
});

test('breakdown explains a low-confidence rejection', () => {
  const msg = { text: 'ETH looking bullish today, might long soon' };
  const res = parseMessage(msg, classifier(0.8));
  const missing = res.cand.breakdown.filter((b) => !b.found).map((b) => b.label);
  assert.ok(missing.includes('Entry price given'));
  assert.ok(missing.includes('Stop-loss given'));
});
