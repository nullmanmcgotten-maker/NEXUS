/**
 * store.js — ported from signalbot/internal/store/store.go, extended with
 * an approval workflow: every signal is written as status='pending' and
 * sits there until a human approves/rejects it via Telegram (see
 * approvalBot.js). TonyBot's bridge.py only ever reads status='approved'
 * rows and flips them to 'executed' once an order is placed — so a signal
 * can never reach the exchange without a human tap in between.
 */
'use strict';

const path = require('path');

let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  // Node < 22.5, or built without SQLite support.
  DatabaseSync = null;
}

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS processed_messages (
    channel_id   TEXT NOT NULL,
    message_id   INTEGER NOT NULL,
    processed_at INTEGER NOT NULL,
    PRIMARY KEY (channel_id, message_id)
  );

  CREATE TABLE IF NOT EXISTS signals (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id   TEXT NOT NULL,
    channel_name TEXT NOT NULL,
    message_id   INTEGER NOT NULL,
    coin         TEXT NOT NULL,
    pair         TEXT,
    direction    TEXT,
    entry_min    REAL,
    entry_max    REAL,
    take_profits TEXT, -- JSON array
    stop_loss    REAL,
    leverage     INTEGER,
    timeframe    TEXT,
    confidence   REAL,
    breakdown    TEXT, -- JSON array, for the "why" UI
    raw_text     TEXT,
    created_at   INTEGER NOT NULL,
    status       TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected | executed | failed
    status_note  TEXT,                             -- e.g. exchange error, or who approved
    decided_at   INTEGER,
    approval_msg_id INTEGER,                       -- Telegram message id of the approval prompt
    source       TEXT NOT NULL DEFAULT 'telegram', -- telegram | nexus_ta — who generated this signal
    outcome      TEXT,                             -- NULL until executed; then 'pending' | 'win' | 'loss'
    outcome_price REAL,                             -- price that resolved it (stop_loss or a take_profit)
    resolved_at  INTEGER,
    size_pct       REAL,   -- suggested position size, % of portfolio (see sizing.js)
    size_method    TEXT,   -- 'kelly' | 'fixed' — how size_pct was derived
    size_rationale TEXT,   -- human-readable explanation shown in the approval prompt
    current_stop_loss REAL,   -- live stop, may differ from stop_loss after a breakeven move (see exitManager.js)
    breakeven_moved_at INTEGER -- set once a breakeven-move notice has fired, so it only fires once per trade
  );

  CREATE INDEX IF NOT EXISTS idx_signals_coin ON signals(coin);
  CREATE INDEX IF NOT EXISTS idx_signals_created_at ON signals(created_at);
  CREATE INDEX IF NOT EXISTS idx_signals_status ON signals(status);
`;

class Store {
  constructor(dbPath) {
    if (!DatabaseSync) {
      throw new Error(
        'node:sqlite is unavailable (needs Node >= 22.5). Upgrade Node, or ' +
        'swap this module for a driver of your choice — Store is a small, ' +
        'self-contained class, see store.js.'
      );
    }
    this.db = new DatabaseSync(dbPath);
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA busy_timeout = 5000;');
    this.db.exec(SCHEMA);
    this._migrateStatusColumns();
  }

  // Safe to run against a pre-existing signals.db from before the approval
  // workflow existed — adds the new columns if they're missing, no-ops
  // otherwise. SQLite has no "ADD COLUMN IF NOT EXISTS", so check first.
  _migrateStatusColumns() {
    const cols = this.db.prepare("PRAGMA table_info(signals)").all().map((r) => r.name);
    const add = (name, ddl) => {
      if (!cols.includes(name)) this.db.exec(`ALTER TABLE signals ADD COLUMN ${ddl}`);
    };
    add('status', "status TEXT NOT NULL DEFAULT 'pending'");
    add('status_note', 'status_note TEXT');
    add('decided_at', 'decided_at INTEGER');
    add('approval_msg_id', 'approval_msg_id INTEGER');
    add('source', "source TEXT NOT NULL DEFAULT 'telegram'");
    add('outcome', 'outcome TEXT');
    add('outcome_price', 'outcome_price REAL');
    add('resolved_at', 'resolved_at INTEGER');
    add('size_pct', 'size_pct REAL');
    add('size_method', 'size_method TEXT');
    add('size_rationale', 'size_rationale TEXT');
    add('current_stop_loss', 'current_stop_loss REAL');
    add('breakeven_moved_at', 'breakeven_moved_at INTEGER');
  }

  seen(channelId, messageId) {
    const row = this.db
      .prepare('SELECT 1 FROM processed_messages WHERE channel_id = ? AND message_id = ?')
      .get(String(channelId), messageId);
    return !!row;
  }

  markSeen(channelId, messageId) {
    this.db
      .prepare('INSERT OR IGNORE INTO processed_messages (channel_id, message_id, processed_at) VALUES (?, ?, ?)')
      .run(String(channelId), messageId, Date.now());
  }

  /** Inserts a new signal as status='pending' and returns its row id. */
  saveSignal(sig) {
    const res = this.db.prepare(`
      INSERT INTO signals (
        channel_id, channel_name, message_id, coin, pair, direction,
        entry_min, entry_max, take_profits, stop_loss, leverage,
        timeframe, confidence, breakdown, raw_text, created_at, status, source,
        size_pct, size_method, size_rationale, current_stop_loss
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)
    `).run(
      String(sig.channelId), sig.channelName, sig.messageId, sig.coin, sig.pair || '', sig.direction || '',
      sig.entryMin, sig.entryMax, JSON.stringify(sig.takeProfits || []), sig.stopLoss, sig.leverage || 0,
      sig.timeframe || '', sig.confidence, JSON.stringify(sig.breakdown || []), sig.rawText,
      sig.createdAt || Date.now(), sig.source || 'telegram',
      sig.sizePct != null ? sig.sizePct : null, sig.sizeMethod || null, sig.sizeRationale || null,
      sig.stopLoss // current_stop_loss starts equal to the original stop_loss
    );
    return res.lastInsertRowid;
  }

  /** Most recent signal (any source) for this coin, or null. Used to enforce
   *  a per-coin cooldown so a scanner can't re-signal the same symbol every
   *  cycle — the pattern behind a lot of rapid-fire, small, choppy trades. */
  lastForCoin(coin) {
    const r = this.db
      .prepare('SELECT * FROM signals WHERE coin = ? ORDER BY created_at DESC, id DESC LIMIT 1')
      .get(coin);
    return r ? rowToSignal(r) : null;
  }

  /** Counts how many of the most recent `lookback` decided (approved/executed
   *  vs rejected/failed) signals for this coin, within `sinceTs`, ended up
   *  rejected or failed — a cheap proxy for "we keep getting told no (or the
   *  risk gate keeps blocking) on this symbol" without needing full PnL
   *  tracking. Used to pause a symbol after a losing/rejected streak instead
   *  of signaling into it again immediately. */
  recentRejectionStreak(coin, sinceTs, lookback = 5) {
    const rows = this.db
      .prepare(
        `SELECT status FROM signals
         WHERE coin = ? AND created_at >= ? AND status IN ('approved','rejected','executed','failed')
         ORDER BY created_at DESC, id DESC LIMIT ?`
      )
      .all(coin, sinceTs, lookback);
    let streak = 0;
    for (const r of rows) {
      if (r.status === 'rejected' || r.status === 'failed') streak++;
      else break; // streak is consecutive from most recent
    }
    return streak;
  }

  setApprovalMessageId(id, msgId) {
    this.db.prepare('UPDATE signals SET approval_msg_id = ? WHERE id = ?').run(msgId, id);
  }

  /** status: 'approved' | 'rejected' | 'executed' | 'failed' */
  setStatus(id, status, note) {
    this.db.prepare(
      'UPDATE signals SET status = ?, status_note = ?, decided_at = ? WHERE id = ?'
    ).run(status, note || null, Date.now(), id);
    // The moment bridge.py marks a row 'executed', it has a live position —
    // start tracking whether price later hits its stop_loss or take_profit.
    if (status === 'executed') {
      this.db.prepare("UPDATE signals SET outcome = 'pending' WHERE id = ?").run(id);
    }
  }

  /** Executed trades whose win/loss hasn't been determined yet. */
  getUnresolvedOutcomes(limit = 200) {
    const rows = this.db
      .prepare("SELECT * FROM signals WHERE status = 'executed' AND outcome = 'pending' ORDER BY decided_at ASC LIMIT ?")
      .all(limit);
    return rows.map(rowToSignal);
  }

  resolveOutcome(id, outcome, price) {
    this.db.prepare(
      'UPDATE signals SET outcome = ?, outcome_price = ?, resolved_at = ? WHERE id = ?'
    ).run(outcome, price, Date.now(), id);
  }

  /** Moves a trade's *live* stop (current_stop_loss) without touching the
   *  original stop_loss column — the original is preserved as the initial
   *  risk basis for R-multiple stats (see getStats()) even after a
   *  breakeven move. Records when it happened so a breakeven notice only
   *  fires once per trade (see exitManager.js / outcomeResolver.js). */
  updateStopLoss(id, newStop) {
    this.db.prepare(
      'UPDATE signals SET current_stop_loss = ?, breakeven_moved_at = ? WHERE id = ?'
    ).run(newStop, Date.now(), id);
  }

  /** Counts ALL signals (any status) for source (and optionally a specific
   *  coin) created since sinceTs — used to cap how many proposals can fire
   *  in a rolling window, independent of whether they were approved. */
  countSince({ source = null, coin = null, sinceTs = 0 } = {}) {
    const clauses = ['created_at >= ?'];
    const params = [sinceTs];
    if (source) { clauses.push('source = ?'); params.push(source); }
    if (coin) { clauses.push('coin = ?'); params.push(coin); }
    const row = this.db
      .prepare(`SELECT COUNT(*) AS n FROM signals WHERE ${clauses.join(' AND ')}`)
      .get(...params);
    return row ? row.n : 0;
  }

  /** Groups decided proposals (approved/rejected/executed/failed — i.e. a
   *  human or the risk gate actually acted on them) into confidence
   *  buckets and reports the approval rate per bucket. Lets you check
   *  whether you (or the risk gate) are actually approving high-confluence
   *  proposals more than low-confluence ones, or just approving everything
   *  regardless of the score — which would mean the score isn't doing
   *  anything for you. */
  approvalStatsByConfidence({ source = null, bucketSize = 0.2 } = {}) {
    const clauses = ["status IN ('approved','rejected','executed','failed')"];
    const params = [];
    if (source) { clauses.push('source = ?'); params.push(source); }
    const rows = this.db
      .prepare(`SELECT confidence, status FROM signals WHERE ${clauses.join(' AND ')}`)
      .all(...params);

    const buckets = new Map();
    for (const r of rows) {
      const c = r.confidence == null ? 0 : Math.max(0, Math.min(1, r.confidence));
      const lo = Math.min(1 - bucketSize, Math.floor(c / bucketSize) * bucketSize);
      const key = lo.toFixed(2);
      if (!buckets.has(key)) buckets.set(key, { bucket: key, total: 0, approvedOrExecuted: 0 });
      const b = buckets.get(key);
      b.total++;
      if (r.status === 'approved' || r.status === 'executed') b.approvedOrExecuted++;
    }
    return Array.from(buckets.values())
      .sort((a, b) => parseFloat(a.bucket) - parseFloat(b.bucket))
      .map((b) => Object.assign(b, { approvalRate: b.total ? b.approvedOrExecuted / b.total : null }));
  }

  /** Same idea as recentRejectionStreak but based on actual resolved
   *  outcome (win/loss from price action), not approval-flow status. This
   *  is the stronger signal once trades have had time to resolve — a coin
   *  can get approved and executed every time and still be losing money. */
  recentLossStreak(coin, sinceTs, lookback = 5) {
    const rows = this.db
      .prepare(
        `SELECT outcome FROM signals
         WHERE coin = ? AND resolved_at >= ? AND outcome IN ('win','loss')
         ORDER BY resolved_at DESC, id DESC LIMIT ?`
      )
      .all(coin, sinceTs, lookback);
    let streak = 0;
    for (const r of rows) {
      if (r.outcome === 'loss') streak++;
      else break;
    }
    return streak;
  }

  /** Real win/loss stats — the number that actually answers "is this
   *  working", as opposed to approval-flow status. `pct` is the average
   *  %-move captured relative to entry, signed by direction, which is a
   *  cleaner apples-to-apples metric than raw PNL across coins/position
   *  sizes (it doesn't need leverage or position size to compare setups). */
  getStats({ source = null, coin = null, sinceTs = 0 } = {}) {
    const clauses = ["outcome IN ('win','loss')", 'resolved_at >= ?'];
    const params = [sinceTs];
    if (source) { clauses.push('source = ?'); params.push(source); }
    if (coin) { clauses.push('coin = ?'); params.push(coin); }
    const rows = this.db
      .prepare(`SELECT * FROM signals WHERE ${clauses.join(' AND ')}`)
      .all(...params);

    if (!rows.length) return { n: 0, winRate: null, avgWinPct: null, avgLossPct: null, expectancyPct: null, avgWinR: null, avgLossR: null, expectancyR: null };

    const pctMove = (r) => {
      const dir = (r.direction || '').toUpperCase();
      const entry = r.entry_min;
      if (!entry || !r.outcome_price) return 0;
      const raw = (r.outcome_price - entry) / entry;
      return dir === 'SHORT' || dir === 'SELL' ? -raw * 100 : raw * 100;
    };

    // R-multiple: the %-move actually captured, expressed as a multiple of
    // the ORIGINAL initial risk (entry-to-stop_loss distance), not the
    // current stop after any breakeven move. This is what actually answers
    // "is average loss size eating average win size" — a 45% win rate with
    // wins averaging 2R and losses averaging -1R is profitable; a 45% win
    // rate with wins averaging 0.5R and losses averaging -1R is not, and
    // raw %-move alone can't tell you which one you have.
    const rMultiple = (r) => {
      const dir = (r.direction || '').toUpperCase();
      const entry = r.entry_min;
      if (!entry || !r.outcome_price || !r.stop_loss) return null;
      const riskDist = Math.abs(entry - r.stop_loss);
      if (!riskDist) return null;
      const moveDist = dir === 'SHORT' || dir === 'SELL' ? entry - r.outcome_price : r.outcome_price - entry;
      return moveDist / riskDist;
    };

    const wins = rows.filter((r) => r.outcome === 'win').map(pctMove);
    const losses = rows.filter((r) => r.outcome === 'loss').map(pctMove);
    const winRate = wins.length / rows.length;
    const avgWinPct = wins.length ? wins.reduce((a, b) => a + b, 0) / wins.length : 0;
    const avgLossPct = losses.length ? losses.reduce((a, b) => a + b, 0) / losses.length : 0;
    // Expectancy: average %-move per trade, win or lose — the number that
    // actually tells you if a 45% win rate is profitable or not, because it
    // accounts for win size vs loss size instead of just counting outcomes.
    const expectancyPct = winRate * avgWinPct + (1 - winRate) * avgLossPct;

    const winsR = rows.filter((r) => r.outcome === 'win').map(rMultiple).filter((v) => v !== null);
    const lossesR = rows.filter((r) => r.outcome === 'loss').map(rMultiple).filter((v) => v !== null);
    const avgWinR = winsR.length ? winsR.reduce((a, b) => a + b, 0) / winsR.length : null;
    const avgLossR = lossesR.length ? lossesR.reduce((a, b) => a + b, 0) / lossesR.length : null;
    const expectancyR = (avgWinR !== null && avgLossR !== null)
      ? winRate * avgWinR + (1 - winRate) * avgLossR
      : null;

    return { n: rows.length, winRate, avgWinPct, avgLossPct, expectancyPct, avgWinR, avgLossR, expectancyR };
  }

  getById(id) {
    const r = this.db.prepare('SELECT * FROM signals WHERE id = ?').get(id);
    return r ? rowToSignal(r) : null;
  }

  findByApprovalMsgId(msgId) {
    const r = this.db.prepare('SELECT * FROM signals WHERE approval_msg_id = ?').get(msgId);
    return r ? rowToSignal(r) : null;
  }

  /** Rows waiting on a human tap, oldest first (so approvals process in order). */
  getPending(limit = 50) {
    const rows = this.db
      .prepare("SELECT * FROM signals WHERE status = 'pending' ORDER BY created_at ASC LIMIT ?")
      .all(limit);
    return rows.map(rowToSignal);
  }

  /** Approved but not yet picked up by TonyBot's bridge. */
  getApprovedUnexecuted(limit = 50) {
    const rows = this.db
      .prepare("SELECT * FROM signals WHERE status = 'approved' ORDER BY decided_at ASC LIMIT ?")
      .all(limit);
    return rows.map(rowToSignal);
  }

  /** Newest first. */
  recentSignals(limit = 100) {
    const n = (limit > 0 && limit <= 500) ? limit : 100;
    const rows = this.db
      .prepare('SELECT * FROM signals ORDER BY created_at DESC LIMIT ?')
      .all(n);
    return rows.map(rowToSignal);
  }

  /** Deletes dedup rows older than maxAgeMs; returns rows removed. Signal audit rows are never auto-pruned. */
  pruneProcessed(maxAgeMs) {
    const cutoff = Date.now() - maxAgeMs;
    const res = this.db.prepare('DELETE FROM processed_messages WHERE processed_at < ?').run(cutoff);
    return res.changes;
  }

  close() {
    this.db.close();
  }
}

function safeParse(json, fallback) {
  if (!json) return fallback;
  try { return JSON.parse(json); } catch (e) { return fallback; }
}

function rowToSignal(r) {
  return {
    id: r.id,
    channelId: r.channel_id,
    channelName: r.channel_name,
    messageId: r.message_id,
    coin: r.coin,
    pair: r.pair,
    direction: r.direction,
    entryMin: r.entry_min,
    entryMax: r.entry_max,
    takeProfits: safeParse(r.take_profits, []),
    stopLoss: r.stop_loss,
    leverage: r.leverage,
    timeframe: r.timeframe,
    confidence: r.confidence,
    breakdown: safeParse(r.breakdown, []),
    rawText: r.raw_text,
    createdAt: r.created_at,
    status: r.status,
    statusNote: r.status_note,
    decidedAt: r.decided_at,
    approvalMsgId: r.approval_msg_id,
    source: r.source || 'telegram',
    outcome: r.outcome,
    outcomePrice: r.outcome_price,
    resolvedAt: r.resolved_at,
    sizePct: r.size_pct,
    sizeMethod: r.size_method,
    sizeRationale: r.size_rationale,
    currentStopLoss: r.current_stop_loss,
    breakevenMovedAt: r.breakeven_moved_at,
  };
}

function open(dbPath) {
  return new Store(path.resolve(dbPath));
}

module.exports = { Store, open };
