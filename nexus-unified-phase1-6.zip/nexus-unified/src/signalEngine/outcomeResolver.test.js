'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const { open: openStore } = require('./store');
const { OutcomeResolver } = require('./outcomeResolver');

function tmpDb() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'outc-')), 'test.db');
}

function mkSig(coin, direction, entry, stopLoss, tp, overrides = {}) {
  const now = Date.now();
  return Object.assign({
    channelId: 'nexus-ta', channelName: 'Nexus TA Engine', messageId: now,
    coin, pair: `${coin}/USDT`, direction, entryMin: entry, entryMax: entry,
    takeProfits: [tp], stopLoss, leverage: 5, timeframe: '1h',
    confidence: 0.5, breakdown: [], rawText: 'test', createdAt: now, source: 'nexus_ta',
  }, overrides);
}

test('OutcomeResolver: LONG resolves WIN when a candle high touches take-profit before stop', async () => {
  const store = openStore(tmpDb());
  const id = store.saveSignal(mkSig('SOL', 'LONG', 100, 95, 110));
  store.setStatus(id, 'executed', 'test'); // sets outcome='pending'

  const fakeKlines = async () => [
    { t: 1, o: 100, h: 102, l: 99, c: 101 },
    { t: 2, o: 101, h: 111, l: 100, c: 110 }, // touches TP=110
  ];
  const resolver = new OutcomeResolver(store, () => {}, {}, fakeKlines);
  await resolver._runCycle();

  const sig = store.getById(id);
  assert.equal(sig.outcome, 'win');
  assert.equal(sig.outcomePrice, 110);
  store.close();
});

test('OutcomeResolver: SHORT resolves LOSS when price rises to stop-loss', async () => {
  const store = openStore(tmpDb());
  const id = store.saveSignal(mkSig('LSK', 'SHORT', 1.0, 1.1, 0.8));
  store.setStatus(id, 'executed', 'test');

  const fakeKlines = async () => [
    { t: 1, o: 1.0, h: 1.05, l: 0.98, c: 1.02 },
    { t: 2, o: 1.02, h: 1.12, l: 1.0, c: 1.1 }, // touches stop=1.1
  ];
  const resolver = new OutcomeResolver(store, () => {}, {}, fakeKlines);
  await resolver._runCycle();

  const sig = store.getById(id);
  assert.equal(sig.outcome, 'loss');
  assert.equal(sig.outcomePrice, 1.1);
  store.close();
});

test('OutcomeResolver: stays pending when neither level has been touched yet', async () => {
  const store = openStore(tmpDb());
  const id = store.saveSignal(mkSig('ETH', 'LONG', 100, 95, 110));
  store.setStatus(id, 'executed', 'test');

  const fakeKlines = async () => [{ t: 1, o: 100, h: 103, l: 98, c: 101 }];
  const resolver = new OutcomeResolver(store, () => {}, {}, fakeKlines);
  await resolver._runCycle();

  const sig = store.getById(id);
  assert.equal(sig.outcome, 'pending');
  store.close();
});

test('store.getStats: computes win rate and signed expectancy across mixed win/loss trades', () => {
  const store = openStore(tmpDb());
  // LONG win: entry 100 -> tp 110 = +10%
  let id = store.saveSignal(mkSig('BTC', 'LONG', 100, 90, 110));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'win', 110);
  // SHORT win: entry 100 -> tp 80 = +20% (price fell, short profits)
  id = store.saveSignal(mkSig('BTC', 'SHORT', 100, 120, 80));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'win', 80);
  // LONG loss: entry 100 -> sl 90 = -10%
  id = store.saveSignal(mkSig('BTC', 'LONG', 100, 90, 110));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'loss', 90);

  const stats = store.getStats({ coin: 'BTC', sinceTs: 0 });
  assert.equal(stats.n, 3);
  assert.ok(Math.abs(stats.winRate - 2 / 3) < 1e-9);
  assert.ok(stats.avgWinPct > 0);
  assert.ok(stats.avgLossPct < 0);
  // expectancy should be positive here: two decent wins outweigh one loss
  assert.ok(stats.expectancyPct > 0);
  store.close();
});

test('OutcomeResolver: moves tracked stop to breakeven once price covers triggerR, and notifies once', async () => {
  const store = openStore(tmpDb());
  // entry 100, original stop 90 (risk=10), tp 130 far away so it isn't hit yet.
  const id = store.saveSignal(mkSig('SOL', 'LONG', 100, 90, 130));
  store.setStatus(id, 'executed', 'test');

  const fakeKlines = async () => [
    { t: 1, o: 100, h: 101, l: 99, c: 100 },  // no progress yet
    { t: 2, o: 100, h: 106, l: 99, c: 105 },  // +0.6R favorable -> should trigger breakeven (triggerR=0.5)
  ];
  const sent = [];
  const fakeNotifier = { send: async (text) => { sent.push(text); } };
  const resolver = new OutcomeResolver(store, () => {}, { breakeven: { triggerR: 0.5, enabled: true } }, fakeKlines, fakeNotifier);
  await resolver._runCycle();

  const sig = store.getById(id);
  assert.equal(sig.outcome, 'pending'); // neither TP nor the (now-moved) stop has been hit
  assert.ok(sig.currentStopLoss > 100); // moved above raw entry (fee buffer)
  assert.ok(sig.breakevenMovedAt != null);
  assert.equal(sent.length, 1);
  assert.match(sent[0], /SOL LONG/);
  store.close();
});

test('OutcomeResolver: a stop-out after breakeven has moved resolves using the NEW stop, not the original', async () => {
  const store = openStore(tmpDb());
  const id = store.saveSignal(mkSig('SOL', 'LONG', 100, 90, 130));
  store.setStatus(id, 'executed', 'test');

  const fakeKlines = async () => [
    { t: 1, o: 100, h: 106, l: 99, c: 105 },  // triggers breakeven mid-cycle
    { t: 2, o: 105, h: 106, l: 100.05, c: 101 }, // dips back down through the NEW (breakeven) stop, well above the original stop of 90
  ];
  const resolver = new OutcomeResolver(store, () => {}, { breakeven: { triggerR: 0.5, enabled: true, feeBufferPct: 0.001 } }, fakeKlines, null);
  await resolver._runCycle();

  const sig = store.getById(id);
  assert.equal(sig.outcome, 'loss'); // stopped out...
  assert.ok(sig.outcomePrice > 100); // ...but at the breakeven level, not the original stop of 90 — a scratch, not a full loss
  store.close();
});

test('OutcomeResolver: does not re-trigger or re-notify breakeven once already moved', async () => {
  const store = openStore(tmpDb());
  const id = store.saveSignal(mkSig('SOL', 'LONG', 100, 90, 130));
  store.setStatus(id, 'executed', 'test');
  store.updateStopLoss(id, 100.1); // simulate an earlier cycle already having moved it

  const fakeKlines = async () => [
    { t: 1, o: 105, h: 108, l: 104, c: 107 }, // still well in profit, would re-trigger if the guard were missing
  ];
  const sent = [];
  const fakeNotifier = { send: async (text) => { sent.push(text); } };
  const resolver = new OutcomeResolver(store, () => {}, { breakeven: { triggerR: 0.5, enabled: true } }, fakeKlines, fakeNotifier);
  await resolver._runCycle();

  assert.equal(sent.length, 0); // no second notification
  store.close();
});

test('store.getStats: also reports R-multiple stats (win/loss size relative to initial risk)', () => {
  const store = openStore(tmpDb());
  // LONG win: entry 100, stop 90 (risk=10), resolved at 120 -> +2R
  let id = store.saveSignal(mkSig('BTC', 'LONG', 100, 90, 120));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'win', 120);
  // LONG loss: entry 100, stop 90 (risk=10), resolved at 90 -> -1R
  id = store.saveSignal(mkSig('BTC', 'LONG', 100, 90, 120));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'loss', 90);

  const stats = store.getStats({ coin: 'BTC' });
  assert.ok(Math.abs(stats.avgWinR - 2) < 1e-9);
  assert.ok(Math.abs(stats.avgLossR - (-1)) < 1e-9);
  assert.ok(stats.expectancyR !== null);
  store.close();
});

test('store.countSince: counts all signals for a coin+source regardless of status', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  store.saveSignal(mkSig('SOL', 'LONG', 100, 90, 110, { createdAt: now - 1000 }));
  const id2 = store.saveSignal(mkSig('SOL', 'LONG', 100, 90, 110, { createdAt: now }));
  store.setStatus(id2, 'rejected', 'test');
  store.saveSignal(mkSig('ETH', 'LONG', 100, 90, 110, { createdAt: now }));

  assert.equal(store.countSince({ source: 'nexus_ta', coin: 'SOL', sinceTs: now - 24 * 3600 * 1000 }), 2);
  assert.equal(store.countSince({ source: 'nexus_ta', sinceTs: now - 24 * 3600 * 1000 }), 3);
  store.close();
});

test('store.approvalStatsByConfidence: buckets decided proposals and reports approval rate per bucket', () => {
  const store = openStore(tmpDb());
  const mk = (conf) => mkSig('BTC', 'LONG', 100, 90, 110, { confidence: conf });
  let id = store.saveSignal(mk(0.9)); store.setStatus(id, 'approved', 't');
  id = store.saveSignal(mk(0.85)); store.setStatus(id, 'approved', 't');
  id = store.saveSignal(mk(0.2)); store.setStatus(id, 'rejected', 't');
  id = store.saveSignal(mk(0.15)); store.setStatus(id, 'rejected', 't');

  const buckets = store.approvalStatsByConfidence({ source: 'nexus_ta', bucketSize: 0.2 });
  const high = buckets.find((b) => parseFloat(b.bucket) >= 0.8);
  const low = buckets.find((b) => parseFloat(b.bucket) < 0.2);
  assert.equal(high.approvalRate, 1);
  assert.equal(low.approvalRate, 0);
  store.close();
});

test('store.recentLossStreak: counts consecutive real losses by resolution time, stops at a win', () => {
  const store = openStore(tmpDb());
  const now = Date.now();
  let id = store.saveSignal(mkSig('LSK', 'SHORT', 1, 1.1, 0.9, { createdAt: now - 5000 }));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'win', 0.9); // oldest: a win
  id = store.saveSignal(mkSig('LSK', 'SHORT', 1, 1.1, 0.9, { createdAt: now - 4000 }));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'loss', 1.1);
  id = store.saveSignal(mkSig('LSK', 'SHORT', 1, 1.1, 0.9, { createdAt: now - 3000 }));
  store.setStatus(id, 'executed', 't'); store.resolveOutcome(id, 'loss', 1.1);

  // Two most recent resolved are losses; the one before is a win -> streak = 2
  assert.equal(store.recentLossStreak('LSK', now - 24 * 3600 * 1000, 5), 2);
  store.close();
});
