/**
 * config.js — ported from signalbot/internal/config/config.go, JSON instead
 * of YAML (no extra parser dependency needed — Node has JSON built in, and
 * this is now one config file for the whole unified app instead of a
 * separate one per service). Loading fails fast and loud: a bad config
 * should never surface three hours later as a silent "no signals ever
 * fire" bug.
 */
'use strict';

const fs = require('fs');

function applyDefaults(cfg) {
  cfg.telegram = cfg.telegram || {};
  cfg.telegram.sessionFile = cfg.telegram.sessionFile || 'session.txt';
  cfg.channels = cfg.channels || [];
  cfg.notification = cfg.notification || {};
  cfg.filters = cfg.filters || {};
  if (cfg.filters.minConfidence === undefined || cfg.filters.minConfidence === null) {
    cfg.filters.minConfidence = 0.8;
  }
  cfg.filters.excludePatterns = cfg.filters.excludePatterns || [];
  cfg.storage = cfg.storage || {};
  cfg.storage.sqlitePath = cfg.storage.sqlitePath || 'signalbot.db';
  cfg.storage.retainProcessedDays = cfg.storage.retainProcessedDays || 30;
  cfg.signalEngine = cfg.signalEngine || {};
  if (cfg.signalEngine.enabled === undefined) cfg.signalEngine.enabled = false;
  // taSource: Nexus's own indicators.js generating proposals (separate from
  // the Telegram parser above) — see signalEngine/taSignalSource.js. Off by
  // default; only starts if enabled=true AND symbols is non-empty.
  cfg.signalEngine.taSource = cfg.signalEngine.taSource || {};
  if (cfg.signalEngine.taSource.enabled === undefined) cfg.signalEngine.taSource.enabled = false;
  cfg.signalEngine.taSource.symbols = cfg.signalEngine.taSource.symbols || [];
  return cfg;
}

function validate(cfg) {
  const errs = [];
  // Telegram *channel watching* (MTProto login, reads channels you follow)
  // is only required if you actually listed channels to watch. This lets
  // taSource run standalone — proposing trades from Nexus's own TA instead
  // of parsing other people's calls — without needing a personal Telegram
  // API login at all.
  const wantsChannelWatching = cfg.signalEngine.enabled && cfg.channels.length > 0;
  if (wantsChannelWatching) {
    if (!cfg.telegram.apiId) errs.push('telegram.apiId is required when channels are configured');
    if (!cfg.telegram.apiHash) errs.push('telegram.apiHash is required when channels are configured');
  }
  if (cfg.signalEngine.enabled && (wantsChannelWatching || cfg.signalEngine.taSource.enabled)) {
    if (!cfg.notification.botToken) errs.push('notification.botToken is required when watching channels or taSource is enabled');
    if (!cfg.notification.chatId) errs.push('notification.chatId is required when watching channels or taSource is enabled');
  }
  if (cfg.signalEngine.taSource.enabled) {
    if (!cfg.signalEngine.taSource.symbols.length) {
      errs.push('signalEngine.taSource.symbols: at least one symbol is required when taSource.enabled is true');
    }
    if (!cfg.notification.botToken || !cfg.notification.chatId) {
      errs.push('notification.botToken/chatId are required when taSource.enabled is true — TA-generated proposals still go through the same Telegram Approve/Reject gate');
    }
  }
  for (let i = 0; i < cfg.filters.excludePatterns.length; i++) {
    try { new RegExp(cfg.filters.excludePatterns[i], 'i'); }
    catch (e) { errs.push(`filters.excludePatterns[${i}] ${JSON.stringify(cfg.filters.excludePatterns[i])}: ${e.message}`); }
  }
  if (cfg.filters.minConfidence < 0 || cfg.filters.minConfidence > 1) {
    errs.push('filters.minConfidence must be between 0 and 1');
  }
  if (errs.length) {
    throw new Error('invalid config:\n' + errs.map((e) => `  - ${e}`).join('\n'));
  }
}

function load(path) {
  let raw;
  try {
    raw = fs.readFileSync(path, 'utf8');
  } catch (e) {
    throw new Error(`read config ${path}: ${e.message}`);
  }
  let cfg;
  try {
    cfg = JSON.parse(raw);
  } catch (e) {
    throw new Error(`parse config ${path}: ${e.message}`);
  }
  cfg = applyDefaults(cfg);
  validate(cfg);
  return cfg;
}

module.exports = { load, applyDefaults, validate };
