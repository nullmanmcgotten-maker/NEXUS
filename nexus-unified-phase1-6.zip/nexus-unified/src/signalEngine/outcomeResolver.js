/**
 * outcomeResolver.js — closes the measurement loop.
 *
 * Nothing before this tracked whether an executed trade actually won or
 * lost — the signals table only recorded approval-flow status (approved/
 * rejected/executed/failed), which tells you what a human or the risk gate
 * decided, not what the market did afterward. Without this, "45% win rate"
 * or "the new taSource is better" are both just claims — this is what
 * makes them checkable.
 *
 * Same idea as TonyBot's own tonybot/core/signal_tracker.py
 * (resolve_pending: check high/low since the signal fired against its
 * stop_loss/take_profit, first one touched wins), ported here so Nexus's
 * signals table — which covers BOTH nexus_ta signals and Telegram signals
 * approved through the same pipeline — can report real stats independent
 * of whether TonyBot's own DB is reachable.
 */
'use strict';

const { fetchPerpKlines } = require('./taSignalSource');
const exitManager = require('./exitManager');

const DEFAULTS = {
  enabled: true,
  pollIntervalMs: 5 * 60 * 1000, // 5 min
  maxAgeMs: 14 * 24 * 60 * 60 * 1000, // give up tracking (mark 'none') after 14 days unresolved
  breakeven: exitManager.DEFAULTS,
};

class OutcomeResolver {
  /**
   * @param {import('./store').Store} store
   * @param {(level:string,msg:string,meta?:object)=>void} log
   * @param {object} opts - overrides for DEFAULTS
   * @param {(coin:string, interval:string, limit:number) => Promise<Array>} [fetchKlines] - injectable for tests; defaults to the real Binance fetch.
   * @param {{send:(text:string)=>Promise<void>}|null} [notifier] - if provided, a
   *   breakeven trigger sends you a plain-text Telegram notice (Nexus can't
   *   move your real exchange stop itself — see exitManager.js's header).
   */
  constructor(store, log, opts, fetchKlines, notifier) {
    this.store = store;
    this.log = log || (() => {});
    this.cfg = Object.assign({}, DEFAULTS, opts || {});
    this.cfg.breakeven = Object.assign({}, exitManager.DEFAULTS, (opts && opts.breakeven) || {});
    this._fetchKlines = fetchKlines || fetchPerpKlines;
    this.notifier = notifier || null;
    this._timer = null;
  }

  start() {
    if (!this.cfg.enabled) return;
    this._runCycle();
    this._timer = setInterval(() => this._runCycle(), this.cfg.pollIntervalMs);
    this._timer.unref?.();
  }

  stop() {
    if (this._timer) clearInterval(this._timer);
  }

  async _runCycle() {
    const pending = this.store.getUnresolvedOutcomes();
    for (const sig of pending) {
      try {
        await this._resolveOne(sig);
      } catch (e) {
        this.log('error', 'outcome resolve failed', { id: sig.id, coin: sig.coin, err: e.message });
      }
    }
  }

  async _resolveOne(sig) {
    const age = Date.now() - (sig.decidedAt || sig.createdAt);
    if (age > this.cfg.maxAgeMs) {
      this.store.resolveOutcome(sig.id, 'none', null);
      this.log('info', 'gave up tracking outcome (too old, still open)', { id: sig.id, coin: sig.coin });
      return;
    }

    // Pull candles since (roughly) the decision — 1m granularity, capped at
    // Binance's 1500-candle limit, generous enough for anything resolved
    // within maxAgeMs at 5-min polling.
    const minutesSince = Math.min(1440, Math.max(5, Math.ceil(age / 60000)));
    const candles = await this._fetchKlines(sig.coin, '1m', Math.min(1000, minutesSince + 5));
    if (!candles.length) return;

    const direction = (sig.direction || '').toUpperCase();
    const originalStop = sig.stopLoss; // initial risk basis — never overwritten, see store.updateStopLoss
    const takeProfit = (sig.takeProfits && sig.takeProfits[0]) || null;
    if (!originalStop || !takeProfit) return; // can't resolve without both levels

    // effectiveStop is what actually gets checked for a stop-out this
    // cycle — it starts at whatever store already has (possibly already
    // moved to breakeven on a prior cycle) and can move again mid-loop if
    // this cycle's candles cross the breakeven trigger.
    let effectiveStop = sig.currentStopLoss != null ? sig.currentStopLoss : originalStop;
    let breakevenAlreadyMoved = sig.breakevenMovedAt != null;

    // Walk candles in order — first level touched wins, same
    // stop-takes-precedence-on-simultaneous-touch rule as TonyBot's tracker.
    for (const c of candles) {
      const hitSl = direction === 'LONG' || direction === 'BUY' ? c.l <= effectiveStop : c.h >= effectiveStop;
      const hitTp = direction === 'LONG' || direction === 'BUY' ? c.h >= takeProfit : c.l <= takeProfit;
      if (hitSl) {
        this.store.resolveOutcome(sig.id, 'loss', effectiveStop);
        this.log('info', breakevenAlreadyMoved ? 'outcome resolved: SCRATCH (breakeven stop hit)' : 'outcome resolved: LOSS', { id: sig.id, coin: sig.coin });
        return;
      }
      if (hitTp) {
        this.store.resolveOutcome(sig.id, 'win', takeProfit);
        this.log('info', 'outcome resolved: WIN', { id: sig.id, coin: sig.coin });
        return;
      }

      if (!breakevenAlreadyMoved) {
        const favorablePrice = direction === 'LONG' || direction === 'BUY' ? c.h : c.l;
        const check = exitManager.checkBreakeven(
          { direction, entry: sig.entryMin, stopLoss: originalStop, currentPrice: favorablePrice },
          this.cfg.breakeven
        );
        if (check.trigger) {
          this.store.updateStopLoss(sig.id, check.newStop);
          effectiveStop = check.newStop;
          breakevenAlreadyMoved = true;
          this.log('info', 'breakeven trigger — moved tracked stop', { id: sig.id, coin: sig.coin, r: check.r.toFixed(2), newStop: check.newStop });
          if (this.notifier) {
            const dirLabel = direction === 'SHORT' || direction === 'SELL' ? 'SHORT' : 'LONG';
            const text = `\u26a0\ufe0f ${sig.coin} ${dirLabel} has moved ${check.r.toFixed(2)}R in your favor.\n` +
              `Nexus is tracking this as breakeven now (${check.newStop.toFixed(6)}) for its own stats \u2014 ` +
              `move your real stop-loss on the exchange to lock it in if you want the same protection.`;
            try { await this.notifier.send(text); } catch (e) { this.log('error', 'breakeven notice send failed', { id: sig.id, err: e.message }); }
          }
        }
      }
    }
    // Neither level touched yet — leave outcome='pending', check again next cycle.
  }
}

module.exports = { OutcomeResolver, DEFAULTS };
