/**
 * ingest.js — Telegram MTProto ingest, using teleproto (an actively
 * maintained fork of gram.js; the original `telegram` package on npm is
 * archived — see teleproto's README) as the Node equivalent of Go's
 * gotd/td used by the original signalbot.
 *
 * This uses `client.updates.watch(channel, handler)` rather than a manual
 * "resolve once, filter every update" registry. That's a genuine
 * correctness fix, not just a style choice: Telegram only streams updates
 * for a channel to a session that is either a member of it or explicitly
 * kept "watched" — a channel you've merely resolved (looked up) but never
 * joined can silently stop producing updates. `watch()` handles keeping
 * that subscription alive and tears it down cleanly via the function it
 * returns; the original design (both the Go version and this file's first
 * draft) didn't surface that distinction.
 *
 * This sandbox has no network path to Telegram's MTProto servers, so this
 * file is written-but-not-live-verified here — same status the original
 * Go listener.go shipped in. Exercise it against a real account/session
 * before trusting it unattended.
 */
'use strict';

const { TelegramClient } = require('teleproto');
const { StringSession } = require('teleproto/sessions');

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/**
 * @param {object} opts
 * @param {number} opts.apiId
 * @param {string} opts.apiHash
 * @param {string} opts.sessionString - empty string on first run; persist what
 *   client.session.save() returns after login so you aren't re-prompted.
 * @param {string[]} opts.channels - usernames to monitor
 * @param {(sessionString:string)=>void} opts.onSession - called after login with
 *   the session string to persist to disk
 * @param {import('./pipeline').Pipeline} opts.pipeline
 * @param {(level:string,msg:string,meta?:object)=>void} opts.log
 * @returns {Promise<{client: TelegramClient, stop: () => Promise<void>}>}
 */
async function startListener({ apiId, apiHash, sessionString, channels, onSession, pipeline, log }) {
  const session = new StringSession(sessionString || '');
  const client = new TelegramClient(session, apiId, apiHash, { connectionRetries: 5 });

  await client.start({
    phoneNumber: async () => promptStdin('Phone number (with country code): '),
    password: async () => promptStdin('2FA password (leave blank if none): '),
    phoneCode: async () => promptStdin('Login code Telegram just sent you: '),
    onError: (err) => log('error', 'telegram login error', { err: err.message }),
  });

  if (onSession) onSession(client.session.save());

  // One handler shared across every watched channel; the channel identity
  // comes off the update itself so we don't need a separate resolve pass.
  const handleUpdate = async (update) => {
    const msg = update?.message;
    if (!msg || !msg.message) return; // no text (media-only, service message, etc.)
    const chat = await msg.getChat().catch(() => null);
    const channelName = chat?.username || chat?.title || String(msg.peerId?.channelId ?? 'unknown');
    const channelId = String(msg.peerId?.channelId ?? channelName);

    await pipeline.handle({
      channelId,
      channelName,
      messageId: msg.id,
      text: msg.message,
      postedAt: msg.date ? msg.date * 1000 : Date.now(),
    });
  };

  const stops = [];
  let watchedCount = 0;
  // Watched sequentially with a pause between each, same reasoning as the
  // Go version's ResolveChannels rate limit: doing 15+ of these back to
  // back on a cold start risks Telegram's FLOOD_WAIT.
  for (const chan of channels) {
    try {
      const stop = client.updates.watch(chan, handleUpdate);
      stops.push(stop);
      watchedCount++;
      log('info', 'watching channel', { channel: chan });
    } catch (e) {
      log('error', 'watch channel failed', { channel: chan, err: e.message });
      // one bad channel name shouldn't take the whole bot down
    }
    await sleep(1500);
  }
  if (watchedCount === 0) {
    await client.disconnect();
    throw new Error('no configured channels could be watched successfully');
  }

  log('info', 'listening for updates', { channels: watchedCount });

  return {
    client,
    stop: async () => {
      for (const s of stops) { try { s(); } catch (e) { /* already stopped */ } }
      await client.disconnect();
    },
  };
}

function promptStdin(question) {
  return new Promise((resolve) => {
    process.stdout.write(question);
    process.stdin.resume();
    process.stdin.once('data', (d) => {
      process.stdin.pause();
      resolve(d.toString().trim());
    });
  });
}

module.exports = { startListener };
