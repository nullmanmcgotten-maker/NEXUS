/**
 * telegramSignals.js — displays signals from the in-process signal engine
 * (src/signalEngine, formerly the separate signalbot Go service — now
 * merged into this same server, see server.js's /api/signals route).
 *
 * Trust model — read this before wiring it into anything else:
 * These are OTHER PEOPLE'S calls from Telegram channels, filtered for
 * completeness (has entry/TP/SL/etc) and confidence-scored, but NEVER
 * vetted for whether the channel's calls are actually good. The confidence
 * score measures setup completeness, not call quality. The technical
 * confluence check (SignalConfluence, see signalConfluence.js) is
 * corroborating evidence at best — RSI/MACD/BB agreeing with a channel's
 * stated direction is not confirmation that the trade will work. Nothing
 * on this panel is a recommendation, and none of it should be read as one.
 */
'use strict';

let _tgSignalsEndpoint = ''; // '' = same-origin /api/signals (the in-process engine)
(function(){ try { const s = localStorage.getItem('nexus_tg_signals_endpoint'); if (s) _tgSignalsEndpoint = s; } catch(e){} })();
function setTelegramSignalsEndpoint(url) {
  _tgSignalsEndpoint = url.replace(/\/$/, '');
  try { localStorage.setItem('nexus_tg_signals_endpoint', _tgSignalsEndpoint); } catch(e){}
  loadTelegramSignals();
}
function resetTelegramSignalsEndpoint() {
  _tgSignalsEndpoint = '';
  try { localStorage.removeItem('nexus_tg_signals_endpoint'); } catch(e){}
  loadTelegramSignals();
}

let _tgSignals = [];
let _tgSignalsStatus = 'not connected';
let _tgExpanded = new Set(); // messageId/createdAt keys currently expanded
let _tgTier = 'free';
let _tgDelayedMinutes = 0;
let _tgFreeLimit = null;

async function loadTelegramSignals() {
  _tgSignalsStatus = 'checking…';
  renderTelegramSignalsPanel();
  try {
    const base = _tgSignalsEndpoint || '';
    const health = await fetch(`${base}/api/signals/health`, { signal: AbortSignal.timeout(3000) });
    if (!health.ok) throw new Error(`health check HTTP ${health.status}`);
    const healthJson = await health.json().catch(() => ({}));

    const res = await fetch(`${base}/api/signals?limit=30`, { signal: AbortSignal.timeout(5000), credentials: 'same-origin' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const payload = await res.json();
    // Same-origin built-in engine returns {tier, delayedMinutes, limit, signals};
    // a bare array is still accepted for custom/remote endpoints running an
    // older wire format.
    if (Array.isArray(payload)) {
      _tgSignals = payload;
      _tgTier = 'pro'; // remote endpoints aren't paywalled by this app
      _tgDelayedMinutes = 0;
      _tgFreeLimit = null;
    } else {
      _tgSignals = payload.signals || [];
      _tgTier = payload.tier || 'free';
      _tgDelayedMinutes = payload.delayedMinutes || 0;
      _tgFreeLimit = payload.limit ?? null;
    }

    if (healthJson.signalEngineEnabled === false) {
      _tgSignalsStatus = `signal engine is off — set signalEngine.enabled: true in config.json and add your Telegram channels to start receiving signals`;
    } else {
      _tgSignalsStatus = `connected — ${_tgSignals.length} recent signals`;
    }
  } catch (e) {
    _tgSignals = [];
    _tgSignalsStatus = `not connected (${e.message})`;
  }
  renderTelegramSignalsPanel();
}

async function startProUpgrade() {
  try {
    const res = await fetch('/api/billing/checkout', { method: 'POST', credentials: 'same-origin' });
    const json = await res.json();
    if (json.url) { window.location.href = json.url; return; }
    if (json.error && /log in/i.test(json.error)) {
      alert('Create a free account or log in first (top-right), then hit Upgrade again.');
    } else {
      alert('Upgrade unavailable: ' + (json.error || 'unknown error'));
    }
  } catch (e) {
    alert('Upgrade unavailable: ' + e.message);
  }
}

function fmtTgPrice(v) {
  if (v === null || v === undefined || v === 0) return '—';
  return v < 1 ? v.toFixed(6) : v.toFixed(2);
}

function tgSignalKey(s) {
  return `${s.channel}:${s.coin}:${s.createdAt}`;
}

function toggleTgSignal(key) {
  if (_tgExpanded.has(key)) _tgExpanded.delete(key); else _tgExpanded.add(key);
  renderTelegramSignalsPanel();
}

function renderTelegramSignalsPanel() {
  const el = document.getElementById('telegramSignalsPanel');
  if (!el) return;

  const statusColor = _tgSignals.length ? 'var(--green)' : 'var(--muted)';
  const usingCustomEndpoint = !!_tgSignalsEndpoint;
  const header = `
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:10px;">
      <div>
        <span style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;">📡 Telegram Channel Signals</span>
        <span style="font-family:var(--mono);font-size:10px;color:${statusColor};margin-left:8px;">${esc(_tgSignalsStatus)}</span>
      </div>
      <div style="display:flex;gap:8px;align-items:center;">
        ${usingCustomEndpoint ? `<input class="inp compact" id="tgEndpointInput" placeholder="http://127.0.0.1:8090" value="${escAttr(_tgSignalsEndpoint)}" style="width:180px;font-size:10px;"/>
        <button class="btn-sm" onclick="setTelegramSignalsEndpoint(document.getElementById('tgEndpointInput').value)">Connect</button>
        <button class="btn-sm" onclick="resetTelegramSignalsEndpoint()" title="Use this server's own signal engine instead">Use built-in</button>` :
        `<button class="btn-sm" onclick="setTelegramSignalsEndpoint(prompt('Point at a signal engine running elsewhere:', 'http://127.0.0.1:8090') || '')" title="Only needed if you're running the signal engine on a different machine/port">Use remote…</button>`}
        <button class="btn-sm" onclick="loadTelegramSignals()">⟳</button>
      </div>
    </div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--amber);background:rgba(245,166,35,.1);border:1px solid rgba(245,166,35,.3);border-radius:6px;padding:8px 12px;margin-bottom:12px;">
      ⚠ Unverified third-party content from Telegram channels — NOT computed by Nexus, NOT vetted for call quality. The confidence score reflects setup completeness (has entry/TP/SL), not whether the channel is any good. The "TA check" badge compares the channel's stated direction against Nexus's own RSI/MACD/BB/EMA reading for that asset — agreement is corroborating evidence, not confirmation. Tap a signal to see exactly why it scored the way it did. Nothing here is financial advice or a guarantee of profit.
    </div>
    ${_tgTier !== 'pro' ? `
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-family:var(--mono);font-size:11px;color:var(--text);background:rgba(80,120,255,.08);border:1px solid rgba(80,120,255,.35);border-radius:6px;padding:10px 12px;margin-bottom:12px;">
      <span>🔒 Free tier: showing up to ${_tgFreeLimit ?? 3} signals, delayed ${_tgDelayedMinutes || 30} min. Pro removes the delay and cap, and unlocks full TA-confluence breakdowns as they post.</span>
      <button class="btn-sm" style="white-space:nowrap;" onclick="startProUpgrade()">Upgrade to Pro</button>
    </div>` : ''}`;

  if (!_tgSignals.length) {
    el.innerHTML = header + `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:12px 0;">No signals to show yet. ${usingCustomEndpoint ? 'Check the remote signal engine is running and reachable.' : 'Enable the signal engine in config.json and add channels to watch — see config.example.json.'}</div>`;
    return;
  }

  const rows = _tgSignals.map(s => {
    const key = tgSignalKey(s);
    const expanded = _tgExpanded.has(key);
    const dirColor = s.direction === 'LONG' ? 'var(--green)' : s.direction === 'SHORT' ? 'var(--red)' : 'var(--muted)';
    const entry = s.entryMin === s.entryMax ? fmtTgPrice(s.entryMin) : `${fmtTgPrice(s.entryMin)}–${fmtTgPrice(s.entryMax)}`;
    const tps = (s.takeProfits || []).map(fmtTgPrice).join(', ') || '—';

    const breakdownRows = (s.breakdown || []).map(b => `
      <div style="display:flex;justify-content:space-between;gap:10px;padding:2px 0;">
        <span style="color:${b.found?'var(--green)':'var(--muted)'};">${b.found?'✓':'✗'} ${esc(b.label)}</span>
        <span style="color:var(--muted);">${b.found?'+':''}${(b.weight*100).toFixed(0)}%</span>
      </div>`).join('');

    return `<div class="ts-card" style="cursor:pointer;" onclick="toggleTgSignal('${key.replace(/'/g,"\\'")}')">
      <div class="ts-card-hdr">
        <span class="perp-sym">${esc(s.coin || '?')}</span>
        <span style="color:${dirColor};font-family:var(--mono);font-weight:700;font-size:12px;">${esc(s.direction || '')}</span>
        <span id="tgConf_${cssId(key)}" style="margin-left:auto;font-family:var(--mono);font-size:10px;color:var(--muted);">via ${esc(s.channel)} · confidence ${(s.confidence*100).toFixed(0)}% · ${new Date(s.createdAt).toLocaleString()}</span>
      </div>
      <div style="font-family:var(--mono);font-size:11px;color:var(--text);display:flex;gap:16px;flex-wrap:wrap;">
        <span>Entry: ${entry}</span>
        <span>TP: ${tps}</span>
        <span>SL: ${fmtTgPrice(s.stopLoss)}</span>
        ${s.leverage ? `<span>Leverage: ${s.leverage}x</span>` : ''}
        ${s.timeframe ? `<span>TF: ${esc(s.timeframe)}</span>` : ''}
        <span id="tgTaBadge_${cssId(key)}" style="margin-left:auto;">⋯ checking TA…</span>
      </div>
      ${expanded ? `
        <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--border);font-family:var(--mono);font-size:10px;">
          <div style="color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;">Why this confidence score (setup completeness)</div>
          ${breakdownRows}
          <div id="tgTaDetail_${cssId(key)}" style="margin-top:8px;color:var(--muted);">Loading technical analysis check…</div>
        </div>` : ''}
    </div>`;
  }).join('');

  el.innerHTML = header + `<div class="ts-grid">${rows}</div>`;

  // Fire off (or reuse cached) confluence checks per visible signal, async
  // so the panel renders immediately and badges fill in as they resolve.
  _tgSignals.forEach(s => {
    const key = tgSignalKey(s);
    const id = cssId(key);
    if (typeof SignalConfluence === 'undefined') return;
    SignalConfluence.check(s.coin, s.direction).then(result => {
      const badge = SignalConfluence.badge(result.status);
      const badgeEl = document.getElementById(`tgTaBadge_${id}`);
      if (badgeEl) badgeEl.innerHTML = `<span style="color:${badge.color};">${esc(badge.text)}</span>`;
      const detailEl = document.getElementById(`tgTaDetail_${id}`);
      if (detailEl) {
        if (result.status === 'unavailable') {
          detailEl.innerHTML = `<div style="color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;">Technical analysis check</div>Unavailable: ${esc(result.error || 'unknown error')}`;
        } else {
          const lines = (result.taSignals || []).slice(1, 6).map(t => `<div>• ${esc(t.text)}</div>`).join('');
          detailEl.innerHTML = `<div style="color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;">Technical analysis check (1h, live Binance data)</div><div style="margin-bottom:4px;">${esc(result.biasLine || '')}</div>${lines}<div style="margin-top:6px;color:var(--amber);">Agreement with the channel's stated direction is corroborating evidence, not confirmation.</div>`;
        }
      }
    }).catch(() => {
      const badgeEl = document.getElementById(`tgTaBadge_${id}`);
      if (badgeEl) badgeEl.innerHTML = `<span style="color:var(--muted);">TA check failed</span>`;
    });
  });
}

function cssId(key) {
  return key.replace(/[^a-zA-Z0-9]/g, '_');
}
