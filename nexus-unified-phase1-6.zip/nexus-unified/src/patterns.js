/**
 * patterns.js — Chart pattern scanner: double top/bottom, head & shoulders,
 * bull/bear flag, ascending/descending triangle, divergence.
 */
function detectPatterns(candles){
  if(candles.length<20) return [];
  const signals=[], h=candles.map(c=>c.h), l=candles.map(c=>c.l), cl=candles.map(c=>c.c);
  const n=candles.length, last=n-1;

  // Find local peaks/troughs
  const peaks=[], troughs=[];
  for(let i=2;i<n-2;i++){
    if(h[i]>h[i-1]&&h[i]>h[i-2]&&h[i]>h[i+1]&&h[i]>h[i+2]) peaks.push({i,v:h[i]});
    if(l[i]<l[i-1]&&l[i]<l[i-2]&&l[i]<l[i+1]&&l[i]<l[i+2]) troughs.push({i,v:l[i]});
  }

  // Double Top
  if(peaks.length>=2){
    const p1=peaks[peaks.length-2], p2=peaks[peaks.length-1];
    if(Math.abs(p1.v-p2.v)/p1.v<0.02 && p2.i-p1.i>=5){
      signals.push({pattern:'Double Top',type:'bearish',confidence:'High',desc:`Two peaks near $${fmtNum(p1.v,2)} — bearish reversal signal`,idx:p2.i});
    }
  }
  // Double Bottom
  if(troughs.length>=2){
    const t1=troughs[troughs.length-2], t2=troughs[troughs.length-1];
    if(Math.abs(t1.v-t2.v)/t1.v<0.02 && t2.i-t1.i>=5){
      signals.push({pattern:'Double Bottom',type:'bullish',confidence:'High',desc:`Two troughs near $${fmtNum(t1.v,2)} — bullish reversal signal`,idx:t2.i});
    }
  }
  // Head & Shoulders
  if(peaks.length>=3){
    const [left,head,right]=[peaks[peaks.length-3],peaks[peaks.length-2],peaks[peaks.length-1]];
    if(head.v>left.v&&head.v>right.v&&Math.abs(left.v-right.v)/left.v<0.04){
      signals.push({pattern:'Head & Shoulders',type:'bearish',confidence:'Medium',desc:`Head at $${fmtNum(head.v,2)}, shoulders at $${fmtNum(left.v,2)}/$${fmtNum(right.v,2)}`,idx:right.i});
    }
  }
  // Inverse H&S
  if(troughs.length>=3){
    const [left,head,right]=[troughs[troughs.length-3],troughs[troughs.length-2],troughs[troughs.length-1]];
    if(head.v<left.v&&head.v<right.v&&Math.abs(left.v-right.v)/left.v<0.04){
      signals.push({pattern:'Inv. Head & Shoulders',type:'bullish',confidence:'Medium',desc:`Head at $${fmtNum(head.v,2)}, shoulders at $${fmtNum(left.v,2)}/$${fmtNum(right.v,2)}`,idx:right.i});
    }
  }
  // Bull Flag (strong up move then tight consolidation)
  const recentH=cl.slice(-10), recentPre=cl.slice(-25,-10);
  const preMove=(recentPre[recentPre.length-1]-recentPre[0])/recentPre[0]*100;
  const consolidation=Math.max(...recentH)/Math.min(...recentH)-1;
  if(preMove>8&&consolidation<0.04)  signals.push({pattern:'Bull Flag',type:'bullish',confidence:'Medium',desc:`+${preMove.toFixed(1)}% pole, tight ${(consolidation*100).toFixed(1)}% flag — continuation likely`,idx:last});
  if(preMove<-8&&consolidation<0.04) signals.push({pattern:'Bear Flag',type:'bearish',confidence:'Medium',desc:`${preMove.toFixed(1)}% pole, tight ${(consolidation*100).toFixed(1)}% flag — breakdown likely`,idx:last});

  // Ascending Triangle (higher lows, flat resistance)
  if(troughs.length>=3){
    const lastTroughs=troughs.slice(-3);
    const risingLows=lastTroughs[2].v>lastTroughs[1].v&&lastTroughs[1].v>lastTroughs[0].v;
    const flatResist=Math.abs(h[last]-h[last-5])/h[last]<0.015;
    if(risingLows&&flatResist) signals.push({pattern:'Ascending Triangle',type:'bullish',confidence:'Medium',desc:`Rising lows + flat resistance at $${fmtNum(h[last],2)} — bullish breakout setup`,idx:last});
  }

  // RSI Divergence
  const rsi=TA.rsi(cl,14);
  if(peaks.length>=2&&rsi[peaks[peaks.length-1].i]!==null&&rsi[peaks[peaks.length-2].i]!==null){
    const p1=peaks[peaks.length-2],p2=peaks[peaks.length-1];
    const priceHigher=p2.v>p1.v, rsiLower=rsi[p2.i]<rsi[p1.i];
    if(priceHigher&&rsiLower) signals.push({pattern:'Bearish RSI Divergence',type:'bearish',confidence:'High',desc:`Price made higher high but RSI lower — momentum weakening`,idx:last});
    if(!priceHigher&&!rsiLower) signals.push({pattern:'Bullish RSI Divergence',type:'bullish',confidence:'High',desc:`Price made lower high but RSI higher — hidden strength`,idx:last});
  }

  return signals;
}

let _patternScanInterval=null;
function runPatternScan(){
  const el=document.getElementById('patternScanResults');if(!el)return;
  const allResults=[];
  positions.forEach(p=>{
    const h=window._priceHistory?.[p.sym]||[];
    if(h.length<25)return;
    const candles=h.map((x,i)=>({t:x.t,o:x.p,h:x.p*1.002,l:x.p*0.998,c:x.p,v:0}));
    const found=detectPatterns(candles);
    found.forEach(f=>allResults.push({...f,sym:p.sym,type2:p.type}));
  });
  if(!allResults.length){
    el.innerHTML='<div style="text-align:center;padding:24px;font-family:var(--mono);font-size:13px;color:var(--muted);">No patterns detected yet. Scanner needs 25+ price ticks per asset (accumulates from live WS data). Add crypto positions — they tick fastest.</div>';
    return;
  }
  const typeColor={bullish:'var(--green)',bearish:'var(--red)',neutral:'var(--muted)'};
  el.innerHTML=allResults.map(r=>`
    <div class="scanner-row">
      <div class="scanner-sym">${r.sym}</div>
      <div style="font-family:var(--mono);font-size:13px;font-weight:700;color:${typeColor[r.type]||'var(--muted)'};">${r.pattern}</div>
      <div style="font-family:var(--mono);font-size:12px;color:var(--muted);">${r.desc}</div>
      <div style="text-align:right;font-family:var(--mono);font-size:11px;color:var(--muted);">${r.confidence} confidence</div>
    </div>`).join('');
}
