/**
 * backtester.js — Strategy backtester on real Binance klines. No key needed.
 * Strategies: EMA Cross, RSI Reversal, MACD Signal, BB Breakout
 */
const STRATEGIES = {
  ema_cross: { name:'EMA Crossover', params:{fast:9,slow:21},
    run(c,p){ const cl=c.map(x=>x.c),f=TA.ema(cl,p.fast),s=TA.ema(cl,p.slow),tr=[];let pos=null;
      for(let i=1;i<c.length;i++){if(!f[i]||!s[i]||!f[i-1]||!s[i-1])continue;
        if(f[i]>s[i]&&f[i-1]<=s[i-1]&&!pos)pos={entry:c[i].c,entryIdx:i,t:c[i].t};
        if(f[i]<s[i]&&f[i-1]>=s[i-1]&&pos){tr.push({...pos,exit:c[i].c,exitIdx:i});pos=null;}}
      if(pos)tr.push({...pos,exit:c[c.length-1].c,exitIdx:c.length-1});return tr;}},
  rsi_reversal: { name:'RSI Mean Reversion', params:{period:14,os:30,ob:70},
    run(c,p){ const cl=c.map(x=>x.c),rsi=TA.rsi(cl,p.period),tr=[];let pos=null;
      for(let i=1;i<c.length;i++){if(rsi[i]===null)continue;
        if(rsi[i]<p.os&&!pos)pos={entry:c[i].c,entryIdx:i,t:c[i].t};
        if(rsi[i]>p.ob&&pos){tr.push({...pos,exit:c[i].c,exitIdx:i});pos=null;}}
      if(pos)tr.push({...pos,exit:c[c.length-1].c,exitIdx:c.length-1});return tr;}},
  macd_signal: { name:'MACD Signal Cross', params:{fast:12,slow:26,sig:9},
    run(c,p){ const cl=c.map(x=>x.c),m=TA.macd(cl,p.fast,p.slow,p.sig),tr=[];let pos=null;
      for(let i=1;i<c.length;i++){const h=m.histogram[i],hp=m.histogram[i-1];if(h===null||hp===null)continue;
        if(h>0&&hp<=0&&!pos)pos={entry:c[i].c,entryIdx:i,t:c[i].t};
        if(h<0&&hp>=0&&pos){tr.push({...pos,exit:c[i].c,exitIdx:i});pos=null;}}
      if(pos)tr.push({...pos,exit:c[c.length-1].c,exitIdx:c.length-1});return tr;}},
  bb_breakout: { name:'BB Breakout', params:{period:20,std:2},
    run(c,p){ const cl=c.map(x=>x.c),bb=TA.bollinger(cl,p.period,p.std),tr=[];let pos=null;
      for(let i=1;i<c.length;i++){if(!bb.upper[i]||!bb.middle[i])continue;
        if(cl[i]>bb.upper[i]&&!pos)pos={entry:c[i].c,entryIdx:i,t:c[i].t};
        if(pos&&cl[i]<bb.middle[i]){tr.push({...pos,exit:c[i].c,exitIdx:i});pos=null;}}
      if(pos)tr.push({...pos,exit:c[c.length-1].c,exitIdx:c.length-1});return tr;}},
};

function calcBTStats(trades, cap=10000) {
  if (!trades.length) return null;
  const rets = trades.map(t=>(t.exit-t.entry)/t.entry);
  const wins = rets.filter(r=>r>0), losses = rets.filter(r=>r<=0);
  let eq=cap; const curve=[cap];
  trades.forEach(t=>{eq*=(1+(t.exit-t.entry)/t.entry);curve.push(eq);});
  let peak=-Infinity,maxDD=0;
  curve.forEach(v=>{if(v>peak)peak=v;const dd=(peak-v)/peak*100;if(dd>maxDD)maxDD=dd;});
  return {
    n:trades.length, winRate:(wins.length/trades.length*100).toFixed(1),
    avgWin:wins.length?(wins.reduce((a,b)=>a+b,0)/wins.length*100).toFixed(2):0,
    avgLoss:losses.length?(losses.reduce((a,b)=>a+b,0)/losses.length*100).toFixed(2):0,
    profFactor:losses.length&&Math.abs(wins.reduce((a,b)=>a+b,0))>0?
      (Math.abs(wins.reduce((a,b)=>a+b,0))/Math.abs(losses.reduce((a,b)=>a+b,0))).toFixed(2):'∞',
    totalReturn:((eq-cap)/cap*100).toFixed(2), maxDD:maxDD.toFixed(2),
    finalEq:eq.toFixed(2), curve,
  };
}

let _btChart=null;
async function runBacktest(){
  const sym=document.getElementById('btSym')?.value.trim().toUpperCase()||'BTC';
  const sk=document.getElementById('btStrategy')?.value||'ema_cross';
  const iv=document.getElementById('btInterval')?.value||'1d';
  const lim=parseInt(document.getElementById('btLimit')?.value)||365;
  const cap=parseFloat(document.getElementById('btCapital')?.value)||10000;
  const el=document.getElementById('btResults'), btn=document.getElementById('btRunBtn');
  if(!el)return;
  btn.disabled=true; btn.textContent='⟳ Fetching…';
  el.innerHTML=`<div style="text-align:center;padding:24px;font-family:var(--mono);color:var(--muted);">Fetching ${lim} ${iv} candles for ${sym}/USDT from Binance…</div>`;
  try {
    const res=await fetch(`https://api.binance.com/api/v3/klines?symbol=${sym}USDT&interval=${iv}&limit=${lim}`);
    if(!res.ok) throw new Error('HTTP '+res.status+' — use BTC, ETH, SOL, DOGE, XRP etc.');
    const rows=await res.json();
    const candles=rows.map(d=>({t:+d[0],o:+d[1],h:+d[2],l:+d[3],c:+d[4],v:+d[5]}));
    const strat=STRATEGIES[sk], trades=strat.run(candles,strat.params);
    const st=calcBTStats(trades,cap);
    if(!st){el.innerHTML='<div style="color:var(--amber);font-family:var(--mono);padding:20px;text-align:center;">No trades generated — try a different interval or strategy.</div>';
      btn.disabled=false;btn.textContent='▶ Run Backtest';return;}
    const pos=parseFloat(st.totalReturn)>=0;
    el.innerHTML=`
      <div class="bt-stats-grid">
        <div class="bt-stat"><div class="bt-stat-l">Total Return</div><div class="bt-stat-v ${pos?'up':'dn'}">${pos?'+':''}${st.totalReturn}%</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Win Rate</div><div class="bt-stat-v">${st.winRate}%</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Trades</div><div class="bt-stat-v">${st.n}</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Profit Factor</div><div class="bt-stat-v ${parseFloat(st.profFactor)>=1?'up':'dn'}">${st.profFactor}</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Max Drawdown</div><div class="bt-stat-v dn">-${st.maxDD}%</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Final Equity</div><div class="bt-stat-v">$${parseFloat(st.finalEq).toLocaleString()}</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Avg Win</div><div class="bt-stat-v up">+${st.avgWin}%</div></div>
        <div class="bt-stat"><div class="bt-stat-l">Avg Loss</div><div class="bt-stat-v dn">${st.avgLoss}%</div></div>
      </div>
      <div style="position:relative;height:200px;margin-top:16px;"><canvas id="btEqChart"></canvas></div>
      <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-top:10px;">
        ${strat.name} · ${sym}/USDT · ${candles.length} ${iv} bars · $${cap.toLocaleString()} initial · Binance data
      </div>`;
    const ctx=document.getElementById('btEqChart').getContext('2d');
    if(_btChart)_btChart.destroy();
    _btChart=new Chart(ctx,{type:'line',data:{labels:st.curve.map((_,i)=>'T'+i),datasets:[{data:st.curve,borderColor:pos?'#00d4aa':'#ff4d6a',borderWidth:2,pointRadius:2,fill:true,backgroundColor:pos?'rgba(0,212,170,0.08)':'rgba(255,77,106,0.08)',tension:0.3}]},
      options:{responsive:true,maintainAspectRatio:false,animation:{duration:300},plugins:{legend:{display:false},tooltip:{backgroundColor:'#131920',callbacks:{label:c=>'$'+c.raw.toFixed(2)}}},
        scales:{x:{display:false},y:{display:true,position:'right',grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:'#5a6880',font:{family:"'IBM Plex Mono'",size:9},callback:v=>'$'+Math.round(v)}}}}});
  } catch(e) {
    el.innerHTML=`<div style="color:var(--red);font-family:var(--mono);padding:24px;text-align:center;">⚠ ${e.message}<br><br>Note: Backtester works with crypto only (Binance). Use BTC, ETH, SOL, DOGE, XRP, BNB, ADA.</div>`;
  }
  btn.disabled=false; btn.textContent='▶ Run Backtest';
}
