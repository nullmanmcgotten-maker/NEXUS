/** converter.js */
function buildConverter(){
  const currencies=Object.keys(fxRates);
  const opts=(sel)=>currencies.map(c=>`<option value="${c}"${c===sel?' selected':''}>${c}</option>`).join('');
  document.getElementById('converterUI').innerHTML=`
    <input class="inp" id="convAmt" type="number" value="1000" oninput="updateConversion()" style="margin-bottom:10px;">
    <div class="conv-row">
      <select class="inp" id="convFrom" onchange="updateConversion()">${opts('USD')}</select>
      <button class="conv-swap" onclick="swapConv()">⇌</button>
      <select class="inp" id="convTo" onchange="updateConversion()">${opts('EUR')}</select>
    </div>
    <div class="conv-result" id="convResult">—</div>
    <div class="conv-rate" id="convRate"></div>
    <div class="quick-pairs">
      ${['USD→EUR','USD→GHS','EUR→GBP','GBP→JPY','USD→NGN','USD→ZAR'].map(p=>{
        const[f,t]=p.split('→');
        return `<button class="btn-sm" onclick="setConvPair('${f}','${t}')">${p}</button>`;
      }).join('')}
    </div>`;
  updateConversion();
}
function updateConversion(){
  const amt=parseFloat(document.getElementById('convAmt')?.value)||0;
  const from=document.getElementById('convFrom')?.value||'USD';
  const to=document.getElementById('convTo')?.value||'EUR';
  const rate=(fxRates[to]||1)/(fxRates[from]||1),result=amt*rate;
  document.getElementById('convResult').textContent=`${amt.toLocaleString()} ${from} = ${fmtNum(result,result<1?6:2)} ${to}`;
  document.getElementById('convRate').textContent=`1 ${from} = ${fmtNum(rate,rate<1?6:4)} ${to}`;
}
function swapConv(){const f=document.getElementById('convFrom'),t=document.getElementById('convTo'),tmp=f.value;f.value=t.value;t.value=tmp;updateConversion();}
function setConvPair(f,t){if(fxRates[f])document.getElementById('convFrom').value=f;if(fxRates[t])document.getElementById('convTo').value=t;updateConversion();}
