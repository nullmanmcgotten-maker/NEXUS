/**
 * analytics.js — Portfolio analytics: Sharpe, drawdown, win rate, risk score,
 *                trade journal, signal scanner, order book, economic calendar
 */

// ── PORTFOLIO ANALYTICS ───────────────────────────────────────────────────────
function computeAnalytics(){
  if (!positions.length) return null;
  const returns = positions.map(p => posPnlPct(p));
  const avgReturn = returns.reduce((a,b)=>a+b,0)/returns.length;
  const stdDev = Math.sqrt(returns.reduce((s,r)=>s+(r-avgReturn)**2,0)/returns.length) || 1;
  const sharpe  = (avgReturn - 2.5) / stdDev; // risk-free ~2.5%
  const winners = positions.filter(p=>posPnl(p)>0).length;
  const winRate = positions.length ? (winners/positions.length*100).toFixed(1) : 0;
  const totalPnl= positions.reduce((s,p)=>s+posPnl(p),0);
  const maxDD   = Math.min(...returns);
  // Simple risk score 1-10
  const risk = Math.min(10, Math.max(1, Math.round(stdDev * 2 + (positions.filter(p=>p.type==='crypto').length/positions.length)*4)));
  return { sharpe: sharpe.toFixed(2), winRate, totalPnl, maxDD: maxDD.toFixed(2), risk, stdDev: stdDev.toFixed(2) };
}

function renderAnalytics(){
  const el = document.getElementById('analyticsPanel');
  if (!el) return;
  const a = computeAnalytics();
  if (!a) { el.innerHTML='<div style="color:var(--muted);font-family:var(--mono);font-size:13px;text-align:center;padding:20px;">Add positions to see analytics</div>'; return; }
  const riskColor = a.risk<=3?'var(--green)':a.risk<=6?'var(--amber)':'var(--red)';
  const sharpeColor = a.sharpe>=1?'var(--green)':a.sharpe>=0?'var(--amber)':'var(--red)';
  el.innerHTML = `
    <div class="analytics-grid">
      <div class="an-card">
        <div class="an-label">Sharpe Ratio</div>
        <div class="an-val" style="color:${sharpeColor};">${a.sharpe}</div>
        <div class="an-hint">${a.sharpe>=1?'Good risk-adj return':a.sharpe>=0?'Moderate':'Below benchmark'}</div>
      </div>
      <div class="an-card">
        <div class="an-label">Win Rate</div>
        <div class="an-val" style="color:${parseFloat(a.winRate)>=50?'var(--green)':'var(--red)'};">${a.winRate}%</div>
        <div class="an-hint">${positions.filter(p=>posPnl(p)>0).length}/${positions.length} positions profitable</div>
      </div>
      <div class="an-card">
        <div class="an-label">Max Drawdown</div>
        <div class="an-val" style="color:var(--red);">${a.maxDD}%</div>
        <div class="an-hint">Worst single position</div>
      </div>
      <div class="an-card">
        <div class="an-label">Volatility (σ)</div>
        <div class="an-val" style="color:var(--amber);">${a.stdDev}%</div>
        <div class="an-hint">Position return std dev</div>
      </div>
      <div class="an-card">
        <div class="an-label">Risk Score</div>
        <div class="an-val" style="color:${riskColor};">${a.risk}/10</div>
        <div class="an-hint">${a.risk<=3?'Conservative':a.risk<=6?'Moderate':'Aggressive'}</div>
      </div>
      <div class="an-card">
        <div class="an-label">Total P&L</div>
        <div class="an-val ${a.totalPnl>=0?'up':'dn'}">${a.totalPnl>=0?'+':'-'}${fmtMoney(Math.abs(a.totalPnl))}</div>
        <div class="an-hint">All open positions</div>
      </div>
    </div>
    <div style="margin-top:16px;">
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;margin-bottom:10px;">Position Breakdown</div>
      ${positions.map(p=>{
        const pnl=posPnl(p), pct=posPnlPct(p), isUp=pnl>=0;
        const barW=Math.min(Math.abs(pct)/50*100,100).toFixed(0);
        return `<div style="margin-bottom:8px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:3px;">
            <span style="font-family:var(--mono);font-size:12px;font-weight:600;">${p.sym}</span>
            <span style="font-family:var(--mono);font-size:12px;color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':'-'}$${fmtNum(Math.abs(pnl))} (${fmtPct(pct)})</span>
          </div>
          <div style="height:4px;background:var(--bg4);border-radius:2px;overflow:hidden;">
            <div style="width:${barW}%;height:100%;background:${isUp?'var(--green)':'var(--red)'};border-radius:2px;"></div>
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

// ── ADVANCED RISK (equity-curve based, not cross-sectional) ─────────────────────
// The cards above (Sharpe/Win Rate/Max DD) use a snapshot of open-position
// returns — useful, but not the same thing as time-series risk. This block
// uses the actual portfolio equity curve (getPortfolioCandles(), one point/min
// from realtime.js) so Sharpe/Sortino/drawdown mean what a trader expects them
// to mean: performance over time, not dispersion across today's positions.
function computeAdvancedRisk(){
  const candles = getPortfolioCandles();
  if (!candles || candles.length < 10) return null; // need real history, not a guess

  // Resample to one point per calendar day (last snapshot of each day) so
  // "daily return" doesn't mean "return since 60 seconds ago".
  const byDay = {};
  candles.forEach(c => { byDay[new Date(c.t).toISOString().split('T')[0]] = c.v; });
  const daily = Object.entries(byDay).sort((a,b)=>a[0].localeCompare(b[0])).map(([,v])=>v);
  if (daily.length < 3) return null;

  const rets = [];
  for (let i=1;i<daily.length;i++) rets.push((daily[i]-daily[i-1])/daily[i-1]);

  const mean = rets.reduce((a,b)=>a+b,0)/rets.length;
  const variance = rets.reduce((s,r)=>s+(r-mean)**2,0)/rets.length;
  const dailyVol = Math.sqrt(variance);
  const annualVol = dailyVol * Math.sqrt(365) * 100;

  const downside = rets.filter(r=>r<0);
  const downsideDev = downside.length ? Math.sqrt(downside.reduce((s,r)=>s+r*r,0)/downside.length) : 0;

  const RISK_FREE_DAILY = 0.05/365; // ~5% annualized risk-free, as a daily rate
  const sharpe  = dailyVol>0 ? ((mean-RISK_FREE_DAILY)/dailyVol)*Math.sqrt(365) : 0;
  const sortino = downsideDev>0 ? ((mean-RISK_FREE_DAILY)/downsideDev)*Math.sqrt(365) : 0;

  // Max drawdown — true peak-to-trough on the equity curve, not "worst position today"
  let peak = daily[0], maxDD = 0;
  daily.forEach(v => { if (v>peak) peak=v; const dd=(v-peak)/peak; if (dd<maxDD) maxDD=dd; });

  return {
    days: daily.length,
    annualVol: annualVol.toFixed(1),
    sharpe: sharpe.toFixed(2),
    sortino: sortino.toFixed(2),
    maxDrawdown: (maxDD*100).toFixed(2),
  };
}

function renderAdvancedRisk(){
  const el = document.getElementById('advRiskPanel');
  if (!el) return;
  const r = computeAdvancedRisk();
  if (!r) {
    el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;text-align:center;padding:20px;">
      Needs a few days of portfolio snapshots (1/min, collected automatically) before time-series risk metrics are meaningful. Check back after the dashboard's been open across a few sessions.</div>`;
    return;
  }
  const sharpeColor  = r.sharpe>=1?'var(--green)':r.sharpe>=0?'var(--amber)':'var(--red)';
  const sortinoColor = r.sortino>=1?'var(--green)':r.sortino>=0?'var(--amber)':'var(--red)';
  el.innerHTML = `
    <div class="analytics-grid">
      <div class="an-card">
        <div class="an-label">Sharpe (annualized)</div>
        <div class="an-val" style="color:${sharpeColor};">${r.sharpe}</div>
        <div class="an-hint">From ${r.days}-day equity curve</div>
      </div>
      <div class="an-card">
        <div class="an-label">Sortino (annualized)</div>
        <div class="an-val" style="color:${sortinoColor};">${r.sortino}</div>
        <div class="an-hint">Downside deviation only</div>
      </div>
      <div class="an-card">
        <div class="an-label">Annualized Volatility</div>
        <div class="an-val" style="color:var(--amber);">${r.annualVol}%</div>
        <div class="an-hint">σ of daily portfolio returns</div>
      </div>
      <div class="an-card">
        <div class="an-label">Max Drawdown (equity curve)</div>
        <div class="an-val" style="color:var(--red);">${r.maxDrawdown}%</div>
        <div class="an-hint">True peak-to-trough, ${r.days} days</div>
      </div>
    </div>`;
}

// ── CORRELATION MATRIX ───────────────────────────────────────────────────────────
// Approximate: aligns each pair's price history by index over the shared tail
// length, not by exact timestamp — fine for "do these move together" but not
// precise enough to treat as a covariance input. Said explicitly in the UI.
function pearson(a, b){
  const n = Math.min(a.length, b.length);
  if (n < 5) return null;
  const av = a.slice(-n), bv = b.slice(-n);
  const ma = av.reduce((s,v)=>s+v,0)/n, mb = bv.reduce((s,v)=>s+v,0)/n;
  let num=0, da=0, db=0;
  for (let i=0;i<n;i++){ const xa=av[i]-ma, xb=bv[i]-mb; num+=xa*xb; da+=xa*xa; db+=xb*xb; }
  const denom = Math.sqrt(da*db);
  return denom>0 ? num/denom : null;
}
function returnsSeries(sym){
  const hist = window._priceHistory?.[sym] || [];
  if (hist.length < 6) return null;
  const prices = hist.map(h=>h.p);
  const rets = [];
  for (let i=1;i<prices.length;i++) if (prices[i-1]>0) rets.push((prices[i]-prices[i-1])/prices[i-1]);
  return rets.length >= 5 ? rets : null;
}
function computeCorrelationMatrix(){
  const syms = [...new Set(positions.map(p=>p.sym))];
  const series = {};
  syms.forEach(s => { const r = returnsSeries(s); if (r) series[s] = r; });
  const usable = Object.keys(series);
  if (usable.length < 2) return null;
  const matrix = usable.map(a => usable.map(b => a===b ? 1 : pearson(series[a], series[b])));
  return { symbols: usable, matrix };
}
function corrColor(r){
  if (r===null) return { bg:'var(--bg4)', fg:'var(--muted)' };
  if (r >  0.6) return { bg:'rgba(255,77,106,.30)', fg:'var(--red)' };   // highly correlated = concentration risk
  if (r >  0.2) return { bg:'rgba(255,77,106,.12)', fg:'var(--text)' };
  if (r > -0.2) return { bg:'var(--bg4)',           fg:'var(--muted2)' };
  if (r > -0.6) return { bg:'rgba(0,212,170,.12)',  fg:'var(--text)' };
  return          { bg:'rgba(0,212,170,.30)',  fg:'var(--green)' };      // strongly inverse = real diversification
}
function renderCorrelationMatrix(){
  const el = document.getElementById('corrMatrixPanel');
  if (!el) return;
  const c = computeCorrelationMatrix();
  if (!c) {
    el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;text-align:center;padding:20px;">
      Needs at least 2 positions with enough accumulated price ticks. Leave the dashboard open a bit longer.</div>`;
    return;
  }
  const n = c.symbols.length;
  el.innerHTML = `
    <div style="overflow-x:auto;">
      <div style="display:grid;grid-template-columns:56px repeat(${n},52px);gap:3px;width:max-content;">
        <div></div>
        ${c.symbols.map(s=>`<div style="font-family:var(--mono);font-size:9px;color:var(--muted);text-align:center;writing-mode:vertical-rl;padding:4px 0;">${esc(s)}</div>`).join('')}
        ${c.symbols.map((rowSym,i)=>`
          <div style="font-family:var(--mono);font-size:10px;color:var(--muted);display:flex;align-items:center;">${esc(rowSym)}</div>
          ${c.matrix[i].map(r=>{ const col=corrColor(r); return `
            <div title="${r===null?'insufficient overlap':r.toFixed(2)}" style="background:${col.bg};color:${col.fg};border-radius:4px;height:32px;display:flex;align-items:center;justify-content:center;font-family:var(--mono);font-size:10px;font-weight:700;">${r===null?'—':r.toFixed(2)}</div>`;}).join('')}
        `).join('')}
      </div>
    </div>
    <div style="margin-top:10px;font-family:var(--mono);font-size:10px;color:var(--muted);">
      Pearson correlation on tracked price ticks, aligned by recency (not exact timestamp) — read as directional, not precise. Red = moves together (concentration risk) · Green = moves inversely (real diversification).
    </div>`;
}

function logTrade(entry){
  tradeJournal.unshift({ id:genId(), ...entry, timestamp:Date.now(), date:new Date().toLocaleString() });
  if (tradeJournal.length > 500) tradeJournal.length = 500;
  saveJournal();
  renderJournal();
}

function renderJournal(){
  const el = document.getElementById('journalList');
  if (!el) return;
  if (!tradeJournal.length){
    el.innerHTML='<div style="text-align:center;padding:32px;font-family:var(--mono);font-size:13px;color:var(--muted);">No trades logged yet. Add or close positions to start the journal.</div>';
    return;
  }
  el.innerHTML = tradeJournal.slice(0,50).map(t=>{
    const isBuy = t.action==='BUY';
    return `<div class="journal-row">
      <div class="journal-badge ${isBuy?'jbuy':'jsell'}">${t.action}</div>
      <div>
        <div style="font-family:var(--mono);font-size:14px;font-weight:700;">${t.sym}</div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">${t.date}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-family:var(--mono);font-size:13px;">Qty: ${safeNum(t.qty).toLocaleString()}</div>
        <div style="font-family:var(--mono);font-size:13px;color:var(--muted);">@ $${fmtNum(safeNum(t.price),4)}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-family:var(--mono);font-size:12px;color:var(--muted);">${esc(t.note||'')}</div>
        <span class="badge ${typeBadge(t.type)}">${(t.type||'').toUpperCase()}</span>
      </div>
      <button style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:14px;" onclick="deleteJournalEntry('${t.id}')">✕</button>
    </div>`;
  }).join('');
}

function deleteJournalEntry(id){
  const idx = tradeJournal.findIndex(t=>t.id===id);
  if (idx!==-1){ tradeJournal.splice(idx,1); saveJournal(); renderJournal(); }
}

function openManualTradeModal(){ document.getElementById('manualTradeModal')?.classList.remove('hidden'); }
function closeManualTradeModal(){ document.getElementById('manualTradeModal')?.classList.add('hidden'); }
function logManualTrade(){
  const sym   = document.getElementById('mtSym')?.value.trim().toUpperCase();
  const action= document.getElementById('mtAction')?.value;
  const qty   = safeNum(document.getElementById('mtQty')?.value);
  const price = safeNum(document.getElementById('mtPrice')?.value);
  const note  = document.getElementById('mtNote')?.value.trim();
  const type  = document.getElementById('mtType')?.value;
  if (!sym||qty<=0||price<=0){ alert('Fill all fields.'); return; }
  logTrade({ action, sym, type, qty, price, note });
  closeManualTradeModal();
  ['mtSym','mtQty','mtPrice','mtNote'].forEach(id=>{ const e=document.getElementById(id); if(e) e.value=''; });
}

// ── SIGNAL SCANNER ────────────────────────────────────────────────────────────
let _lastScanTime = 0;

function runSignalScanner(){
  const now = Date.now();
  if (now - _lastScanTime < 30000) return; // throttle 30s
  _lastScanTime = now;

  const newAlerts = [];
  positions.forEach(p => {
    const hist = window._priceHistory?.[p.sym] || [];
    if (hist.length < 30) return;
    const closes = hist.map(h=>h.p);
    const rsi    = TA.rsi(closes, 14);
    const macdR  = TA.macd(closes);
    const bb     = TA.bollinger(closes, 20);
    const n      = closes.length - 1;
    const rv     = rsi[n], price = closes[n];

    if (rv !== null) {
      if (rv < 30)        newAlerts.push({ sym:p.sym, signal:'RSI OVERSOLD',  detail:`RSI ${rv.toFixed(1)} < 30`, color:'green', ts:now });
      else if (rv > 70)   newAlerts.push({ sym:p.sym, signal:'RSI OVERBOUGHT',detail:`RSI ${rv.toFixed(1)} > 70`, color:'red',   ts:now });
    }
    const hn = macdR.histogram[n], hp = macdR.histogram[n-1];
    if (hn!==null && hp!==null){
      if (hn>0&&hp<=0)    newAlerts.push({ sym:p.sym, signal:'MACD CROSS ▲',  detail:'Bullish crossover', color:'green', ts:now });
      else if (hn<0&&hp>=0) newAlerts.push({ sym:p.sym, signal:'MACD CROSS ▼',detail:'Bearish crossover', color:'red',   ts:now });
    }
    const bu=bb.upper[n], bl=bb.lower[n];
    if (bu&&bl){
      if (price>bu)       newAlerts.push({ sym:p.sym, signal:'BB BREAKOUT ▲', detail:'Above upper band', color:'amber', ts:now });
      else if (price<bl)  newAlerts.push({ sym:p.sym, signal:'BB BREAKDOWN ▼',detail:'Below lower band', color:'amber', ts:now });
    }
  });

  if (newAlerts.length) {
    window._scannerAlerts = [...newAlerts, ...(window._scannerAlerts||[])].slice(0, 50);
    renderScannerAlerts();
    // Push notification for strong signals
    if (typeof _pushOK!=='undefined' && _pushOK && newAlerts.length) {
      new Notification(`NEXUS Scanner: ${newAlerts.length} signal${newAlerts.length>1?'s':''}`, {
        body: newAlerts.slice(0,3).map(a=>`${a.sym}: ${a.signal}`).join('\n'),
      });
    }
  }
}

function renderScannerAlerts(){
  const el = document.getElementById('scannerAlerts');
  if (!el) return;
  const alerts = window._scannerAlerts || [];
  if (!alerts.length){
    el.innerHTML='<div style="text-align:center;padding:24px;font-family:var(--mono);font-size:13px;color:var(--muted);">Scanner active. Signals appear here when triggered (requires 30+ price points per asset).</div>';
    return;
  }
  el.innerHTML = alerts.map(a=>{
    const col = {green:'var(--green)',red:'var(--red)',amber:'var(--amber)'}[a.color]||'var(--muted)';
    return `<div class="scanner-row">
      <div class="scanner-sym">${a.sym}</div>
      <div class="scanner-signal" style="color:${col};">${a.signal}</div>
      <div class="scanner-detail">${a.detail}</div>
      <div class="scanner-time">${new Date(a.ts).toLocaleTimeString()}</div>
    </div>`;
  }).join('');
}

// ── ORDER BOOK (Binance WebSocket) ────────────────────────────────────────────
let _obWS = null, _obSym = null;

function openOrderBook(sym){
  const binSym = sym.replace('/','') + 'USDT';
  _obSym = sym;
  if (_obWS) { _obWS.close(); _obWS = null; }

  const el = document.getElementById('orderBookPanel');
  if (!el) return;
  el.innerHTML = `<div style="text-align:center;padding:20px;font-family:var(--mono);font-size:12px;color:var(--muted);">Connecting to order book…</div>`;

  _obWS = new WebSocket(`wss://stream.binance.com:9443/ws/${binSym.toLowerCase()}@depth10@100ms`);
  _obWS.onmessage = ({data}) => {
    try {
      const d = JSON.parse(data);
      renderOrderBook(sym, d.bids||[], d.asks||[]);
    } catch(e){}
  };
  _obWS.onerror = () => {
    if (el) el.innerHTML = `<div style="text-align:center;padding:20px;color:var(--amber);font-family:var(--mono);">⚠ Order book only available for crypto pairs traded on Binance (e.g. BTC, ETH, SOL)</div>`;
  };
}

function renderOrderBook(sym, bids, asks){
  const el = document.getElementById('orderBookPanel');
  if (!el) return;
  const maxVol = Math.max(...bids.concat(asks).map(r=>parseFloat(r[1]))) || 1;
  const rows = (side, data, color) => data.slice(0,10).map(([price,qty])=>{
    const p=parseFloat(price), q=parseFloat(qty), bar=(q/maxVol*100).toFixed(0);
    return `<div class="ob-row">
      <span class="ob-price" style="color:${color};">$${fmtNum(p, p<1?6:2)}</span>
      <span class="ob-qty">${fmtNum(q,4)}</span>
      <div class="ob-bar-wrap"><div class="ob-bar" style="width:${bar}%;background:${color};opacity:0.35;"></div></div>
    </div>`;
  }).join('');

  const spread = asks.length&&bids.length ? (parseFloat(asks[0][0])-parseFloat(bids[0][0])).toFixed(6) : '—';
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div>
        <div style="font-family:var(--mono);font-size:10px;color:var(--red);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px;">Asks (Sell)</div>
        <div class="ob-head"><span>Price</span><span>Size</span><span>Depth</span></div>
        ${rows('asks', asks.slice().reverse(), 'var(--red)')}
      </div>
      <div>
        <div style="font-family:var(--mono);font-size:10px;color:var(--green);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px;">Bids (Buy)</div>
        <div class="ob-head"><span>Price</span><span>Size</span><span>Depth</span></div>
        ${rows('bids', bids, 'var(--green)')}
      </div>
    </div>
    <div style="text-align:center;margin-top:10px;font-family:var(--mono);font-size:12px;color:var(--muted);">
      Spread: <span style="color:var(--text);">${spread}</span> &nbsp;·&nbsp; ${sym} via Binance · Live 100ms
    </div>`;
}

// ── ECONOMIC CALENDAR ─────────────────────────────────────────────────────────
const ECON_EVENTS = [
  {date:'2026-06-11',time:'08:30',event:'US CPI (May)',impact:'high',prev:'3.4%',fore:'3.3%',currency:'USD'},
  {date:'2026-06-12',time:'14:00',event:'FOMC Rate Decision',impact:'high',prev:'5.25-5.50%',fore:'5.25-5.50%',currency:'USD'},
  {date:'2026-06-13',time:'08:30',event:'US PPI (May)',impact:'medium',prev:'2.2%',fore:'2.3%',currency:'USD'},
  {date:'2026-06-14',time:'10:00',event:'US Michigan Sentiment',impact:'medium',prev:'69.1',fore:'70.0',currency:'USD'},
  {date:'2026-06-17',time:'09:00',event:'Eurozone CPI (Final)',impact:'medium',prev:'2.6%',fore:'2.6%',currency:'EUR'},
  {date:'2026-06-18',time:'08:30',event:'US Retail Sales (May)',impact:'high',prev:'-0.3%',fore:'+0.2%',currency:'USD'},
  {date:'2026-06-19',time:'--:--',event:'Juneteenth — US Markets Closed',impact:'low',prev:'—',fore:'—',currency:'USD'},
  {date:'2026-06-20',time:'12:30',event:'BOE Rate Decision',impact:'high',prev:'5.25%',fore:'5.25%',currency:'GBP'},
  {date:'2026-06-25',time:'08:30',event:'US GDP Q1 (Final)',impact:'high',prev:'1.6%',fore:'1.6%',currency:'USD'},
  {date:'2026-06-27',time:'08:30',event:'US PCE Price Index (May)',impact:'high',prev:'2.7%',fore:'2.6%',currency:'USD'},
  {date:'2026-07-04',time:'--:--',event:'Independence Day — US Markets Closed',impact:'low',prev:'—',fore:'—',currency:'USD'},
  {date:'2026-07-05',time:'08:30',event:'US Non-Farm Payrolls (Jun)',impact:'high',prev:'272K',fore:'185K',currency:'USD'},
  {date:'2026-07-10',time:'08:30',event:'US CPI (Jun)',impact:'high',prev:'3.3%',fore:'3.1%',currency:'USD'},
  {date:'2026-07-30',time:'14:00',event:'FOMC Rate Decision',impact:'high',prev:'5.25-5.50%',fore:'5.00-5.25%',currency:'USD'},
];

async function fetchEconomicCalendar(){
  const el = document.getElementById('econCalendar');
  if (!el) return;
  el.innerHTML = `<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:12px;color:var(--muted);">Loading economic calendar…</div>`;

  // Try live fetch from Forex Factory RSS first — the static list below is a
  // hand-maintained illustrative fallback, not a live feed, so it goes stale
  // the moment its dates pass. Never show it as if it were current.
  try {
    const rssUrl = 'https://nfs.faireconomy.media/ff_calendar_thisweek.xml';
    const proxy  = 'https://api.allorigins.win/get?url=' + encodeURIComponent(rssUrl);
    const res    = await fetch(proxy, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error('HTTP '+res.status);
    const json   = await res.json();
    const xml    = new DOMParser().parseFromString(json.contents, 'text/xml');
    const items  = [...xml.querySelectorAll('event')];
    if (items.length > 0) {
      const live = items.slice(0,20).map(el=>({
        date:  el.querySelector('date')?.textContent?.trim()||'',
        time:  el.querySelector('time')?.textContent?.trim()||'',
        event: el.querySelector('title')?.textContent?.trim()||'',
        impact:el.querySelector('impact')?.textContent?.trim()||'medium',
        currency:el.querySelector('country')?.textContent?.trim()||'',
        prev:  el.querySelector('previous')?.textContent?.trim()||'—',
        fore:  el.querySelector('forecast')?.textContent?.trim()||'—',
      })).filter(e=>e.event);
      if (live.length) { renderEconCalendar(live, { live:true }); return; }
    }
  } catch(e){ /* fall through to static */ }

  // Live feed unavailable — only show static entries that haven't happened
  // yet. Showing a June event as if current in August is worse than showing
  // nothing: it's not "stale data", it's wrong data presented as live.
  const today = new Date().toISOString().split('T')[0];
  const upcoming = ECON_EVENTS.filter(e => e.date >= today);
  if (upcoming.length) {
    renderEconCalendar(upcoming, { live:false });
  } else {
    el.innerHTML = `<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:13px;color:var(--amber);">
      Live economic calendar feed is unreachable right now, and the built-in reference list has no upcoming entries left (it needs a maintenance refresh). Showing nothing rather than outdated dates.</div>`;
  }
}

function renderEconCalendar(events, { live } = {}){
  const el = document.getElementById('econCalendar');
  if (!el) return;
  const today = new Date().toISOString().split('T')[0];
  const impColor = {high:'var(--red)',medium:'var(--amber)',low:'var(--muted)'};
  const impIcon  = {high:'🔴',medium:'🟡',low:'⚪'};

  el.innerHTML = `
    ${live===false ? `<div style="margin-bottom:12px;font-family:var(--mono);font-size:11px;color:var(--amber);background:rgba(245,166,35,.1);border:1px solid rgba(245,166,35,.3);border-radius:6px;padding:8px 12px;">⚠ Live feed unavailable — showing built-in reference events (upcoming-only, hand-maintained, not real-time).</div>` : ''}
    <div class="econ-grid">
      ${events.map(e=>{
        const isPast = e.date < today;
        const isToday= e.date === today;
        return `<div class="econ-row ${isToday?'econ-today':''} ${isPast?'econ-past':''}">
          <div class="econ-date">
            <div style="font-family:var(--mono);font-size:13px;font-weight:${isToday?700:400};color:${isToday?'var(--accent)':'var(--text)'};">${e.date}</div>
            <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">${e.time}</div>
          </div>
          <div style="font-size:18px;">${impIcon[e.impact]||'⚪'}</div>
          <div>
            <div style="font-size:14px;font-weight:500;">${esc(e.event)}</div>
            <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">
              <span style="background:var(--bg3);border-radius:3px;padding:1px 6px;">${e.currency}</span>
            </div>
          </div>
          <div style="text-align:right;font-family:var(--mono);">
            <div style="font-size:12px;color:var(--muted);">Prev: <span style="color:var(--text);">${esc(e.prev)}</span></div>
            <div style="font-size:12px;color:var(--muted);">Fore: <span style="color:var(--amber);">${esc(e.fore)}</span></div>
          </div>
        </div>`;
      }).join('')}
    </div>
    <div style="margin-top:12px;font-family:var(--mono);font-size:10px;color:var(--muted);text-align:right;">
      ${live ? 'Live — Forex Factory RSS feed' : 'Reference events only, upcoming dates verified against today'}
    </div>`;
}

// ── THEME CUSTOMISER ──────────────────────────────────────────────────────────
const THEMES = {
  default: { accent:'#00d4aa', accent2:'#0096ff', bg:'#080b0f', label:'Teal (Default)' },
  blue:    { accent:'#3b82f6', accent2:'#8b5cf6', bg:'#080b0f', label:'Blue/Purple'    },
  orange:  { accent:'#f59e0b', accent2:'#ef4444', bg:'#0c0a08', label:'Amber/Red'      },
  pink:    { accent:'#ec4899', accent2:'#8b5cf6', bg:'#0c080f', label:'Pink/Violet'    },
  white:   { accent:'#00d4aa', accent2:'#0096ff', bg:'#f0f4f8', label:'Light Mode'     },
};

let _currentTheme   = localStorage.getItem('nexus_theme')   || 'default';
let _layoutDensity  = localStorage.getItem('nexus_density') || 'normal';

function applyTheme(key){
  const t = THEMES[key] || THEMES.default;
  document.documentElement.style.setProperty('--accent',  t.accent);
  document.documentElement.style.setProperty('--accent2', t.accent2);
  document.documentElement.style.setProperty('--green',   t.accent);
  if (key === 'white') {
    document.documentElement.style.setProperty('--bg',    '#f0f4f8');
    document.documentElement.style.setProperty('--bg2',   '#ffffff');
    document.documentElement.style.setProperty('--bg3',   '#e8edf2');
    document.documentElement.style.setProperty('--bg4',   '#d8e0e8');
    document.documentElement.style.setProperty('--text',  '#0f172a');
    document.documentElement.style.setProperty('--muted', '#64748b');
    document.documentElement.style.setProperty('--border','rgba(0,0,0,0.08)');
  } else {
    document.documentElement.style.setProperty('--bg',    t.bg);
    document.documentElement.style.setProperty('--bg2',   '#0d1117');
    document.documentElement.style.setProperty('--bg3',   '#131920');
    document.documentElement.style.setProperty('--bg4',   '#1a2232');
    document.documentElement.style.setProperty('--text',  '#eef0f6');
    document.documentElement.style.setProperty('--muted', '#5a6880');
    document.documentElement.style.setProperty('--border','rgba(255,255,255,0.07)');
  }
  _currentTheme = key;
  localStorage.setItem('nexus_theme', key);
  document.querySelectorAll('.theme-btn').forEach(b=>b.classList.toggle('active', b.dataset.theme===key));
}

function applyDensity(d){
  _layoutDensity = d;
  localStorage.setItem('nexus_density', d);
  document.documentElement.style.setProperty('--row-pad', d==='compact'?'8px':'14px');
  document.documentElement.style.setProperty('--card-pad', d==='compact'?'14px':'20px');
  document.documentElement.style.setProperty('--base-font', d==='compact'?'13px':'15px');
  document.querySelectorAll('.density-btn').forEach(b=>b.classList.toggle('active', b.dataset.density===d));
}

function renderThemePanel(){
  const el = document.getElementById('themePanel');
  if (!el) return;
  el.innerHTML = `
    <div style="margin-bottom:20px;">
      <div class="card-title" style="margin-bottom:12px;">Accent Theme</div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;">
        ${Object.entries(THEMES).map(([k,t])=>`
          <button class="theme-btn ${_currentTheme===k?'active':''}" data-theme="${k}" onclick="applyTheme('${k}')"
            style="--tbg:${t.accent};">
            <div style="width:24px;height:24px;border-radius:50%;background:${t.accent};margin:0 auto 6px;"></div>
            ${t.label}
          </button>`).join('')}
      </div>
    </div>
    <div>
      <div class="card-title" style="margin-bottom:12px;">Layout Density</div>
      <div style="display:flex;gap:10px;">
        <button class="density-btn ${_layoutDensity==='compact'?'active':''}" data-density="compact" onclick="applyDensity('compact')">Compact</button>
        <button class="density-btn ${_layoutDensity==='normal'?'active':''}"  data-density="normal"  onclick="applyDensity('normal')">Normal</button>
        <button class="density-btn ${_layoutDensity==='spacious'?'active':''}" data-density="spacious" onclick="applyDensity('spacious')">Spacious</button>
      </div>
    </div>`;
}

// ── SHARE / EXPORT ────────────────────────────────────────────────────────────
function exportPortfolioCSV(){
  const rows = [['Symbol','Name','Type','Qty','Avg Price','Current Price','Change %','Value','P&L','P&L %']];
  positions.forEach(p=>{
    rows.push([p.sym,p.name,p.type,p.qty,p.avgPrice,safeNum(p.price),safeNum(p.chg).toFixed(2),fmtNum(posDisplayValue(p)),fmtNum(posPnl(p)),posPnlPct(p).toFixed(2)]);
  });
  const csv  = rows.map(r=>r.join(',')).join('\n');
  const blob = new Blob([csv],{type:'text/csv'});
  const a    = Object.assign(document.createElement('a'),{href:URL.createObjectURL(blob),download:`nexus-portfolio-${new Date().toISOString().split('T')[0]}.csv`});
  a.click(); URL.revokeObjectURL(a.href);
}

function generateShareLink(){
  const payload = {
    positions: positions.map(p=>({sym:p.sym,name:p.name,type:p.type,qty:p.qty,avgPrice:p.avgPrice,price:safeNum(p.price),chg:safeNum(p.chg)})),
    portfolioName: window.portfolios[window.activePortfolioId]?.name||'Portfolio',
    generatedAt: new Date().toISOString(),
  };
  const b64  = btoa(JSON.stringify(payload));
  const link = `${location.origin}${location.pathname}?share=${b64}`;
  navigator.clipboard?.writeText(link).then(()=>alert('Share link copied to clipboard!\n\nRecipients can view your portfolio in read-only mode.'))
    .catch(()=>{ prompt('Copy this share link:', link); });
}

function checkShareParam(){
  const params = new URLSearchParams(location.search);
  const share  = params.get('share');
  if (!share) return;
  try {
    const data = JSON.parse(atob(share));
    const banner = document.createElement('div');
    banner.style.cssText = 'background:rgba(0,150,255,0.15);border:1px solid rgba(0,150,255,0.4);border-radius:8px;padding:12px 20px;margin-bottom:16px;font-family:var(--mono);font-size:13px;color:var(--accent2);display:flex;justify-content:space-between;align-items:center;';
    banner.innerHTML = `<span>👁 Viewing shared portfolio: <strong>${esc(data.portfolioName)}</strong> (read-only · generated ${new Date(data.generatedAt).toLocaleDateString()})</span><button onclick="this.parentElement.remove();history.replaceState({},'',location.pathname)" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;">✕</button>`;
    document.querySelector('.tab-container')?.prepend(banner);
    // Load shared positions as read-only view
    if (data.positions?.length) {
      window.portfolios['__shared__'] = { name: data.portfolioName + ' (shared)', positions: data.positions, cash: 0 };
      window.activePortfolioId = '__shared__';
    }
  } catch(e){}
}
