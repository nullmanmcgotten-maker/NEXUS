/**
 * charts.js — Real portfolio performance chart + mini sparkline.
 * Uses actual stored portfolio history from realtime.js.
 * Falls back to building from current positions if no history yet.
 */

let perfChartInstance = null;

function buildPerfChart() {
  const canvas = document.getElementById('perfChart');
  if (!canvas) return;

  let labels = [], data = [];

  // Use real portfolio history if we have it
  const history = getPortfolioCandles ? getPortfolioCandles() : null;

  if (history && history.length >= 2) {
    labels = history.map(h => {
      const d = new Date(h.t);
      return d.toLocaleTimeString('en', { hour:'2-digit', minute:'2-digit' });
    });
    data = history.map(h => Math.round(h.v));
  } else {
    // No history yet — show flat line at current value
    const now = Date.now();
    const cur = totalPortfolioValue();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now - i * 60000);
      labels.push(d.toLocaleTimeString('en', { hour:'2-digit', minute:'2-digit' }));
      data.push(Math.round(cur)); // flat until real data accumulates
    }
  }

  const isUp = data.length >= 2 ? data[data.length-1] >= data[0] : true;
  const color = isUp ? '#00d4aa' : '#ff4d6a';

  if (perfChartInstance) perfChartInstance.destroy();

  perfChartInstance = new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data,
        borderColor: color,
        borderWidth: 2,
        pointRadius: 0,
        fill: true,
        backgroundColor: isUp ? 'rgba(0,212,170,0.08)' : 'rgba(255,77,106,0.08)',
        tension: 0.3,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, animation: { duration: 400 },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#131920', borderColor: 'rgba(255,255,255,0.1)', borderWidth: 1,
          titleColor: '#e8eaf0', bodyColor: color,
          callbacks: { label: c => '$' + c.raw.toLocaleString() }
        }
      },
      scales: {
        x: { display: false },
        y: {
          display: true,
          grid: { color: 'rgba(255,255,255,0.04)' },
          ticks: { color:'#5a6880', font:{ family:"'IBM Plex Mono',monospace", size:10 }, callback: v => '$'+Math.round(v/1000)+'k' }
        }
      }
    }
  });
}

function buildMiniChart() {
  const canvas = document.getElementById('miniPerfChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  // Use real history for mini chart too
  const history = getPortfolioCandles ? getPortfolioCandles() : null;
  let data = [];

  if (history && history.length >= 2) {
    // Downsample to 28 points
    const step = Math.max(1, Math.floor(history.length / 28));
    data = history.filter((_, i) => i % step === 0).map(h => h.v);
  } else {
    // Flat line until data accumulates — still accurate, just boring
    const cur = totalPortfolioValue();
    data = Array(24).fill(cur);
  }

  const isUp  = data[data.length-1] >= data[0];
  const color = isUp ? '#00d4aa' : '#ff4d6a';
  const mn    = Math.min(...data) * 0.999;
  const mx    = Math.max(...data) * 1.001;
  const rng   = mx - mn || 1;
  const sy    = v => H - 4 - ((v - mn) / rng) * (H - 8);
  const PTS   = data.length;

  ctx.clearRect(0, 0, W, H);

  // Filled area
  ctx.beginPath();
  data.forEach((v, i) => { const x=(i/(PTS-1))*W; i===0?ctx.moveTo(x,sy(v)):ctx.lineTo(x,sy(v)); });
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
  ctx.fillStyle = isUp ? 'rgba(0,212,170,0.1)' : 'rgba(255,77,106,0.1)';
  ctx.fill();

  // Line
  ctx.beginPath();
  data.forEach((v, i) => { const x=(i/(PTS-1))*W; i===0?ctx.moveTo(x,sy(v)):ctx.lineTo(x,sy(v)); });
  ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
}
