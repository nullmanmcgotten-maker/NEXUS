'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { describeError } = require('./httpJson');

test('httpJson.describeError: unwraps AggregateError into a readable, non-empty message', () => {
  const err = new AggregateError([new Error('connect ECONNREFUSED 1.2.3.4:443'), new Error('connect ETIMEDOUT [::1]:443')], '');
  const msg = describeError(err);
  assert.notEqual(msg, '');
  assert.match(msg, /AggregateError/);
  assert.match(msg, /ECONNREFUSED/);
  assert.match(msg, /ETIMEDOUT/);
});

test('httpJson.describeError: passes through a normal Error message unchanged', () => {
  assert.equal(describeError(new Error('timeout')), 'timeout');
});

test('httpJson.describeError: falls back to .code when .message is empty', () => {
  const e = new Error('');
  e.code = 'ECONNRESET';
  assert.equal(describeError(e), 'ECONNRESET');
});

test('httpJson.describeError: never returns an empty string, even for a bare/unknown throw', () => {
  assert.notEqual(describeError({}), '');
  assert.notEqual(describeError(null), '');
  assert.notEqual(describeError(undefined), '');
});
