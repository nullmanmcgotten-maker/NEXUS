/**
 * authClient.js — front-end half of the auth/paywall system. Talks to the
 * /api/auth/* and /api/billing/* routes added in server.js + src/auth.js +
 * src/billing.js. No dependency on any framework — vanilla DOM, matches
 * the rest of this app's style.
 */
'use strict';

let _authUser = null; // null = logged out, else {email, tier, subscriptionStatus, createdAt}
let _authMode = 'login'; // 'login' | 'signup'

async function refreshAuthState() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
    const json = await res.json();
    _authUser = json.user || null;
  } catch (e) {
    _authUser = null;
  }
  renderAuthWidget();
}

function renderAuthWidget() {
  const el = document.getElementById('authWidget');
  if (!el) return;
  if (!_authUser) {
    el.innerHTML = `<button class="btn-sm" onclick="openAuthModal('login')">Log in</button>
      <button class="btn-sm" onclick="openAuthModal('signup')">Sign up</button>`;
    return;
  }
  const tierBadge = _authUser.tier === 'pro'
    ? `<span style="color:var(--green);">★ Pro</span>`
    : `<span style="color:var(--muted);">Free</span>`;
  el.innerHTML = `
    <span title="${escAttrSafe(_authUser.email)}" style="color:var(--muted);max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escSafe(_authUser.email)}</span>
    ${tierBadge}
    ${_authUser.tier !== 'pro' ? `<button class="btn-sm" onclick="startProUpgrade()">Upgrade</button>` : `<button class="btn-sm" onclick="openBillingPortal()">Manage</button>`}
    <button class="btn-sm" onclick="doLogout()">Log out</button>`;
}

function escSafe(s) { return String(s || '').replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c])); }
function escAttrSafe(s) { return escSafe(s).replace(/"/g, '&quot;'); }

function openAuthModal(mode) {
  _authMode = mode;
  document.getElementById('authModalTitle').textContent = mode === 'login' ? 'Log in' : 'Sign up';
  document.getElementById('authSubmitBtn').textContent = mode === 'login' ? 'Log in' : 'Create account';
  document.getElementById('authSwitchPrompt').textContent = mode === 'login' ? 'No account?' : 'Already have one?';
  document.getElementById('authSwitchLink').textContent = mode === 'login' ? 'Sign up' : 'Log in';
  document.getElementById('authError').style.display = 'none';
  document.getElementById('authEmailInput').value = '';
  document.getElementById('authPasswordInput').value = '';
  document.getElementById('authModalBackdrop').style.display = 'flex';
}

function closeAuthModal() {
  document.getElementById('authModalBackdrop').style.display = 'none';
}

function toggleAuthMode() {
  openAuthModal(_authMode === 'login' ? 'signup' : 'login');
}

async function submitAuthForm() {
  const email = document.getElementById('authEmailInput').value.trim();
  const password = document.getElementById('authPasswordInput').value;
  const errEl = document.getElementById('authError');
  errEl.style.display = 'none';
  try {
    const res = await fetch(`/api/auth/${_authMode === 'login' ? 'login' : 'signup'}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Something went wrong');
    _authUser = json.user;
    closeAuthModal();
    renderAuthWidget();
    if (typeof loadTelegramSignals === 'function') loadTelegramSignals(); // refresh paywalled panel with new session
  } catch (e) {
    errEl.textContent = e.message;
    errEl.style.display = 'block';
  }
}

async function doLogout() {
  try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }); } catch (e) { /* ignore */ }
  _authUser = null;
  renderAuthWidget();
  if (typeof loadTelegramSignals === 'function') loadTelegramSignals();
}

async function openBillingPortal() {
  try {
    const res = await fetch('/api/billing/portal', { method: 'POST', credentials: 'same-origin' });
    const json = await res.json();
    if (json.url) { window.location.href = json.url; return; }
    alert(json.error || 'Portal unavailable');
  } catch (e) {
    alert('Portal unavailable: ' + e.message);
  }
}

window.addEventListener('DOMContentLoaded', refreshAuthState);
