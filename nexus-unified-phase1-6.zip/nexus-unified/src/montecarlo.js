/**
 * montecarlo.js — Monte Carlo simulator on real price history.
 * 500 paths, Box-Muller sampling, fan chart via Chart.js.
 */
let _mcChart = null;

function runMonteCarlo() {
  const el    = document.getElementById('mcResults');
  const years = parseFloat(document.getElementById('mcYears')?.value) || 1;
  const sims  = parseInt(document.getElementById('mcSims')?.value)    || 500;
  const cap   = totalPortfolioValue();
  if (!el) return;

  const allReturns = [];
  positions.forEach(p => {
    const h = window._priceHistory?.[p.sym] || [];
    if (h.length < 5) return;
    const w = posDisplayValue(p) / Math.max(cap - 8200, 1);
    for (let i = 1; i < h.length; i++) {
      allReturns.push(((h[i].p - h[i-1].p) / h[i-1].p) * w);
    }
  });

  if (allReturns.length < 10) {
    el.innerHTML = '<div style="font-family:var(--mono);font-size:13px;color:var(--amber);padding:20px;text-align:center;">⚠ Need more price history. Keep the dashboard open for a few minutes then re-run.</div>';
    return;
  }

  const mean   = allReturns.reduce((a,b)=>a+b,0) / allReturns.length;
  const stdDev = Math.sqrt(allReturns.reduce((s,r)=>s+(r-mean)**2,0) / allReturns.length);
  const steps  = Math.round(years * 252);

  function nr() {
    let u=0,v=0;
    while(!u) u=Math.random(); while(!v) v=Math.random();
    return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
  }

  const finals = [], paths = [];
  for (let s=0; s<sims; s++) {
    let v=cap; const path=[v];
    for (let d=0; d<steps; d++) { v=Math.max(0, v*(1+mean+stdDev*nr())); path.push(v); }
    paths.push(path); finals.push(v);
  }
  finals.sort((a,b)=>a-b);
  const pct = q => finals[Math.floor(sims*q)];
  const pLoss = (finals.filter(v=>v<cap).length/sims*100).toFixed(1);

  el.innerHTML = `
    <div class="bt-stats-grid" style="grid-template-columns:repeat(5,1fr);">
      <div class="bt-stat"><div class="bt-stat-l">5th % (Bear)</div><div class="bt-stat-v dn">$${fmtNum(pct(.05))}</div></div>
      <div class="bt-stat"><div class="bt-stat-l">25th %</div><div class="bt-stat-v">$${fmtNum(pct(.25))}</div></div>
      <div class="bt-stat"><div class="bt-stat-l">Median</div><div class="bt-stat-v ${pct(.5)>=cap?'up':'dn'}">$${fmtNum(pct(.5))}</div></div>
      <div class="bt-stat"><div class="bt-stat-l">75th %</div><div class="bt-stat-v up">$${fmtNum(pct(.75))}</div></div>
      <div class="bt-stat"><div class="bt-stat-l">95th % (Bull)</div><div class="bt-stat-v up">$${fmtNum(pct(.95))}</div></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin:12px 0;">
      <div class="an-card"><div class="an-label">Prob of Loss</div><div class="an-val ${parseFloat(pLoss)>50?'dn':'up'}">${pLoss}%</div></div>
      <div class="an-card"><div class="an-label">Starting Value</div><div class="an-val">$${fmtNum(cap)}</div></div>
      <div class="an-card"><div class="an-label">Simulations</div><div class="an-val">${sims}</div></div>
    </div>
    <div style="position:relative;height:240px;"><canvas id="mcCanvas"></canvas></div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">
      μ=${(mean*100).toFixed(4)}%/step · σ=${(stdDev*100).toFixed(4)}%/step · ${years}Y horizon · Real price history
    </div>`;

  const ctx = document.getElementById('mcCanvas')?.getContext('2d');
  if (!ctx) return;
  if (_mcChart) _mcChart.destroy();
  const step = Math.max(1, Math.floor(sims/40));
  const datasets = paths.filter((_,i)=>i%step===0).map(p=>({
    data:p, borderWidth:1, pointRadius:0, fill:false, tension:0,
    borderColor: p[p.length-1]>=cap?'rgba(0,212,170,0.15)':'rgba(255,77,106,0.15)'
  }));
  datasets.push({ data:paths[Math.floor(sims/2)], borderColor:'#e8eaf0', borderWidth:2.5, pointRadius:0, fill:false, tension:0 });
  _mcChart = new Chart(ctx, {
    type:'line', data:{labels:Array.from({length:steps+1},(_,i)=>i), datasets},
    options:{responsive:true,maintainAspectRatio:false,animation:{duration:300},
      plugins:{legend:{display:false},tooltip:{enabled:false}},
      scales:{x:{display:false},y:{display:true,position:'right',grid:{color:'rgba(255,255,255,0.03)'},
        ticks:{color:'#5a6880',font:{family:"'IBM Plex Mono'",size:9},callback:v=>'$'+Math.round(v/1000)+'k'}}}}});
}
