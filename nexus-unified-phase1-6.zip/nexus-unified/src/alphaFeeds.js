/**
 * alphaFeeds.js — front-end for the two server-computed, tier-gated
 * "alpha" feeds: perps composite mover score (src/perpsAlpha.js) and
 * Polymarket mover score (src/polymarketAlpha.js). Same free-teaser /
 * pro-full pattern as telegramSignals.js — see that file's header for
 * the trust-model rationale, which applies equally here.
 */
'use strict';

function fmtAgo(ts) {
  if (!ts) return '—';
  const mins = Math.round((Date.now() - ts) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  return `${Math.round(mins / 60)}h ago`;
}

function paywallBanner(payload, featureLabel) {
  if (payload.tier === 'pro') return '';
  return `
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-family:var(--mono);font-size:11px;color:var(--text);background:rgba(80,120,255,.08);border:1px solid rgba(80,120,255,.35);border-radius:6px;padding:10px 12px;margin-bottom:10px;">
      <span>🔒 Free tier: top ${payload.limit ?? 5} ${featureLabel}, delayed ~${payload.delayedMinutes || 60} min. Pro gets the full ranked list, refreshed live.</span>
      <button class="btn-sm" style="white-space:nowrap;" onclick="startProUpgrade()">Upgrade to Pro</button>
    </div>`;
}

async function fetchAlphaJson(path) {
  const res = await fetch(path, { credentials: 'same-origin', signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function renderPerpsAlphaRows(rows) {
  if (!rows.length) return `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:8px 0;">No standout movers right now.</div>`;
  return `<table class="mono-table" style="width:100%;font-family:var(--mono);font-size:11px;">
    <thead><tr style="color:var(--muted);text-align:left;">
      <th style="padding:4px 8px;">Symbol</th><th>24h %</th><th>Funding</th><th>24h Vol (USDT)</th><th>Composite</th>
    </tr></thead>
    <tbody>
      ${rows.map(r => `
        <tr style="border-top:1px solid var(--border2);">
          <td style="padding:4px 8px;font-weight:600;">${esc(r.symbol)}</td>
          <td style="color:${r.priceChangePercent >= 0 ? 'var(--green)' : 'var(--red)'};">${r.priceChangePercent.toFixed(2)}%</td>
          <td>${(r.fundingRate * 100).toFixed(4)}%</td>
          <td>${Math.round(r.volume24hrUsdt).toLocaleString()}</td>
          <td style="color:${r.composite >= 0 ? 'var(--green)' : 'var(--red)'};font-weight:600;">${r.composite}</td>
        </tr>`).join('')}
    </tbody>
  </table>`;
}

function renderPolymarketAlphaRows(rows) {
  if (!rows.length) return `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:8px 0;">No standout movers right now.</div>`;
  return `<div style="display:flex;flex-direction:column;gap:8px;">
    ${rows.map(r => `
      <div style="border:1px solid var(--border2);border-radius:6px;padding:8px 10px;font-family:var(--mono);font-size:11px;">
        <div style="display:flex;justify-content:space-between;gap:10px;">
          <a href="${r.url || '#'}" target="_blank" rel="noopener" style="color:var(--text);text-decoration:none;flex:1;">${esc(r.question)}</a>
          <span style="color:var(--accent);font-weight:600;white-space:nowrap;">score ${r.moverScore}</span>
        </div>
        <div style="color:var(--muted);margin-top:4px;">
          ${r.oneDayPriceChange !== null ? `24h Δ ${(r.oneDayPriceChange * 100).toFixed(1)}pp` : ''}
          · vol24h $${Math.round(r.volume24hr).toLocaleString()}
          · liq $${Math.round(r.liquidity).toLocaleString()}
          ${r.outcomes.length ? ` · ${r.outcomes.map((o, i) => `${esc(o)} ${(r.outcomePrices[i]*100).toFixed(0)}¢`).join(' / ')}` : ''}
        </div>
      </div>`).join('')}
  </div>`;
}

async function renderAlphaFeedsTab() {
  const perpsEl = document.getElementById('perpsAlphaPanel');
  const polyEl = document.getElementById('polymarketAlphaPanel');
  if (!perpsEl || !polyEl) return;

  perpsEl.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">Loading perps alpha…</div>`;
  polyEl.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">Loading Polymarket alpha…</div>`;

  try {
    const perps = await fetchAlphaJson('/api/perps-alpha');
    perpsEl.innerHTML = `
      <div class="card-hdr" style="padding:0 0 8px;">
        <span class="card-title" style="font-size:13px;">🎯 Perps Composite Movers <span style="color:var(--muted);font-weight:400;font-size:10px;">(${perps.tier}, updated ${fmtAgo(perps.updatedAt)})</span></span>
      </div>
      ${paywallBanner(perps, 'perps movers')}
      ${perps.error && !perps.data.length ? `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">${esc(perps.error)}</div>` : renderPerpsAlphaRows(perps.data)}`;
  } catch (e) {
    perpsEl.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--red);">Couldn't load perps alpha (${esc(e.message)}).</div>`;
  }

  try {
    const poly = await fetchAlphaJson('/api/polymarket-alpha');
    polyEl.innerHTML = `
      <div class="card-hdr" style="padding:0 0 8px;">
        <span class="card-title" style="font-size:13px;">🗳 Polymarket Movers <span style="color:var(--muted);font-weight:400;font-size:10px;">(${poly.tier}, updated ${fmtAgo(poly.updatedAt)})</span></span>
      </div>
      ${paywallBanner(poly, 'Polymarket movers')}
      ${poly.error && !poly.data.length ? `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">${esc(poly.error)}</div>` : renderPolymarketAlphaRows(poly.data)}`;
  } catch (e) {
    polyEl.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--red);">Couldn't load Polymarket alpha (${esc(e.message)}).</div>`;
  }
}
