/**
 * dataHealth.js — Retry/backoff + freshness tracking, shared across every
 * data source in the app. One change here benefits realtime.js's apiFetch,
 * perps.js's hlPost, and anything else that routes through them, instead of
 * bolting retry logic onto each module separately.
 *
 * This does NOT make data "100% accurate" — no live feed can promise that.
 * What it does: retries transient failures instead of silently dropping a
 * symbol, and makes staleness/disagreement visible instead of hidden.
 */

window._dataHealth = {}; // source -> { lastSuccess, lastError, errorCount, successCount, lastErrorMsg }

function sourceFromUrl(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); }
  catch (e) { return 'unknown'; }
}

function recordHealthSuccess(source) {
  const h = window._dataHealth[source] || (window._dataHealth[source] = { errorCount:0, successCount:0, lastError:null, lastErrorMsg:null });
  h.lastSuccess = Date.now();
  h.successCount++;
}
function recordHealthError(source, msg) {
  const h = window._dataHealth[source] || (window._dataHealth[source] = { errorCount:0, successCount:0, lastSuccess:null });
  h.lastError = Date.now();
  h.errorCount++;
  h.lastErrorMsg = msg;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/**
 * Wrap any async fetch-like function with exponential backoff + jitter.
 * fn must return a Promise that rejects on failure (matches apiFetch/hlPost).
 */
async function withRetry(fn, { retries = 3, baseDelayMs = 400, source = 'unknown' } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const result = await fn();
      recordHealthSuccess(source);
      return result;
    } catch (e) {
      lastErr = e;
      recordHealthError(source, e?.message || String(e));
      if (attempt < retries) {
        const jitter = Math.random() * 150;
        await sleep(baseDelayMs * Math.pow(2, attempt) + jitter);
      }
    }
  }
  throw lastErr;
}

function freshnessText(ts) {
  if (!ts) return 'never';
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 5)   return 'just now';
  if (s < 60)  return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  return `${Math.floor(s/3600)}h ago`;
}
function healthStatus(h) {
  if (!h || !h.lastSuccess) return h?.errorCount ? 'down' : 'unknown';
  const sinceSuccess = Date.now() - h.lastSuccess;
  const recentErrorAfterSuccess = h.lastError && h.lastError > h.lastSuccess;
  if (sinceSuccess > 5 * 60 * 1000) return 'down';
  if (recentErrorAfterSuccess || sinceSuccess > 60 * 1000) return 'degraded';
  return 'ok';
}
const HEALTH_COLOR = { ok:'var(--green)', degraded:'var(--amber)', down:'var(--red)', unknown:'var(--muted)' };
const HEALTH_ICON  = { ok:'●', degraded:'●', down:'●', unknown:'○' };

function renderDataHealthPanel(elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  const sources = Object.keys(window._dataHealth).sort();
  if (!sources.length) {
    el.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);">No requests tracked yet this session.</div>`;
    return;
  }
  el.innerHTML = `<div class="dh-grid">
    ${sources.map(s => {
      const h = window._dataHealth[s];
      const status = healthStatus(h);
      return `<div class="dh-row" title="${h.successCount} ok · ${h.errorCount} errors${h.lastErrorMsg ? ' · last error: '+esc(h.lastErrorMsg) : ''}">
        <span style="color:${HEALTH_COLOR[status]};">${HEALTH_ICON[status]}</span>
        <span class="dh-src">${esc(s)}</span>
        <span class="dh-time">${freshnessText(h.lastSuccess)}</span>
        ${h.errorCount ? `<span class="dh-err">${h.errorCount} err</span>` : ''}
      </div>`;
    }).join('')}
  </div>`;
}

function startDataHealthPolling(elId) {
  renderDataHealthPanel(elId);
  setInterval(() => renderDataHealthPanel(elId), 5000); // re-render for freshness text only, no new fetches
}

function overallHealthStatus() {
  const sources = Object.values(window._dataHealth);
  if (!sources.length) return 'unknown';
  const statuses = sources.map(healthStatus);
  if (statuses.includes('down')) return 'down';
  if (statuses.includes('degraded')) return 'degraded';
  return 'ok';
}
function updateDataHealthPill() {
  const pill = document.getElementById('dataHealthPill');
  if (!pill) return;
  const status = overallHealthStatus();
  const labels = { ok:'● Data', degraded:'● Data', down:'● Data', unknown:'○ Data' };
  pill.textContent = labels[status];
  pill.style.color = HEALTH_COLOR[status];
  pill.style.borderColor = status==='unknown' ? '' : HEALTH_COLOR[status];
}
function toggleDataHealthPanel() {
  const dd = document.getElementById('dataHealthDropdown');
  if (!dd) return;
  const showing = dd.style.display !== 'none';
  dd.style.display = showing ? 'none' : 'block';
  if (!showing) renderDataHealthPanel('dataHealthPanel');
}
function startDataHealthTracking() {
  updateDataHealthPill();
  setInterval(updateDataHealthPill, 5000);
  setInterval(() => { if (document.getElementById('dataHealthDropdown')?.style.display !== 'none') renderDataHealthPanel('dataHealthPanel'); }, 5000);
}
