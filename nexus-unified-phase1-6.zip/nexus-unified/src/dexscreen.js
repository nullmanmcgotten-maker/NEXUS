/**
 * dexscreen.js — On-chain DEX pair screener (DexScreener-style), using
 * DexScreener's free public API (no key, CORS-open — built for embeds).
 *
 * What this gives that the CEX/Hyperliquid Perps tab can't: market cap
 * (FDV), liquidity depth, and — the actual point — buy/sell TRANSACTION
 * PRESSURE per timeframe. DexScreener's API does not expose buy-volume vs
 * sell-volume split (only total volume + separate buy/sell tx counts), so
 * "bullish/bearish volume" here is reported honestly as a buy/sell
 * transaction-count ratio, not a fabricated buy-volume number the API
 * doesn't actually provide.
 */

const DEXSCREENER_BASE = 'https://api.dexscreener.com/latest/dex';

async function dexSearch(query) {
  const data = await apiFetch(`${DEXSCREENER_BASE}/search?q=${encodeURIComponent(query)}`);
  return (data?.pairs || []);
}

// A no-query "trending-ish" view: search a handful of major tickers people
// actually screen for, since DexScreener's API has no generic "top pairs"
// endpoint without a query — this is the practical workaround, not a hack
// pretending to be an official trending list.
const DEX_DEFAULT_QUERIES = ['ETH', 'SOL', 'BASE', 'PEPE', 'WIF'];

function normalizeDexPair(p) {
  const buys  = safeNum(p.txns?.h24?.buys);
  const sells = safeNum(p.txns?.h24?.sells);
  const totalTx = buys + sells;
  return {
    pairAddress: p.pairAddress,
    chain: p.chainId,
    dex: p.dexId,
    baseSymbol: p.baseToken?.symbol || '?',
    quoteSymbol: p.quoteToken?.symbol || '?',
    priceUsd: safeNum(p.priceUsd),
    chg24h: safeNum(p.priceChange?.h24),
    chg6h: safeNum(p.priceChange?.h6),
    volume24h: safeNum(p.volume?.h24),
    liquidityUsd: safeNum(p.liquidity?.usd),
    marketCap: safeNum(p.fdv), // DexScreener labels this fdv (fully diluted valuation) — the closest thing to "market cap" it actually provides; real circulating-supply market cap isn't in this API, so it's not fabricated here
    buys, sells, totalTx,
    // Honest label: this is transaction-count pressure, not a volume split.
    buyRatioPct: totalTx > 0 ? (buys / totalTx) * 100 : null,
    url: p.url,
    pairCreatedAt: p.pairCreatedAt,
  };
}

let _dexResults = [];
let _dexLoading = false;

async function loadDexScreener(query) {
  if (_dexLoading) return;
  _dexLoading = true;
  renderDexStatus('Searching DexScreener…');
  renderDexTable();

  try {
    let pairs;
    if (query && query.trim()) {
      pairs = await dexSearch(query.trim());
    } else {
      const results = await Promise.allSettled(DEX_DEFAULT_QUERIES.map(q => dexSearch(q)));
      pairs = results.filter(r => r.status === 'fulfilled').flatMap(r => r.value);
    }
    // Dedup by pair address (search across multiple queries can overlap),
    // keep only pairs with real liquidity so empty/rug pairs don't dominate.
    const seen = new Set();
    _dexResults = pairs
      .filter(p => p.pairAddress && !seen.has(p.pairAddress) && seen.add(p.pairAddress))
      .map(normalizeDexPair)
      .filter(p => p.liquidityUsd > 1000 && p.priceUsd > 0)
      .sort((a,b) => b.volume24h - a.volume24h)
      .slice(0, 60);
    _dexLoading = false;
    renderDexTable();
    renderDexStatus(`${_dexResults.length} pairs loaded${query ? ' for "'+query+'"' : ' (default watchlist: '+DEX_DEFAULT_QUERIES.join(', ')+')'}.`);
  } catch (e) {
    _dexLoading = false;
    renderDexStatus('DexScreener unreachable right now — try again shortly.');
    renderDexTable();
  }
}

function searchDexScreener() {
  const q = document.getElementById('dexSearchInput')?.value || '';
  loadDexScreener(q);
}

// ── FILTER / SORT ────────────────────────────────────────────────────────────
let _dexFilter = { sort: 'volume', minLiquidity: 0 };
function setDexSort(v) { _dexFilter.sort = v; renderDexTable(); }
function setDexMinLiquidity(v) { _dexFilter.minLiquidity = parseFloat(v) || 0; renderDexTable(); }

function getFilteredDexPairs() {
  let list = _dexResults.filter(p => p.liquidityUsd >= _dexFilter.minLiquidity);
  const sortFns = {
    volume:      (a,b) => b.volume24h - a.volume24h,
    marketCap:   (a,b) => b.marketCap - a.marketCap,
    liquidity:   (a,b) => b.liquidityUsd - a.liquidityUsd,
    chg:         (a,b) => b.chg24h - a.chg24h,
    buyPressure: (a,b) => (b.buyRatioPct ?? -1) - (a.buyRatioPct ?? -1),
  };
  return [...list].sort(sortFns[_dexFilter.sort] || sortFns.volume);
}

// ── RENDER ───────────────────────────────────────────────────────────────────
function renderDexStatus(msg) {
  const el = document.getElementById('dexStatus');
  if (el) el.textContent = msg;
}
function fmtUSDCompact(v) {
  if (v >= 1e9) return '$'+(v/1e9).toFixed(2)+'B';
  if (v >= 1e6) return '$'+(v/1e6).toFixed(2)+'M';
  if (v >= 1e3) return '$'+(v/1e3).toFixed(1)+'K';
  return '$'+fmtNum(v,0);
}
function buyPressureBar(p) {
  if (p.buyRatioPct === null) return `<span style="color:var(--muted);font-size:10px;">no tx data</span>`;
  const pct = p.buyRatioPct;
  const color = pct >= 60 ? 'var(--green)' : pct <= 40 ? 'var(--red)' : 'var(--muted2)';
  return `<div style="display:flex;align-items:center;gap:6px;" title="${p.buys} buys / ${p.sells} sells (24h) — transaction count ratio, not a volume split">
    <div style="width:44px;height:5px;background:var(--bg4);border-radius:3px;overflow:hidden;">
      <div style="width:${pct}%;height:100%;background:${color};"></div>
    </div>
    <span style="font-family:var(--mono);font-size:10px;color:${color};">${pct.toFixed(0)}%</span>
  </div>`;
}
function renderDexTable() {
  const body = document.getElementById('dexBody');
  if (!body) return;
  const cEl = document.getElementById('dexCounts');
  if (cEl) cEl.textContent = _dexResults.length ? `${_dexResults.length} pairs loaded` : 'No pairs loaded yet';

  const list = getFilteredDexPairs();
  if (!list.length) {
    body.innerHTML = `<div style="padding:32px;text-align:center;font-family:var(--mono);font-size:13px;color:var(--muted);">
      ${_dexResults.length ? 'No pairs match this filter.' : 'Search a token (e.g. "PEPE") or click Load Default to see a starter set.'}</div>`;
    return;
  }
  body.innerHTML = list.map(p => `
    <div class="dex-row" onclick="${p.url ? `window.open('${escAttr(p.url)}','_blank','noopener')` : ''}">
      <span class="perp-src perp-src-dex" title="${esc(p.dex)}">${esc(p.chain)}</span>
      <span class="perp-sym">${esc(p.baseSymbol)}<span style="color:var(--muted);">/${esc(p.quoteSymbol)}</span></span>
      <span class="r">$${p.priceUsd < 0.01 ? p.priceUsd.toPrecision(3) : fmtNum(p.priceUsd, p.priceUsd<1?6:2)}</span>
      <span class="r ${p.chg24h >= 0 ? 'up' : 'dn'}">${fmtPct(p.chg24h)}</span>
      <span class="r">${fmtUSDCompact(p.marketCap)}</span>
      <span class="r">${fmtUSDCompact(p.liquidityUsd)}</span>
      <span class="r">${fmtUSDCompact(p.volume24h)}</span>
      <span>${buyPressureBar(p)}</span>
    </div>`).join('');
}
