/**
 * polymarket.js — pulls active markets from Polymarket's public Gamma API
 * (no key/auth required: https://gamma-api.polymarket.com) and scores them
 * for "worth a look" rather than just dumping the raw list, since the raw
 * list is public and free everywhere already (Polymarket's own site,
 * countless scrapers). The score is a simple, transparent heuristic —
 * NOT a probability estimate, NOT a recommendation to trade either side.
 *
 * Scoring inputs (all from the same public payload):
 *  - |oneDayPriceChange|: how far the implied probability moved in 24h
 *  - volume24hr: how much money is actually backing that move (a big
 *    price swing on $50 of volume means much less than the same swing
 *    on $500k)
 *  - liquidity: thin books mean the "price" is easy to move without much
 *    money, so extreme prints on illiquid markets are downweighted
 *
 * mover_score = |oneDayPriceChange| * log10(volume24hr + 10) / log10(liquidity + 10 + 1)
 * clamped and rounded for display. This rewards big, well-supported moves
 * and penalizes thin-book noise. It is a sorting heuristic, nothing more.
 */
'use strict';

const { fetchJson } = require('./httpJson');

function safeNum(v, fallback = 0) {
  const n = typeof v === 'string' ? parseFloat(v) : v;
  return Number.isFinite(n) ? n : fallback;
}

function scoreMarket(m) {
  const change = Math.abs(safeNum(m.oneDayPriceChange, 0));
  const vol = safeNum(m.volume24hr, 0);
  const liq = safeNum(m.liquidity, 0);
  if (change === 0 || vol < 50) return 0; // ignore dead/no-move markets
  const score = change * Math.log10(vol + 10) / Math.log10(liq + 11);
  return Math.round(score * 1000) / 1000;
}

async function fetchTopMovers(limit = 100) {
  const url = `https://gamma-api.polymarket.com/markets?active=true&closed=false&order=volume24hr&ascending=false&limit=${limit}`;
  const markets = await fetchJson(url);
  if (!Array.isArray(markets)) throw new Error('unexpected Polymarket response shape');

  const scored = markets.map(m => {
    let outcomes = [], prices = [];
    try { outcomes = JSON.parse(m.outcomes || '[]'); } catch (e) { /* leave empty */ }
    try { prices = JSON.parse(m.outcomePrices || '[]').map(Number); } catch (e) { /* leave empty */ }
    return {
      question: m.question,
      slug: m.slug,
      url: m.slug ? `https://polymarket.com/event/${m.slug}` : null,
      outcomes,
      outcomePrices: prices,
      oneDayPriceChange: safeNum(m.oneDayPriceChange, null),
      volume24hr: safeNum(m.volume24hr, 0),
      liquidity: safeNum(m.liquidity, 0),
      endDate: m.endDate || null,
      moverScore: scoreMarket(m),
    };
  })
  .filter(m => m.moverScore > 0)
  .sort((a, b) => b.moverScore - a.moverScore);

  return scored;
}

module.exports = { fetchTopMovers };
