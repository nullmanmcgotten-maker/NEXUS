/**
 * auth.js — minimal, dependency-free auth + subscription tier store.
 *
 * Users are persisted to data/users.json. Passwords are hashed with
 * scrypt (Node's built-in, no bcrypt dependency needed). Sessions are
 * random tokens kept in memory + set as an httpOnly cookie; they're
 * lost on server restart (fine for a v1 — swap for Redis/DB-backed
 * sessions if you need persistence across restarts).
 *
 * Tiers: 'free' | 'pro'. Gate premium routes/features by checking
 * req.user.tier === 'pro' (see requirePro() below).
 */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const USERS_PATH = path.join(DATA_DIR, 'users.json');

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(USERS_PATH)) fs.writeFileSync(USERS_PATH, JSON.stringify({ users: [] }, null, 2));
}

function readUsers() {
  ensureStore();
  try { return JSON.parse(fs.readFileSync(USERS_PATH, 'utf8')).users; }
  catch (e) { return []; }
}

function writeUsers(users) {
  ensureStore();
  fs.writeFileSync(USERS_PATH, JSON.stringify({ users }, null, 2));
}

function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  // timing-safe compare
  const a = Buffer.from(check);
  const b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ── in-memory sessions: token -> { email, expiresAt } ──────────────────────
const sessions = new Map();
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function createSession(email) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { email, expiresAt: Date.now() + SESSION_TTL_MS });
  return token;
}

function getSession(token) {
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() > s.expiresAt) { sessions.delete(token); return null; }
  return s;
}

function destroySession(token) {
  sessions.delete(token);
}

// ── user CRUD ────────────────────────────────────────────────────────────
function findUser(email) {
  return readUsers().find(u => u.email.toLowerCase() === String(email).toLowerCase()) || null;
}

function createUser(email, password) {
  email = String(email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Invalid email');
  if (!password || password.length < 8) throw new Error('Password must be at least 8 characters');
  if (findUser(email)) throw new Error('An account with that email already exists');

  const { salt, hash } = hashPassword(password);
  const user = {
    email,
    salt,
    hash,
    tier: 'free',            // 'free' | 'pro'
    stripeCustomerId: null,
    subscriptionStatus: null, // 'active' | 'canceled' | null
    createdAt: new Date().toISOString(),
  };
  const users = readUsers();
  users.push(user);
  writeUsers(users);
  return user;
}

function authenticate(email, password) {
  const user = findUser(email);
  if (!user) throw new Error('Invalid email or password');
  if (!verifyPassword(password, user.salt, user.hash)) throw new Error('Invalid email or password');
  return user;
}

function setTier(email, tier, extra) {
  const users = readUsers();
  const idx = users.findIndex(u => u.email.toLowerCase() === String(email).toLowerCase());
  if (idx === -1) return null;
  users[idx].tier = tier;
  if (extra) Object.assign(users[idx], extra);
  writeUsers(users);
  return users[idx];
}

function publicUser(user) {
  if (!user) return null;
  const { email, tier, subscriptionStatus, createdAt } = user;
  return { email, tier, subscriptionStatus, createdAt };
}

// ── cookie helpers ───────────────────────────────────────────────────────
function parseCookies(req) {
  const header = req.headers.cookie || '';
  const out = {};
  header.split(';').forEach(pair => {
    const idx = pair.indexOf('=');
    if (idx === -1) return;
    const k = pair.slice(0, idx).trim();
    const v = pair.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  });
  return out;
}

const SESSION_COOKIE = 'nexus_session';

function setSessionCookie(res, token) {
  const maxAge = Math.floor(SESSION_TTL_MS / 1000);
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=${token}; Max-Age=${maxAge}; Path=/; HttpOnly; SameSite=Lax`);
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax`);
}

/** Attaches req.user (or null) based on the session cookie. Never blocks. */
function attachUser(req) {
  const cookies = parseCookies(req);
  const token = cookies[SESSION_COOKIE];
  if (!token) return null;
  const session = getSession(token);
  if (!session) return null;
  const user = findUser(session.email);
  return user || null;
}

module.exports = {
  createUser,
  authenticate,
  findUser,
  setTier,
  publicUser,
  createSession,
  getSession,
  destroySession,
  parseCookies,
  setSessionCookie,
  clearSessionCookie,
  attachUser,
  SESSION_COOKIE,
};
