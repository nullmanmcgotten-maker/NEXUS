/**
 * signalConfluence.js — cross-checks a Telegram-channel signal's stated
 * direction against Nexus's own technical-analysis engine (indicators.js)
 * for the same asset, and produces a plain-language explanation of whether
 * they agree.
 *
 * This is intentionally a SEPARATE, weaker claim from either input alone:
 * - A community call being "complete" (has entry/TP/SL) says nothing about
 *   whether the channel is actually good at calling trades.
 * - Nexus's own RSI/MACD/BB/EMA bias is a snapshot of recent price action,
 *   not a prediction — see indicators.js's own signals for what each one
 *   means and generateSignals' notes.
 * Confluence (both pointing the same way) is corroborating evidence, not
 * confirmation. Presented that way in the UI — never as "verified" or
 * "confirmed" language.
 */
'use strict';

const SignalConfluence = {
  _cache: new Map(), // coin -> { ts, result }
  CACHE_TTL_MS: 2 * 60 * 1000, // technical bias doesn't need to be recomputed every render

  /**
   * @param {string} coin - base asset, e.g. "STORJ"
   * @param {string} direction - "LONG" | "SHORT" | ""
   * @returns {Promise<{status:string, bias:string, taSignals:Array, error?:string}>}
   *   status: 'agree' | 'disagree' | 'mixed' | 'unavailable'
   */
  async check(coin, direction) {
    if (!coin) return { status: 'unavailable', bias: 'N/A', taSignals: [], error: 'no coin identified' };

    const cached = this._cache.get(coin);
    if (cached && Date.now() - cached.ts < this.CACHE_TTL_MS) return cached.result;

    let candles;
    try {
      candles = await fetchBinanceKlines(coin, '1h', 100);
    } catch (e) {
      const result = { status: 'unavailable', bias: 'N/A', taSignals: [], error: e.message };
      this._cache.set(coin, { ts: Date.now(), result });
      return result;
    }
    if (!candles || candles.length < 30) {
      const result = { status: 'unavailable', bias: 'N/A', taSignals: [], error: 'not enough price history on Binance for this symbol' };
      this._cache.set(coin, { ts: Date.now(), result });
      return result;
    }

    const closes = candles.map(c => c.c);
    const taSignals = TA.generateSignals(closes, candles);
    const biasLine = taSignals[0]; // {type, text, bold} — "Bias: BULLISH (n bullish · m bearish signals)"
    const bias = biasLine.text.includes('BULLISH') ? 'BULLISH' : biasLine.text.includes('BEARISH') ? 'BEARISH' : 'NEUTRAL';

    let status;
    if (!direction || bias === 'NEUTRAL') {
      status = 'mixed';
    } else if ((direction === 'LONG' && bias === 'BULLISH') || (direction === 'SHORT' && bias === 'BEARISH')) {
      status = 'agree';
    } else {
      status = 'disagree';
    }

    const result = { status, bias, taSignals, biasLine: biasLine.text };
    this._cache.set(coin, { ts: Date.now(), result });
    return result;
  },

  /** Short badge text + color for the given status. */
  badge(status) {
    switch (status) {
      case 'agree':    return { text: '✓ TA agrees', color: 'var(--green)' };
      case 'disagree': return { text: '✗ TA disagrees', color: 'var(--red)' };
      case 'mixed':    return { text: '~ TA mixed/neutral', color: 'var(--amber)' };
      default:         return { text: 'TA unavailable', color: 'var(--muted)' };
    }
  },
};
