/**
 * news.js — Multi-layer news aggregator.
 *
 * Layer 1: /api/news  (server.js endpoint — fetches RSS server-side, returns JSON)
 * Layer 2: rss2json.com  (free browser-CORS proxy, 1000/day)
 * Layer 3: allorigins.win (CORS proxy fallback)
 * Layer 4: Curated live links (always works — links open in new tab)
 */

const RSS_SOURCES = {
  markets: [
    { url:'https://feeds.reuters.com/reuters/businessNews',        name:'Reuters'        },
    { url:'https://feeds.bbci.co.uk/news/business/rss.xml',       name:'BBC Business'   },
    { url:'https://feeds.marketwatch.com/marketwatch/topstories',  name:'MarketWatch'    },
    { url:'https://www.cnbc.com/id/100003114/device/rss/rss.html',name:'CNBC'           },
    { url:'https://www.theguardian.com/business/rss',             name:'The Guardian'   },
    { url:'https://feeds.skynews.com/feeds/rss/business.xml',     name:'Sky News'       },
  ],
  stocks: [
    { url:'https://feeds.reuters.com/reuters/businessNews',        name:'Reuters'        },
    { url:'https://feeds.marketwatch.com/marketwatch/marketpulse', name:'MarketWatch'    },
    { url:'https://finance.yahoo.com/news/rssindex',               name:'Yahoo Finance'  },
    { url:'https://feeds.nasdaq.com/nasdaq/rss/headlines',         name:'Nasdaq'         },
    { url:'https://feeds.fool.com/usmf/headlines',                 name:'Motley Fool'    },
  ],
  crypto: [
    { url:'https://www.coindesk.com/arc/outboundfeeds/rss/',       name:'CoinDesk'       },
    { url:'https://cointelegraph.com/rss',                         name:'CoinTelegraph'  },
    { url:'https://decrypt.co/feed',                               name:'Decrypt'        },
    { url:'https://bitcoinmagazine.com/feed',                      name:'Bitcoin Mag'    },
    { url:'https://cryptonews.com/news/feed',                      name:'CryptoNews'     },
  ],
  forex: [
    { url:'https://www.fxstreet.com/rss/news',                     name:'FXStreet'       },
    { url:'https://feeds.reuters.com/reuters/businessNews',        name:'Reuters'        },
    { url:'https://www.dailyfx.com/feeds/all',                     name:'DailyFX'        },
    { url:'https://www.fxstreet.com/rss/analysis',                 name:'FXStreet Anlys' },
  ],
  economy: [
    { url:'https://feeds.reuters.com/reuters/businessNews',        name:'Reuters'        },
    { url:'https://feeds.bbci.co.uk/news/business/rss.xml',       name:'BBC Business'   },
    { url:'https://www.theguardian.com/business/economics/rss',   name:'Guardian Econ'  },
    { url:'https://feeds.npr.org/1017/rss.xml',                    name:'NPR Economy'    },
    { url:'https://www.aljazeera.com/xml/rss/all.xml',            name:'Al Jazeera'     },
  ],
};

// Direct links shown when all fetches fail (always clickable)
const FALLBACK_LINKS = {
  markets: ['https://www.reuters.com/business','https://www.bbc.co.uk/news/business','https://www.marketwatch.com','https://www.cnbc.com/markets'],
  stocks:  ['https://finance.yahoo.com','https://www.marketwatch.com','https://www.nasdaq.com/news-and-insights'],
  crypto:  ['https://coindesk.com','https://cointelegraph.com','https://decrypt.co'],
  forex:   ['https://www.fxstreet.com','https://www.dailyfx.com','https://www.forexlive.com'],
  economy: ['https://www.reuters.com/world/us','https://www.bbc.co.uk/news/business','https://www.theguardian.com/business/economics'],
};

// ── TAG ENGINE ────────────────────────────────────────────────────────────────
const TAG_RULES = [
  { w:['bitcoin','btc','ethereum','eth','crypto','blockchain','defi','solana','nft','web3','altcoin'],tag:'CRYPTO',  c:'amber'  },
  { w:['federal reserve','fed rate','rate cut','interest rate','boj','ecb','central bank','hawkish'], tag:'RATES',   c:'blue'   },
  { w:['earnings','revenue','profit','quarterly','eps','guidance','beat','miss','results'],            tag:'EARNINGS',c:'green'  },
  { w:['recession','gdp','inflation','cpi','unemployment','payroll','jobs report','pmi'],              tag:'MACRO',   c:'blue'   },
  { w:['surge','rally','soars','record high','all-time high','jumps','climbs','rallies'],              tag:'BULLISH', c:'green'  },
  { w:['drops','falls','plunges','crash','selloff','slumps','declines','tumbles','collapses'],         tag:'BEARISH', c:'red'    },
  { w:['eur/usd','gbp/usd','usd/jpy','forex','dollar index','pound','yen','yuan','franc'],             tag:'FOREX',   c:'blue'   },
  { w:['sec','regulation','ban','sanction','policy','compliance','oversight','ruling','lawsuit'],       tag:'POLICY',  c:'amber'  },
  { w:['merger','acquisition','ipo','deal','buyout','takeover','spinoff'],                             tag:'M&A',     c:'purple' },
  { w:['oil','gold','silver','copper','commodities','crude','brent','wti'],                            tag:'COMMOD',  c:'amber'  },
  { w:['tariff','trade war','export','import','supply chain','sanctions'],                             tag:'TRADE',   c:'amber'  },
  { w:['ai','artificial intelligence','nvidia','semiconductor','chips','openai','machine learning'],   tag:'TECH',    c:'blue'   },
  { w:['bank','banking','credit','loan','mortgage','bond','yield','treasury'],                         tag:'FINANCE', c:'blue'   },
];

function autoTag(title) {
  const l = title.toLowerCase();
  for (const r of TAG_RULES) if (r.w.some(w => l.includes(w))) return { tag:r.tag, tagColor:r.c };
  return { tag:'NEWS', tagColor:'blue' };
}

function relTime(s) {
  if (!s) return 'recently';
  const d = (Date.now() - new Date(s)) / 1000;
  if (isNaN(d)||d<0) return 'recently';
  if (d < 60)    return Math.round(d) + 's ago';
  if (d < 3600)  return Math.round(d/60) + 'm ago';
  if (d < 86400) return Math.round(d/3600) + 'h ago';
  return Math.round(d/86400) + 'd ago';
}

// ── FETCH STRATEGIES ─────────────────────────────────────────────────────────
async function tryServerEndpoint(feedUrl, name) {
  // Local server.js /api/news endpoint
  const isLocal = ['localhost','127.0.0.1'].includes(location.hostname);
  if (!isLocal) return [];
  try {
    const res  = await fetch(`/api/news?url=${encodeURIComponent(feedUrl)}`, { signal:AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error('HTTP '+res.status);
    const items = await res.json();
    return items.map(i => ({ ...i, source: name }));
  } catch(e) { return []; }
}

async function tryRss2Json(feedUrl, name) {
  try {
    const res  = await fetch(`https://api.rss2json.com/v1/api.json?count=8&rss_url=${encodeURIComponent(feedUrl)}`, { signal:AbortSignal.timeout(9000) });
    const data = await res.json();
    if (data.status !== 'ok' || !data.items?.length) return [];
    return data.items.map(i => ({
      title:   (i.title||'').trim(),
      pubDate: i.pubDate||'',
      link:    i.link||'#',
      image:   i.thumbnail||i.enclosure?.link||null,
      source:  name,
    })).filter(i => i.title.length > 15);
  } catch(e) { return []; }
}

async function tryAllOrigins(feedUrl, name) {
  try {
    const res  = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(feedUrl)}`, { signal:AbortSignal.timeout(10000) });
    const json = await res.json();
    if (!json.contents) return [];
    const xml  = new DOMParser().parseFromString(json.contents, 'text/xml');
    const items= [...xml.querySelectorAll('item')];
    return items.slice(0,8).map(el => ({
      title:   (el.querySelector('title')?.textContent||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim(),
      pubDate: (el.querySelector('pubDate')?.textContent||'').trim(),
      link:    (el.querySelector('link')?.textContent||'#').trim(),
      image:   el.querySelector('enclosure[type^="image"]')?.getAttribute('url')||null,
      source:  name,
    })).filter(i => i.title.length > 15);
  } catch(e) { return []; }
}

async function fetchOneFeed(feedUrl, name) {
  // Try all three strategies in order — already a fallback chain, just now
  // recorded so a "News: degraded" state is visible instead of silent.
  let items = await tryServerEndpoint(feedUrl, name);
  if (items.length) { if (typeof recordHealthSuccess==='function') recordHealthSuccess('news-feed'); return items; }

  items = await tryRss2Json(feedUrl, name);
  if (items.length) { if (typeof recordHealthSuccess==='function') recordHealthSuccess('news-feed'); return items; }

  items = await tryAllOrigins(feedUrl, name);
  if (items.length) { if (typeof recordHealthSuccess==='function') recordHealthSuccess('news-feed'); }
  else if (typeof recordHealthError==='function') recordHealthError('news-feed', `all 3 strategies failed for ${name}`);
  return items;
}

// Cache to avoid refetching every click
let _newsCache = {};
let _newsCacheTime = {};
const NEWS_CACHE_TTL = 5 * 60 * 1000; // 5 minutes

window._allNewsItems = [];

async function fetchAINews() {
  const category = document.getElementById('newsCategory')?.value || 'markets';
  const btn      = document.getElementById('fetchNewsBtn');
  const now      = Date.now();
  const cached   = _newsCache[category];
  const cacheAge = now - (_newsCacheTime[category]||0);

  if (btn) { btn.disabled = true; btn.textContent = '⟳ Fetching…'; }

  // Use cache if fresh
  if (cached?.length && cacheAge < NEWS_CACHE_TTL) {
    window._allNewsItems = cached;
    applyNewsFilter();
    if (btn) { btn.disabled=false; btn.textContent='⟳ Refresh'; }
    return;
  }

  showNewsLoading(category);

  const sources = RSS_SOURCES[category] || RSS_SOURCES.markets;

  // Fetch all feeds in parallel
  const results = await Promise.allSettled(
    sources.map(s => fetchOneFeed(s.url, s.name))
  );

  const all = [];
  results.forEach(r => { if (r.status==='fulfilled') all.push(...r.value); });

  if (!all.length) {
    showNewsFallback(category);
    if (btn) { btn.disabled=false; btn.textContent='⟳ Refresh'; }
    return;
  }

  // Deduplicate
  const seen   = new Set();
  const unique = all.filter(i => {
    const k = i.title.slice(0,50).toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });

  // Sort newest first
  unique.sort((a,b) => new Date(b.pubDate) - new Date(a.pubDate));

  // Build final items
  const items = unique.slice(0,24).map(i => ({
    title:  i.title, source: i.source, link:   i.link,
    time:   relTime(i.pubDate), image:  i.image,
    ...autoTag(i.title),
  }));

  // Cache it
  _newsCache[category]     = items;
  _newsCacheTime[category] = now;
  window._allNewsItems     = items;

  applyNewsFilter();
  if (btn) { btn.disabled=false; btn.textContent='⟳ Refresh'; }
}

function showNewsLoading(category) {
  document.getElementById('newsFeed').innerHTML = `
    <div style="padding:48px;text-align:center;">
      <div style="font-family:var(--mono);font-size:15px;color:var(--muted);margin-bottom:16px;">
        <span class="ldot">●</span> <span class="ldot">●</span> <span class="ldot">●</span>
        &nbsp; Fetching ${category} news…
      </div>
      <div style="font-family:var(--mono);font-size:12px;color:var(--muted);">
        Trying ${(RSS_SOURCES[category]||[]).length} sources via 3 fetch strategies
      </div>
    </div>`;
}

function showNewsFallback(category) {
  const links = FALLBACK_LINKS[category] || FALLBACK_LINKS.markets;
  document.getElementById('newsFeed').innerHTML = `
    <div style="padding:32px;">
      <div style="font-family:var(--mono);font-size:15px;color:var(--amber);margin-bottom:12px;text-align:center;">
        ⚠ RSS feeds blocked in this environment
      </div>
      <div style="font-family:var(--mono);font-size:13px;color:var(--muted);margin-bottom:20px;text-align:center;">
        Open sources directly — all open in new tab:
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin-bottom:24px;">
        ${links.map(url => {
          const name = new URL(url).hostname.replace('www.','').replace('feeds.','');
          return `<a href="${url}" target="_blank" rel="noopener" class="btn-sm" style="text-decoration:none;padding:10px 16px;font-size:12px;">
            🔗 ${name}
          </a>`;
        }).join('')}
      </div>
      <div style="background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:16px;max-width:500px;margin:0 auto;">
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-bottom:8px;">💡 For live news feed, run:</div>
        <code style="color:var(--accent);font-size:13px;">node server.js</code>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-top:6px;">The server fetches RSS server-side and serves it to the browser</div>
      </div>
    </div>`;
}

function applyNewsFilter() {
  const q     = (document.getElementById('newsSearch')?.value||'').toLowerCase().trim();
  const tag   = document.getElementById('newsTagFilter')?.value || 'all';
  let   items = window._allNewsItems;

  if (q)          items = items.filter(i => i.title.toLowerCase().includes(q) || i.source.toLowerCase().includes(q));
  if (tag!=='all') items = items.filter(i => i.tag === tag);

  const cnt = document.getElementById('newsCount');
  if (cnt) cnt.textContent = items.length + ' articles';
  renderNews(items.slice(0,9));
}

function renderNews(items) {
  if (!items.length) {
    document.getElementById('newsFeed').innerHTML = '<div style="padding:32px;text-align:center;font-family:var(--mono);color:var(--muted);">No articles match your filter.</div>';
    return;
  }
  document.getElementById('newsFeed').innerHTML = `<div class="news-grid">
    ${items.map(item => `
      <div class="news-card" onclick="window.open('${escAttr(item.link)}','_blank','noopener')">
        ${item.image ? `<div class="news-img" style="background-image:url('${escAttr(item.image)}')"></div>` : `<div class="news-img-placeholder"><span>${esc(item.source)}</span></div>`}
        <div class="news-meta">
          <span class="news-src">${esc(item.source)}</span>
          <span class="news-time">${esc(item.time)}</span>
          <span class="news-tag" style="${TAG_COLORS[item.tagColor]||TAG_COLORS.blue}">${esc(item.tag)}</span>
        </div>
        <div class="news-title">${esc(item.title)}</div>
        <div class="news-read-more">Read full article →</div>
      </div>`).join('')}
  </div>`;
}
