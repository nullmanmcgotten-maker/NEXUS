/**
 * forex.js — Forex OHLC from Frankfurter ECB API for charts.
 * Rate polling (fetchLiveForex / startForexPolling) is in realtime.js.
 * This file is kept for chart-specific OHLC fetching.
 */

// fetchForexOHLC is defined in realtime.js
// startForexPolling is defined in realtime.js
// fetchLiveForex is defined in realtime.js

// Re-export for backwards compatibility with any direct calls
// (everything is already in realtime.js — this file is now a stub)
console.log('[Forex] Module loaded. Rate polling handled by realtime.js');
