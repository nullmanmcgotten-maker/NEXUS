/**
 * ticker.js — Topbar ticker using real live prices from positions + watchlist.
 */
function buildTicker() {
  const items = [...positions, ...watchlist].map(p => ({
    sym: p.sym, price: safeNum(p.price), chg: safeNum(p.chg),
  }));
  const all = [...items, ...items]; // duplicate for infinite scroll
  document.getElementById('tickerScroll').innerHTML = all.map(t => {
    const ps  = t.price < 10 ? t.price.toFixed(4) : fmtNum(t.price);
    const isUp= t.chg >= 0;
    return `<div class="tick-item">
      <span class="tick-sym">${t.sym}</span>
      <span class="tick-price">${ps}</span>
      <span style="font-family:var(--mono);font-size:12px;color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':''}${t.chg.toFixed(2)}%</span>
    </div>`;
  }).join('');
}

function startClock() {
  function tick() {
    const n = new Date();
    const h = String(n.getUTCHours()).padStart(2,'0');
    const m = String(n.getUTCMinutes()).padStart(2,'0');
    const s = String(n.getUTCSeconds()).padStart(2,'0');
    const el = document.getElementById('clockDisplay');
    if (el) el.textContent = `${h}:${m}:${s} UTC`;
  }
  tick();
  setInterval(tick, 1000);
}
