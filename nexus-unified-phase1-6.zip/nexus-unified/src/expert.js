/**
 * expert.js — Expert-level tools for professionals and advanced users.
 *
 * 1. Position Sizing Calculator (Kelly Criterion + Fixed Risk)
 * 2. P&L Calculator with fees (crypto maker/taker, stock commissions)
 * 3. Correlation Matrix (between portfolio assets)
 * 4. Fear & Greed Index (alternative.me API — free, CORS open)
 * 5. Multi-timeframe analysis summary
 * 6. Risk/Reward planner
 */

// ── FEAR & GREED INDEX ───────────────────────────────────────────────────────
async function fetchFearGreed() {
  try {
    const res  = await fetch('https://api.alternative.me/fng/?limit=7', { signal: AbortSignal.timeout(6000) });
    const data = await res.json();
    renderFearGreed(data.data || []);
  } catch(e) {
    const el = document.getElementById('fearGreedPanel');
    if (el) el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;text-align:center;padding:16px;">⚠ Fear & Greed offline</div>`;
  }
}

function renderFearGreed(data) {
  const el = document.getElementById('fearGreedPanel');
  if (!el || !data.length) return;
  const now      = data[0];
  const val      = parseInt(now.value);
  const label    = now.value_classification;
  const color    = val>=75?'var(--green)':val>=55?'#90ee90':val>=45?'var(--amber)':val>=25?'#ff8c00':'var(--red)';
  const arc      = (val/100)*180;

  el.innerHTML = `
    <div style="text-align:center;padding:8px 0;">
      <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;margin-bottom:12px;">
        Crypto Fear &amp; Greed Index
      </div>
      <!-- Gauge -->
      <div style="position:relative;width:180px;height:100px;margin:0 auto 12px;">
        <svg viewBox="0 0 180 100" style="width:100%;overflow:visible;">
          <!-- Background arc -->
          <path d="M 10 90 A 80 80 0 0 1 170 90" fill="none" stroke="var(--bg4)" stroke-width="16" stroke-linecap="round"/>
          <!-- Value arc -->
          <path d="M 10 90 A 80 80 0 0 1 170 90" fill="none"
            stroke="${color}" stroke-width="16" stroke-linecap="round"
            stroke-dasharray="${(val/100)*251.2} 251.2"/>
          <!-- Zone labels -->
          <text x="10"  y="100" fill="var(--red)"   font-size="8" font-family="monospace">Fear</text>
          <text x="145" y="100" fill="var(--green)" font-size="8" font-family="monospace">Greed</text>
        </svg>
        <div style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);text-align:center;">
          <div style="font-family:var(--mono);font-size:32px;font-weight:700;color:${color};line-height:1;">${val}</div>
          <div style="font-family:var(--mono);font-size:11px;color:${color};margin-top:2px;">${label}</div>
        </div>
      </div>
      <!-- 7-day history -->
      <div style="display:flex;gap:4px;justify-content:center;margin-top:8px;">
        ${data.slice(0,7).reverse().map((d,i) => {
          const v=parseInt(d.value), c=v>=55?'var(--green)':v>=45?'var(--amber)':'var(--red)';
          return `<div style="text-align:center;" title="${d.value_classification}: ${d.value}">
            <div style="width:22px;height:${Math.max(8,v*0.4)}px;background:${c};border-radius:2px 2px 0 0;opacity:${i===6?1:0.55};"></div>
            <div style="font-family:var(--mono);font-size:8px;color:var(--muted);margin-top:2px;">${v}</div>
          </div>`;
        }).join('')}
      </div>
      <div style="font-family:var(--mono);font-size:9px;color:var(--muted);margin-top:8px;">Source: alternative.me · Updated daily</div>
    </div>`;
}

// ── POSITION SIZING CALCULATOR ────────────────────────────────────────────────
function renderPositionSizer() {
  const el = document.getElementById('positionSizerPanel');
  if (!el) return;
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <!-- Kelly Criterion -->
      <div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;margin-bottom:12px;">Kelly Criterion</div>
        <div style="margin-bottom:8px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Win Rate (%)</label>
          <input class="inp" id="kellyWin" type="number" value="55" min="1" max="99" style="margin-top:4px;" oninput="calcKelly()"/>
        </div>
        <div style="margin-bottom:8px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Avg Win / Avg Loss Ratio</label>
          <input class="inp" id="kellyRatio" type="number" value="1.5" step="0.1" min="0.1" style="margin-top:4px;" oninput="calcKelly()"/>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Portfolio Size ($)</label>
          <input class="inp" id="kellyPortfolio" type="number" value="${Math.round(totalPortfolioValue())}" style="margin-top:4px;" oninput="calcKelly()"/>
        </div>
        <div id="kellyResult" class="expert-result"></div>
      </div>

      <!-- Fixed Risk Sizing -->
      <div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;margin-bottom:12px;">Fixed Risk Sizing</div>
        <div style="margin-bottom:8px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Risk Per Trade (%)</label>
          <input class="inp" id="riskPct" type="number" value="1" step="0.5" min="0.1" max="10" style="margin-top:4px;" oninput="calcFixedRisk()"/>
        </div>
        <div style="margin-bottom:8px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Entry Price</label>
          <input class="inp" id="riskEntry" type="number" value="" placeholder="e.g. 45000" style="margin-top:4px;" oninput="calcFixedRisk()"/>
        </div>
        <div style="margin-bottom:12px;">
          <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Stop Loss Price</label>
          <input class="inp" id="riskStop" type="number" value="" placeholder="e.g. 44000" style="margin-top:4px;" oninput="calcFixedRisk()"/>
        </div>
        <div id="fixedRiskResult" class="expert-result"></div>
      </div>
    </div>`;
  calcKelly();
  calcFixedRisk();
}

function calcKelly() {
  const win   = safeNum(document.getElementById('kellyWin')?.value) / 100;
  const ratio = safeNum(document.getElementById('kellyRatio')?.value);
  const port  = safeNum(document.getElementById('kellyPortfolio')?.value) || totalPortfolioValue();
  const el    = document.getElementById('kellyResult');
  if (!el) return;
  if (!win || !ratio) { el.innerHTML='<div style="color:var(--muted);font-size:12px;">Enter values above</div>'; return; }
  const kelly     = (win - (1-win)/ratio) * 100;
  const halfKelly = kelly / 2;
  const posSize   = (Math.max(0, halfKelly) / 100) * port;
  const color     = kelly > 0 ? 'var(--green)' : 'var(--red)';
  el.innerHTML = `
    <div class="expert-result-row"><span>Full Kelly</span><span style="color:${color};font-weight:700;">${kelly.toFixed(1)}%</span></div>
    <div class="expert-result-row"><span>Half Kelly (recommended)</span><span style="color:var(--accent);font-weight:700;">${Math.max(0,halfKelly).toFixed(1)}%</span></div>
    <div class="expert-result-row"><span>Position Size</span><span style="color:var(--text);font-weight:700;">$${fmtNum(Math.max(0,posSize))}</span></div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:6px;">${kelly<=0?'Edge is negative — skip this trade':'Half-Kelly reduces variance, use full Kelly with caution'}</div>`;
}

function calcFixedRisk() {
  const pct   = safeNum(document.getElementById('riskPct')?.value);
  const entry = safeNum(document.getElementById('riskEntry')?.value);
  const stop  = safeNum(document.getElementById('riskStop')?.value);
  const port  = totalPortfolioValue();
  const el    = document.getElementById('fixedRiskResult');
  if (!el) return;
  if (!entry || !stop) { el.innerHTML='<div style="color:var(--muted);font-size:12px;">Enter entry & stop prices</div>'; return; }
  const riskAmt   = (pct / 100) * port;
  const riskPerUnit = Math.abs(entry - stop);
  if (!riskPerUnit) { el.innerHTML='<div style="color:var(--red);font-size:12px;">Entry and stop cannot be equal</div>'; return; }
  const units   = riskAmt / riskPerUnit;
  const posVal  = units * entry;
  const portPct = (posVal / port) * 100;
  const rrLabel = entry > stop ? 'Long' : 'Short';
  el.innerHTML = `
    <div class="expert-result-row"><span>Risk Amount</span><span style="color:var(--red);font-weight:700;">$${fmtNum(riskAmt)}</span></div>
    <div class="expert-result-row"><span>Units to Buy</span><span style="color:var(--accent);font-weight:700;">${fmtNum(units,4)}</span></div>
    <div class="expert-result-row"><span>Position Value</span><span style="color:var(--text);font-weight:700;">$${fmtNum(posVal)}</span></div>
    <div class="expert-result-row"><span>% of Portfolio</span><span style="color:${portPct>20?'var(--red)':'var(--amber)'};">${portPct.toFixed(1)}%</span></div>
    <div class="expert-result-row"><span>Direction</span><span style="color:var(--muted);">${rrLabel}</span></div>`;
}

// ── P&L CALCULATOR WITH FEES ─────────────────────────────────────────────────
function renderPnlCalculator() {
  const el = document.getElementById('pnlCalcPanel');
  if (!el) return;
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:12px;">
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Asset Type</label>
        <select class="inp" id="pnlType" style="margin-top:4px;" onchange="calcPnl()">
          <option value="crypto">Crypto (Binance)</option>
          <option value="stock">Stock (US)</option>
          <option value="forex">Forex (Spread)</option>
          <option value="custom">Custom Fees</option>
        </select>
      </div>
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Entry Price</label>
        <input class="inp" id="pnlEntry" type="number" placeholder="e.g. 45000" style="margin-top:4px;" oninput="calcPnl()"/>
      </div>
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Exit Price</label>
        <input class="inp" id="pnlExit"  type="number" placeholder="e.g. 48000" style="margin-top:4px;" oninput="calcPnl()"/>
      </div>
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Quantity</label>
        <input class="inp" id="pnlQty"   type="number" value="1" step="any"   style="margin-top:4px;" oninput="calcPnl()"/>
      </div>
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Leverage (1x = none)</label>
        <input class="inp" id="pnlLev"   type="number" value="1" min="1" max="100" style="margin-top:4px;" oninput="calcPnl()"/>
      </div>
      <div>
        <label style="font-family:var(--mono);font-size:11px;color:var(--muted);">Custom Fee %</label>
        <input class="inp" id="pnlFee"   type="number" value="0.1" step="0.01" style="margin-top:4px;" oninput="calcPnl()"/>
      </div>
    </div>
    <div id="pnlResult"></div>`;
  calcPnl();
}

const FEE_PRESETS = {
  crypto: { maker:0.1, taker:0.1, label:'Binance spot (0.1% each side)' },
  stock:  { maker:0.0, taker:0.005, label:'US stocks ($0 commission, 0.005% SEC fee)' },
  forex:  { maker:0.02,taker:0.02, label:'Forex typical spread (~0.02% per side)' },
  custom: { maker:0.0, taker:0.0,  label:'Custom fees' },
};

function calcPnl() {
  const type  = document.getElementById('pnlType')?.value || 'crypto';
  const entry = safeNum(document.getElementById('pnlEntry')?.value);
  const exit  = safeNum(document.getElementById('pnlExit')?.value);
  const qty   = safeNum(document.getElementById('pnlQty')?.value) || 1;
  const lev   = safeNum(document.getElementById('pnlLev')?.value) || 1;
  const custFee = safeNum(document.getElementById('pnlFee')?.value) / 100;
  const el    = document.getElementById('pnlResult');
  if (!el || !entry || !exit) { if(el) el.innerHTML='<div style="color:var(--muted);font-size:12px;">Enter entry and exit prices</div>'; return; }

  const preset   = FEE_PRESETS[type] || FEE_PRESETS.custom;
  const feeIn    = type === 'custom' ? custFee : preset.taker / 100;
  const feeOut   = type === 'custom' ? custFee : preset.taker / 100;

  const notional = entry * qty;
  const feeInAmt = notional * feeIn;
  const gross    = (exit - entry) * qty * lev;
  const feeOutAmt= exit * qty * lev * feeOut;
  const net      = gross - feeInAmt - feeOutAmt;
  const pct      = entry ? (net / notional) * 100 : 0;
  const roe      = entry ? (gross / (notional / lev)) * 100 : 0;
  const isUp     = net >= 0;

  el.innerHTML = `
    <div style="background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:14px;">
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-bottom:10px;">${preset.label}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;">
        <div class="expert-result-row-v"><span>Gross P&L</span><span style="color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':'-'}$${fmtNum(Math.abs(gross))}</span></div>
        <div class="expert-result-row-v"><span>Total Fees</span><span style="color:var(--red);">-$${fmtNum(feeInAmt+feeOutAmt)}</span></div>
        <div class="expert-result-row-v"><span>Net P&L</span><span style="color:${isUp?'var(--green)':'var(--red)'};font-size:18px;font-weight:700;">${isUp?'+':'-'}$${fmtNum(Math.abs(net))}</span></div>
        <div class="expert-result-row-v"><span>Return %</span><span style="color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':''}${pct.toFixed(2)}%</span></div>
        <div class="expert-result-row-v"><span>ROE ${lev>1?'('+lev+'x)':''}</span><span style="color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':''}${roe.toFixed(2)}%</span></div>
        <div class="expert-result-row-v"><span>Breakeven</span><span style="color:var(--muted);">$${fmtNum(entry*(1+feeIn+feeOut),4)}</span></div>
      </div>
    </div>`;
}

// ── CORRELATION MATRIX ───────────────────────────────────────────────────────
function computeCorrelation(a, b) {
  const n  = Math.min(a.length, b.length);
  if (n < 5) return null;
  const aS = a.slice(-n), bS = b.slice(-n);
  const mA = aS.reduce((s,v)=>s+v,0)/n, mB = bS.reduce((s,v)=>s+v,0)/n;
  let cov=0, dA=0, dB=0;
  for (let i=0;i<n;i++){cov+=(aS[i]-mA)*(bS[i]-mB);dA+=(aS[i]-mA)**2;dB+=(bS[i]-mB)**2;}
  const d = Math.sqrt(dA*dB);
  return d ? parseFloat((cov/d).toFixed(2)) : null;
}

function renderCorrelationMatrix() {
  const el = document.getElementById('correlationMatrix');
  if (!el) return;

  const assets = positions.filter(p => {
    const h = window._priceHistory?.[p.sym];
    return h && h.length >= 10;
  }).slice(0, 8);

  if (assets.length < 2) {
    el.innerHTML = `<div style="text-align:center;padding:24px;font-family:var(--mono);font-size:13px;color:var(--muted);">
      Need at least 2 positions with price history (accumulates over time as prices tick in).
    </div>`;
    return;
  }

  const returns = assets.map(a => {
    const h = window._priceHistory[a.sym];
    return h.slice(1).map((x,i) => (x.p - h[i].p) / h[i].p);
  });

  const corr = assets.map((a,i) => assets.map((b,j) => computeCorrelation(returns[i], returns[j])));
  const corrColor = v => {
    if (v === null) return 'var(--bg4)';
    if (v >= 0.7)  return 'rgba(255,77,106,0.6)';
    if (v >= 0.4)  return 'rgba(255,166,35,0.4)';
    if (v >= 0.1)  return 'rgba(255,255,255,0.08)';
    if (v >= -0.1) return 'rgba(255,255,255,0.04)';
    if (v >= -0.4) return 'rgba(0,150,255,0.2)';
    return 'rgba(0,212,170,0.4)';
  };

  el.innerHTML = `
    <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-bottom:10px;">
      <span style="background:rgba(255,77,106,0.6);padding:2px 6px;border-radius:2px;margin-right:6px;">High +corr</span>
      <span style="background:rgba(0,212,170,0.4);padding:2px 6px;border-radius:2px;margin-right:6px;">Negative corr</span>
      <span style="background:rgba(255,255,255,0.06);padding:2px 6px;border-radius:2px;">Uncorrelated</span>
    </div>
    <div style="overflow-x:auto;">
      <table style="border-collapse:collapse;font-family:var(--mono);font-size:12px;">
        <tr>
          <th style="padding:6px;color:var(--muted);"></th>
          ${assets.map(a => `<th style="padding:6px 10px;color:var(--text);font-weight:600;">${a.sym}</th>`).join('')}
        </tr>
        ${assets.map((a,i) => `
          <tr>
            <td style="padding:6px 10px;color:var(--text);font-weight:600;">${a.sym}</td>
            ${corr[i].map((v,j) => `
              <td style="padding:6px 10px;text-align:center;background:${corrColor(v)};border-radius:3px;">
                ${i===j ? '—' : v!==null ? v.toFixed(2) : 'n/a'}
              </td>`).join('')}
          </tr>`).join('')}
      </table>
    </div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">
      Based on ${returns[0]?.length||0} price ticks. More ticks = more accurate. Updates in real-time.
    </div>`;
}

// ── RENDER ALL EXPERT PANELS ─────────────────────────────────────────────────
function renderExpertTools() {
  renderPositionSizer();
  renderPnlCalculator();
  renderCorrelationMatrix();
  fetchFearGreed();
}
