/**
 * portfolio.js — Overview, positions, watchlist, multi-portfolio switcher
 */
let currentFilter = 'all';

// ── HERO ──────────────────────────────────────────────────────────────────────
function updateHero(){
  const total   = totalPortfolioValue();
  const cash    = window.portfolios[window.activePortfolioId]?.cash || 8200;
  const dayPnl  = positions.reduce((s,p) => s + safeNum(p.qty)*safeNum(p.price)*(safeNum(p.chg)/100), 0);
  const totPnl  = positions.reduce((s,p) => s + posPnl(p), 0);
  const dayPct  = total > 0 ? (dayPnl/total)*100 : 0;

  const tvEl = document.getElementById('totalValue');
  if (tvEl) tvEl.textContent = '$' + fmtNum(total);

  const hs = document.getElementById('heroSub');
  if (hs) {
    hs.innerHTML = `${dayPnl>=0?'▲':'▼'} ${fmtMoney(Math.abs(dayPnl))} &nbsp;${fmtPct(dayPct)} today`;
    hs.className = 'hero-sub ' + (dayPnl>=0?'up':'dn');
  }

  const badge = document.getElementById('portfBadge');
  if (badge) { badge.textContent = fmtPct(dayPct)+' TODAY'; badge.className='badge '+(dayPnl>=0?'badge-green':'badge-red'); }

  const de = document.getElementById('dayPnl');
  if (de) { de.textContent=(dayPnl>=0?'+':'-')+fmtMoney(Math.abs(dayPnl)); de.className='hstat-val '+(dayPnl>=0?'up':'dn'); }

  const te = document.getElementById('totalPnl');
  if (te) { te.textContent=(totPnl>=0?'+':'-')+fmtMoney(Math.abs(totPnl)); te.className='hstat-val '+(totPnl>=0?'up':'dn'); }

  const pc = document.getElementById('posCount');
  if (pc) pc.textContent = positions.length;

  const ce = document.getElementById('cashVal');
  if (ce) ce.textContent = '$' + fmtNum(cash);

  if (positions.length) {
    const best  = positions.reduce((a,b) => safeNum(b.chg)>safeNum(a.chg)?b:a);
    const worst = positions.reduce((a,b) => safeNum(b.chg)<safeNum(a.chg)?b:a);
    const be = document.getElementById('bestPos');
    const we = document.getElementById('worstPos');
    if (be) be.textContent = best.sym+' '+fmtPct(safeNum(best.chg));
    if (we) we.textContent = worst.sym+' '+fmtPct(safeNum(worst.chg));
  }
}

// ── ALLOCATION ────────────────────────────────────────────────────────────────
function buildAllocation(){
  const byType = {};
  positions.forEach(p => { byType[p.type] = (byType[p.type]||0) + posDisplayValue(p); });
  const total = Object.values(byType).reduce((a,b)=>a+b, 0) || 1;
  const META  = { stock:{label:'Equities',color:'#00d4aa'}, crypto:{label:'Crypto',color:'#9945ff'}, forex:{label:'Forex',color:'#0096ff'} };
  const el    = document.getElementById('allocBars');
  if (!el) return;
  el.innerHTML = Object.entries(byType).sort((a,b)=>b[1]-a[1]).map(([type,val])=>{
    const pct = ((val/total)*100).toFixed(1), meta = META[type]||{label:type,color:'#5a6478'};
    return `<div class="alloc-row">
      <div class="alloc-label"><span class="alloc-name">${meta.label}</span><span class="alloc-pct">${pct}%</span></div>
      <div class="alloc-bar"><div class="alloc-fill" style="width:${pct}%;background:${meta.color};"></div></div>
    </div>`;
  }).join('');
}

// ── POSITIONS TABLE ───────────────────────────────────────────────────────────
function renderPositions(){
  const list = currentFilter==='all' ? positions : positions.filter(p=>p.type===currentFilter);
  const el   = document.getElementById('positionsList');
  if (!el) return;
  el.innerHTML = list.map(p => {
    const val    = posDisplayValue(p);
    const pnl    = posPnl(p);
    const pnlPct = posPnlPct(p);
    const isUp   = safeNum(p.chg) >= 0;
    const isPnlUp= pnl >= 0;
    const priceStr = safeNum(p.price) < 10 ? safeNum(p.price).toFixed(4) : fmtNum(safeNum(p.price));
    return `<div class="pos-row" onclick="openAssetChart('${p.sym}','${p.name}','${p.type}')">
      <div class="a-icon" style="background:${iconBg(p.type)};color:${iconColor(p.type)};">${p.sym.replace('/','').slice(0,3)}</div>
      <div><div class="a-name">${p.sym}</div><div class="a-sub">${p.name} · ${safeNum(p.qty).toLocaleString()} units</div></div>
      <div class="cr">$${priceStr}</div>
      <div class="cr ${isUp?'up':'dn'}">${fmtPct(safeNum(p.chg))}</div>
      <div class="cr">$${fmtNum(val)}</div>
      <div class="cr ${isPnlUp?'up':'dn'}">${isPnlUp?'+':'-'}$${fmtNum(Math.abs(pnl))}</div>
      <div class="cr ${isPnlUp?'up':'dn'}">${fmtPct(pnlPct)}</div>
      <div class="r"><span class="badge ${typeBadge(p.type)}">${p.type.toUpperCase()}</span></div>
      <div class="r" onclick="event.stopPropagation()">
        <button class="rm-btn" onclick="removePosition(${p.id})" title="Remove">✕</button>
      </div>
    </div>`;
  }).join('') || '<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:13px;color:var(--muted);">No positions. Add one above.</div>';
}

function filterPositions(type, btn){
  currentFilter = type;
  document.querySelectorAll('.pill').forEach(t=>t.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderPositions();
}

function addPosition(override){
  const type  = override?.type  ?? document.getElementById('assetType')?.value;
  const sym   = (override?.sym ?? document.getElementById('addSymbol')?.value ?? '').trim().toUpperCase();
  const qty   = override?.qty   !== undefined ? safeNum(override.qty)   : safeNum(document.getElementById('addQty')?.value);
  const price = override?.price !== undefined ? safeNum(override.price) : safeNum(document.getElementById('addPrice')?.value);
  if (!sym||qty<=0||price<=0) { alert('Fill all fields correctly.'); return; }
  const newPos = {id:window._nextId++, type, sym, name:sym, qty, avgPrice:price, price, chg:0};
  positions.push(newPos);
  // Log to journal
  logTrade({ action:'BUY', sym, type, qty, price, note: override ? 'Position opened (Trade Cockpit)' : 'Position opened' });
  if (!override) ['addSymbol','addQty','addPrice'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  savePositions(); savePortfolios(); updateAll();
  if (type==='crypto' && typeof refreshCryptoWS==='function') refreshCryptoWS();
}

function removePosition(id){
  const p = positions.find(x=>x.id===id);
  if (p) logTrade({ action:'CLOSE', sym:p.sym, type:p.type, qty:p.qty, price:p.price, note:'Position closed' });
  const idx = positions.findIndex(x=>x.id===id);
  if (idx!==-1) { positions.splice(idx,1); savePositions(); savePortfolios(); updateAll(); }
}

// ── MULTI-PORTFOLIO ───────────────────────────────────────────────────────────
function renderPortfolioSwitcher(){
  const el = document.getElementById('portfolioSwitcher');
  if (!el) return;
  const names = Object.entries(window.portfolios);
  el.innerHTML = `
    <div class="port-switcher">
      ${names.map(([id,p])=>`
        <button class="port-btn ${id===window.activePortfolioId?'active':''}" onclick="switchPortfolio('${id}')">
          ${esc(p.name)}
          ${names.length>1?`<span class="port-del" onclick="event.stopPropagation();deletePortfolio('${id}')">✕</span>`:''}
        </button>`).join('')}
      <button class="port-btn port-add" onclick="createNewPortfolio()">＋ New</button>
    </div>`;
}

function switchPortfolio(id){
  if (!window.portfolios[id]) return;
  window.activePortfolioId = id;
  localStorage.setItem('nexus_active_portfolio', id);
  renderPortfolioSwitcher();
  updateAll();
  if (typeof connectBinanceWS==='function') setTimeout(connectBinanceWS, 300);
}

function createNewPortfolio(){
  const name = prompt('Portfolio name:');
  if (!name) return;
  const id = 'port_' + genId();
  window.portfolios[id] = { name, positions:[], cash:0, createdAt:Date.now() };
  savePortfolios();
  switchPortfolio(id);
}

function deletePortfolio(id){
  if (Object.keys(window.portfolios).length<=1){ alert('Cannot delete the last portfolio.'); return; }
  if (!confirm('Delete portfolio "'+window.portfolios[id]?.name+'"?')) return;
  delete window.portfolios[id];
  savePortfolios();
  window.activePortfolioId = Object.keys(window.portfolios)[0];
  localStorage.setItem('nexus_active_portfolio', window.activePortfolioId);
  renderPortfolioSwitcher();
  updateAll();
}

// ── WATCHLIST ─────────────────────────────────────────────────────────────────
function renderWatchlist(){
  const el = document.getElementById('watchlistContainer');
  if (!el) return;
  el.innerHTML = `<div class="watch-grid">${watchlist.map((w,idx)=>{
    const ps=safeNum(w.price)<10?safeNum(w.price).toFixed(4):fmtNum(safeNum(w.price));
    const isUp=safeNum(w.chg)>=0;
    return `<div class="watch-card">
      <div class="watch-head" onclick="document.getElementById('wb-${idx}').classList.toggle('open')">
        <div style="display:flex;align-items:center;gap:12px;">
          <div class="a-icon" style="background:${iconBg(w.type)};color:${iconColor(w.type)};width:36px;height:36px;font-size:9px;">${w.sym.replace('/','').slice(0,3)}</div>
          <div><div class="watch-sym">${w.sym}</div><div class="watch-name">${w.name}</div></div>
        </div>
        <div style="text-align:right;">
          <div class="watch-price ${isUp?'up':'dn'}">$${ps}</div>
          <div class="watch-chg ${isUp?'up':'dn'}">${fmtPct(safeNum(w.chg))}</div>
        </div>
      </div>
      <div class="watch-body" id="wb-${idx}">
        <div class="watch-links">
          <a class="w-link" href="https://www.youtube.com/results?search_query=${encodeURIComponent(w.sym+' analysis 2026')}" target="_blank" rel="noopener">▶ YouTube</a>
          <a class="w-link" href="https://finance.yahoo.com/quote/${encodeURIComponent(w.sym.replace('/','-'))}" target="_blank" rel="noopener">📊 Yahoo</a>
          <a class="w-link" href="https://www.tradingview.com/symbols/${encodeURIComponent(w.sym.replace('/',''))}" target="_blank" rel="noopener">📈 TradingView</a>
          <button class="w-link" onclick="openAssetChart('${w.sym}','${w.name}','${w.type}')">🔍 Chart+TA</button>
        </div>
        <textarea class="watch-notes" placeholder="Notes…" onchange="watchlist[${idx}].notes=this.value">${w.notes||''}</textarea>
        <button class="watch-rm" onclick="watchlist.splice(${idx},1);renderWatchlist()">Remove</button>
      </div>
    </div>`;
  }).join('')}</div>`;
}

function openAddWatchModal(){ document.getElementById('addWatchModal')?.classList.remove('hidden'); }
function closeAddWatchModal(){ document.getElementById('addWatchModal')?.classList.add('hidden'); ['wSym','wName','wPrice'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';}); }
function addToWatchlist(){
  const sym=document.getElementById('wSym')?.value.trim().toUpperCase();
  const name=document.getElementById('wName')?.value.trim()||sym;
  const price=safeNum(document.getElementById('wPrice')?.value);
  const type=document.getElementById('wType')?.value;
  if(!sym||price<=0){alert('Enter symbol and price.');return;}
  watchlist.push({sym,name,type,price,chg:0,notes:''});
  closeAddWatchModal(); renderWatchlist();
  if(type==='crypto'&&typeof refreshCryptoWS==='function') refreshCryptoWS();
}

function buildChartPicker(){
  const el = document.getElementById('chartPickerGrid');
  if (!el) return;
  const all = [...positions.map(p=>({sym:p.sym,name:p.name,type:p.type})), ...watchlist.map(w=>({sym:w.sym,name:w.name,type:w.type}))];
  el.innerHTML = all.map(a=>`<button class="chart-pick-btn" onclick="openAssetChart('${a.sym}','${a.name}','${a.type}');document.querySelectorAll('.chart-pick-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active')">${a.sym}</button>`).join('');
}

function updateAll(){
  updateHero(); buildAllocation(); renderPositions(); renderWatchlist();
  buildTicker(); buildMiniChart(); checkAlerts();
  renderHeatmap(); renderScreener(); buildChartPicker();
  renderPortfolioSwitcher(); renderAnalytics();
  if (typeof runSignalScanner==='function') runSignalScanner();
}
