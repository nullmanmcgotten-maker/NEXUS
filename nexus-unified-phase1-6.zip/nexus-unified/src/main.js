/**
 * main.js — Bootstrap. No simulation. All browser-side real data.
 */
window.addEventListener('DOMContentLoaded', () => {
  applyTheme(localStorage.getItem('nexus_theme')    || 'default');
  applyDensity(localStorage.getItem('nexus_density') || 'normal');
  checkShareParam();
  initTabs();

  // Render UI with cached/stored data first
  updateAll();
  buildPerfChart();
  buildConverter();
  renderAlerts();
  renderJournal();
  renderScannerAlerts();
  startClock();
  checkPushPermission();
  renderThemePanel();
  renderTelegramPanel();

  // ── ALL REAL DATA — browser fetches directly ────────────────────────────────
  startCryptoWS();       // Binance WS + REST snapshot   (real-time)
  startForexPolling();   // open.er-api.com               (every 60s)
  startStockPolling();   // Yahoo Finance v7               (every 15s)
  startGlobalMarkets();  // Yahoo Finance v7 bulk          (every 90s)
  startHeatmapPolling(); // Binance bulk + Yahoo bulk      (every 30s)
  startPortfolioHistory();
  startTrendingPolling(); // localStorage snapshots       (every 60s)
  fetchAINews();         // rss2json + allorigins          (on demand)
  startMacroNewsPolling(); // severity-scored macro alerts (every 3 min)
  startDataHealthTracking(); // pill + dropdown, no fetches of its own — just observes apiFetch/hlPost
  startPerpAlertPolling(); // re-scores top perps every 5min so 🎯/🔥/⚡ alerts fire even off-tab

  // Expert tools (lazy - render on tab click)

  // Signal scanner on real price history
  setInterval(runSignalScanner, 30000);
  // Redraw charts with fresh history
  setInterval(() => { buildPerfChart(); buildMiniChart(); }, 60000);
  // Screener refresh
  setInterval(renderScreener, 10000);

  // ── TAB VISIBILITY RECOVERY ──────────────────────────────────────────────
  // Browsers throttle backgrounded tabs (Chrome clamps setInterval/setTimeout
  // to ~1/min after ~5 min hidden) and can silently drop a long-idle
  // WebSocket without firing onclose promptly — laptop sleep/wake and VPN/
  // network changes are the most common triggers. Left alone, that can look
  // exactly like "the app died, I need to restart something" even though
  // every polling loop above would eventually self-heal on its own; this
  // just makes it immediate instead of waiting on a throttled timer. (The
  // service worker was a second, bigger contributor to that same symptom —
  // see sw.js v3 for why /api/news and /proxy were being served stale
  // forever regardless of what the server was doing; that's fixed now too.)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    ensureCryptoWSConnected(); // forces reconnect immediately if the WS dropped while backgrounded, no-op otherwise
    fetchInitialCryptoPrices();
    fetchLiveForex();
    pollStockPrices();
    updateAll();
  });
});

function initTabs() {
  initNavGroups();
  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      const panel = document.getElementById('tab-'+btn.dataset.tab);
      if (panel) panel.classList.add('active');
      // remember the last-opened tab per group, so re-clicking a group
      // restores where the user left off instead of always resetting to its first tab
      if (btn.dataset.group) {
        try { localStorage.setItem('nexus_lastTab_'+btn.dataset.group, btn.dataset.tab); } catch(e) {}
      }
      if (btn.dataset.tab==='calendar')  fetchEconomicCalendar();
      if (btn.dataset.tab==='analytics') { renderAnalytics(); renderJournal(); renderScannerAlerts(); renderAdvancedRisk(); renderCorrelationMatrix(); }
      if (btn.dataset.tab==='themes')      renderThemePanel();
      if (btn.dataset.tab==='trending')    fetchTrending();
      if (btn.dataset.tab==='montecarlo')    runMonteCarlo();
      if (btn.dataset.tab==='expert')      renderExpertTools();
      if (btn.dataset.tab==='tools')       { renderTelegramPanel(); }
      if (btn.dataset.tab==='tvcharts')    buildTVChartPicker();
      if (btn.dataset.tab==='backtest')    {} // ready on click
      if (btn.dataset.tab==='macro')       { renderMacroDashboard(); renderMacroNewsPanel(); renderMacroAlertHistory(); }
      if (btn.dataset.tab==='patterns')    runPatternScan();
      if (btn.dataset.tab==='fundamentals'){ populateFundSymSelect(); }
      if (btn.dataset.tab==='pnlcal')      renderPnlCalendar();
      if (btn.dataset.tab==='heatmap')   { fetchHeatmapData().then(renderHeatmap); }
      if (btn.dataset.tab==='perps' && !window._perpsAll.length) loadAllPerps();
      if (btn.dataset.tab==='perps') renderPerpAlertHistory();
      if (btn.dataset.tab==='perps') { updateSignalTrackOutcomes(); renderSignalTrackRecord(); renderNewListingsPanel(); }
      if (btn.dataset.tab==='dexscreen' && !_dexResults.length) loadDexScreener();
      if (btn.dataset.tab==='tradesignals') { renderTradeSignalsTab(); renderTelegramSignalsPanel(); if (!_tgSignals.length) loadTelegramSignals(); }
      if (btn.dataset.tab==='alpha')        renderAlphaFeedsTab();
    });
  });
  // open the first tab of whichever group is active on load (Portfolio, by default)
  document.querySelector('.nav-tab[data-group="overview"]')?.click();
}

// ── NAV GROUPS — two-tier nav: a small set of category buttons filters which
// tabs are visible in the row below, so 28 tabs don't sit in one endless
// horizontal scroll strip. Purely a display/filter layer — it doesn't touch
// the existing per-tab click handlers or side effects above.
function initNavGroups() {
  const groupBtns = document.querySelectorAll('.nav-group-btn');
  const nav = document.getElementById('mainNav');
  if (!groupBtns.length || !nav) return;

  function showGroup(group, opts) {
    opts = opts || {};
    groupBtns.forEach(b => b.classList.toggle('active', b.dataset.group === group));
    nav.dataset.activeGroup = group;
    const tabsInGroup = [];
    document.querySelectorAll('.nav-tab').forEach(t => {
      const belongs = t.dataset.group === group;
      t.classList.toggle('hidden', !belongs);
      if (belongs) tabsInGroup.push(t);
    });
    if (opts.openTab) {
      // restore the last tab the user was on within this group, if any and still present
      let restored = null;
      try {
        const lastTab = localStorage.getItem('nexus_lastTab_'+group);
        if (lastTab) restored = tabsInGroup.find(t => t.dataset.tab === lastTab);
      } catch(e) {}
      (restored || tabsInGroup[0])?.click();
    }
  }

  groupBtns.forEach(btn => {
    btn.addEventListener('click', () => showGroup(btn.dataset.group, { openTab: true }));
  });

  // initial state: show the default group's tabs (bootstrap click happens in initTabs)
  showGroup('overview');
}

// ── NEWS TAG FILTER ───────────────────────────────────────────────────────────
let _activeNewsTag = 'all';
function setNewsTag(tag, btn) {
  _activeNewsTag = tag;
  document.querySelectorAll('.tag-filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  applyNewsFilter();
}

// Patch applyNewsFilter to also filter by tag (news.js uses _activeNewsTag)
const _origApplyFilter = applyNewsFilter;
function applyNewsFilter() {
  const q     = (document.getElementById('newsSearch')?.value||'').toLowerCase().trim();
  const tag   = _activeNewsTag || 'all';
  let   items = window._allNewsItems || [];
  if (q)          items = items.filter(i => i.title.toLowerCase().includes(q) || (i.source||'').toLowerCase().includes(q));
  if (tag!=='all') items = items.filter(i => i.tag === tag);
  const cnt = document.getElementById('newsCount');
  if (cnt) cnt.textContent = items.length + ' articles';
  renderNews(items.slice(0,9));
}

function populateFundSymSelect() {
  const el = document.getElementById('fundSymSelect');
  if (!el) return;
  const stocks = positions.filter(p=>p.type==='stock').map(p=>p.sym);
  const watched = watchlist.filter(w=>w.type==='stock').map(w=>w.sym);
  const all = [...new Set([...stocks,...watched])];
  el.innerHTML = '<option value="">Select stock…</option>' + all.map(s=>`<option value="${s}">${s}</option>`).join('');
}
