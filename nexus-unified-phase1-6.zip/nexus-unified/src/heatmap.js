/**
 * heatmap.js — Market sentiment heatmap.
 * Data from realtime.js bulk fetches (Binance crypto + Yahoo stocks + fxRates forex).
 * No simulation. Zero = "loading" state shown as neutral grey.
 */

function heatColor(chg) {
  if      (chg >  5) return { bg:'#007a55', fg:'#c8fff0', border:'rgba(0,212,170,0.5)' };
  else if (chg >  2) return { bg:'#005238', fg:'#e8eaf0', border:'rgba(0,212,170,0.3)' };
  else if (chg > .5) return { bg:'#002e20', fg:'#aabbcc', border:'rgba(0,212,170,0.15)' };
  else if (chg >-.5) return { bg:'#181e26', fg:'#556677', border:'rgba(255,255,255,0.07)' };
  else if (chg > -2) return { bg:'#2e0a10', fg:'#aabbcc', border:'rgba(255,77,106,0.15)' };
  else if (chg > -5) return { bg:'#520818', fg:'#e8eaf0', border:'rgba(255,77,106,0.3)' };
  else               return { bg:'#780010', fg:'#ffe0e6', border:'rgba(255,77,106,0.5)' };
}

function renderHeatmap() {
  const el = document.getElementById('heatmapGrid');
  if (!el) return;

  const allSyms = Object.values(HEATMAP_DATA).flat();
  const allChgs = allSyms.map(s => safeNum(getHeatChgReal(s)));
  const bull    = allChgs.filter(c => c >  0.5).length;
  const bear    = allChgs.filter(c => c < -0.5).length;
  const neut    = allChgs.length - bull - bear;

  const be = document.getElementById('hmBull');
  const re = document.getElementById('hmBear');
  const ne = document.getElementById('hmNeut');
  if (be) be.textContent = `▲ ${bull} Bullish`;
  if (re) re.textContent = `▼ ${bear} Bearish`;
  if (ne) ne.textContent = `● ${neut} Neutral`;

  el.innerHTML = `
    <div class="hm-legend-row">
      <span class="hm-leg-lbl">Bearish</span>
      <div class="hm-leg-bar"><div class="hm-leg-grad"></div></div>
      <span class="hm-leg-lbl">Bullish</span>
      <span class="hm-leg-hint">Live: Binance (crypto) · Yahoo Finance (stocks) · ECB (forex) · click to chart</span>
    </div>
    <div class="hm-body">
      ${Object.entries(HEATMAP_DATA).map(([sector, syms]) => {
        const chgs   = syms.map(s => safeNum(getHeatChgReal(s)));
        const avg    = chgs.reduce((a,b)=>a+b,0) / chgs.length;
        const wt     = {Technology:3,Crypto:2.5,Finance:2,Energy:1.5,Healthcare:1.5,Forex:1.5,Commodities:1.5}[sector]||1.5;
        return `
        <div class="hm-sector" style="flex:${wt};">
          <div class="hm-sector-hdr">
            <div class="hm-sector-name">${sector}</div>
            <div class="hm-sector-avg ${avg>=0?'up':'dn'}">${avg>=0?'▲':'▼'} ${Math.abs(avg).toFixed(2)}%</div>
          </div>
          <div class="hm-cells">
            ${syms.map(sym => {
              const chg = safeNum(getHeatChgReal(sym));
              const col = heatColor(chg);
              const sz  = Math.max(58, Math.min(96, 58 + Math.abs(chg) * 5));
              const lbl = sym.replace('/', '').length > 7 ? sym.replace('/', '').slice(0,7) : sym;
              const isLoading = chg === 0;
              return `
              <div class="hm-cell" style="background:${col.bg};border-color:${col.border};width:${sz}px;height:${sz}px;${isLoading?'opacity:0.5;':''}"
                   title="${sym}  ${chg>=0?'+':''}${chg.toFixed(2)}%  ${isLoading?'(loading…)':''}"
                   onclick="tryHmChart('${sym}')">
                <div class="hm-csym">${lbl}</div>
                <div class="hm-cchg" style="color:${chg>=0?'#4dffc8':'#ff7090'};">
                  ${isLoading ? '…' : (chg>=0?'+':'')+chg.toFixed(2)+'%'}
                </div>
                <div class="hm-cbar">
                  <div style="width:${Math.min(Math.abs(chg)/10*100,100)}%;height:100%;background:${chg>=0?'rgba(0,212,170,0.55)':'rgba(255,77,106,0.55)'};border-radius:1px;"></div>
                </div>
              </div>`;
            }).join('')}
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

function tryHmChart(sym) {
  const p    = positions.find(x => x.sym === sym);
  const w    = watchlist.find(x => x.sym === sym);
  const type = sym.includes('/')   ? 'forex'
             : ['BTC','ETH','SOL','DOGE','XRP','BNB','ADA','AVAX','DOT','MATIC','LTC','LINK'].includes(sym) ? 'crypto'
             : 'stock';
  if (p) openAssetChart(p.sym, p.name, p.type);
  else if (w) openAssetChart(w.sym, w.name, w.type);
  else openAssetChart(sym, sym, type);
}
