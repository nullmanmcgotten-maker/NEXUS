/**
 * data.js — Central store with multi-portfolio support
 */

// ── PORTFOLIOS ────────────────────────────────────────────────────────────────
window.portfolios = {
  default: {
    name: 'Main Portfolio',
    positions: [
      { id:1,  type:'stock',  sym:'AAPL',    name:'Apple Inc.',       qty:10,   avgPrice:165.20, price:189.50, chg:+1.8  },
      { id:2,  type:'stock',  sym:'NVDA',    name:'NVIDIA Corp.',     qty:5,    avgPrice:410.00, price:875.30, chg:+2.9  },
      { id:3,  type:'stock',  sym:'TSLA',    name:'Tesla Inc.',       qty:8,    avgPrice:220.00, price:172.40, chg:-1.4  },
      { id:4,  type:'stock',  sym:'MSFT',    name:'Microsoft Corp.',  qty:6,    avgPrice:310.00, price:414.80, chg:+0.7  },
      { id:5,  type:'crypto', sym:'BTC',     name:'Bitcoin',          qty:0.5,  avgPrice:38000,  price:67420,  chg:+3.2  },
      { id:6,  type:'crypto', sym:'ETH',     name:'Ethereum',         qty:4,    avgPrice:1900,   price:3820,   chg:+2.1  },
      { id:7,  type:'crypto', sym:'SOL',     name:'Solana',           qty:20,   avgPrice:60,     price:182.40, chg:+4.5  },
      { id:8,  type:'forex',  sym:'EUR/USD', name:'Euro/Dollar',      qty:10,   avgPrice:1.0800, price:1.0842, chg:+0.1  },
      { id:9,  type:'forex',  sym:'GBP/USD', name:'Pound/Dollar',     qty:5,    avgPrice:1.2500, price:1.2714, chg:+0.2  },
      { id:11, type:'stock',  sym:'AMZN',    name:'Amazon.com Inc.',  qty:3,    avgPrice:140.00, price:184.90, chg:+1.1  },
      { id:12, type:'crypto', sym:'DOGE',    name:'Dogecoin',         qty:5000, avgPrice:0.08,   price:0.162,  chg:+1.7  },
    ],
    cash: 8200,
    createdAt: Date.now(),
  }
};

(function(){
  try {
    const saved = localStorage.getItem('nexus_portfolios');
    if (saved) window.portfolios = JSON.parse(saved);
  } catch(e){}
})();

window.activePortfolioId = localStorage.getItem('nexus_active_portfolio') || 'default';
if (!window.portfolios[window.activePortfolioId]) window.activePortfolioId = Object.keys(window.portfolios)[0];

// Active positions proxy
Object.defineProperty(window, 'positions', {
  get(){ return window.portfolios[window.activePortfolioId]?.positions || []; },
  set(v){ if(window.portfolios[window.activePortfolioId]) window.portfolios[window.activePortfolioId].positions = v; },
});

// ── TRADE JOURNAL ─────────────────────────────────────────────────────────────
window.tradeJournal = [];
(function(){
  try { const s=localStorage.getItem('nexus_journal'); if(s) window.tradeJournal=JSON.parse(s); } catch(e){}
})();
function saveJournal(){ try{localStorage.setItem('nexus_journal',JSON.stringify(tradeJournal));}catch(e){} }

// ── WATCHLIST ─────────────────────────────────────────────────────────────────
window.watchlist = [
  { sym:'SPY',    name:'S&P 500 ETF',    type:'stock',  price:528.40, chg:+0.6, notes:'' },
  { sym:'QQQ',    name:'Nasdaq 100 ETF', type:'stock',  price:446.20, chg:+0.9, notes:'' },
  { sym:'XRP',    name:'Ripple',         type:'crypto', price:0.618,  chg:-0.4, notes:'' },
  { sym:'GLD',    name:'Gold ETF',       type:'stock',  price:218.60, chg:+0.3, notes:'' },
  { sym:'BNB',    name:'BNB',            type:'crypto', price:584.20, chg:+1.2, notes:'' },
];

// ── ALERTS ────────────────────────────────────────────────────────────────────
window.alerts = [];
(function(){ try{ const s=localStorage.getItem('nexus_alerts'); if(s) window.alerts=JSON.parse(s); }catch(e){} })();

// ── FX RATES ──────────────────────────────────────────────────────────────────
window.fxRates = {
  USD:1,EUR:0.922,GBP:0.787,JPY:156.4,GHS:15.2,NGN:1580,
  KES:131.5,ZAR:18.7,CAD:1.363,AUD:1.527,CHF:0.901,
  CNY:7.238,INR:83.4,BRL:4.97,MXN:17.1,SGD:1.342,AED:3.673,
};

// ── GLOBAL MARKETS ────────────────────────────────────────────────────────────
window.globalMarkets = [
  {sym:'S&P 500',   val:5248.49, chg:+0.62, type:'index'},
  {sym:'NASDAQ',    val:16428.82,chg:+0.92, type:'index'},
  {sym:'DOW JONES', val:39142.23,chg:+0.40, type:'index'},
  {sym:'FTSE 100',  val:8147.03, chg:-0.21, type:'index'},
  {sym:'DAX',       val:18161.01,chg:+0.35, type:'index'},
  {sym:'NIKKEI',    val:38460.08,chg:+1.14, type:'index'},
  {sym:'HANG SENG', val:18475.92,chg:-0.84, type:'index'},
  {sym:'VIX',       val:13.74,   chg:-2.14, type:'index'},
  {sym:'Gold',      val:2328.40, chg:+0.52, type:'commodity'},
  {sym:'Silver',    val:27.14,   chg:+0.74, type:'commodity'},
  {sym:'Crude Oil', val:78.26,   chg:-0.93, type:'commodity'},
  {sym:'Nat Gas',   val:2.14,    chg:-1.24, type:'commodity'},
  {sym:'Copper',    val:4.52,    chg:+0.31, type:'commodity'},
  {sym:'Wheat',     val:548.20,  chg:-0.62, type:'commodity'},
  {sym:'US 10Y',    val:4.42,    chg:+0.03, type:'bond'},
  {sym:'US 2Y',     val:4.89,    chg:-0.01, type:'bond'},
  {sym:'US 30Y',    val:4.61,    chg:+0.02, type:'bond'},
  {sym:'DE 10Y',    val:2.51,    chg:+0.02, type:'bond'},
  {sym:'DXY',       val:105.24,  chg:-0.18, type:'forex'},
  {sym:'EUR/USD',   val:1.0842,  chg:+0.10, type:'forex'},
  {sym:'GBP/USD',   val:1.2714,  chg:+0.20, type:'forex'},
  {sym:'USD/JPY',   val:156.40,  chg:-0.30, type:'forex'},
];

window.HEATMAP_DATA = {
  'Technology':  ['AAPL','MSFT','NVDA','AMZN','GOOGL','META','TSLA','AMD','INTC','CRM','ORCL','ADBE'],
  'Crypto':      ['BTC','ETH','SOL','DOGE','XRP','BNB','ADA','AVAX','DOT','MATIC','LTC','LINK'],
  'Finance':     ['JPM','BAC','GS','MS','WFC','V','MA','AXP','BLK','C'],
  'Energy':      ['XOM','CVX','COP','SLB','EOG','MPC','PSX','VLO'],
  'Healthcare':  ['JNJ','UNH','PFE','ABBV','MRK','TMO','ABT','DHR'],
  'Forex':       ['EUR/USD','GBP/USD','USD/JPY','USD/CHF','AUD/USD','USD/CAD','NZD/USD','USD/CNY'],
  'Commodities': ['GOLD','SILVER','OIL','NATGAS','COPPER','WHEAT','CORN','COFFEE'],
};

window._nextId        = 20;
window._priceHistory  = {};
window._scannerAlerts = [];

const TAG_COLORS = {
  green:'background:rgba(0,212,170,0.15);color:#00d4aa;',
  red:'background:rgba(255,77,106,0.15);color:#ff4d6a;',
  blue:'background:rgba(0,150,255,0.15);color:#0096ff;',
  amber:'background:rgba(245,166,35,0.15);color:#f5a623;',
  purple:'background:rgba(153,69,255,0.15);color:#9945ff;',
};
