/**
 * macro.js — Macro dashboard + on-chain + DeFi + crypto derivatives
 * FRED API (free, no key for basic), Binance futures, DefiLlama, blockchain.info
 */

// ── CRYPTO FUNDING RATES (Binance futures — free, no key) ─────────────────────
async function fetchFundingRates() {
  const el = document.getElementById('fundingRatesPanel');
  if (!el) return;
  try {
    const res  = await fetch('https://fapi.binance.com/fapi/v1/fundingRate?limit=1', { signal: AbortSignal.timeout(8000) });
    // Binance futures fundingInfo for top pairs
    const url2 = 'https://fapi.binance.com/fapi/v1/premiumIndex';
    const res2 = await fetch(url2, { signal: AbortSignal.timeout(8000) });
    if (!res2.ok) throw new Error('HTTP '+res2.status);
    const data = await res2.json();
    const pairs = ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT'];
    const filtered = data.filter(d => pairs.includes(d.symbol));
    el.innerHTML = `
      <div class="macro-grid">
        ${filtered.map(d => {
          const fr  = parseFloat(d.lastFundingRate)*100;
          const isPos = fr >= 0;
          const signal = fr > 0.05 ? '⚠ Longs heavy' : fr < -0.05 ? '⚠ Shorts heavy' : '✓ Balanced';
          return `<div class="macro-card">
            <div class="macro-sym">${d.symbol.replace('USDT','')}/USDT</div>
            <div class="macro-val ${isPos?'up':'dn'}">${isPos?'+':''}${fr.toFixed(4)}%</div>
            <div class="macro-hint">${signal}</div>
            <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:2px;">
              Mark: $${parseFloat(d.markPrice).toLocaleString(undefined,{maximumFractionDigits:2})}
            </div>
          </div>`;
        }).join('')}
      </div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">
        Binance Perpetuals · Funding rates paid every 8h · Positive = longs pay shorts · Updated live
      </div>`;
  } catch(e) {
    if (el) el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:12px;">⚠ Funding rates: ${e.message}</div>`;
  }
}

// ── DEFI TVL (DefiLlama — free, CORS open) ────────────────────────────────────
async function fetchDefiTVL() {
  const el = document.getElementById('defiTVLPanel');
  if (!el) return;
  try {
    const res  = await fetch('https://api.llama.fi/protocols', { signal: AbortSignal.timeout(10000) });
    if (!res.ok) throw new Error('HTTP '+res.status);
    const data = await res.json();
    const top  = data.sort((a,b) => b.tvl - a.tvl).slice(0, 12);
    el.innerHTML = `
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-bottom:10px;letter-spacing:.1em;text-transform:uppercase;">Top DeFi Protocols by TVL</div>
      ${top.map((p,i) => {
        const tvl = p.tvl >= 1e9 ? '$'+(p.tvl/1e9).toFixed(2)+'B' : '$'+(p.tvl/1e6).toFixed(0)+'M';
        const chg = p.change_1d;
        const isUp = chg >= 0;
        return `<div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--border);">
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="font-family:var(--mono);font-size:10px;color:var(--muted);width:16px;">${i+1}</span>
            <img src="${p.logo}" style="width:20px;height:20px;border-radius:50%;object-fit:cover;" onerror="this.style.display='none'">
            <div>
              <div style="font-family:var(--mono);font-size:13px;font-weight:600;">${p.name}</div>
              <div style="font-family:var(--mono);font-size:10px;color:var(--muted);">${p.category}</div>
            </div>
          </div>
          <div style="text-align:right;">
            <div style="font-family:var(--mono);font-size:13px;font-weight:600;">${tvl}</div>
            <div style="font-family:var(--mono);font-size:11px;color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':''}${chg?.toFixed(2)||0}%</div>
          </div>
        </div>`;
      }).join('')}
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:8px;">Source: DefiLlama · Free API · No key</div>`;
  } catch(e) {
    if (el) el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:12px;">⚠ DeFi TVL: ${e.message}</div>`;
  }
}

// ── CRYPTO DERIVATIVES DASHBOARD ─────────────────────────────────────────────
async function fetchDerivatives() {
  const el = document.getElementById('derivativesPanel');
  if (!el) return;
  try {
    // Binance futures open interest
    const [oiRes, lsRes] = await Promise.allSettled([
      fetch('https://fapi.binance.com/fapi/v1/openInterest?symbol=BTCUSDT', {signal:AbortSignal.timeout(6000)}),
      fetch('https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=BTCUSDT&period=5m&limit=1', {signal:AbortSignal.timeout(6000)}),
    ]);

    let oiHtml = '', lsHtml = '';
    if (oiRes.status==='fulfilled' && oiRes.value.ok) {
      const oi = await oiRes.value.json();
      const oiVal = parseFloat(oi.openInterest);
      const oiUsd = oiVal * parseFloat(oi.time||0);
      oiHtml = `<div class="macro-card"><div class="macro-sym">BTC Open Interest</div><div class="macro-val">${fmtNum(oiVal,0)} BTC</div></div>`;
    }
    if (lsRes.status==='fulfilled' && lsRes.value.ok) {
      const ls = await lsRes.value.json();
      if (ls[0]) {
        const ratio = parseFloat(ls[0].longShortRatio);
        const longPct = parseFloat(ls[0].longAccount)*100;
        const shortPct= parseFloat(ls[0].shortAccount)*100;
        lsHtml = `<div class="macro-card">
          <div class="macro-sym">BTC Long/Short</div>
          <div class="macro-val ${ratio>1?'up':'dn'}">${ratio.toFixed(3)}</div>
          <div class="macro-hint">🟢 ${longPct.toFixed(1)}% long · 🔴 ${shortPct.toFixed(1)}% short</div>
        </div>`;
      }
    }
    el.innerHTML = `<div class="macro-grid">${oiHtml}${lsHtml}</div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">Binance Futures · Free public endpoints</div>`;
  } catch(e) {
    if (el) el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:12px;">⚠ Derivatives: ${e.message}</div>`;
  }
}

// ── GAS TRACKER (Ethereum) ────────────────────────────────────────────────────
async function fetchGasTracker() {
  const el = document.getElementById('gasTrackerPanel');
  if (!el) return;
  try {
    // Blocknative gas API (free, no key for basic)
    const res = await fetch('https://api.blocknative.com/gasprices/blockprices', {
      headers: { 'Authorization': '' }, signal: AbortSignal.timeout(6000)
    });
    if (!res.ok) throw new Error('HTTP '+res.status);
    const data = await res.json();
    const bp   = data.blockPrices?.[0];
    const prices = bp?.estimatedPrices || [];
    el.innerHTML = `
      <div class="macro-grid">
        ${prices.slice(0,4).map(p => `
          <div class="macro-card">
            <div class="macro-sym">${p.confidence}% confidence</div>
            <div class="macro-val">${p.maxFeePerGas} Gwei</div>
            <div class="macro-hint">Max: ${p.maxFeePerGas} · Priority: ${p.maxPriorityFeePerGas}</div>
          </div>`).join('')}
      </div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:8px;">Blocknative · Ethereum gas prices</div>`;
  } catch(e) {
    // Fallback: ethgasstation
    try {
      const res2 = await fetch('https://ethgasstation.info/json/ethgasAPI.json', {signal:AbortSignal.timeout(6000)});
      const d = await res2.json();
      el.innerHTML = `
        <div class="macro-grid">
          <div class="macro-card"><div class="macro-sym">Slow</div><div class="macro-val">${(d.safeLow/10).toFixed(1)}</div><div class="macro-hint">Gwei</div></div>
          <div class="macro-card"><div class="macro-sym">Standard</div><div class="macro-val">${(d.average/10).toFixed(1)}</div><div class="macro-hint">Gwei</div></div>
          <div class="macro-card"><div class="macro-sym">Fast</div><div class="macro-val">${(d.fast/10).toFixed(1)}</div><div class="macro-hint">Gwei</div></div>
          <div class="macro-card"><div class="macro-sym">Instant</div><div class="macro-val">${(d.fastest/10).toFixed(1)}</div><div class="macro-hint">Gwei</div></div>
        </div>
        <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:8px;">EthGasStation · Ethereum gas prices</div>`;
    } catch(e2) {
      if (el) el.innerHTML = `<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:12px;">⚠ Gas tracker offline</div>`;
    }
  }
}

// ── MACRO: YIELD CURVE + DXY ─────────────────────────────────────────────────
function renderMacroCurve() {
  const el = document.getElementById('yieldCurvePanel');
  if (!el) return;
  // Use live global markets data (we already fetch US 10Y, 2Y, 30Y from Yahoo)
  const t10 = globalMarkets.find(g=>g.sym==='US 10Y');
  const t2  = globalMarkets.find(g=>g.sym==='US 2Y');
  const t30 = globalMarkets.find(g=>g.sym==='US 30Y');
  const dxy = globalMarkets.find(g=>g.sym==='DXY');

  if (!t10||!t2) { el.innerHTML='<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:12px;">Loading yield data… (requires Global Markets tab to have loaded)</div>'; return; }

  const spread = safeNum(t10.val) - safeNum(t2.val);
  const inverted = spread < 0;

  el.innerHTML = `
    <div class="macro-grid">
      <div class="macro-card">
        <div class="macro-sym">2Y-10Y Spread</div>
        <div class="macro-val ${inverted?'dn':'up'}">${spread.toFixed(2)}%</div>
        <div class="macro-hint">${inverted?'⚠ Inverted (recession signal)':'✓ Normal curve'}</div>
      </div>
      <div class="macro-card">
        <div class="macro-sym">US 2Y Yield</div>
        <div class="macro-val">${safeNum(t2.val).toFixed(2)}%</div>
        <div class="macro-hint" style="color:${t2.chg>=0?'var(--red)':'var(--green)'};">${t2.chg>=0?'▲':'▼'} ${Math.abs(t2.chg).toFixed(2)}bps</div>
      </div>
      <div class="macro-card">
        <div class="macro-sym">US 10Y Yield</div>
        <div class="macro-val">${safeNum(t10.val).toFixed(2)}%</div>
        <div class="macro-hint" style="color:${t10.chg>=0?'var(--red)':'var(--green)'};">${t10.chg>=0?'▲':'▼'} ${Math.abs(t10.chg).toFixed(2)}bps</div>
      </div>
      ${t30?`<div class="macro-card">
        <div class="macro-sym">US 30Y Yield</div>
        <div class="macro-val">${safeNum(t30.val).toFixed(2)}%</div>
        <div class="macro-hint" style="color:${t30.chg>=0?'var(--red)':'var(--green)'};">${t30.chg>=0?'▲':'▼'} ${Math.abs(t30.chg).toFixed(2)}bps</div>
      </div>`:''}
      ${dxy?`<div class="macro-card">
        <div class="macro-sym">DXY Dollar Index</div>
        <div class="macro-val">${safeNum(dxy.val).toFixed(2)}</div>
        <div class="macro-hint" style="color:${dxy.chg>=0?'var(--green)':'var(--red)'};">${dxy.chg>=0?'▲':'▼'} ${Math.abs(dxy.chg).toFixed(2)}%</div>
      </div>`:''}
    </div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">
      Data: Yahoo Finance · ${inverted?'⚠ Yield curve inverted — historically precedes recession by 12-18 months':'Yield curve healthy'}
    </div>`;
}

// ── STRESS TEST ───────────────────────────────────────────────────────────────
function runStressTest() {
  const scenario = document.getElementById('stressScenario')?.value || 'crypto_crash';
  const el = document.getElementById('stressResult');
  if (!el) return;

  const SCENARIOS = {
    crypto_crash:  { name:'Crypto Crash -40%',   crypto:-40, stock:-5,  forex:0,   color:'var(--red)'   },
    stock_bear:    { name:'Stock Bear Market -30%',crypto:-15, stock:-30, forex:2,   color:'var(--red)'   },
    usd_surge:     { name:'USD Surge +10%',        crypto:-12, stock:-3,  forex:-8,  color:'var(--amber)' },
    rate_hike:     { name:'Fed Rate Hike Shock',   crypto:-20, stock:-15, forex:5,   color:'var(--amber)' },
    bull_run:      { name:'Crypto Bull +100%',     crypto:100, stock:10,  forex:-2,  color:'var(--green)' },
    black_swan:    { name:'Black Swan -60%',        crypto:-60, stock:-40, forex:10,  color:'var(--red)'   },
  };

  const sc  = SCENARIOS[scenario];
  let impact = 0;
  positions.forEach(p => {
    const pctChg = sc[p.type] / 100 || 0;
    impact += posDisplayValue(p) * pctChg;
  });
  const total = totalPortfolioValue();
  const pct   = (impact/total*100).toFixed(2);
  const isPos = impact >= 0;

  el.innerHTML = `
    <div style="background:var(--bg3);border:1px solid ${isPos?'rgba(0,212,170,.3)':'rgba(255,77,106,.3)'};border-radius:8px;padding:16px;">
      <div style="font-family:var(--mono);font-size:14px;font-weight:700;margin-bottom:10px;">${sc.name}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:12px;">
        <div><div style="font-family:var(--mono);font-size:10px;color:var(--muted);">CRYPTO IMPACT</div><div style="font-family:var(--mono);font-size:16px;font-weight:700;color:${sc.crypto>=0?'var(--green)':'var(--red)'};">${sc.crypto>=0?'+':''}${sc.crypto}%</div></div>
        <div><div style="font-family:var(--mono);font-size:10px;color:var(--muted);">STOCKS IMPACT</div><div style="font-family:var(--mono);font-size:16px;font-weight:700;color:${sc.stock>=0?'var(--green)':'var(--red)'};">${sc.stock>=0?'+':''}${sc.stock}%</div></div>
        <div><div style="font-family:var(--mono);font-size:10px;color:var(--muted);">FOREX IMPACT</div><div style="font-family:var(--mono);font-size:16px;font-weight:700;color:${sc.forex>=0?'var(--green)':'var(--red)'};">${sc.forex>=0?'+':''}${sc.forex}%</div></div>
      </div>
      <div style="border-top:1px solid var(--border);padding-top:12px;">
        <div style="font-family:var(--mono);font-size:12px;color:var(--muted);margin-bottom:4px;">PORTFOLIO IMPACT</div>
        <div style="font-family:var(--mono);font-size:28px;font-weight:700;color:${isPos?'var(--green)':'var(--red)'};">${isPos?'+':'-'}$${fmtNum(Math.abs(impact))}</div>
        <div style="font-family:var(--mono);font-size:14px;color:${isPos?'var(--green)':'var(--red)'};">${isPos?'+':''}${pct}% of portfolio</div>
        <div style="font-family:var(--mono);font-size:12px;color:var(--muted);margin-top:6px;">Portfolio after: $${fmtNum(total+impact)}</div>
      </div>
    </div>`;
}

// ── INIT ALL MACRO ────────────────────────────────────────────────────────────
function renderMacroDashboard() {
  renderMacroCurve();
  fetchFundingRates();
  fetchDerivatives();
  fetchDefiTVL();
  fetchGasTracker();
}
