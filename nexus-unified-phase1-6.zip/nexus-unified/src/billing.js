/**
 * billing.js — Stripe Checkout + webhook handling, implemented with raw
 * HTTPS calls to Stripe's REST API so no `stripe` npm package is required
 * to get started. Swap in the official SDK later if you want richer
 * error handling — the wire format is the same.
 *
 * Env vars (set these before `npm start`, or put them in a .env you load
 * yourself — this file just reads process.env directly):
 *   STRIPE_SECRET_KEY     sk_live_... / sk_test_...
 *   STRIPE_PRICE_ID       price_... (the recurring "Pro" price you create
 *                         in the Stripe dashboard, e.g. $19/mo)
 *   STRIPE_WEBHOOK_SECRET whsec_... (from the webhook endpoint you add in
 *                         the Stripe dashboard pointing at
 *                         POST /api/billing/webhook)
 *   PUBLIC_URL            e.g. https://your-domain.com (used for Checkout
 *                         success/cancel redirect URLs)
 *
 * If STRIPE_SECRET_KEY is unset, checkout() rejects with a clear message
 * and the rest of the app (including the free tier) works normally —
 * billing is opt-in infrastructure, not a hard dependency.
 */
'use strict';

const https = require('https');
const crypto = require('crypto');
const querystring = require('querystring');

function stripeConfigured() {
  return !!process.env.STRIPE_SECRET_KEY;
}

function stripeRequest(pathname, method, formBody) {
  return new Promise((resolve, reject) => {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) return reject(new Error('STRIPE_SECRET_KEY is not set'));
    const body = formBody ? querystring.stringify(formBody) : '';
    const req = https.request({
      hostname: 'api.stripe.com',
      path: pathname,
      method,
      headers: {
        'Authorization': 'Bearer ' + key,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
      },
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        let json;
        try { json = JSON.parse(data); } catch (e) { return reject(new Error('Stripe returned non-JSON: ' + data.slice(0, 200))); }
        if (res.statusCode >= 400) return reject(new Error(json.error?.message || ('Stripe error ' + res.statusCode)));
        resolve(json);
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

/** Creates a Stripe Checkout Session for the Pro subscription and returns its URL. */
async function createCheckoutSession(userEmail, stripeCustomerId) {
  if (!stripeConfigured()) throw new Error('Billing is not configured yet (missing STRIPE_SECRET_KEY). See MONETIZATION.md.');
  const priceId = process.env.STRIPE_PRICE_ID;
  if (!priceId) throw new Error('STRIPE_PRICE_ID is not set. See MONETIZATION.md.');
  const base = process.env.PUBLIC_URL || 'http://localhost:3000';

  const form = {
    mode: 'subscription',
    'line_items[0][price]': priceId,
    'line_items[0][quantity]': '1',
    success_url: base + '/?upgraded=1',
    cancel_url: base + '/?upgraded=0',
    customer_email: userEmail,
    'metadata[nexus_email]': userEmail,
  };
  if (stripeCustomerId) {
    delete form.customer_email;
    form.customer = stripeCustomerId;
  }
  const session = await stripeRequest('/v1/checkout/sessions', 'POST', form);
  return session.url;
}

/** Creates a Billing Portal session so a Pro user can manage/cancel their subscription. */
async function createPortalSession(stripeCustomerId) {
  if (!stripeConfigured()) throw new Error('Billing is not configured');
  const base = process.env.PUBLIC_URL || 'http://localhost:3000';
  const session = await stripeRequest('/v1/billing_portal/sessions', 'POST', {
    customer: stripeCustomerId,
    return_url: base + '/',
  });
  return session.url;
}

/**
 * Verifies a Stripe webhook signature per Stripe's documented scheme
 * (t=timestamp,v1=hmac). rawBody must be the exact, unparsed request body.
 */
function verifyWebhookSignature(rawBody, sigHeader, secret) {
  if (!sigHeader) return false;
  const parts = Object.fromEntries(sigHeader.split(',').map(kv => kv.split('=')));
  if (!parts.t || !parts.v1) return false;
  const signedPayload = `${parts.t}.${rawBody}`;
  const expected = crypto.createHmac('sha256', secret).update(signedPayload).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(parts.v1);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = {
  stripeConfigured,
  createCheckoutSession,
  createPortalSession,
  verifyWebhookSignature,
};
