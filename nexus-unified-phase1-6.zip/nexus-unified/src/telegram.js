/**
 * telegram.js — Telegram bot alerts. User provides their own free bot token.
 * No server needed — browser calls Telegram API directly (CORS open).
 */
let _tgToken='', _tgChatId='';
function saveTelegramConfig(){
  _tgToken=document.getElementById('tgToken')?.value.trim()||'';
  _tgChatId=document.getElementById('tgChatId')?.value.trim()||'';
  try{localStorage.setItem('nexus_tg',JSON.stringify({token:_tgToken,chatId:_tgChatId}));}catch(e){}
  if(_tgToken&&_tgChatId) sendTelegram('🟢 NEXUS connected! Alerts will appear here.');
}
(function(){try{const s=localStorage.getItem('nexus_tg');if(s){const d=JSON.parse(s);_tgToken=d.token||'';_tgChatId=d.chatId||'';}}catch(e){}})();
async function sendTelegram(msg){
  if(!_tgToken||!_tgChatId)return;
  try{await fetch(`https://api.telegram.org/bot${_tgToken}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:_tgChatId,text:msg,parse_mode:'HTML'})});}
  catch(e){console.warn('[Telegram]',e.message);}
}
function renderTelegramPanel(){
  const el=document.getElementById('telegramPanel');if(!el)return;
  el.innerHTML=`
    <div style="margin-bottom:14px;padding:14px;background:var(--bg3);border-radius:8px;border:1px solid var(--border);">
      <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-bottom:10px;">
        Setup in 3 steps:<br>
        1. Message <a href="https://t.me/BotFather" target="_blank" style="color:var(--accent2);">@BotFather</a> on Telegram → /newbot → copy token<br>
        2. Message your bot once to start chat → get chat ID from <a href="https://t.me/userinfobot" target="_blank" style="color:var(--accent2);">@userinfobot</a><br>
        3. Paste both below and click Save
      </div>
      <input class="inp" id="tgToken" placeholder="Bot token (e.g. 123456:ABC-DEF...)" value="${_tgToken}" style="margin-bottom:8px;"/>
      <input class="inp" id="tgChatId" placeholder="Your chat ID (e.g. 123456789)" value="${_tgChatId}" style="margin-bottom:8px;"/>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <button class="btn-primary" onclick="saveTelegramConfig()">💾 Save & Test</button>
        <button class="btn-sm" style="padding:10px;" onclick="sendTelegram('📊 Portfolio test alert from NEXUS!')">📤 Send Test</button>
      </div>
      ${_tgToken&&_tgChatId?'<div style="font-family:var(--mono);font-size:11px;color:var(--green);margin-top:8px;">✓ Telegram configured — alerts will be sent automatically</div>':''}
    </div>`;
}
