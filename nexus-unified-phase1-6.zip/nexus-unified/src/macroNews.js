/**
 * macroNews.js — Multi-asset macro news impact scoring & alert queue.
 *
 * Ported from the tonybot `macro_news.py` aggregator into browser-native JS,
 * wired to nexus-portfolio's existing RSS pipeline (news.js: fetchOneFeed)
 * and existing alert channels (alerts.js toast/Notification, telegram.js).
 *
 * Adds on top of plain headline fetching:
 *   1. Category-aware bullish/bearish keyword scoring — "cut" means something
 *      different next to "earnings" than it does next to "rate".
 *   2. Impact/severity scoring (0-100) — trigger phrases ("emergency meeting",
 *      "halts trading", "intervention"), source authority weighting, and a
 *      central-bank-name + policy-verb co-occurrence bonus.
 *   3. Entity extraction — FX pairs (EUR/USD), stock cashtags ($AAPL), and
 *      central bank identification (Fed/FOMC, ECB, BoE, BoJ, PBOC).
 *   4. Cross-source dedup via normalized-headline hashing, persisted to
 *      localStorage so a refresh doesn't re-alert on the same wire story.
 *   5. A stateful alert queue — pollMacroAlerts() only fires on items that
 *      are both new and above the configured severity floor.
 */

// ── SOURCES (reuses news.js RSS_SOURCES where the category overlaps) ───────────
const MACRO_NEWS_SOURCES = {
  fx:              (typeof RSS_SOURCES !== 'undefined' ? RSS_SOURCES.forex  : []),
  stocks:          (typeof RSS_SOURCES !== 'undefined' ? RSS_SOURCES.stocks : []),
  tech: [
    { url:'https://techcrunch.com/feed/',                          name:'TechCrunch'  },
    { url:'https://www.theverge.com/rss/index.xml',                name:'The Verge'   },
    { url:'https://feeds.arstechnica.com/arstechnica/technology-lab', name:'Ars Technica' },
  ],
  monetary_policy: (typeof RSS_SOURCES !== 'undefined' ? RSS_SOURCES.economy : []),
};

const MACRO_CATEGORY_LABEL = { fx:'FX', stocks:'Stocks', tech:'Tech', monetary_policy:'Macro' };

// ── SEVERITY / IMPACT SCORING ───────────────────────────────────────────────────
// Category-aware sentiment: same word, different weight depending on asset class.
const CATEGORY_KEYWORDS = {
  fx: {
    bullish: ['rate hike','hawkish','intervention','strengthens','safe haven inflow','surplus'],
    bearish: ['rate cut','dovish','devalu','weakens','capital flight','deficit widen'],
  },
  stocks: {
    bullish: ['beat estimates','raises guidance','buyback','record revenue','upgrade','soars'],
    bearish: ['misses estimates','cuts guidance','downgrade','profit warning','plunges','layoffs'],
  },
  tech: {
    bullish: ['breakthrough','record shipments','partnership','chip demand surges','ai investment'],
    bearish: ['antitrust','data breach','recall','ban','chip shortage','security flaw'],
  },
  monetary_policy: {
    bullish: ['rate cut','stimulus','dovish pivot','QE','liquidity injection'],
    bearish: ['rate hike','hawkish','tightening','QT','emergency meeting'],
  },
};

// Trigger phrases that materially move markets — weighted, not binary.
const TRIGGER_PHRASES = [
  { p:'emergency meeting',   w:30 }, { p:'halts trading',      w:30 },
  { p:'rate hike',           w:22 }, { p:'rate cut',           w:22 },
  { p:'intervention',        w:24 }, { p:'devaluation',        w:26 },
  { p:'default',             w:28 }, { p:'downgrade',          w:18 },
  { p:'bankruptcy',          w:28 }, { p:'circuit breaker',    w:26 },
  { p:'flash crash',         w:30 }, { p:'sanctions',          w:16 },
  { p:'antitrust',           w:14 }, { p:'data breach',        w:14 },
  { p:'stimulus',            w:16 }, { p:'quantitative easing',w:18 },
  { p:'recession',           w:20 }, { p:'inflation surge',    w:18 },
  { p:'guidance cut',        w:16 }, { p:'guidance raise',     w:14 },
];

const CENTRAL_BANKS   = ['fed','fomc','federal reserve','ecb','european central bank','bank of england','boe','boj','bank of japan','pboc','snb'];
const POLICY_VERBS    = ['hikes','cuts','holds','raises','lowers','signals','pauses','tightens','eases'];

// Source authority weighting — wire services and majors carry more signal
// than aggregator/blog-tier sources.
const SOURCE_WEIGHT = {
  'Reuters':1.3, 'BBC Business':1.2, 'CNBC':1.15, 'Bloomberg':1.3,
  'MarketWatch':1.1, 'Yahoo Finance':1.05, 'Nasdaq':1.05, 'FXStreet':1.1,
  'DailyFX':1.05, 'The Guardian':1.1, 'Sky News':1.05, 'NPR Economy':1.1,
  'Guardian Econ':1.1, 'Al Jazeera':1.05,
};

function computeSeverity(title, category, sourceName) {
  const l = title.toLowerCase();
  let score = 0;

  const kw = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.stocks;
  if (kw.bullish.some(w => l.includes(w))) score += 12;
  if (kw.bearish.some(w => l.includes(w))) score += 12;

  for (const t of TRIGGER_PHRASES) if (l.includes(t.p)) score += t.w;

  const hasBank  = CENTRAL_BANKS.some(b => l.includes(b));
  const hasVerb  = POLICY_VERBS.some(v => l.includes(v));
  if (hasBank && hasVerb) score += 20;
  else if (hasBank)       score += 6;

  score *= (SOURCE_WEIGHT[sourceName] || 1.0);

  return Math.max(0, Math.min(100, Math.round(score)));
}

function severityBand(score) {
  if (score >= 70) return { key:'critical',    label:'CRITICAL',    color:'#FF3B5C' };
  if (score >= 45) return { key:'high_impact', label:'HIGH IMPACT', color:'#F0B90B' };
  if (score >= 20) return { key:'notable',     label:'NOTABLE',     color:'#00D4FF' };
  return              { key:'routine',     label:'ROUTINE',     color:'#7A8BA8' };
}

// ── ENTITY EXTRACTION ───────────────────────────────────────────────────────────
const FX_PAIR_RX  = /\b(EUR|GBP|USD|JPY|CHF|AUD|CAD|NZD|CNY)\/(EUR|GBP|USD|JPY|CHF|AUD|CAD|NZD|CNY)\b/gi;
const CASHTAG_RX  = /\$[A-Z]{1,5}\b/g;
const BANK_LABELS = { fed:'Fed', fomc:'FOMC', 'federal reserve':'Fed', ecb:'ECB',
  'european central bank':'ECB', 'bank of england':'BoE', boe:'BoE',
  boj:'BoJ', 'bank of japan':'BoJ', pboc:'PBOC', snb:'SNB' };

function extractEntities(title) {
  const l = title.toLowerCase();
  const pairs    = [...new Set((title.match(FX_PAIR_RX)||[]).map(s => s.toUpperCase()))];
  const cashtags = [...new Set(title.match(CASHTAG_RX)||[])];
  const banks    = [...new Set(CENTRAL_BANKS.filter(b => l.includes(b)).map(b => BANK_LABELS[b]||b.toUpperCase()))];
  return { pairs, cashtags, banks };
}

// ── DEDUP (normalized-headline hashing, persisted) ──────────────────────────────
function normalizeHeadline(title) {
  return title.toLowerCase().replace(/[^a-z0-9\s]/g,'').replace(/\s+/g,' ').trim();
}
function hashHeadline(title) {
  const s = normalizeHeadline(title);
  let h = 0;
  for (let i=0;i<s.length;i++) { h = ((h<<5)-h + s.charCodeAt(i))|0; }
  return 'h'+h;
}

let _macroSeen = {}; // hash -> timestamp
(function(){ try { const s = localStorage.getItem('nexus_macro_seen'); if (s) _macroSeen = JSON.parse(s); } catch(e){} })();
function saveMacroSeen() {
  // Prune anything older than 48h so the store doesn't grow forever.
  const cutoff = Date.now() - 48*3600*1000;
  for (const k in _macroSeen) if (_macroSeen[k] < cutoff) delete _macroSeen[k];
  try { localStorage.setItem('nexus_macro_seen', JSON.stringify(_macroSeen)); } catch(e){}
}

// ── ALERT CONFIG (persisted) ────────────────────────────────────────────────────
let _macroAlertConfig = {
  enabled: true, minSeverity: 45, // default: high_impact and up
  categories: { fx:true, stocks:true, tech:true, monetary_policy:true }, // per-category on/off
};
(function(){ try { const s = localStorage.getItem('nexus_macro_alert_cfg'); if (s) _macroAlertConfig = { ..._macroAlertConfig, ...JSON.parse(s) }; } catch(e){} })();
function saveMacroAlertConfig() { try { localStorage.setItem('nexus_macro_alert_cfg', JSON.stringify(_macroAlertConfig)); } catch(e){} }
function toggleMacroCategoryAlert(cat, checked) { _macroAlertConfig.categories[cat] = checked; saveMacroAlertConfig(); }

// ── ALERT HISTORY (persisted log — separate from the fire-and-forget toast) ────
let _macroAlertHistory = [];
(function(){ try { const s = localStorage.getItem('nexus_macro_alert_history'); if (s) _macroAlertHistory = JSON.parse(s); } catch(e){} })();
function logMacroAlert(item) {
  _macroAlertHistory.unshift({
    title: item.title, source: item.source, category: item.category,
    severity: item.severity, band: item.band.label, color: item.band.color,
    link: item.link, ts: Date.now(),
  });
  if (_macroAlertHistory.length > 100) _macroAlertHistory.length = 100;
  try { localStorage.setItem('nexus_macro_alert_history', JSON.stringify(_macroAlertHistory)); } catch(e){}
  renderMacroAlertHistory();
}
function clearMacroAlertHistory() {
  _macroAlertHistory = [];
  try { localStorage.setItem('nexus_macro_alert_history', '[]'); } catch(e){}
  renderMacroAlertHistory();
}
function renderMacroAlertHistory() {
  const el = document.getElementById('macroAlertHistory');
  if (!el) return;
  if (!_macroAlertHistory.length) {
    el.innerHTML = `<div style="font-family:var(--mono);font-size:11px;color:var(--muted);padding:8px 0;">No alerts fired yet this session (or restored from storage).</div>`;
    return;
  }
  el.innerHTML = _macroAlertHistory.slice(0, 20).map(a => `
    <div class="mn-hist-row" onclick="${a.link && a.link!=='#' ? `window.open('${escAttr(a.link)}','_blank','noopener')` : ''}">
      <span class="mn-hist-badge" style="color:${a.color};border-color:${a.color};">${esc(a.band)}</span>
      <span class="mn-hist-title">${esc(a.title)}</span>
      <span class="mn-hist-time">${new Date(a.ts).toLocaleTimeString()}</span>
    </div>`).join('');
}

// ── FETCH + SCORE ────────────────────────────────────────────────────────────────
let _macroNewsCache = {}, _macroNewsCacheTime = {};
const MACRO_CACHE_TTL = 3 * 60 * 1000; // 3 min — macro moves faster than general news

// Freshness — a trader needs *current* news. Anything older than this is
// dropped before scoring, not just sorted lower. Alerts use a tighter window
// since an alert implies "this just happened."
const MACRO_MAX_AGE_MS       = 24 * 3600 * 1000; // 24h — display feed
const MACRO_ALERT_MAX_AGE_MS = 6  * 3600 * 1000; // 6h  — alert-worthy

function ageMs(pubDate) {
  const t = new Date(pubDate).getTime();
  if (isNaN(t)) return Infinity; // unparseable date — treat as stale, don't trust it
  return Date.now() - t;
}

async function fetchMacroCategory(category) {
  const now = Date.now();
  const cached = _macroNewsCache[category];
  if (cached && (now - (_macroNewsCacheTime[category]||0)) < MACRO_CACHE_TTL) return cached;

  const sources = MACRO_NEWS_SOURCES[category] || [];
  const results = await Promise.allSettled(sources.map(s => fetchOneFeed(s.url, s.name)));
  const all = [];
  results.forEach(r => { if (r.status==='fulfilled') all.push(...r.value); });

  const seenLocal = new Set();
  const items = all
    .filter(i => ageMs(i.pubDate) <= MACRO_MAX_AGE_MS)   // drop stale/backfilled RSS entries
    .filter(i => {
      const k = normalizeHeadline(i.title).slice(0,60);
      if (seenLocal.has(k)) return false;
      seenLocal.add(k); return true;
    })
    .map(i => {
      const severity = computeSeverity(i.title, category, i.source);
      return {
        ...i,
        hash: hashHeadline(i.title),
        severity,
        band: severityBand(severity),
        entities: extractEntities(i.title),
        category,
      };
    })
    .sort((a,b) => new Date(b.pubDate) - new Date(a.pubDate)) // freshest first — severity is a badge, not a ranking override
    .slice(0, 20);

  _macroNewsCache[category] = items;
  _macroNewsCacheTime[category] = now;
  return items;
}

// ── ALERT QUEUE ──────────────────────────────────────────────────────────────────
async function pollMacroAlerts() {
  if (!_macroAlertConfig.enabled) return;
  const categories = Object.keys(MACRO_NEWS_SOURCES);
  for (const cat of categories) {
    if (_macroAlertConfig.categories[cat] === false) continue; // per-category opt-out
    let items;
    try { items = await fetchMacroCategory(cat); } catch(e) { continue; }
    for (const item of items) {
      if (item.severity < _macroAlertConfig.minSeverity) continue;
      if (ageMs(item.pubDate) > MACRO_ALERT_MAX_AGE_MS) continue; // stale — don't alert on old news just because we saw it for the first time
      if (_macroSeen[item.hash]) continue;
      _macroSeen[item.hash] = Date.now();
      fireMacroAlert(item);
    }
  }
  saveMacroSeen();
}

function fireMacroAlert(item) {
  const toast = document.createElement('div');
  toast.style.cssText = `position:fixed;bottom:24px;right:24px;background:#1a2232;border:1px solid ${item.band.color};border-radius:10px;padding:16px 20px;font-family:'IBM Plex Mono',monospace;font-size:12px;color:${item.band.color};z-index:3000;max-width:340px;box-shadow:0 12px 40px rgba(0,0,0,.6);`;
  toast.innerHTML = `<div style="font-weight:700;margin-bottom:6px;font-size:13px;letter-spacing:.06em;">🌐 ${item.band.label} — ${MACRO_CATEGORY_LABEL[item.category]}</div>
    <div style="color:#eef0f6;font-size:13px;margin-bottom:4px;line-height:1.4;">${esc(item.title)}</div>
    <div style="color:#5a6880;font-size:11px;">${esc(item.source)} · severity ${item.severity}</div>`;
  document.body.appendChild(toast);
  setTimeout(() => { toast.style.opacity='0'; toast.style.transition='opacity .5s'; setTimeout(()=>toast.remove(),500); }, 7000);

  if (typeof _pushOK !== 'undefined' && _pushOK && Notification.permission === 'granted') {
    new Notification(`NEXUS Macro: ${item.band.label}`, { body: item.title });
  }
  if (typeof sendTelegram === 'function') {
    sendTelegram(`🌐 <b>${item.band.label}</b> [${MACRO_CATEGORY_LABEL[item.category]}]\n${item.title}\n<i>${item.source} · severity ${item.severity}</i>`);
  }
  logMacroAlert(item);
  renderMacroNewsPanel(_activeMacroNewsTab);
}

// ── SENTIMENT MOOD (aggregate bullish/bearish tilt across loaded headlines) ────
function computeCategoryMood(items, category) {
  const kw = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.stocks;
  let bull = 0, bear = 0;
  items.forEach(i => {
    const l = i.title.toLowerCase();
    if (kw.bullish.some(w => l.includes(w))) bull++;
    if (kw.bearish.some(w => l.includes(w))) bear++;
  });
  const total = bull + bear;
  const score = total ? Math.round(((bull - bear) / total) * 100) : 0; // -100 bearish .. +100 bullish
  return { bull, bear, scored: total, unscored: items.length - total, score };
}
function moodLabel(score) {
  if (score >= 40)  return { text:'BULLISH TILT',  color:'var(--green)' };
  if (score <= -40) return { text:'BEARISH TILT',  color:'var(--red)'   };
  return               { text:'MIXED / NEUTRAL', color:'var(--muted2)' };
}
function renderMoodGauge(items, category) {
  const el = document.getElementById('macroMoodGauge');
  if (!el) return;
  const m = computeCategoryMood(items, category);
  const lbl = moodLabel(m.score);
  const pct = (m.score + 100) / 2; // 0..100 for bar position
  el.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
      <span style="font-family:var(--mono);font-size:10px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;" title="Keyword-lexicon match, not NLP — no negation handling (e.g. 'not considering a rate hike' would still score hawkish). Read as a rough tilt, not a sentiment score.">${MACRO_CATEGORY_LABEL[category]} Mood — from ${m.scored} of ${items.length} loaded headlines with a clear tilt · ⓘ keyword heuristic, not NLP</span>
      <span style="font-family:var(--mono);font-size:11px;font-weight:700;color:${lbl.color};">${lbl.text} (${m.score>0?'+':''}${m.score})</span>
    </div>
    <div style="height:6px;background:var(--bg4);border-radius:3px;overflow:hidden;position:relative;">
      <div style="position:absolute;left:50%;top:0;bottom:0;width:1px;background:var(--border2);"></div>
      <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,var(--red),var(--muted2) 50%,var(--green));border-radius:3px;"></div>
    </div>`;
}

// ── RENDER ───────────────────────────────────────────────────────────────────────
let _activeMacroNewsTab = 'fx';
function setMacroNewsTab(cat, btn) {
  _activeMacroNewsTab = cat;
  document.querySelectorAll('.macro-news-tab').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderMacroNewsPanel(cat);
}

function entityChips(entities) {
  const chips = [];
  entities.pairs.forEach(p    => chips.push(`<span class="mn-chip mn-chip-fx">${p}</span>`));
  entities.cashtags.forEach(c => chips.push(`<span class="mn-chip mn-chip-tick">${c}</span>`));
  entities.banks.forEach(b    => chips.push(`<span class="mn-chip mn-chip-bank">${b}</span>`));
  return chips.join('');
}

async function renderMacroNewsPanel(category) {
  category = category || _activeMacroNewsTab;
  _activeMacroNewsTab = category;
  const panel = document.getElementById('macroNewsFeed');
  if (!panel) return;
  panel.innerHTML = `<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:12px;color:var(--muted);">
    <span class="ldot">●</span><span class="ldot">●</span><span class="ldot">●</span> Scoring ${MACRO_CATEGORY_LABEL[category]} headlines…</div>`;

  let items;
  try { items = await fetchMacroCategory(category); }
  catch(e) { panel.innerHTML = `<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:12px;color:var(--amber);">Feed unavailable right now.</div>`; return; }

  if (!items.length) {
    panel.innerHTML = `<div style="padding:24px;text-align:center;font-family:var(--mono);font-size:12px;color:var(--muted);">No ${MACRO_CATEGORY_LABEL[category]} headlines scored above routine right now.</div>`;
    return;
  }

  renderMoodGauge(items, category);

  panel.innerHTML = items.map(item => `
    <div class="mn-row" onclick="window.open('${escAttr(item.link)}','_blank','noopener')">
      <div class="mn-sev" style="background:${item.band.color}22;color:${item.band.color};border:1px solid ${item.band.color};">${item.band.label} · ${item.severity}</div>
      <div class="mn-body">
        <div class="mn-title">${esc(item.title)}</div>
        <div class="mn-meta">
          <span>${esc(item.source)}</span><span>·</span><span>${relTime(item.pubDate)}</span>
          ${entityChips(item.entities)}
        </div>
      </div>
    </div>`).join('');
}

function testMacroAlert() {
  fireMacroAlert({
    title: 'Fed signals emergency meeting after overnight rate volatility',
    source: 'Reuters', pubDate: new Date().toISOString(), link: '#',
    severity: 82, band: severityBand(82), entities: { pairs:['EUR/USD'], cashtags:[], banks:['Fed'] },
    category: 'monetary_policy', hash: 'test-'+Date.now(),
  });
}

function startMacroNewsPolling() {
  pollMacroAlerts();
  setInterval(pollMacroAlerts, MACRO_CACHE_TTL);
}
