/**
 * tradingview.js — TradingView widget integration (free embed, no key)
 * Replaces home-built canvas charts with professional TV charts.
 */
function toTVSymbol(sym, type) {
  if (type === 'crypto') return 'BINANCE:' + sym + 'USDT';
  if (type === 'forex')  return 'FX:' + sym.replace('/', '');
  const nyse = ['JPM','BAC','GS','XOM','CVX','JNJ','V','MA','WFC','C','MS','UNH','PFE','KO','PG'];
  return (nyse.includes(sym) ? 'NYSE:' : 'NASDAQ:') + sym;
}

function renderTVChart(sym, name, type) {
  const container = document.getElementById('tvChartContainer');
  if (!container) return;
  container.innerHTML = '';
  const tvSym = toTVSymbol(sym, type);

  const div = document.createElement('div');
  div.style.cssText = 'height:580px;width:100%;';
  container.appendChild(div);

  const script = document.createElement('script');
  script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
  script.type = 'text/javascript';
  script.async = true;
  script.textContent = JSON.stringify({
    autosize: true, symbol: tvSym, interval: 'D', timezone: 'Etc/UTC',
    theme: 'dark', style: '1', locale: 'en',
    backgroundColor: '#0d1117', gridColor: '#1a2232',
    hide_top_toolbar: false, hide_legend: false, save_image: true,
    studies: ['STD;RSI','STD;MACD','STD;Bollinger_Bands','STD;Volume'],
    support_host: 'https://www.tradingview.com',
  });
  div.appendChild(script);

  const title = document.getElementById('tvChartTitle');
  if (title) title.textContent = sym + '  ·  ' + name + '  (' + tvSym + ')';
}

function buildTVChartPicker() {
  const el = document.getElementById('tvPickerGrid');
  if (!el) return;
  const all = [
    ...positions.map(p => ({ sym:p.sym, name:p.name, type:p.type })),
    ...watchlist.map(w => ({ sym:w.sym, name:w.name, type:w.type })),
  ];
  el.innerHTML = all.map(a => `
    <button class="chart-pick-btn" onclick="
      renderTVChart('${a.sym}','${a.name}','${a.type}');
      document.querySelectorAll('.chart-pick-btn').forEach(b=>b.classList.remove('active'));
      this.classList.add('active');">${a.sym}
    </button>`).join('');
  // Auto-open first
  if (all.length) setTimeout(() => renderTVChart(all[0].sym, all[0].name, all[0].type), 100);
}
