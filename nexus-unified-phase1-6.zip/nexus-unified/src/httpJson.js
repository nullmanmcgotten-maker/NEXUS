'use strict';

/**
 * httpJson.js — one shared "fetch a JSON API over HTTPS" helper, used by
 * perpsAlpha.js, polymarketAlpha.js, and taSignalSource.js. Previously
 * each of those had its own near-identical copy of this, which is how a
 * real bug ended up living in three places at once (see below).
 *
 * THE BUG THIS FIXES: "[polymarketAlpha] refresh failed:" with an EMPTY
 * message, and "[perpsAlpha] refresh failed: timeout" firing more than
 * expected, are consistent with Node's Happy Eyeballs behavior
 * (autoSelectFamily, on by default since Node 18.13/20): when a host
 * resolves to both an IPv4 and IPv6 address, Node races both and — if
 * neither connects fast enough, or one path is broken on the network
 * this runs on — throws an `AggregateError` whose own top-level
 * `.message` is an EMPTY STRING; the real reasons are nested in
 * `.errors[]`. `console.error('[name] refresh failed:', e.message)`
 * against that error prints exactly the empty-after-the-colon line
 * you're seeing. This is a known, common false-timeout/blank-error
 * source on networks with partial/broken IPv6, not a sign the upstream
 * API itself is down.
 *
 * Fix: force IPv4 (`family: 4`) so there's no dual-stack race to fail
 * ambiguously, AND unwrap AggregateError into a readable message as a
 * defense-in-depth for any other cause of the same empty-message shape.
 * Also bumped the default timeout from 10s to 20s — perpsAlpha in
 * particular fetches two full-universe Binance endpoints in parallel,
 * which can legitimately take longer than 10s on a slower connection.
 */

const https = require('https');

/** Turns any thrown value into a non-empty, readable message — handles
 *  plain Errors, AggregateError (see header), and non-Error throws. */
function describeError(e) {
  if (!e) return 'unknown error';
  if (e.name === 'AggregateError' && Array.isArray(e.errors) && e.errors.length) {
    return `AggregateError: ${e.errors.map((sub) => sub.message || sub.code || String(sub)).join('; ')}`;
  }
  if (e.message) return e.message;
  if (e.code) return e.code;
  return String(e);
}

/**
 * @param {string} url
 * @param {object} [opts]
 * @param {number} [opts.timeoutMs=20000]
 * @param {string} [opts.userAgent]
 * @returns {Promise<any>} parsed JSON body
 */
function fetchJson(url, opts = {}) {
  const timeoutMs = opts.timeoutMs || 20000;
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: { 'User-Agent': opts.userAgent || 'Mozilla/5.0 (compatible; NexusPortfolio/4.0)' },
      timeout: timeoutMs,
      family: 4, // avoid Happy-Eyeballs dual-stack races — see header comment
    }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => {
        if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('bad JSON response')); }
      });
    });
    req.on('error', (e) => reject(new Error(describeError(e))));
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

module.exports = { fetchJson, describeError };
