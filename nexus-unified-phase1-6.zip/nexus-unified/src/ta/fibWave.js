/**
 * ta/fibWave.js — Fibonacci retracement/extension confluence, and a
 * rule-checked (not discretionary) Elliott Wave read.
 *
 * IMPORTANT HONESTY NOTE (surface this in the UI, don't bury it): real
 * Elliott Wave analysis is famously discretionary — professional analysts
 * routinely disagree on the count for the same chart, and there is no
 * general algorithm that resolves that ambiguity. What's implemented here
 * is narrower and fully mechanical: take the zigzag pivots, check them
 * against Elliott's three *hard* rules (wave 2 doesn't retrace past the
 * start of wave 1; wave 3 is never the shortest of 1/3/5; wave 4 doesn't
 * enter wave 1's price territory) plus the *typical* Fibonacci ratios
 * (wave 3 ≈ 1.618× wave 1, wave 4 retraces 0.236–0.5 of wave 3). If a
 * 5-swing sequence passes, it's reported as "a valid impulse count is
 * possible" — never "this IS wave 3", because that certainty isn't
 * available from price data alone.
 */
'use strict';

const FibWave = {
  FIB_RETRACE: [0.236, 0.382, 0.5, 0.618, 0.786],
  FIB_EXT: [1.272, 1.618, 2.0, 2.618],

  /** Retracement + extension levels for the most recent significant swing. */
  levels(candles, pct = 3) {
    const pivots = TAUtil.zigzag(candles, pct);
    if (pivots.length < 2) return null;
    const a = pivots[pivots.length - 2], b = pivots[pivots.length - 1];
    const up = b.v > a.v;
    const range = Math.abs(b.v - a.v);
    const retr = this.FIB_RETRACE.map(f => ({ f, price: up ? b.v - range * f : b.v + range * f }));
    const ext = this.FIB_EXT.map(f => ({ f, price: up ? b.v + range * (f - 1) : b.v - range * (f - 1) }));
    return { swingFrom: a, swingTo: b, up, retracements: retr, extensions: ext };
  },

  /**
   * Confluence zones: cluster retracement/extension levels from the last
   * few swings (not just the latest) with fractal S/R levels, within a
   * tight tolerance. A price zone with 3+ independent things lining up is
   * a materially stronger reference level than any single fib line.
   */
  confluence(candles, srLevels = [], pct = 3, tolPct = 0.5) {
    const pivots = TAUtil.zigzag(candles, pct);
    if (pivots.length < 4) return [];
    const allLevels = [];
    // Build fib levels off the last 3 swing pairs, not just the latest.
    for (let k = pivots.length - 1; k >= Math.max(1, pivots.length - 4); k--) {
      const a = pivots[k - 1], b = pivots[k];
      if (!a) continue;
      const range = Math.abs(b.v - a.v), up = b.v > a.v;
      this.FIB_RETRACE.forEach(f => allLevels.push({ price: up ? b.v - range * f : b.v + range * f, src: `${(f*100).toFixed(1)}% retrace of swing @${a.i}-${b.i}` }));
    }
    srLevels.forEach(l => allLevels.push({ price: l.level ?? l, src: 'S/R level' }));

    allLevels.sort((x, y) => x.price - y.price);
    const clusters = [];
    let cur = [allLevels[0]];
    for (let i = 1; i < allLevels.length; i++) {
      const prev = cur[cur.length - 1];
      if (Math.abs(allLevels[i].price - prev.price) / prev.price * 100 <= tolPct) cur.push(allLevels[i]);
      else { if (cur.length >= 2) clusters.push(cur); cur = [allLevels[i]]; }
    }
    if (cur.length >= 2) clusters.push(cur);
    return clusters.map(c => ({
      price: c.reduce((s, x) => s + x.price, 0) / c.length,
      strength: c.length,
      sources: c.map(x => x.src),
    })).sort((a, b) => b.strength - a.strength).slice(0, 5);
  },

  /** Mechanical rule-check for a 5-wave impulse on the last 6 zigzag pivots. */
  elliottCheck(candles, pct = 3) {
    // Deliberately KEEP the trailing unconfirmed pivot — it's the current,
    // still-forming swing extreme, i.e. exactly where wave 5 would be if a
    // count is in progress. Every pivot before it is already a confirmed
    // reversal by construction of the zigzag algorithm.
    const pivots = TAUtil.zigzag(candles, pct);
    if (pivots.length < 6) return null;
    const w = pivots.slice(-6); // p0..p5 = start + 5 wave-ends
    const [p0, p1, p2, p3, p4, p5] = w;
    const len = (x, y) => Math.abs(y.v - x.v);
    const wave1 = len(p0, p1), wave2 = len(p1, p2), wave3 = len(p2, p3), wave4 = len(p3, p4), wave5 = len(p4, p5);
    const bullish = p1.v > p0.v;

    const rules = {
      wave2NoFullRetrace: bullish ? p2.v > p0.v : p2.v < p0.v,
      wave3NotShortest: wave3 >= wave1 && wave3 >= wave5,
      wave4NoOverlap: bullish ? p4.v > p1.v : p4.v < p1.v,
    };
    const allPass = Object.values(rules).every(Boolean);

    const w3Ratio = wave1 ? wave3 / wave1 : null;
    const w4Retrace = wave3 ? wave4 / wave3 : null;
    const nearFib = (v, targets, tol = 0.25) => v != null && targets.some(t => Math.abs(v - t) <= tol);
    const fibConformity = nearFib(w3Ratio, [1.618, 2.618]) && nearFib(w4Retrace, [0.236, 0.382, 0.5], 0.15);

    return { pivots: w, bullish, rules, allPass, w3Ratio, w4Retrace, fibConformity, lastIdx: p5.i };
  },

  toSignals(fib, wave) {
    const out = [];
    if (fib) {
      const near = [...fib.retracements, ...fib.extensions].reduce((a, b) => Math.abs(b.price - fib.swingTo.v) < Math.abs(a.price - fib.swingTo.v) ? b : a);
      out.push({ type: 'neut', text: `Swing ${fib.up ? 'up' : 'down'} from ${fib.swingFrom.v.toFixed(4)} to ${fib.swingTo.v.toFixed(4)} — key retracements: ${fib.retracements.map(r => `${(r.f*100).toFixed(1)}%=${r.price.toFixed(4)}`).join(', ')}`});
    }
    if (wave) {
      if (wave.allPass) {
        out.push({ type: wave.bullish ? 'buy' : 'sell', text: `Valid ${wave.bullish ? 'bullish' : 'bearish'} 5-wave impulse count is possible (all 3 Elliott rules pass)${wave.fibConformity ? ', ratios fit typical Fibonacci proportions' : ', but ratios are atypical'} — this is a rule-check, not a confirmed count` });
      } else {
        const failed = Object.entries(wave.rules).filter(([, ok]) => !ok).map(([k]) => k);
        out.push({ type: 'neut', text: `No valid Elliott impulse count on the last 6 swings (fails: ${failed.join(', ')})` });
      }
    }
    return out;
  },

  toFactors(wave) {
    if (!wave || !wave.allPass) return [];
    // Deliberately modest weight — this is the most discretionary-adjacent
    // framework in the suite even with rule-checking, so it shouldn't swing
    // the composite alone.
    return [{ name: 'Elliott Wave', direction: wave.bullish ? 1 : -1, weight: wave.fibConformity ? 2 : 1, detail: `5-wave ${wave.bullish ? 'impulse up' : 'impulse down'}, rules pass${wave.fibConformity ? ' + fib ratios fit' : ''}` }];
  },
};
