/**
 * ta/orderflow.js — VWAP + deviation bands, and REAL order flow (cumulative
 * volume delta) computed from Binance aggTrades rather than approximated
 * from candle bodies.
 *
 * Why aggTrades and not candle-derived delta: a candle only tells you OHLCV
 * — it cannot tell you whether the volume inside it was buyer- or
 * seller-initiated. Approximating that from candle shape (e.g. "green candle
 * = all buy volume") is a common shortcut but it's just wrong on any candle
 * with real two-way trade inside it. Binance's aggTrades stream carries the
 * `m` (isBuyerMaker) flag per trade, which tells you which side was the
 * taker (aggressor) — that's what actually defines buy- vs sell-initiated
 * volume. So this module fetches real trades and buckets them into the
 * candle timeframe, giving a genuine cumulative volume delta (CVD) rather
 * than a proxy.
 */
'use strict';

const OrderFlow = {
  /** Anchored VWAP (from the start of the given candle array) + stdev bands. */
  vwap(candles) {
    if (candles.length < 5) return null;
    let cumPV = 0, cumV = 0;
    const series = [];
    for (const c of candles) {
      const typical = (c.h + c.l + c.c) / 3;
      cumPV += typical * (c.v || 0);
      cumV += (c.v || 0);
      series.push(cumV > 0 ? cumPV / cumV : null);
    }
    const deviations = candles.map((c, i) => series[i] != null ? (c.c - series[i]) : null);
    const sd = TAUtil.stdev(deviations);
    const last = series.length - 1;
    return {
      vwap: series[last], series,
      upper1: series[last] + sd, lower1: series[last] - sd,
      upper2: series[last] + 2 * sd, lower2: series[last] - 2 * sd,
      price: candles[last].c, sd,
    };
  },

  /** GET Binance aggTrades — up to 1000 most recent trades for the symbol. */
  async fetchAggTrades(symbol, limit = 1000) {
    const rows = await apiFetch(`${BINANCE_BASE}/aggTrades?symbol=${symbol}USDT&limit=${limit}`);
    if (!Array.isArray(rows)) throw new Error(`no aggTrades for ${symbol}USDT`);
    // { a:tradeId, p:price, q:qty, T:timestamp, m:isBuyerMaker }
    return rows.map(r => ({ p: +r.p, q: +r.q, t: r.T, sellInitiated: r.m === true }));
  },

  /** Cumulative volume delta across a flat trade list. */
  computeCVD(trades) {
    let buyVol = 0, sellVol = 0;
    const cumSeries = [];
    let running = 0;
    for (const tr of trades) {
      const signed = tr.sellInitiated ? -tr.q : tr.q;
      if (tr.sellInitiated) sellVol += tr.q; else buyVol += tr.q;
      running += signed;
      cumSeries.push(running);
    }
    return { buyVol, sellVol, delta: buyVol - sellVol, deltaPct: (buyVol + sellVol) ? (buyVol - sellVol) / (buyVol + sellVol) * 100 : 0, cumSeries };
  },

  /** Bucket trades into the candle whose [open,close) time window contains them; flags absorption. */
  bucketDeltaByCandle(trades, candles, intervalMs) {
    const buckets = candles.map(c => ({ t: c.t, buy: 0, sell: 0 }));
    for (const tr of trades) {
      // find the candle bucket — walk from the end since aggTrades are recent-most
      for (let i = buckets.length - 1; i >= 0; i--) {
        if (tr.t >= buckets[i].t && tr.t < buckets[i].t + intervalMs) {
          if (tr.sellInitiated) buckets[i].sell += tr.q; else buckets[i].buy += tr.q;
          break;
        }
      }
    }
    return buckets.map((b, i) => {
      const delta = b.buy - b.sell;
      const total = b.buy + b.sell;
      const priceMove = candles[i] ? (candles[i].c - candles[i].o) : 0;
      // Absorption: heavy one-sided delta but price barely moved — the
      // aggressor's flow was absorbed rather than pushing price.
      const absorption = total > 0 && Math.abs(delta) / (total || 1) > 0.3 && Math.abs(priceMove) / (candles[i]?.o || 1) < 0.001;
      return { t: b.t, buy: b.buy, sell: b.sell, delta, absorption, absorptionSide: absorption ? (delta > 0 ? 'buy-absorbed' : 'sell-absorbed') : null };
    });
  },

  toSignals(vwapResult, cvd) {
    const out = [];
    if (vwapResult) {
      let pos = 'at VWAP';
      if (vwapResult.price > vwapResult.upper2) pos = 'far above VWAP (2σ+)';
      else if (vwapResult.price > vwapResult.upper1) pos = 'above VWAP (1σ)';
      else if (vwapResult.price < vwapResult.lower2) pos = 'far below VWAP (2σ+)';
      else if (vwapResult.price < vwapResult.lower1) pos = 'below VWAP (1σ)';
      out.push({ type: vwapResult.price > vwapResult.vwap ? 'buy' : 'sell', text: `Price ${pos} (VWAP ${vwapResult.vwap.toFixed(4)})` });
    }
    if (cvd) {
      out.push({ type: cvd.delta > 0 ? 'buy' : cvd.delta < 0 ? 'sell' : 'neut', text: `Order flow: ${cvd.deltaPct.toFixed(1)}% net ${cvd.delta > 0 ? 'buy' : 'sell'}-side (last ${cvd.buyVol.toFixed(0)} buy / ${cvd.sellVol.toFixed(0)} sell, real taker flow)` });
    }
    return out;
  },

  toFactors(vwapResult, cvd, recentBuckets) {
    const factors = [];
    if (vwapResult && Math.abs(vwapResult.price - vwapResult.vwap) > vwapResult.sd * 0.5) {
      factors.push({ name: 'VWAP', direction: vwapResult.price > vwapResult.vwap ? 1 : -1, weight: 1, detail: `price ${(Math.abs(vwapResult.price - vwapResult.vwap) / (vwapResult.sd || 1)).toFixed(1)}σ from VWAP` });
    }
    if (cvd && Math.abs(cvd.deltaPct) > 15) {
      factors.push({ name: 'Order Flow (CVD)', direction: cvd.delta > 0 ? 1 : -1, weight: 2, detail: `${cvd.deltaPct.toFixed(1)}% net taker imbalance, real trade flow` });
    }
    if (recentBuckets && recentBuckets.length) {
      const last = recentBuckets[recentBuckets.length - 1];
      if (last.absorption) {
        // Absorption is a fade signal: heavy one-sided flow that failed to
        // move price often precedes a reversal against that flow.
        factors.push({ name: 'Absorption', direction: last.absorptionSide === 'buy-absorbed' ? -1 : 1, weight: 1, detail: `${last.absorptionSide.replace('-', ' ')} — heavy flow, no follow-through` });
      }
    }
    return factors;
  },
};
