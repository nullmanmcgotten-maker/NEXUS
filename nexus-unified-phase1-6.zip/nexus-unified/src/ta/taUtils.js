/**
 * ta/taUtils.js — shared primitives for the advanced-TA suite (structure,
 * Wyckoff, Ichimoku, Fibonacci/wave, order flow, harmonics).
 *
 * Everything here is a pure function of a candle array ({t,o,h,l,c,v}), so
 * every module downstream can be unit-tested against fixed arrays without
 * touching the network. Two swing-detection strategies are provided because
 * they serve different purposes:
 *
 *  - fractalSwings(): local 5-bar (2-left/2-right) highs/lows. Fast, always
 *    on, used for order-block / FVG / liquidity-sweep detection where you
 *    want every minor swing.
 *  - zigzag(): percentage-reversal filtered swings. Used for Elliott/Fibonacci
 *    and harmonic-pattern detection where minor noise swings would produce
 *    garbage wave counts — those methods need the *significant* swings only.
 */
'use strict';

const TAUtil = {
  /** Local fractal highs/lows (2 bars either side). Returns {peaks:[{i,v}], troughs:[{i,v}]} in index order. */
  fractalSwings(candles, lookback = 2) {
    const h = candles.map(c => c.h), l = candles.map(c => c.l);
    const n = candles.length, peaks = [], troughs = [];
    for (let i = lookback; i < n - lookback; i++) {
      let isPeak = true, isTrough = true;
      for (let k = 1; k <= lookback; k++) {
        if (!(h[i] > h[i - k] && h[i] > h[i + k])) isPeak = false;
        if (!(l[i] < l[i - k] && l[i] < l[i + k])) isTrough = false;
      }
      if (isPeak) peaks.push({ i, v: h[i] });
      if (isTrough) troughs.push({ i, v: l[i] });
    }
    return { peaks, troughs };
  },

  /**
   * Percentage zig-zag: walks the series, keeps extending the current
   * extreme until price reverses by >= pct from that extreme, then confirms
   * a pivot and flips direction. Standard "Zig Zag indicator" definition —
   * deterministic, not a discretionary call.
   * Returns ordered array of {i, v, type:'high'|'low'}.
   */
  zigzag(candles, pct = 3) {
    if (candles.length < 3) return [];
    const pivots = [];
    let dir = 0; // 0 = direction not yet determined, 1 = tracking a high, -1 = tracking a low
    // While undetermined, accumulate BOTH the running high and running low
    // since candle 0 — the first one that ends up >= pct away from the
    // other decides which was the actual starting pivot.
    let hiV = candles[0].h, hiI = 0, loV = candles[0].l, loI = 0;
    for (let i = 1; i < candles.length; i++) {
      const hi = candles[i].h, lo = candles[i].l;
      if (dir === 0) {
        if (hi > hiV) { hiV = hi; hiI = i; }
        if (lo < loV) { loV = lo; loI = i; }
        if ((hiV - loV) / loV * 100 >= pct) {
          if (hiI < loI) { pivots.push({ i: hiI, v: hiV, type: 'high' }); dir = -1; loV = lo; loI = i; }
          else { pivots.push({ i: loI, v: loV, type: 'low' }); dir = 1; hiV = hi; hiI = i; }
        }
      } else if (dir === 1) {
        if (hi > hiV) { hiV = hi; hiI = i; }
        if ((hiV - lo) / hiV * 100 >= pct) { pivots.push({ i: hiI, v: hiV, type: 'high' }); dir = -1; loV = lo; loI = i; }
      } else {
        if (lo < loV) { loV = lo; loI = i; }
        if ((hi - loV) / loV * 100 >= pct) { pivots.push({ i: loI, v: loV, type: 'low' }); dir = 1; hiV = hi; hiI = i; }
      }
    }
    // Trailing extreme in progress (unconfirmed — may still extend further).
    if (dir === 1) pivots.push({ i: hiI, v: hiV, type: 'high', unconfirmed: true });
    else if (dir === -1) pivots.push({ i: loI, v: loV, type: 'low', unconfirmed: true });
    else pivots.push({ i: hiV - candles[0].c >= candles[0].c - loV ? hiI : loI, v: hiV - candles[0].c >= candles[0].c - loV ? hiV : loV, type: hiV - candles[0].c >= candles[0].c - loV ? 'high' : 'low', unconfirmed: true });
    return pivots;
  },

  /** Simple moving average of an array (nulls preserved at head). */
  sma(arr, period) {
    return arr.map((_, i) => {
      if (i < period - 1) return null;
      let s = 0, valid = true;
      for (let k = i - period + 1; k <= i; k++) { if (arr[k] == null) { valid = false; break; } s += arr[k]; }
      return valid ? s / period : null;
    });
  },

  stdev(arr) {
    const valid = arr.filter(v => v != null && !isNaN(v));
    if (!valid.length) return 0;
    const m = valid.reduce((a, b) => a + b, 0) / valid.length;
    return Math.sqrt(valid.reduce((s, v) => s + (v - m) ** 2, 0) / valid.length);
  },

  /** Clamp a normalized -1..1 direction score, tolerant of NaN. */
  clampDir(x) { return isNaN(x) ? 0 : Math.max(-1, Math.min(1, x)); },
};
