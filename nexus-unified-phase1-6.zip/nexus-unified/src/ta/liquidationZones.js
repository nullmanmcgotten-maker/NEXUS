/**
 * ta/liquidationZones.js — estimates WHERE clustered forced-liquidation
 * price levels likely sit relative to current price, across common
 * leverage tiers. This is the tool for "where are the liquidation
 * magnets" that nothing else in this codebase computes.
 *
 * IMPORTANT — this is a model, not a measurement. Binance doesn't publish
 * per-position leverage or entry price (that's private account data), and
 * the only real liquidation data source is the `@forceOrder` WebSocket
 * (recent liquidations AS THEY HAPPEN, a live push feed with no queryable
 * history) — out of scope for an on-demand REST-based panel like this one.
 * What this DOES compute, honestly: standard isolated-margin liquidation-
 * price math for a set of common leverage tiers, assuming a position was
 * opened near the CURRENT price (the only price actually known here). That
 * assumption weakens the further open interest has churned since — treat
 * these as "where a fresh position at this leverage would blow up from
 * here," not "here's the exchange's real order book of stops."
 *
 * Useful anyway, for the same reason round-leverage tiers act as real
 * magnets in practice: a lot of retail leverage clusters at 5x/10x/20x/
 * 50x/100x (see TIERS' weighting below), so the % distance to each tier's
 * liquidation price tells you which nearby level plausibly has real
 * forced-selling/buying pressure behind it — independent of whether any
 * one entry-price assumption is exactly right.
 */
'use strict';

// Maintenance margin rate approximation. Binance's real MMR is a tiered
// schedule that gets more conservative at large notional; 0.5% is a
// reasonable small/mid-notional approximation for the position sizes this
// panel targets — not exact for every symbol or size.
const DEFAULT_MMR = 0.005;

// Relative popularity weighting across common perp leverage tiers — NOT
// measured (Binance doesn't publish this), just a plausible retail-leverage
// distribution shape (heavier in the middle tiers, thinner at the
// extremes) so "which zone looks heavier" isn't a meaningless flat spread.
const TIERS = [
  { leverage: 5, weight: 0.10 },
  { leverage: 10, weight: 0.22 },
  { leverage: 20, weight: 0.28 },
  { leverage: 25, weight: 0.16 },
  { leverage: 50, weight: 0.16 },
  { leverage: 100, weight: 0.08 },
];

/** Isolated-margin approx: a long liquidates once price falls (1/leverage -
 *  mmr) below entry; a short liquidates the same distance above entry. */
function liqDistancePct(leverage, mmr = DEFAULT_MMR) {
  return Math.max(0, 1 / leverage - mmr);
}

const LiquidationZones = {
  DEFAULT_MMR,
  TIERS,
  liqDistancePct,

  /**
   * @param {number} price - current mark price
   * @param {number|null} [openInterest] - in COIN units (not USD notional);
   *   used only to scale a relative `estNotional` label, entirely optional.
   * @param {{long:number,short:number}|null} [positioning] - fraction long
   *   vs short (e.g. derived from a long/short account ratio); defaults 50/50.
   * @returns {{longZones:Array, shortZones:Array}} each zone:
   *   { leverage, price, distancePct, weight, estNotional }
   */
  estimateZones(price, openInterest = null, positioning = null, mmr = DEFAULT_MMR) {
    if (!price || price <= 0) return { longZones: [], shortZones: [] };
    const longFrac = positioning?.long ?? 0.5;
    const shortFrac = positioning?.short ?? (1 - longFrac);
    const notional = openInterest != null ? openInterest * price : null;

    const longZones = TIERS.map((t) => {
      const distancePct = liqDistancePct(t.leverage, mmr) * 100;
      return {
        leverage: t.leverage,
        price: price * (1 - distancePct / 100),
        distancePct: -distancePct,
        weight: t.weight * longFrac,
        estNotional: notional != null ? notional * t.weight * longFrac : null,
      };
    });
    const shortZones = TIERS.map((t) => {
      const distancePct = liqDistancePct(t.leverage, mmr) * 100;
      return {
        leverage: t.leverage,
        price: price * (1 + distancePct / 100),
        distancePct,
        weight: t.weight * shortFrac,
        estNotional: notional != null ? notional * t.weight * shortFrac : null,
      };
    });
    return { longZones, shortZones };
  },

  /** Collapses long+short zones into one list sorted by distance from
   *  price, nearest first — the simple "what's coming up either way" view. */
  nearestZones(price, openInterest = null, positioning = null, count = 6, mmr = DEFAULT_MMR) {
    const { longZones, shortZones } = this.estimateZones(price, openInterest, positioning, mmr);
    return [...longZones, ...shortZones]
      .sort((a, b) => Math.abs(a.distancePct) - Math.abs(b.distancePct))
      .slice(0, count);
  },

  /** Render-ready signal lines, same {type,text} shape every other ta/*.js
   *  module uses, so advancedTAPanel.js's generic `section()` renderer
   *  works here without a bespoke code path. Direction is a magnet-level
   *  note, not a directional call — price is pulled TOWARD, not away from,
   *  these zones, in either direction, so type is always 'neut'. */
  toSignals(price, openInterest = null, positioning = null) {
    const zones = this.nearestZones(price, openInterest, positioning, 4);
    return zones.map((z) => ({
      type: 'neut',
      text: `~${z.distancePct >= 0 ? '+' : ''}${z.distancePct.toFixed(2)}% (${z.leverage}x ${z.distancePct >= 0 ? 'shorts' : 'longs'} est. liquidation zone, $${z.price < 1 ? z.price.toFixed(6) : z.price.toFixed(2)})`,
    }));
  },
};

if (typeof module !== 'undefined' && module.exports) module.exports = LiquidationZones;
