/**
 * ta/advancedTA.js — single entry point for the advanced-TA suite
 * (structure.js, wyckoff.js, ichimoku.js, fibWave.js, orderflow.js,
 * harmonics.js). Two tiers, matching how the rest of the app already
 * separates cheap/always-on work from expensive/on-demand work:
 *
 *  - analyzeSync(candles) — structure, Wyckoff, single-timeframe Ichimoku,
 *    Fibonacci/Elliott, harmonics. All pure functions of candles you've
 *    already fetched (e.g. the 1h candles perps.js pulls for every scanned
 *    symbol) — safe to run on every symbol, every scan, no extra network
 *    calls. This is what feeds the composite score.
 *
 *  - analyzeDeep(symbol, candles1h, timeframeSets) — adds real order flow
 *    (Binance aggTrades — a genuine extra network call per symbol) and
 *    multi-timeframe Ichimoku alignment (needs several timeframes of
 *    candles). Deliberately NOT run for every symbol on every scan — that
 *    would multiply outbound requests across a whole watchlist and risk
 *    exactly the rate-limit problems dataHealth.js/ROADMAP.md already flag.
 *    Called on demand for one symbol at a time (the dedicated Advanced TA
 *    panel).
 */
'use strict';

const AdvancedTA = {
  analyzeSync(candles) {
    if (!candles || candles.length < 15) return null;
    const structure = SMCStructure.analyze(candles);
    const wyckoff = Wyckoff.analyze(candles);
    const ichimoku = Ichimoku.compute(candles);
    const fib = FibWave.levels(candles);
    const wave = FibWave.elliottCheck(candles);
    const confluence = FibWave.confluence(candles, (structure?.swings || []).map(s => ({ level: s.v })));
    const harmonicMatches = Harmonics.scan(candles);

    return { structure, wyckoff, ichimoku, fib, wave, confluence, harmonicMatches, lastIdx: candles.length - 1 };
  },

  /** Flat {type,text} signal list for display, in the same shape as TA.generateSignals. */
  toSignals(result) {
    if (!result) return [{ type: 'info', text: 'Not enough candle history for advanced TA (need 60+ bars, 100+ for Ichimoku)' }];
    return [
      ...SMCStructure.toSignals(result.structure),
      ...Wyckoff.toSignals(result.wyckoff),
      ...Ichimoku.toSignals(result.ichimoku),
      ...FibWave.toSignals(result.fib, result.wave),
      ...Harmonics.toSignals(result.harmonicMatches),
    ];
  },

  /** Combined {name,direction,weight,detail} factors — spreadable straight into perps.js's composite factors array. */
  toFactors(result) {
    if (!result) return [];
    return [
      ...SMCStructure.toFactors(result.structure),
      ...Wyckoff.toFactors(result.wyckoff),
      ...Ichimoku.toFactors(result.ichimoku, null),
      ...FibWave.toFactors(result.wave),
      ...Harmonics.toFactors(result.harmonicMatches, result.lastIdx),
    ];
  },

  /** Deep tier — real order flow + MTF Ichimoku. Call per-symbol, on demand. */
  async analyzeDeep(symbol, candles1h, timeframeSets = []) {
    const sync = this.analyzeSync(candles1h);
    let orderFlow = null, mtf = null;
    try {
      const trades = await OrderFlow.fetchAggTrades(symbol, 1000);
      const cvd = OrderFlow.computeCVD(trades);
      const vwapResult = OrderFlow.vwap(candles1h.slice(-96)); // ~4 days of 1h bars, session-agnostic anchor
      const buckets = OrderFlow.bucketDeltaByCandle(trades, candles1h.slice(-20), 60 * 60 * 1000);
      orderFlow = { cvd, vwapResult, buckets };
    } catch (e) {
      orderFlow = { error: e.message };
    }
    if (timeframeSets.length) mtf = Ichimoku.multiTimeframe(timeframeSets);

    const deepFactors = [];
    if (orderFlow && !orderFlow.error) deepFactors.push(...OrderFlow.toFactors(orderFlow.vwapResult, orderFlow.cvd, orderFlow.buckets));
    if (mtf) deepFactors.push(...Ichimoku.toFactors(sync?.ichimoku, mtf));

    return {
      ...sync, orderFlow, mtf,
      factors: [...this.toFactors(sync), ...deepFactors],
      signals: [
        ...this.toSignals(sync),
        ...(orderFlow && !orderFlow.error ? OrderFlow.toSignals(orderFlow.vwapResult, orderFlow.cvd) : [{ type: 'info', text: `Order flow unavailable: ${orderFlow?.error || 'unknown error'}` }]),
      ],
    };
  },
};
