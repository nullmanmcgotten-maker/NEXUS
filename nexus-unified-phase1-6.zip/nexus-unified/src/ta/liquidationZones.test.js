'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const LiquidationZones = require('./liquidationZones');

test('liqDistancePct: higher leverage means a closer (smaller) liquidation distance', () => {
  const d5 = LiquidationZones.liqDistancePct(5);
  const d20 = LiquidationZones.liqDistancePct(20);
  const d100 = LiquidationZones.liqDistancePct(100);
  assert.ok(d5 > d20);
  assert.ok(d20 > d100);
  assert.ok(d100 >= 0); // never negative even at very high leverage + mmr
});

test('estimateZones: long zones sit below price, short zones sit above price', () => {
  const { longZones, shortZones } = LiquidationZones.estimateZones(100, null, null);
  for (const z of longZones) {
    assert.ok(z.price < 100, `long liq price ${z.price} should be below entry 100`);
    assert.ok(z.distancePct < 0);
  }
  for (const z of shortZones) {
    assert.ok(z.price > 100, `short liq price ${z.price} should be above entry 100`);
    assert.ok(z.distancePct > 0);
  }
});

test('estimateZones: 100x tier liquidates much closer to price than 5x tier', () => {
  const { longZones } = LiquidationZones.estimateZones(100, null, null);
  const t5 = longZones.find((z) => z.leverage === 5);
  const t100 = longZones.find((z) => z.leverage === 100);
  assert.ok(Math.abs(t100.distancePct) < Math.abs(t5.distancePct));
});

test('estimateZones: skewed positioning shifts weight, not price levels', () => {
  const heavyLong = LiquidationZones.estimateZones(100, 1000, { long: 0.8, short: 0.2 });
  const heavyShort = LiquidationZones.estimateZones(100, 1000, { long: 0.2, short: 0.8 });
  // price levels are leverage-math only, unaffected by positioning
  assert.equal(heavyLong.longZones[0].price, heavyShort.longZones[0].price);
  // but estimated notional weight should differ accordingly
  assert.ok(heavyLong.longZones[0].estNotional > heavyShort.longZones[0].estNotional);
  assert.ok(heavyShort.shortZones[0].estNotional > heavyLong.shortZones[0].estNotional);
});

test('nearestZones: sorted by absolute distance from price, nearest first', () => {
  const zones = LiquidationZones.nearestZones(100, null, null, 12);
  for (let i = 1; i < zones.length; i++) {
    assert.ok(Math.abs(zones[i].distancePct) >= Math.abs(zones[i - 1].distancePct));
  }
});

test('estimateZones: guards against a zero/invalid price instead of dividing by it', () => {
  const result = LiquidationZones.estimateZones(0, 100, null);
  assert.deepEqual(result, { longZones: [], shortZones: [] });
});

test('toSignals: returns neut-typed lines with both leverage and direction in the text', () => {
  const lines = LiquidationZones.toSignals(100, 5000, null);
  assert.ok(lines.length > 0);
  for (const l of lines) {
    assert.equal(l.type, 'neut');
    assert.match(l.text, /\d+x (longs|shorts) est\. liquidation zone/);
  }
});
