/**
 * ta/ichimoku.js — full Ichimoku Kinko Hyo system (standard 9/26/52 periods)
 * plus a multi-timeframe trend-alignment helper that reuses the same read
 * across several candle sets (e.g. 1h/4h/1d) — the actual "hardcore" value
 * of Ichimoku is less any single line and more that price/cloud/TK/chikou
 * all have to agree before it counts as a real signal.
 */
'use strict';

const Ichimoku = {
  _mid(candles, i, period) {
    if (i < period - 1) return null;
    let hi = -Infinity, lo = Infinity;
    for (let k = i - period + 1; k <= i; k++) { if (candles[k].h > hi) hi = candles[k].h; if (candles[k].l < lo) lo = candles[k].l; }
    return (hi + lo) / 2;
  },

  compute(candles, tenkanP = 9, kijunP = 26, senkouBP = 52) {
    const n = candles.length;
    if (n < senkouBP + kijunP) return null; // need the full lookback + forward projection to be meaningful
    const tenkan = candles.map((_, i) => this._mid(candles, i, tenkanP));
    const kijun = candles.map((_, i) => this._mid(candles, i, kijunP));
    const senkouA = candles.map((_, i) => (tenkan[i] != null && kijun[i] != null) ? (tenkan[i] + kijun[i]) / 2 : null);
    const senkouB = candles.map((_, i) => this._mid(candles, i, senkouBP));
    // Cloud that's actually covering *today* was projected 26 bars ago —
    // i.e. today's cloud boundary uses senkouA/B computed at i-kijunP.
    const last = n - 1;
    const cloudIdx = last - kijunP;
    const cloudTop = cloudIdx >= 0 ? Math.max(senkouA[cloudIdx] ?? -Infinity, senkouB[cloudIdx] ?? -Infinity) : null;
    const cloudBottom = cloudIdx >= 0 ? Math.min(senkouA[cloudIdx] ?? Infinity, senkouB[cloudIdx] ?? Infinity) : null;
    const cloudBullish = cloudIdx >= 0 ? senkouA[cloudIdx] > senkouB[cloudIdx] : null;

    const price = candles[last].c;
    let priceVsCloud = 'inside';
    if (cloudTop != null && price > cloudTop) priceVsCloud = 'above';
    else if (cloudBottom != null && price < cloudBottom) priceVsCloud = 'below';

    const tkCrossUp = tenkan[last] != null && kijun[last] != null && tenkan[last - 1] != null && kijun[last - 1] != null
      && tenkan[last] > kijun[last] && tenkan[last - 1] <= kijun[last - 1];
    const tkCrossDown = tenkan[last] != null && kijun[last] != null && tenkan[last - 1] != null && kijun[last - 1] != null
      && tenkan[last] < kijun[last] && tenkan[last - 1] >= kijun[last - 1];

    // Chikou (lagging span = today's close, plotted 26 back) vs price at that time.
    const chikouIdx = last - kijunP;
    const chikouClear = chikouIdx >= 0 ? (price > candles[chikouIdx].c ? 'above' : price < candles[chikouIdx].c ? 'below' : 'equal') : null;

    return {
      tenkan: tenkan[last], kijun: kijun[last], cloudTop, cloudBottom, cloudBullish,
      priceVsCloud, tkCrossUp, tkCrossDown, chikouClear, price, lastIdx: last,
    };
  },

  /** How many of a set of {label, candles} timeframes agree on direction. */
  multiTimeframe(timeframeSets) {
    const reads = [];
    for (const { label, candles } of timeframeSets) {
      const r = this.compute(candles);
      if (!r) continue;
      let dir = 0;
      if (r.priceVsCloud === 'above' && r.tenkan > r.kijun) dir = 1;
      else if (r.priceVsCloud === 'below' && r.tenkan < r.kijun) dir = -1;
      reads.push({ label, dir, priceVsCloud: r.priceVsCloud });
    }
    const bull = reads.filter(r => r.dir === 1).length, bear = reads.filter(r => r.dir === -1).length;
    return { reads, bull, bear, total: reads.length };
  },

  toSignals(result) {
    if (!result) return [{ type: 'info', text: 'Not enough candles for Ichimoku (needs 78+ bars)' }];
    const out = [{ type: result.priceVsCloud === 'above' ? 'buy' : result.priceVsCloud === 'below' ? 'sell' : 'neut', text: `Price is ${result.priceVsCloud} the cloud (${result.cloudBottom?.toFixed(4)}–${result.cloudTop?.toFixed(4)}, ${result.cloudBullish ? 'bullish' : 'bearish'} cloud)` }];
    if (result.tkCrossUp) out.push({ type: 'buy', text: 'Tenkan crossed above Kijun (TK bullish cross)' });
    if (result.tkCrossDown) out.push({ type: 'sell', text: 'Tenkan crossed below Kijun (TK bearish cross)' });
    if (result.chikouClear) out.push({ type: result.chikouClear === 'above' ? 'buy' : 'neut', text: `Chikou span is ${result.chikouClear} price 26 bars back` });
    return out;
  },

  toFactors(result, mtf) {
    const factors = [];
    if (result) {
      let dir = 0;
      if (result.priceVsCloud === 'above' && result.tenkan > result.kijun) dir = 1;
      else if (result.priceVsCloud === 'below' && result.tenkan < result.kijun) dir = -1;
      if (dir !== 0) factors.push({ name: 'Ichimoku', direction: dir, weight: 2, detail: `price ${result.priceVsCloud} cloud, TK ${dir > 0 ? 'bullish' : 'bearish'}` });
      if (result.tkCrossUp || result.tkCrossDown) {
        factors.push({ name: 'Ichimoku TK Cross', direction: result.tkCrossUp ? 1 : -1, weight: 1, detail: result.tkCrossUp ? 'fresh bullish TK cross' : 'fresh bearish TK cross' });
      }
    }
    if (mtf && mtf.total >= 2) {
      if (mtf.bull >= Math.ceil(mtf.total * 0.66)) factors.push({ name: 'Ichimoku MTF', direction: 1, weight: 3, detail: `${mtf.bull}/${mtf.total} timeframes bullish (cloud+TK)` });
      else if (mtf.bear >= Math.ceil(mtf.total * 0.66)) factors.push({ name: 'Ichimoku MTF', direction: -1, weight: 3, detail: `${mtf.bear}/${mtf.total} timeframes bearish (cloud+TK)` });
    }
    return factors;
  },
};
