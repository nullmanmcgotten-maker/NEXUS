/**
 * ta/wyckoff.js — Wyckoff method, reduced to the pieces that have an
 * objective, checkable definition.
 *
 * Full Wyckoff phase analysis (A/B/C/D/E, "composite operator" intent) is
 * inherently a discretionary read of the chart — there is no universally
 * agreed algorithm for it, and any tool claiming to fully automate it is
 * overclaiming. What IS mechanically checkable, and is implemented here:
 *
 *  - Trading range detection — has price been contained in a horizontal
 *    band for long enough to call it a range rather than a trend leg.
 *  - Spring — price wicks below range support then closes back inside.
 *    Classic Wyckoff "test of supply" / stop-run below the range.
 *  - Upthrust after distribution (UTAD) — mirror image at range resistance.
 *  - Effort vs. Result — whether volume and the resulting price move agree
 *    (rising price on rising volume = healthy; rising price on falling
 *    volume = "effort" not matching "result", a genuine Wyckoff divergence
 *    concept with a precise, checkable definition).
 *
 * Output is explicitly labeled "heuristic" in the UI layer — this is a
 * best-effort mechanical proxy for Wyckoff concepts, not a textbook phase
 * call.
 */
'use strict';

const Wyckoff = {
  analyze(candles, rangeLookback = 40, checkBars = 5) {
    if (candles.length < rangeLookback + checkBars) return null;
    // Establish the range from the window BEFORE the most recent checkBars —
    // otherwise a spring/UTAD candle's own extreme would get baked into the
    // range boundary it's supposed to be piercing, and could never trigger.
    const n0 = candles.length;
    const window = candles.slice(n0 - rangeLookback - checkBars, n0 - checkBars);
    const highs = window.map(c => c.h), lows = window.map(c => c.l), closes = window.map(c => c.c);
    const rangeHigh = Math.max(...highs), rangeLow = Math.min(...lows);
    const mid = (rangeHigh + rangeLow) / 2;
    const width = (rangeHigh - rangeLow) / mid * 100;

    // "Is this actually a range" — most closes contained within the
    // high/low band with only occasional excursions, and the band itself
    // isn't just one giant trend leg (width sanity check is left to caller
    // via context; here we just require containment).
    const contained = closes.filter(c => c >= rangeLow && c <= rangeHigh).length / closes.length;
    const isRange = contained >= 0.75 && width < 25;

    const avgVol = window.reduce((s, c) => s + (c.v || 0), 0) / window.length;
    const n = candles.length;

    // Spring: within the last checkBars candles, a low pierced rangeLow but
    // closed back inside it.
    let spring = null;
    for (let i = n - checkBars; i < n; i++) {
      const c = candles[i];
      if (c.l < rangeLow && c.c >= rangeLow) {
        spring = { idx: i, low: c.l, closedBackAbove: c.c, highVolume: (c.v || 0) > avgVol * 1.3 };
      }
    }
    // UTAD: mirror at the top.
    let utad = null;
    for (let i = n - checkBars; i < n; i++) {
      const c = candles[i];
      if (c.h > rangeHigh && c.c <= rangeHigh) {
        utad = { idx: i, high: c.h, closedBackBelow: c.c, highVolume: (c.v || 0) > avgVol * 1.3 };
      }
    }

    // Effort vs result over the last 10 bars: correlate bar-over-bar price
    // change with bar volume. Positive correlation = effort/result agree
    // (volume rising alongside the moves that matter). Near-zero/negative on
    // a directional move = volume not confirming price — classic Wyckoff
    // "no demand" / "no supply" warning.
    const tail = candles.slice(-10);
    const priceChanges = tail.slice(1).map((c, i) => c.c - tail[i].c);
    const vols = tail.slice(1).map(c => c.v || 0);
    const effortResult = this._correlate(priceChanges.map(Math.abs), vols);
    const netMove = tail[tail.length - 1].c - tail[0].c;

    return { rangeHigh, rangeLow, width, isRange, spring, utad, effortResult, netMove, lastIdx: n - 1 };
  },

  _correlate(a, b) {
    const n = a.length;
    if (n < 3) return null;
    const ma = a.reduce((s, v) => s + v, 0) / n, mb = b.reduce((s, v) => s + v, 0) / n;
    let cov = 0, va = 0, vb = 0;
    for (let i = 0; i < n; i++) { cov += (a[i] - ma) * (b[i] - mb); va += (a[i] - ma) ** 2; vb += (b[i] - mb) ** 2; }
    if (va === 0 || vb === 0) return null;
    return cov / Math.sqrt(va * vb);
  },

  toSignals(result) {
    if (!result) return [{ type: 'info', text: 'Not enough history for a Wyckoff range read' }];
    const out = [];
    out.push({ type: 'neut', text: result.isRange ? `Trading range: ${result.rangeLow.toFixed(4)}–${result.rangeHigh.toFixed(4)} (${result.width.toFixed(1)}% wide)` : 'No clean trading range in this window — trending, not ranging' });
    if (result.spring) out.push({ type: 'buy', text: `Spring detected (low ${result.spring.low.toFixed(4)}, closed back above range)${result.spring.highVolume ? ' on elevated volume' : ''} — heuristic accumulation signal` });
    if (result.utad) out.push({ type: 'sell', text: `Upthrust after distribution (high ${result.utad.high.toFixed(4)}, closed back below range)${result.utad.highVolume ? ' on elevated volume' : ''} — heuristic distribution signal` });
    if (result.effortResult != null) {
      if (result.effortResult < 0.15 && Math.abs(result.netMove) > 0) {
        out.push({ type: 'neut', text: `Effort/result divergence: recent ${result.netMove > 0 ? 'up' : 'down'}-move not backed by rising volume (r=${result.effortResult.toFixed(2)}) — weak conviction` });
      } else if (result.effortResult >= 0.4) {
        out.push({ type: result.netMove > 0 ? 'buy' : 'sell', text: `Volume confirms the ${result.netMove > 0 ? 'up' : 'down'}-move (effort/result r=${result.effortResult.toFixed(2)})` });
      }
    }
    return out;
  },

  toFactors(result) {
    if (!result) return [];
    const factors = [];
    const recentEnough = (idx) => result.lastIdx - idx <= 3;
    if (result.spring && recentEnough(result.spring.idx)) {
      factors.push({ name: 'Wyckoff Spring', direction: 1, weight: result.spring.highVolume ? 2 : 1, detail: `spring at ${result.spring.low.toFixed(4)}, heuristic` });
    }
    if (result.utad && recentEnough(result.utad.idx)) {
      factors.push({ name: 'Wyckoff UTAD', direction: -1, weight: result.utad.highVolume ? 2 : 1, detail: `upthrust at ${result.utad.high.toFixed(4)}, heuristic` });
    }
    if (result.effortResult != null && result.effortResult >= 0.4 && Math.abs(result.netMove) > 0) {
      factors.push({ name: 'Effort/Result', direction: result.netMove > 0 ? 1 : -1, weight: 1, detail: `volume confirms move (r=${result.effortResult.toFixed(2)})` });
    }
    return factors;
  },
};
