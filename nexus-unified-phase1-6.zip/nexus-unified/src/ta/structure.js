/**
 * ta/structure.js — Smart Money Concepts / ICT-style market structure.
 *
 * Every concept here has an objective, checkable definition (no discretionary
 * "read the chart" step) so it's actually automatable:
 *
 *  - Market structure: sequence of fractal swing highs/lows classified as
 *    HH/HL (uptrend) or LH/LL (downtrend).
 *  - BOS  (Break of Structure)  — a close beyond the last swing point in the
 *    direction of the *existing* trend. Trend continuation.
 *  - CHoCH (Change of Character) — a close beyond the last swing point
 *    *against* the existing trend. First objective sign of a possible
 *    reversal — this is intentionally a weaker/earlier signal than a
 *    confirmed opposite trend, and is labelled as such downstream.
 *  - Order Block — the last opposite-coloured candle immediately before the
 *    impulsive move that produced a BOS/CHoCH. (Bullish OB = last down
 *    candle before an up-break; bearish OB = last up candle before a
 *    down-break.)
 *  - Fair Value Gap (FVG) — 3-candle imbalance where candle[i-1] and
 *    candle[i+1] don't overlap at all: candle[i] traded through a zone with
 *    one-sided (no two-way) trade, which SMC treats as a magnet for price to
 *    later "fill".
 *  - Liquidity sweep — a wick pierces a prior swing high/low (running the
 *    resting stops there) and closes back inside the prior range. Purely
 *    geometric; no claim is made about *why* it happened.
 *  - Equal highs/lows — swing points within a tight tolerance of each other,
 *    flagged as a resting-liquidity pool (a place sweeps are more likely to
 *    target, not a guarantee one will happen).
 */
'use strict';

const SMCStructure = {
  /** Core structure read: trend classification + most recent BOS/CHoCH. */
  analyze(candles, lookback = 2) {
    if (candles.length < lookback * 2 + 6) return null;
    const { peaks, troughs } = TAUtil.fractalSwings(candles, lookback);
    if (peaks.length < 2 || troughs.length < 2) return null;

    // Merge into one chronological swing sequence for HH/HL/LH/LL labeling.
    const swings = [...peaks.map(p => ({ ...p, kind: 'high' })), ...troughs.map(t => ({ ...t, kind: 'low' }))]
      .sort((a, b) => a.i - b.i);

    const labeled = [];
    let lastHigh = null, lastLow = null;
    for (const s of swings) {
      if (s.kind === 'high') {
        labeled.push({ ...s, label: lastHigh == null ? 'H' : (s.v > lastHigh.v ? 'HH' : 'LH') });
        lastHigh = s;
      } else {
        labeled.push({ ...s, label: lastLow == null ? 'L' : (s.v > lastLow.v ? 'HL' : 'LL') });
        lastLow = s;
      }
    }

    // Prevailing trend = the pattern of the last 4 labeled swings.
    const recent = labeled.slice(-4).map(s => s.label);
    let trend = 'ranging';
    if (recent.filter(l => l === 'HH' || l === 'HL').length >= 2 && !recent.includes('LL')) trend = 'uptrend';
    else if (recent.filter(l => l === 'LH' || l === 'LL').length >= 2 && !recent.includes('HH')) trend = 'downtrend';

    // Scan candles after the second-to-last swing for a structural break:
    // a CLOSE beyond the last opposite-type swing point.
    const lastPeak = peaks[peaks.length - 1], lastTrough = troughs[troughs.length - 1];
    const n = candles.length, last = n - 1;
    let breakEvent = null;
    for (let i = Math.max(lastPeak.i, lastTrough.i) + 1; i < n; i++) {
      const c = candles[i].c;
      if (c > lastPeak.v) {
        const type = trend === 'downtrend' ? 'CHoCH' : 'BOS';
        breakEvent = { i, direction: 'bullish', type, level: lastPeak.v, refIdx: lastPeak.i };
      } else if (c < lastTrough.v) {
        const type = trend === 'uptrend' ? 'CHoCH' : 'BOS';
        breakEvent = { i, direction: 'bearish', type, level: lastTrough.v, refIdx: lastTrough.i };
      }
    }

    const orderBlock = breakEvent ? this._findOrderBlock(candles, breakEvent) : null;
    const fvgs = this._findFVGs(candles).slice(-5);
    const sweeps = this._findLiquiditySweeps(candles, peaks, troughs).slice(-5);
    const equalLevels = this._findEqualLevels(peaks, troughs);

    return { trend, swings: labeled, breakEvent, orderBlock, fvgs, sweeps, equalLevels, lastIdx: last };
  },

  /** Last opposite-coloured candle before the impulse leg that produced the break. */
  _findOrderBlock(candles, breakEvent) {
    const wantBear = breakEvent.direction === 'bullish'; // bullish break -> look for down candle
    for (let i = breakEvent.i; i >= breakEvent.refIdx; i--) {
      const c = candles[i];
      const isDown = c.c < c.o, isUp = c.c > c.o;
      if (wantBear && isDown) return { idx: i, type: 'bullish', top: c.h, bottom: c.l };
      if (!wantBear && isUp) return { idx: i, type: 'bearish', top: c.h, bottom: c.l };
    }
    return null;
  },

  _findFVGs(candles) {
    const gaps = [];
    for (let i = 1; i < candles.length - 1; i++) {
      const c0 = candles[i - 1], c2 = candles[i + 1];
      if (c0.h < c2.l) gaps.push({ idx: i, type: 'bullish', top: c2.l, bottom: c0.h });
      else if (c0.l > c2.h) gaps.push({ idx: i, type: 'bearish', top: c0.l, bottom: c2.h });
    }
    return gaps;
  },

  /** Wick pierces a prior swing extreme, close snaps back inside. */
  _findLiquiditySweeps(candles, peaks, troughs) {
    const sweeps = [];
    for (const p of peaks) {
      for (let i = p.i + 1; i < candles.length; i++) {
        if (candles[i].h > p.v && candles[i].c < p.v) { sweeps.push({ idx: i, type: 'sell-side-swept', level: p.v }); break; }
        if (candles[i].c > p.v) break; // structure actually broke, not a sweep
      }
    }
    for (const t of troughs) {
      for (let i = t.i + 1; i < candles.length; i++) {
        if (candles[i].l < t.v && candles[i].c > t.v) { sweeps.push({ idx: i, type: 'buy-side-swept', level: t.v }); break; }
        if (candles[i].c < t.v) break;
      }
    }
    return sweeps.sort((a, b) => a.idx - b.idx);
  },

  /** Swing highs/lows within 0.1% of each other — resting liquidity pools. */
  _findEqualLevels(peaks, troughs, tolPct = 0.1) {
    const cluster = (arr, kind) => {
      const out = [];
      for (let i = 0; i < arr.length; i++) {
        for (let j = i + 1; j < arr.length; j++) {
          if (Math.abs(arr[i].v - arr[j].v) / arr[i].v * 100 <= tolPct) {
            out.push({ kind, level: (arr[i].v + arr[j].v) / 2, idxs: [arr[i].i, arr[j].i] });
          }
        }
      }
      return out;
    };
    return [...cluster(peaks, 'equal-highs'), ...cluster(troughs, 'equal-lows')].slice(-6);
  },

  /** Plain-language signal list, same {type, text} shape as TA.generateSignals. */
  toSignals(result) {
    if (!result) return [{ type: 'info', text: 'Not enough swing history for structure analysis' }];
    const out = [{ type: 'neut', text: `Structure: ${result.trend}` }];
    if (result.breakEvent) {
      const b = result.breakEvent;
      const t = b.direction === 'bullish' ? 'buy' : 'sell';
      out.push({ type: t, text: `${b.type} ${b.direction} — closed through ${b.level.toFixed(4)}` });
    }
    if (result.orderBlock) {
      const ob = result.orderBlock;
      out.push({ type: ob.type === 'bullish' ? 'buy' : 'sell', text: `${ob.type} order block: ${ob.bottom.toFixed(4)}–${ob.top.toFixed(4)}` });
    }
    if (result.sweeps.length) {
      const s = result.sweeps[result.sweeps.length - 1];
      out.push({ type: s.type === 'buy-side-swept' ? 'buy' : 'sell', text: `Liquidity sweep: ${s.type.replace('-', ' ')} at ${s.level.toFixed(4)}` });
    }
    if (result.fvgs.length) {
      const f = result.fvgs[result.fvgs.length - 1];
      out.push({ type: 'neut', text: `Open FVG (${f.type}): ${f.bottom.toFixed(4)}–${f.top.toFixed(4)}` });
    }
    return out;
  },

  /** {name,direction,weight,detail} factor(s) for the composite scorer. */
  toFactors(result) {
    if (!result || !result.breakEvent) return [];
    const factors = [];
    const b = result.breakEvent;
    const dir = b.direction === 'bullish' ? 1 : -1;
    // CHoCH is an earlier/weaker signal (against prevailing trend) than a
    // trend-confirming BOS, so it gets less weight.
    factors.push({ name: 'SMC Structure', direction: dir, weight: b.type === 'BOS' ? 2 : 1, detail: `${b.type} ${b.direction} at ${b.level.toFixed(4)}` });
    if (result.sweeps.length) {
      const s = result.sweeps[result.sweeps.length - 1];
      if (result.lastIdx - s.idx <= 3) { // only count a *recent* sweep
        factors.push({ name: 'Liquidity Sweep', direction: s.type === 'buy-side-swept' ? 1 : -1, weight: 1, detail: `${s.type.replace('-', ' ')} at ${s.level.toFixed(4)}` });
      }
    }
    return factors;
  },
};
