/**
 * ta/harmonics.js — XABCD harmonic pattern scanner: Gartley, Bat, Butterfly,
 * Crab. Uses the same zigzag pivots as fibWave.js, checked against each
 * pattern's published Fibonacci ratio ranges with a tolerance band. A match
 * only fires when every leg (AB, BC, CD, and the overall XA→D ratio) is
 * simultaneously within tolerance — a single ratio lining up by chance is
 * common, all four together much less so.
 */
'use strict';

const Harmonics = {
  // Each ratio is a [min,max] range on the *retracement/extension of the
  // previous leg*, as published by the original pattern definitions
  // (Gartley 1935 / Scott Carney's Bat & Crab / Butterfly).
  PATTERNS: {
    Gartley:   { ab: [0.586, 0.650], bc: [0.382, 0.886], cd: [1.13, 1.618], ad: [0.75, 0.82] },
    Bat:       { ab: [0.382, 0.50],  bc: [0.382, 0.886], cd: [1.618, 2.618], ad: [0.846, 0.926] },
    Butterfly: { ab: [0.75, 0.82],   bc: [0.382, 0.886], cd: [1.618, 2.618], ad: [1.27, 1.618] },
    Crab:      { ab: [0.382, 0.618], bc: [0.382, 0.886], cd: [2.24, 3.618],  ad: [1.55, 1.68] },
  },

  scan(candles, pct = 3) {
    // Keep the trailing unconfirmed pivot — point D of an in-progress
    // pattern is exactly the current, still-forming swing extreme.
    const pivots = TAUtil.zigzag(candles, pct);
    if (pivots.length < 5) return [];
    const matches = [];
    // Slide a 5-pivot window (X,A,B,C,D) across all recent pivots, not just
    // the very last five, so an already-in-progress pattern from a few
    // swings back isn't missed.
    for (let end = pivots.length - 1; end >= 4; end--) {
      const [X, A, B, C, D] = pivots.slice(end - 4, end + 1);
      const xa = Math.abs(A.v - X.v), ab = Math.abs(B.v - A.v), bc = Math.abs(C.v - B.v), cd = Math.abs(D.v - C.v);
      // "AD ratio" in harmonic-pattern convention is D's retracement of the
      // XA leg measured FROM A (e.g. Gartley's "0.786" means D sits 78.6%
      // of the way back from A toward X) — i.e. |A-D|/|A-X|, not |X-D|/|A-X|.
      const ad = Math.abs(D.v - A.v);
      if (!xa || !ab || !bc) continue;
      const abRatio = ab / xa, bcRatio = bc / ab, cdRatio = cd / bc, adRatio = ad / xa;
      const bullish = D.v < X.v; // D is the completion/reversal point; lower than X = bullish reversal setup

      for (const [name, r] of Object.entries(this.PATTERNS)) {
        const inRange = (v, [lo, hi]) => v >= lo * 0.92 && v <= hi * 1.08; // 8% tolerance band
        if (inRange(abRatio, r.ab) && inRange(bcRatio, r.bc) && inRange(cdRatio, r.cd) && inRange(adRatio, r.ad)) {
          matches.push({ pattern: name, bullish, X, A, B, C, D, abRatio, bcRatio, cdRatio, adRatio, dIdx: D.i });
          break; // one label per pivot window — don't double-count overlapping ratio ranges
        }
      }
      if (matches.length >= 3) break; // enough recent candidates
    }
    return matches;
  },

  toSignals(matches) {
    if (!matches || !matches.length) return [{ type: 'info', text: 'No completed harmonic (Gartley/Bat/Butterfly/Crab) pattern in recent swings' }];
    return matches.map(m => ({
      type: m.bullish ? 'buy' : 'sell',
      text: `${m.pattern} pattern (${m.bullish ? 'bullish' : 'bearish'}) completing near D=${m.D.v.toFixed(4)} — AB=${(m.abRatio*100).toFixed(0)}% CD=${(m.cdRatio*100).toFixed(0)}%`,
    }));
  },

  toFactors(matches, lastIdx) {
    if (!matches || !matches.length) return [];
    const recent = matches.filter(m => lastIdx - m.dIdx <= 5);
    if (!recent.length) return [];
    const m = recent[0]; // most recent completion
    return [{ name: 'Harmonic Pattern', direction: m.bullish ? 1 : -1, weight: 2, detail: `${m.pattern} completed at D=${m.D.v.toFixed(4)}` }];
  },
};
