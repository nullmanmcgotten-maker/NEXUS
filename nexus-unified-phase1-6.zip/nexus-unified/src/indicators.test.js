'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const TA = require('./indicators');

function buildCandles({ compressBars = 40, expandBars = 15, compressRange = 0.15, expandStep = 1.2 }) {
  const candles = [];
  let p = 100;
  for (let i = 0; i < compressBars; i++) {
    const noise = (i % 2 === 0 ? 1 : -1) * (compressRange / 2); // deterministic, no RNG in a regression test
    p += noise * 0.1;
    candles.push({ t: i, o: p, h: p + compressRange / 2, l: p - compressRange / 2, c: p, v: 1000 });
  }
  for (let i = 0; i < expandBars; i++) {
    p += expandStep;
    candles.push({ t: compressBars + i, o: p - expandStep, h: p + 0.3, l: p - expandStep - 0.1, c: p, v: 1500 });
  }
  return candles;
}

test('TA.squeeze: reports on=true during a tight-range compression phase', () => {
  const candles = buildCandles({});
  const sq = TA.squeeze(candles);
  // somewhere well into the compression phase (bar 30), before expansion starts, squeeze should be on
  assert.equal(sq.on[30], true);
});

test('TA.squeeze: fires exactly once, at the transition from compressed to expanding', () => {
  const candles = buildCandles({});
  const sq = TA.squeeze(candles);
  const firedAt = sq.fired.map((f, i) => (f ? i : null)).filter((x) => x !== null);
  assert.equal(firedAt.length, 1);
  // Should fire at or shortly after the compression phase ends (bar 40), not deep into compression or deep into expansion.
  assert.ok(firedAt[0] >= 38 && firedAt[0] <= 43, `expected fire near bar 40, got ${firedAt[0]}`);
});

test('TA.squeeze: momentum turns positive as an upward expansion builds', () => {
  const candles = buildCandles({});
  const sq = TA.squeeze(candles);
  const last = sq.momentum[sq.momentum.length - 1];
  assert.ok(last > 0, `expected positive momentum after a sustained up-move, got ${last}`);
});

test('generateSignals: emits a neutral "Squeeze ON" line while still compressed', () => {
  const candles = buildCandles({}).slice(0, 36); // mid-compression, before the expansion phase
  const closes = candles.map((c) => c.c);
  const sigs = TA.generateSignals(closes, candles);
  const line = sigs.find((s) => s.text.includes('Squeeze ON'));
  assert.ok(line, 'expected a Squeeze ON line');
  assert.equal(line.type, 'neut');
});

test('generateSignals: emits a directional "Squeeze FIRED" line exactly on the release bar', () => {
  const candles = buildCandles({}).slice(0, 41); // the bar the fired test above found
  const closes = candles.map((c) => c.c);
  const sigs = TA.generateSignals(closes, candles);
  const line = sigs.find((s) => s.text.includes('Squeeze FIRED'));
  assert.ok(line, 'expected a Squeeze FIRED line at the release bar');
  assert.equal(line.type, 'buy'); // this fixture expands upward
});
