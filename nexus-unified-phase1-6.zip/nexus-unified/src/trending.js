/**
 * trending.js — Binance crypto top gainers/losers + Yahoo stock movers.
 * One-click add to watchlist.
 */
async function fetchTrending() {
  const el = document.getElementById('trendingPanel');
  if (!el) return;
  el.innerHTML = '<div style="font-family:var(--mono);color:var(--muted);padding:16px;font-size:12px;">Loading trending…</div>';

  let cryptoGainers=[], cryptoLosers=[], stockGainers=[], stockLosers=[];

  try {
    const res  = await fetch('https://api.binance.com/api/v3/ticker/24hr',{signal:AbortSignal.timeout(8000)});
    const data = await res.json();
    const usdt = data.filter(t=>t.symbol.endsWith('USDT')&&parseFloat(t.quoteVolume)>1e6);
    usdt.sort((a,b)=>parseFloat(b.priceChangePercent)-parseFloat(a.priceChangePercent));
    const toItem = t=>({sym:t.symbol.replace('USDT',''),chg:parseFloat(t.priceChangePercent),price:parseFloat(t.lastPrice),type:'crypto'});
    cryptoGainers = usdt.slice(0,5).map(toItem);
    cryptoLosers  = usdt.slice(-5).reverse().map(toItem);
  } catch(e){ console.warn('[Trending Crypto]',e.message); }

  try {
    const url  = 'https://query1.finance.yahoo.com/v1/finance/screener/predefined/saved?formatted=false&scrIds=day_gainers,day_losers&count=10';
    const res  = await fetch(url,{signal:AbortSignal.timeout(8000)});
    const data = await res.json();
    const qs   = data?.finance?.result?.[0]?.quotes||[];
    const toItem = q=>({sym:q.symbol,chg:q.regularMarketChangePercent||0,price:q.regularMarketPrice||0,name:q.shortName||q.symbol,type:'stock'});
    stockGainers = qs.filter(q=>(q.regularMarketChangePercent||0)>0).slice(0,5).map(toItem);
    stockLosers  = qs.filter(q=>(q.regularMarketChangePercent||0)<0).slice(0,5).map(toItem);
  } catch(e){ console.warn('[Trending Stocks]',e.message); }

  const row = (item) => {
    const isUp = item.chg>=0;
    const ps   = item.price<10?item.price.toFixed(4):fmtNum(item.price,2);
    return `<div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);">
      <div style="display:flex;align-items:center;gap:8px;">
        <div class="a-icon" style="background:${iconBg(item.type)};color:${iconColor(item.type)};width:28px;height:28px;font-size:8px;">${item.sym.slice(0,3)}</div>
        <div>
          <div style="font-family:var(--mono);font-size:13px;font-weight:700;">${item.sym}</div>
          ${item.name&&item.name!==item.sym?`<div style="font-family:var(--mono);font-size:9px;color:var(--muted);">${item.name.slice(0,22)}</div>`:''}
        </div>
      </div>
      <div style="text-align:right;margin-right:10px;">
        <div style="font-family:var(--mono);font-size:13px;font-weight:700;color:${isUp?'var(--green)':'var(--red)'};">${isUp?'+':''}${item.chg.toFixed(2)}%</div>
        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);">$${ps}</div>
      </div>
      <button class="btn-sm" onclick="
        watchlist.push({sym:'${item.sym}',name:'${(item.name||item.sym).replace(/'/g,'')}',type:'${item.type}',price:${item.price},chg:${item.chg},notes:''});
        renderWatchlist();this.textContent='✓ Added';this.disabled=true;">+ Watch</button>
    </div>`;
  };

  const col = (title, color, items, empty) => `
    <div>
      <div style="font-family:var(--mono);font-size:10px;color:${color};letter-spacing:.12em;text-transform:uppercase;margin-bottom:10px;">${title}</div>
      ${items.length ? items.map(row).join('') : `<div style="font-family:var(--mono);font-size:12px;color:var(--muted);padding:8px;">${empty}</div>`}
    </div>`;

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
      ${col('🚀 Crypto Gainers','var(--green)',cryptoGainers,'No crypto data')}
      ${col('📉 Crypto Losers','var(--red)',cryptoLosers,'No crypto data')}
      ${col('📈 Stock Gainers','var(--green)',stockGainers,'No stock data')}
      ${col('🔻 Stock Losers','var(--red)',stockLosers,'No stock data')}
    </div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:14px;text-align:right;">
      Binance (crypto) · Yahoo Finance (stocks) · Vol >$1M · refreshes every 5 min
    </div>`;
}

function startTrendingPolling(){ fetchTrending(); setInterval(fetchTrending,300000); }
