/**
 * realtime.js — ALL data fetched client-side (browser).
 * The browser has no CORS restrictions on these public APIs.
 *
 * Crypto prices/history  → Binance REST + WebSocket (no key, no CORS issue)
 * Forex rates            → open.er-api.com (CORS-open, free)
 * Forex OHLC             → Frankfurter ECB API (CORS-open, free)
 * Stock prices/OHLC      → Yahoo Finance (via cors-anywhere or direct — see note)
 * Global markets         → Yahoo Finance v8 spark (CORS-open endpoint)
 * Heatmap bulk           → Binance (crypto) + CoinGecko simple price (stocks via FMP demo)
 * News                   → RSS via rss2json.com (CORS-open, 1000/day free)
 *
 * NOTE on Yahoo: yahoo's v7/v8 endpoints work from browsers directly (no CORS header needed
 * because they return * on OPTIONS). They block server-side curl but allow browser fetch.
 */

// ── HELPERS ───────────────────────────────────────────────────────────────────
const YAHOO_BASE  = 'https://query1.finance.yahoo.com';
const BINANCE_BASE= 'https://api.binance.com/api/v3';
const ER_BASE     = 'https://open.er-api.com/v6';
const FRANK_BASE  = 'https://api.frankfurter.app';
const CG_BASE     = 'https://api.coingecko.com/api/v3';

async function apiFetch(url, timeout=10000) {
  const source = typeof sourceFromUrl === 'function' ? sourceFromUrl(url) : 'unknown';
  const doFetch = async () => {
    const ctrl = new AbortController();
    const t    = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(url, {
        signal: ctrl.signal,
        headers: { 'Accept': 'application/json' },
      });
      clearTimeout(t);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch(e) {
      clearTimeout(t);
      throw e;
    }
  };
  // withRetry (dataHealth.js) retries transient failures with backoff and
  // records success/error timestamps per hostname. Falls back to a plain
  // single attempt if dataHealth.js isn't loaded for some reason.
  if (typeof withRetry === 'function') {
    return withRetry(doFetch, { retries: 2, baseDelayMs: 400, source });
  }
  return doFetch();
}

// ── STOCK PRICE POLLING (Yahoo Finance) ────────────────────────────────────────
async function pollStockPrices() {
  const stocks = [...positions, ...watchlist].filter(p => p.type === 'stock');
  if (!stocks.length) return;

  const syms = [...new Set(stocks.map(p => p.sym))].join(',');
  try {
    // Yahoo v7 quote — works from browser (CORS allowed)
    const data = await apiFetch(
      `${YAHOO_BASE}/v7/finance/quote?symbols=${syms}&fields=regularMarketPrice,regularMarketChangePercent`
    );
    const results = data?.quoteResponse?.result || [];
    results.forEach(q => {
      const price = safeNum(q.regularMarketPrice);
      const chg   = safeNum(q.regularMarketChangePercent);
      if (!price) return;
      [...positions, ...watchlist]
        .filter(x => x.sym === q.symbol && x.type === 'stock')
        .forEach(x => {
          if (!window._priceHistory[x.sym]) window._priceHistory[x.sym] = [];
          window._priceHistory[x.sym].push({ t: Date.now(), p: price });
          if (window._priceHistory[x.sym].length > 500) window._priceHistory[x.sym].shift();
          x.price = price;
          x.chg   = parseFloat(chg.toFixed(2));
        });
    });
    if (results.length) { updateAll(); console.log(`[Stocks] Yahoo: ${results.length} prices`); }
  } catch(e) {
    console.warn('[Stocks] Yahoo failed:', e.message);
    // Try CoinGecko for any crypto-stocks crossover — skip for true stocks
    setStockStatus('⚠ Yahoo offline');
  }
}

function setStockStatus(msg) {
  const el = document.getElementById('stockStatus');
  if (el) el.textContent = msg;
}

function startStockPolling() {
  pollStockPrices();
  setInterval(pollStockPrices, 15000);
}

// Shared last-error tracker for OHLC fetchers — the UI needs the REAL
// reason a chart failed (network error / CORS / rate limit / bad symbol),
// not just "it returned null". Console.warn alone isn't enough; most users
// never open devtools, and a wrong guess here (e.g. blaming "run node
// server.js" when the real issue was a rate limit) sends them down the
// wrong troubleshooting path.
window._lastOHLCError = {};

// ── YAHOO OHLC FOR STOCK CHARTS ────────────────────────────────────────────────
async function fetchYahooOHLC(sym, interval='1h') {
  const rangeMap = { '1h':'5d', '4h':'1mo', '1d':'6mo' };
  const intMap   = { '1h':'1h', '4h':'1h',  '1d':'1d'  };
  const range    = rangeMap[interval] || '5d';
  const yint     = intMap[interval]   || '1h';

  try {
    const data = await apiFetch(
      `${YAHOO_BASE}/v8/finance/chart/${sym}?interval=${yint}&range=${range}`
    );
    const result = data?.chart?.result?.[0];
    if (!result) {
      const apiErr = data?.chart?.error?.description || 'Yahoo returned no data for this symbol — check it\'s a valid ticker';
      throw new Error(apiErr);
    }
    const ts = result.timestamp || [];
    const q  = result.indicators?.quote?.[0] || {};
    const candles = ts.map((t,i) => ({
      t: t * 1000,
      o: safeNum(q.open?.[i]),
      h: safeNum(q.high?.[i]),
      l: safeNum(q.low?.[i]),
      c: safeNum(q.close?.[i]),
      v: safeNum(q.volume?.[i]),
    })).filter(c => c.c > 0);
    if (candles.length < 5) throw new Error(`Only ${candles.length} usable candles returned — likely a low-liquidity or delisted symbol`);
    console.log(`[YahooOHLC] ${sym}: ${candles.length} candles`);
    window._lastOHLCError[sym] = null;
    return candles;
  } catch(e) {
    console.warn(`[YahooOHLC] ${sym}:`, e.message);
    window._lastOHLCError[sym] = e.message;
    return null;
  }
}


// Alias used by assetChart.js
async function fetchStockOHLC(sym, interval) {
  return fetchYahooOHLC(sym, interval);
}
// ── BINANCE KLINES FOR CRYPTO CHARTS ──────────────────────────────────────────
async function fetchBinanceKlines(sym, interval='1h', limit=150) {
  try {
    const rows = await apiFetch(
      `${BINANCE_BASE}/klines?symbol=${sym}USDT&interval=${interval}&limit=${limit}`
    );
    if (!Array.isArray(rows) || !rows.length) throw new Error(`Binance returned no data for ${sym}USDT — check the symbol exists on Binance`);
    window._lastOHLCError[sym] = null;
    return rows.map(d => ({ t:+d[0], o:+d[1], h:+d[2], l:+d[3], c:+d[4], v:+d[5] }));
  } catch(e) {
    console.warn(`[BinanceKlines] ${sym}:`, e.message);
    // Fall back to Bybit's spot klines — a different company, different
    // domain, different infra. If Binance specifically is blocked (regional
    // restriction, ad-blocker rule, rate limit) this gets around it rather
    // than just failing the chart outright.
    try {
      const bybitInterval = { '1h':'60','4h':'240','1d':'D' }[interval] || '60';
      const data = await apiFetch(`https://api.bybit.com/v5/market/kline?category=spot&symbol=${sym}USDT&interval=${bybitInterval}&limit=${limit}`);
      const rows = data?.result?.list;
      if (!Array.isArray(rows) || !rows.length) throw new Error('Bybit fallback also returned no data');
      // Bybit returns [startTime, open, high, low, close, volume, turnover], newest-first
      const candles = rows.map(r => ({ t:+r[0], o:+r[1], h:+r[2], l:+r[3], c:+r[4], v:+r[5] })).reverse();
      console.log(`[BinanceKlines] ${sym}: Binance failed, Bybit fallback succeeded (${candles.length} candles)`);
      window._lastOHLCError[sym] = null;
      return candles;
    } catch(e2) {
      const msg = `Binance: ${e.message} · Bybit fallback also failed: ${e2.message}`;
      console.warn(`[BinanceKlines] ${sym}: both sources failed —`, msg);
      window._lastOHLCError[sym] = msg;
      return null;
    }
  }
}

// ── FOREX RATES (open.er-api.com) ─────────────────────────────────────────────
async function fetchLiveForex() {
  try {
    const data = await apiFetch(`${ER_BASE}/latest/USD`);
    if (data.result !== 'success') throw new Error('API error');

    Object.keys(fxRates).forEach(cur => {
      if (data.rates[cur] !== undefined) fxRates[cur] = data.rates[cur];
    });

    positions.filter(p => p.type === 'forex').forEach(p => {
      const [base, quote] = p.sym.split('/');
      const np = (fxRates[quote]||1) / (fxRates[base]||1);
      if (np && isFinite(np)) {
        const old = p.price;
        p.price = parseFloat(np.toFixed(5));
        p.chg   = old ? parseFloat(((p.price-old)/old*100).toFixed(3)) : 0;
        if (!window._priceHistory[p.sym]) window._priceHistory[p.sym] = [];
        window._priceHistory[p.sym].push({ t: Date.now(), p: p.price });
        if (window._priceHistory[p.sym].length > 500) window._priceHistory[p.sym].shift();
      }
    });
    watchlist.filter(w => w.type === 'forex').forEach(w => {
      const [base, quote] = w.sym.split('/');
      const np = (fxRates[quote]||1) / (fxRates[base]||1);
      if (np && isFinite(np)) w.price = parseFloat(np.toFixed(5));
    });

    updateAll();
    if (typeof updateConversion === 'function') updateConversion();

    const el = document.getElementById('forexStatus');
    if (el) { el.textContent = '✓ FX LIVE'; el.style.color = 'var(--green)'; }
    console.log('[Forex] open.er-api: rates updated');
  } catch(e) {
    const el = document.getElementById('forexStatus');
    if (el) { el.textContent = '⚠ FX offline'; el.style.color = 'var(--amber)'; }
    console.warn('[Forex]', e.message);
  }
}

// ── FOREX OHLC (Frankfurter ECB) ──────────────────────────────────────────────
async function fetchForexOHLC(sym, days=60) {
  const [base, quote] = sym.split('/');
  if (!base || !quote) { window._lastOHLCError[sym] = 'Invalid pair format — expected e.g. "EUR/USD"'; return null; }

  const end   = new Date().toISOString().split('T')[0];
  const start = new Date(Date.now() - days*86400000).toISOString().split('T')[0];

  try {
    const data = await apiFetch(
      `${FRANK_BASE}/${start}..${end}?from=${base}&to=${quote}`
    );
    if (!data.rates) throw new Error(data?.message || 'Frankfurter API returned no rates for this pair');

    const entries = Object.entries(data.rates).sort((a,b) => a[0].localeCompare(b[0]));
    if (entries.length < 5) throw new Error(`Only ${entries.length} days of data available — try a more common pair`);

    const candles = entries.map(([dateStr, rateObj], i) => {
      const close = safeNum(rateObj[quote] || Object.values(rateObj)[0]);
      const prev  = i > 0
        ? safeNum(entries[i-1][1][quote] || Object.values(entries[i-1][1])[0])
        : close;
      const range = Math.abs(close - prev) || close * 0.001;
      return {
        t: new Date(dateStr).getTime(),
        o: prev,
        c: close,
        h: Math.max(prev, close) + range * 0.3,
        l: Math.min(prev, close) - range * 0.3,
        v: 0,
      };
    });
    console.log(`[ForexOHLC] ${sym}: ${candles.length} ECB daily candles`);
    window._lastOHLCError[sym] = null;
    return candles;
  } catch(e) {
    console.warn(`[ForexOHLC] ${sym}:`, e.message);
    window._lastOHLCError[sym] = e.message;
    return null;
  }
}

// Global markets — see globalMarkets.js


// ── HEATMAP BULK PRICES ────────────────────────────────────────────────────────
const _heatCache   = {};
let   _heatFetching= false;

async function fetchHeatmapData() {
  if (_heatFetching) return;
  _heatFetching = true;

  try {
    // Crypto bulk — Binance 24h ticker (single fast call)
    const cryptoSyms = ['BTC','ETH','SOL','DOGE','XRP','BNB','ADA','AVAX','DOT','MATIC','LTC','LINK'];
    const binSyms    = JSON.stringify(cryptoSyms.map(s => s+'USDT'));
    try {
      const tickers = await apiFetch(
        `${BINANCE_BASE}/ticker/24hr?symbols=${encodeURIComponent(binSyms)}`
      );
      tickers.forEach(t => {
        const sym = t.symbol.replace('USDT','');
        _heatCache[sym] = { chg: parseFloat(safeNum(t.priceChangePercent).toFixed(2)), price: safeNum(t.lastPrice) };
      });
      console.log(`[Heatmap] Binance: ${tickers.length} crypto tickers`);
    } catch(e) { console.warn('[Heatmap Crypto]', e.message); }

    // Stocks bulk — Yahoo Finance
    const stockSyms = 'AAPL,MSFT,NVDA,AMZN,GOOGL,META,TSLA,AMD,INTC,CRM,ORCL,ADBE,JPM,BAC,GS,MS,WFC,V,MA,XOM,CVX,COP,JNJ,UNH,PFE';
    try {
      const data = await apiFetch(
        `${YAHOO_BASE}/v7/finance/quote?symbols=${stockSyms}&fields=regularMarketChangePercent,regularMarketPrice`
      );
      (data?.quoteResponse?.result || []).forEach(q => {
        _heatCache[q.symbol] = {
          chg:   parseFloat(safeNum(q.regularMarketChangePercent).toFixed(2)),
          price: safeNum(q.regularMarketPrice),
        };
      });
      console.log('[Heatmap] Yahoo: stock prices');
    } catch(e) { console.warn('[Heatmap Stocks]', e.message); }

    // Forex — from live fxRates (already updated by fetchLiveForex)
    ['EUR/USD','GBP/USD','USD/JPY','USD/CHF','AUD/USD','USD/CAD','NZD/USD','USD/CNY'].forEach(pair => {
      const pos = positions.find(p => p.sym === pair);
      if (pos) _heatCache[pair] = { chg: safeNum(pos.chg), price: safeNum(pos.price) };
    });

  } finally { _heatFetching = false; }
}

function getHeatChgReal(sym) {
  const p = positions.find(x => x.sym === sym);
  if (p && safeNum(p.chg) !== 0) return safeNum(p.chg);
  const w = watchlist.find(x => x.sym === sym);
  if (w && safeNum(w.chg) !== 0) return safeNum(w.chg);
  if (_heatCache[sym]) return _heatCache[sym].chg;
  return 0;
}

function startHeatmapPolling() {
  fetchHeatmapData();
  setInterval(fetchHeatmapData, 30000);
}

// ── PORTFOLIO HISTORY SNAPSHOTS ───────────────────────────────────────────────
const _portfolioHistory = [];
(function() {
  try {
    const s = localStorage.getItem('nexus_port_history');
    if (s) _portfolioHistory.push(...JSON.parse(s));
  } catch(e) {}
})();

function snapshotPortfolio() {
  const v = totalPortfolioValue();
  if (v > 0) {
    _portfolioHistory.push({ t: Date.now(), v });
    if (_portfolioHistory.length > 1440) _portfolioHistory.shift();
    try { localStorage.setItem('nexus_port_history', JSON.stringify(_portfolioHistory.slice(-1440))); } catch(e) {}
  }
}

function startPortfolioHistory() {
  snapshotPortfolio();
  setInterval(snapshotPortfolio, 60000);
}

function getPortfolioCandles() {
  return _portfolioHistory.length >= 2 ? _portfolioHistory : null;
}

function startForexPolling() {
  fetchLiveForex();
  setInterval(fetchLiveForex, 60000);
}
