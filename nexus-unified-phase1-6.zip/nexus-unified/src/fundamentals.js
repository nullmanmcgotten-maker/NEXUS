/**
 * fundamentals.js — Stock fundamentals from Yahoo Finance (free, no key)
 * P/E, EPS, market cap, 52W range, analyst targets, earnings date, dividends.
 */
const _fundCache={};
async function fetchFundamentals(sym){
  if(_fundCache[sym]&&Date.now()-_fundCache[sym].ts<300000)return _fundCache[sym].data;
  try{
    const url=`https://query1.finance.yahoo.com/v10/finance/quoteSummary/${sym}?modules=summaryDetail,defaultKeyStatistics,financialData,recommendationTrend,calendarEvents`;
    const res=await fetch(url,{signal:AbortSignal.timeout(10000)});
    if(!res.ok)throw new Error('HTTP '+res.status);
    const json=await res.json();
    const r=json?.quoteSummary?.result?.[0];
    if(!r)throw new Error('No data');
    const d={
      pe:r.summaryDetail?.trailingPE?.raw,
      fwdPe:r.summaryDetail?.forwardPE?.raw,
      eps:r.defaultKeyStatistics?.trailingEps?.raw,
      mktCap:r.summaryDetail?.marketCap?.raw,
      div:r.summaryDetail?.dividendYield?.raw,
      w52h:r.summaryDetail?.fiftyTwoWeekHigh?.raw,
      w52l:r.summaryDetail?.fiftyTwoWeekLow?.raw,
      beta:r.summaryDetail?.beta?.raw,
      target:r.financialData?.targetMeanPrice?.raw,
      recKey:r.financialData?.recommendationKey,
      earningsDate:r.calendarEvents?.earnings?.earningsDate?.[0]?.raw,
      revenueGrowth:r.financialData?.revenueGrowth?.raw,
      grossMargins:r.financialData?.grossMargins?.raw,
    };
    _fundCache[sym]={data:d,ts:Date.now()};
    return d;
  }catch(e){console.warn('[Fundamentals]',sym,e.message);return null;}
}

async function renderFundamentals(sym){
  const el=document.getElementById('fundamentalsPanel');if(!el)return;
  el.innerHTML='<div style="font-family:var(--mono);font-size:12px;color:var(--muted);padding:16px;">Loading fundamentals…</div>';
  const d=await fetchFundamentals(sym);
  if(!d){el.innerHTML=`<div style="color:var(--muted);font-family:var(--mono);font-size:12px;padding:16px;">⚠ No fundamental data for ${sym}. Only available for stocks (not crypto/forex).</div>`;return;}
  const pos=positions.find(p=>p.sym===sym);
  const price=pos?safeNum(pos.price):0;
  const upside=d.target&&price?(((d.target-price)/price)*100).toFixed(1):null;
  const recColor={buy:'var(--green)',strongbuy:'var(--green)',hold:'var(--amber)',sell:'var(--red)',strongsell:'var(--red)'}[d.recKey]||'var(--muted)';
  const mktCapStr=d.mktCap?d.mktCap>=1e12?'$'+(d.mktCap/1e12).toFixed(2)+'T':d.mktCap>=1e9?'$'+(d.mktCap/1e9).toFixed(1)+'B':'$'+(d.mktCap/1e6).toFixed(0)+'M':'—';
  el.innerHTML=`
    <div style="font-family:var(--mono);font-size:13px;font-weight:700;color:var(--text);margin-bottom:14px;">${sym} — Fundamentals</div>
    <div class="fund-grid">
      <div class="fund-card"><div class="fund-l">P/E Ratio</div><div class="fund-v">${d.pe?d.pe.toFixed(1):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Fwd P/E</div><div class="fund-v">${d.fwdPe?d.fwdPe.toFixed(1):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">EPS</div><div class="fund-v">${d.eps?'$'+d.eps.toFixed(2):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Market Cap</div><div class="fund-v">${mktCapStr}</div></div>
      <div class="fund-card"><div class="fund-l">52W High</div><div class="fund-v">${d.w52h?'$'+fmtNum(d.w52h,2):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">52W Low</div><div class="fund-v">${d.w52l?'$'+fmtNum(d.w52l,2):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Beta</div><div class="fund-v">${d.beta?d.beta.toFixed(2):'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Dividend Yield</div><div class="fund-v">${d.div?(d.div*100).toFixed(2)+'%':'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Analyst Target</div><div class="fund-v ${upside&&parseFloat(upside)>0?'up':'dn'}">${d.target?'$'+fmtNum(d.target,2):'—'}${upside?' ('+upside+'%)':''}</div></div>
      <div class="fund-card"><div class="fund-l">Recommendation</div><div class="fund-v" style="color:${recColor};text-transform:uppercase;">${d.recKey||'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Revenue Growth</div><div class="fund-v ${d.revenueGrowth>=0?'up':'dn'}">${d.revenueGrowth?(d.revenueGrowth*100).toFixed(1)+'%':'—'}</div></div>
      <div class="fund-card"><div class="fund-l">Gross Margin</div><div class="fund-v">${d.grossMargins?(d.grossMargins*100).toFixed(1)+'%':'—'}</div></div>
    </div>
    ${d.earningsDate?`<div style="margin-top:12px;padding:10px;background:rgba(245,166,35,.08);border:1px solid rgba(245,166,35,.2);border-radius:6px;font-family:var(--mono);font-size:12px;color:var(--amber);">📅 Next Earnings: ${new Date(d.earningsDate*1000).toLocaleDateString('en',{weekday:'short',month:'short',day:'numeric',year:'numeric'})}</div>`:''}
    <div style="font-family:var(--mono);font-size:10px;color:var(--muted);margin-top:10px;">Source: Yahoo Finance · Stocks only · Updates every 5 min</div>`;
}
