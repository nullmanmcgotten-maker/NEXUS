/**
 * advancedTAPanel.js — UI for the "Advanced TA" tab. Deliberately per-symbol,
 * on-demand (not a mass scanner like Signal Scanner/Patterns): the deep tier
 * pulls real Binance aggTrades plus 3 timeframes of candles per run, and
 * doing that for every watchlist symbol on a timer would be exactly the
 * kind of rate-limit-multiplying behavior ROADMAP.md already flags as a
 * known risk area. One symbol, on request, is the honest way to offer this.
 *
 * The cheap/sync half of the same suite (structure, Wyckoff, Ichimoku
 * single-TF, Fibonacci/Elliott, harmonics) already runs automatically for
 * every scanned perp as part of computeCompositeSignal — this panel is for
 * going deep on one name, with order flow and full multi-timeframe context.
 */
'use strict';

let _advTALoading = false;

async function runAdvancedTA(symRaw) {
  const el = document.getElementById('advancedTAResults');
  if (!el) return;
  const sym = (symRaw || '').trim().toUpperCase().replace(/USDT$/, '');
  if (!sym) { el.innerHTML = `<div class="adv-ta-empty">Enter a symbol above, e.g. BTC, ETH, SOL.</div>`; return; }
  if (_advTALoading) return;
  _advTALoading = true;
  el.innerHTML = `<div class="adv-ta-empty">Loading ${esc(sym)} — fetching candles across 1h/4h/1d and live order flow…</div>`;

  try {
    const fetchSym = `${sym}USDT`;
    const [c1h, c4h, c1d, openInterest, longShortRatio] = await Promise.all([
      fetchBinanceKlines(sym, '1h', 200),
      fetchBinanceKlines(sym, '4h', 150),
      fetchBinanceKlines(sym, '1d', 150),
      // Both futures-only endpoints — fine to fail quietly (e.g. a symbol
      // that's spot-listed but has no Binance futures market): squeeze and
      // the rest of the deep tier don't depend on them, only the
      // liquidation-zone estimate does, and that degrades gracefully to a
      // 50/50 positioning assumption with no OI-based weighting.
      (typeof fetchCexOpenInterest === 'function' ? fetchCexOpenInterest(fetchSym) : Promise.resolve(null)).catch(() => null),
      (typeof fetchLongShortRatio === 'function' ? fetchLongShortRatio(fetchSym) : Promise.resolve(null)).catch(() => null),
    ]);
    if (!c1h || c1h.length < 60) {
      el.innerHTML = `<div class="adv-ta-empty">Not enough 1h history for ${esc(sym)} on Binance (or symbol not found) — need 60+ candles, ideally 100+ for the Ichimoku cloud.</div>`;
      return;
    }
    const timeframeSets = [];
    if (c1h) timeframeSets.push({ label: '1h', candles: c1h });
    if (c4h && c4h.length > 80) timeframeSets.push({ label: '4h', candles: c4h });
    if (c1d && c1d.length > 80) timeframeSets.push({ label: '1d', candles: c1d });

    const deep = await AdvancedTA.analyzeDeep(sym, c1h, timeframeSets);

    // Squeeze — reuse TA.generateSignals's own squeeze line (same tested
    // logic that already feeds the composite score on every scanned perp)
    // rather than re-deriving it here; fall back to an explicit "not
    // squeezed" line since generateSignals only emits a line when there's
    // something to report (on, or just fired).
    const basicSignals = TA.generateSignals(c1h.map(c => c.c), c1h);
    const squeezeLines = basicSignals.filter(s => s.text.includes('Squeeze'));
    deep.squeeze = squeezeLines.length ? squeezeLines : [{ type: 'neut', text: 'No squeeze currently — bands are not compressed' }];

    // Estimated liquidation zones — see ta/liquidationZones.js's header for
    // exactly what this is and isn't. longShortRatio (longs:shorts accounts)
    // converts to a long/short fraction for weighting; null just falls back
    // to an even 50/50 split inside the estimator.
    const currentPrice = c1h[c1h.length - 1].c;
    const positioning = longShortRatio != null && longShortRatio > 0
      ? { long: longShortRatio / (longShortRatio + 1), short: 1 / (longShortRatio + 1) }
      : null;
    deep.liquidation = (typeof LiquidationZones !== 'undefined')
      ? LiquidationZones.toSignals(currentPrice, openInterest, positioning)
      : [];

    el.innerHTML = renderAdvancedTAResult(sym, deep);
  } catch (e) {
    el.innerHTML = `<div class="adv-ta-empty">Failed to analyze ${esc(sym)}: ${esc(e.message)}</div>`;
  } finally {
    _advTALoading = false;
  }
}

function renderAdvancedTAResult(sym, deep) {
  const factors = deep.factors || [];
  let scoreBlock = '';
  if (factors.length) {
    const totalWeight = factors.reduce((s, f) => s + f.weight, 0);
    const score = factors.reduce((s, f) => s + f.direction * f.weight, 0) / totalWeight;
    const agreeing = factors.filter(f => Math.sign(f.direction) === Math.sign(score) && f.direction !== 0).length;
    const color = score > 0.15 ? 'var(--green)' : score < -0.15 ? 'var(--red)' : 'var(--muted)';
    const label = score > 0.15 ? 'Lean bullish' : score < -0.15 ? 'Lean bearish' : 'Mixed / no edge';
    scoreBlock = `
      <div style="display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--border);margin-bottom:12px;">
        <div style="font-family:var(--mono);font-size:22px;font-weight:800;color:${color};">${label}</div>
        <div style="font-family:var(--mono);font-size:12px;color:var(--muted);">score ${score.toFixed(2)} · ${agreeing}/${factors.length} advanced factors agreeing · same weighting convention as the Composite Signal on Perps</div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;">
        ${factors.map(f => `<span class="ts-factor" style="color:${f.direction>0?'var(--green)':f.direction<0?'var(--red)':'var(--muted)'};border:1px solid var(--border);border-radius:6px;padding:4px 8px;">${f.direction>0?'▲':f.direction<0?'▼':'·'} <b>${esc(f.name)}</b>: ${esc(f.detail)}</span>`).join('')}
      </div>`;
  } else {
    scoreBlock = `<div class="adv-ta-empty" style="padding:14px 0;">No advanced-TA factors fired for ${esc(sym)} right now — that's expected most of the time; these frameworks are built to stay quiet rather than force a read.</div>`;
  }

  const section = (title, sub, sigs) => {
    if (!sigs || !sigs.length) return '';
    return `
      <div style="margin-bottom:18px;">
        <div style="font-family:var(--mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;">${esc(title)}${sub ? ` <span style="opacity:.7;">— ${esc(sub)}</span>` : ''}</div>
        ${sigs.map(s => `<div style="padding:6px 0;border-bottom:1px solid var(--border);font-family:var(--mono);font-size:12.5px;color:${s.type==='buy'?'var(--green)':s.type==='sell'?'var(--red)':'var(--text)'};">${esc(s.text)}</div>`).join('')}
      </div>`;
  };

  const mtfBlock = deep.mtf && deep.mtf.total ? `
    <div style="margin-bottom:18px;">
      <div style="font-family:var(--mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;">Ichimoku Multi-Timeframe</div>
      <div style="font-family:var(--mono);font-size:12.5px;">${deep.mtf.reads.map(r => `<span style="margin-right:14px;color:${r.dir>0?'var(--green)':r.dir<0?'var(--red)':'var(--muted)'};">${esc(r.label)}: ${esc(r.priceVsCloud)} cloud</span>`).join('')}</div>
    </div>` : '';

  const orderFlowNote = deep.orderFlow?.error
    ? `<div class="adv-ta-empty" style="padding:8px 0;">Order flow unavailable: ${esc(deep.orderFlow.error)}</div>` : '';

  return `
    <div style="padding-bottom:8px;font-family:var(--mono);font-size:11px;color:var(--muted);">
      ⚠ Reference only, not financial advice. Elliott Wave and Wyckoff phases are heuristic/rule-checked approximations, not discretionary expert calls — see each section for what's actually mechanical vs. best-effort.
    </div>
    ${scoreBlock}
    ${section('Smart Money Concepts / Structure', deep.structure?.trend, SMCStructure.toSignals(deep.structure))}
    ${section('Wyckoff (heuristic)', null, Wyckoff.toSignals(deep.wyckoff))}
    ${section('Ichimoku Cloud', null, Ichimoku.toSignals(deep.ichimoku))}
    ${mtfBlock}
    ${section('Fibonacci / Elliott Wave (rule-checked)', null, FibWave.toSignals(deep.fib, deep.wave))}
    ${section('Harmonic Patterns', null, Harmonics.toSignals(deep.harmonicMatches))}
    ${section('Volatility Squeeze (TTM)', 'Bollinger inside Keltner = compressed, watch for a breakout', deep.squeeze)}
    ${section('Order Flow & VWAP', 'live Binance aggTrades', deep.orderFlow && !deep.orderFlow.error ? OrderFlow.toSignals(deep.orderFlow.vwapResult, deep.orderFlow.cvd) : null)}
    ${orderFlowNote}
    ${deep.liquidation && deep.liquidation.length ? `
    <div style="margin-bottom:18px;">
      <div style="font-family:var(--mono);font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:6px;">Estimated Liquidation Zones <span style="opacity:.7;">— modeled, not exchange order-book data</span></div>
      <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-bottom:6px;">Assumes a fresh position opened near the current price at common leverage tiers (5x–100x) — a real magnet-level estimate, not a measurement. See tooltip / docs for the model's assumptions.</div>
      ${deep.liquidation.map(s => `<div style="padding:6px 0;border-bottom:1px solid var(--border);font-family:var(--mono);font-size:12.5px;">${esc(s.text)}</div>`).join('')}
    </div>` : ''}
  `;
}
