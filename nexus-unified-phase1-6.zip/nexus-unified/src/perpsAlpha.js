/**
 * perpsAlpha.js — server-computed composite score across all Binance USDT-M
 * perpetuals, using only Binance's public (no-key) REST endpoints:
 *   /fapi/v1/ticker/24hr     price change %, volume, per symbol
 *   /fapi/v1/premiumIndex    current funding rate, per symbol
 *
 * Like polymarketAlpha.js, the raw feeds here are free and public — the
 * paid part is the composite score that combines them into one ranked
 * list instead of making a user watch 300 tickers by hand.
 *
 * composite = momentum_z * 0.6 + funding_extremity_z * 0.4, where both
 * are z-scored across the current universe so the score is relative to
 * "unusual for right now," not an absolute threshold that goes stale.
 * Sign of the composite indicates crowd positioning skew (very positive
 * funding + strong recent up-move = a lot of leveraged longs paying up,
 * historically a mean-reversion risk factor, NOT a guaranteed reversal).
 */
'use strict';

const { fetchJson } = require('./httpJson');

function zScores(values) {
  const n = values.length;
  const mean = values.reduce((a, b) => a + b, 0) / n;
  const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
  const sd = Math.sqrt(variance) || 1;
  return values.map(v => (v - mean) / sd);
}

async function fetchTopMovers(limit = 100) {
  const [tickers, funding] = await Promise.all([
    fetchJson('https://fapi.binance.com/fapi/v1/ticker/24hr'),
    fetchJson('https://fapi.binance.com/fapi/v1/premiumIndex'),
  ]);
  if (!Array.isArray(tickers) || !Array.isArray(funding)) throw new Error('unexpected Binance response shape');

  const fundingBySymbol = new Map(funding.map(f => [f.symbol, parseFloat(f.lastFundingRate)]));

  const usdtPerps = tickers.filter(t => t.symbol.endsWith('USDT') && fundingBySymbol.has(t.symbol));
  const momentum = usdtPerps.map(t => parseFloat(t.priceChangePercent));
  const fundingRates = usdtPerps.map(t => fundingBySymbol.get(t.symbol));

  const momentumZ = zScores(momentum);
  const fundingZ = zScores(fundingRates.map(Math.abs));

  const scored = usdtPerps.map((t, i) => ({
    symbol: t.symbol,
    priceChangePercent: momentum[i],
    fundingRate: fundingRates[i],
    volume24hrUsdt: parseFloat(t.quoteVolume),
    lastPrice: parseFloat(t.lastPrice),
    composite: Math.round((momentumZ[i] * 0.6 + fundingZ[i] * 0.4) * 100) / 100,
  }))
  .filter(t => t.volume24hrUsdt > 1_000_000) // ignore illiquid/dead pairs
  .sort((a, b) => Math.abs(b.composite) - Math.abs(a.composite))
  .slice(0, limit);

  return scored;
}

/**
 * fetchMarketOverview() — the FULL Binance USDT-M perp universe (bare
 * ticker, price, 24h % change, 24h high/low, 24h quote volume), sorted by
 * liquidity, with dead/near-dead pairs dropped. This is deliberately a
 * plain sorted list, not a scored/ranked "alpha" product like
 * fetchTopMovers() above — it's the raw market data a Binance-style
 * "Markets" table needs, and the data source for scanner auto-discovery
 * below. One ticker endpoint call regardless of how many symbols exist.
 *
 * @param {number} [limit=250]
 * @param {(url:string)=>Promise<any>} [fetchFn] - injectable for tests
 */
async function fetchMarketOverview(limit = 250, fetchFn = fetchJson) {
  const tickers = await fetchFn('https://fapi.binance.com/fapi/v1/ticker/24hr');
  if (!Array.isArray(tickers)) throw new Error('unexpected Binance response shape');

  return tickers
    .filter((t) => t.symbol.endsWith('USDT'))
    .map((t) => ({
      symbol: t.symbol.replace(/USDT$/, ''),
      pair: t.symbol,
      lastPrice: parseFloat(t.lastPrice),
      priceChangePercent: parseFloat(t.priceChangePercent),
      highPrice: parseFloat(t.highPrice),
      lowPrice: parseFloat(t.lowPrice),
      volume24hrUsdt: parseFloat(t.quoteVolume),
    }))
    .filter((t) => t.volume24hrUsdt > 100_000) // drop near-dead pairs
    .sort((a, b) => b.volume24hrUsdt - a.volume24hrUsdt)
    .slice(0, limit);
}

/** Bare tickers (e.g. "SOL") for the top-N most liquid perps, for
 *  taSignalSource's auto-discovery mode — see taSignalSource.js's
 *  `autoDiscover` config block. */
function topLiquidSymbols(overview, n) {
  return overview.slice(0, n).map((t) => t.symbol);
}

module.exports = { fetchTopMovers, fetchMarketOverview, topLiquidSymbols };
