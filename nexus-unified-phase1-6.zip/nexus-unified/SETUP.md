# Signal engine — setup

This app now includes an in-process Telegram signal engine (previously a
separate Go service, `signalbot`). One process, one `npm start`.

## What it does

Watches Telegram channels you choose, extracts complete trade setups
(coin, entry, take-profit, stop-loss) from the noise, scores how complete
each one is, and — only for setups that clear your confidence threshold —
saves them and optionally pushes a Bot API alert to your own chat. The
dashboard's Trade Signals tab shows them alongside a cross-check against
Nexus's own RSI/MACD/BB/EMA reading for the same asset.

**What it is not:** a signal quality filter. Completeness (does the
message have an entry/TP/SL) is not the same as the channel being good at
calling trades. Nothing here is financial advice, and no combination of
parsing and technical-indicator agreement removes market risk.

## Setup

1. `npm install`
2. Get `api_id` / `api_hash` from <https://my.telegram.org> (this is your
   personal Telegram account's API credentials — the engine logs in as
   you, the same way the Telegram Desktop app would, so it can read
   channels you follow).
3. Get a bot token from [@BotFather](https://t.me/BotFather) and your
   numeric chat ID from [@userinfobot](https://t.me/userinfobot) — this is
   only for push alerts; you can skip this and just view signals in the
   dashboard.
4. `cp config.example.json config.json`, fill in the values above, set
   `channels` to the usernames you want watched, and set
   `signalEngine.enabled: true`.
5. `npm start`. First run prompts for your phone number, login code, and
   2FA password (if set) right in the terminal — after that a session file
   is written and you won't be prompted again.

If you skip steps 2–4 entirely (no `config.json`, or
`signalEngine.enabled: false`), the rest of the dashboard works exactly as
before — portfolio tracking, charts, backtester, etc. are unaffected.

## Nexus's own TA as a signal source (`taSource`)

By default the only thing that generates a signal is a Telegram channel
message. `signalEngine.taSource` makes Nexus's own indicators.js bias (the
same "Bias: BULLISH/BEARISH" line you'd otherwise only see on a chart)
generate a proposal the same way — saved as `pending`, pushed to your
Telegram as an Approve/Reject prompt, and on approval, picked up by
`bridge.py` and risk-gated by TonyBot exactly like a parsed Telegram call.

This does **not** require `telegram.apiId`/`apiHash` (no MTProto login, no
channel watching) — it only needs `notification.botToken`/`chatId` (a
regular Bot API bot) so it has somewhere to send the Approve/Reject prompt.
You can run `taSource` with `channels: []` and no Telegram account login at
all if you don't want channel parsing, just Nexus's own signals.

```json
"signalEngine": {
  "enabled": true,
  "taSource": {
    "enabled": true,
    "symbols": ["SOL", "ETH", "BTC"],
    "timeframe": "1h",
    "minNetConfluence": 3,
    "minAdx": 20,
    "maxLeverage": 10,
    "cooldownMs": 2700000,
    "streakThreshold": 3
  }
}
```

- `symbols` — bare tickers to scan (fetched as `<SYMBOL>USDT` perps from
  Binance's public futures API, no key needed).
- `minNetConfluence` — how many more bullish than bearish indicator reads
  are needed before a proposal fires (out of ~10 indicators in
  `indicators.js`). Higher = fewer, higher-conviction proposals.
- `minAdx` — skips proposing a directional trade when ADX shows the trend
  is too weak to trust (chop).
- `cooldownMs` — minimum time between two proposals on the *same* coin,
  regardless of outcome. This exists specifically to stop rapid re-entry
  into the same symbol within minutes of the last attempt.
- `streakThreshold` / `streakLookbackMs` / `streakCooldownMs` — if a coin
  racks up this many rejected/failed signals in a row within the lookback
  window, it's paused for `streakCooldownMs`. This is a blunt instrument on
  purpose: it doesn't know *why* a symbol keeps losing, it just stops
  proposing more of the same until you've had a cooldown period.
- `maxLeverage` / `suggestLeverage` — the leverage the proposal itself
  suggests. This is advisory only; TonyBot's own risk engine (`.env`'s
  `MAX_LEVERAGE`) is the actual enforcement point and can reject a trade
  regardless of what a signal suggested.

None of this is a prediction of future performance — see
`signalConfluence.js`'s header comment: agreement across indicators is
corroborating evidence, not confirmation.

## Architecture

```
Telegram (MTProto, via teleproto)
      │
      ▼
src/signalEngine/ingest.js     watches configured channels, hands off
                                 raw messages
      │  {channelId, channelName, messageId, text, postedAt}
      ▼
src/signalEngine/pipeline.js   dedup check → parse → notify → persist
      │                                │
      │                                ▼
      │                        src/signalEngine/parser.js
      │                        normalize → hard exclude filters → field
      │                        extraction → confidence score + breakdown
      │
      ├──────────────► src/signalEngine/store.js     (SQLite via node:sqlite)
      └──────────────► src/signalEngine/notifier.js  (Bot API, retry, MarkdownV2)

server.js  exposes GET /api/signals and /api/signals/health
      │
      ▼
src/telegramSignals.js (front-end)  renders signals + confidence breakdown
      │
      ▼
src/signalConfluence.js (front-end)  cross-checks direction against
                                       Nexus's own TA (indicators.js) using
                                       live Binance candles
```

Every layer under `src/signalEngine/` is plain, dependency-free JS you can
unit test with fake inputs — see `src/signalEngine/*.test.js`. The only
external dependency in the whole engine is `teleproto` (the Telegram
client), used solely by `ingest.js`.

## Tuning false positives / false negatives

Edit `config.json`:
- `filters.excludePatterns` — regexes that hard-reject a message regardless
  of what numbers it contains (promo posts, "target hit" celebrations,
  chit-chat). Add a pattern here if a channel's noise keeps getting
  through.
- `filters.minConfidence` (0–1) — raise it if incomplete setups are
  slipping through as signals; lower it if real setups with unusual
  formatting are getting dropped. See `src/signalEngine/classify.js` for
  what each field is worth.

## Running the tests

```
npm test
```

Covers the parser (ported from the original Go test suite, plus new cases
that caught two real bugs during the port — see git history / code
comments in `extract.js`), config validation, and an end-to-end pipeline
test using a real in-memory-adjacent SQLite file (no live Telegram
connection required).

## What isn't verified here

This was built and tested in a sandbox with no network path to Telegram's
MTProto servers or the Bot API. Everything in `src/signalEngine/` that
doesn't touch the network has a passing test. `ingest.js` (the actual
Telegram connection) and `notifier.js`'s live HTTP calls have not been
exercised against real Telegram infrastructure — run `npm start` with a
real `config.json` and watch the console on first launch before trusting
this unattended.
