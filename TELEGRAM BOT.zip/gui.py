"""
ZIME-FETCH lightweight GUI.

A single-window Tkinter app:
    1. Setup tab: enter Telegram API credentials (once) and log in.
    2. Groups tab: tap checkboxes to pick up to 25 groups to monitor.
    3. Feed tab: shows live incoming messages from the selected groups.

Telethon's asyncio client runs on a background thread with its own event
loop so the Tkinter mainloop (which is synchronous) never blocks it.
"""

import asyncio
import logging
import queue
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from config import MAX_GROUPS, load_config, save_config, set_selected_groups
from telegram_client import TelegramMonitor

log = logging.getLogger("zime_fetch.gui")

APP_TITLE = "ZIME-FETCH"


class AsyncLoopThread:
    """Runs an asyncio event loop on a dedicated background thread."""

    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def start(self):
        self.thread.start()

    def run_coro(self, coro):
        """Schedule a coroutine on the loop from the Tk (main) thread. Returns a Future."""
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self):
        self.loop.call_soon_threadsafe(self.loop.stop)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("560x520")
        self.resizable(True, True)

        self.config_data = load_config()
        self.monitor: TelegramMonitor | None = None
        self.async_thread = AsyncLoopThread()
        self.async_thread.start()

        self.feed_queue: queue.Queue = queue.Queue()
        self.group_vars: dict[int, tuple[tk.BooleanVar, str]] = {}
        self.monitoring = False

        self._build_ui()
        self.after(200, self._drain_feed_queue)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------- UI ----------

    def _build_ui(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self.setup_tab = ttk.Frame(notebook)
        self.groups_tab = ttk.Frame(notebook)
        self.feed_tab = ttk.Frame(notebook)

        notebook.add(self.setup_tab, text="Setup")
        notebook.add(self.groups_tab, text="Groups")
        notebook.add(self.feed_tab, text="Feed")

        self._build_setup_tab()
        self._build_groups_tab()
        self._build_feed_tab()

    def _build_setup_tab(self):
        f = self.setup_tab
        ttk.Label(f, text="Telegram API ID:").grid(row=0, column=0, sticky="w", padx=8, pady=(12, 4))
        self.api_id_var = tk.StringVar(value=self.config_data.get("api_id", ""))
        ttk.Entry(f, textvariable=self.api_id_var, width=40).grid(row=0, column=1, padx=8, pady=(12, 4))

        ttk.Label(f, text="Telegram API Hash:").grid(row=1, column=0, sticky="w", padx=8, pady=4)
        self.api_hash_var = tk.StringVar(value=self.config_data.get("api_hash", ""))
        ttk.Entry(f, textvariable=self.api_hash_var, width=40, show="*").grid(row=1, column=1, padx=8, pady=4)

        ttk.Label(
            f,
            text="Get these from my.telegram.org → API development tools.",
            foreground="gray",
        ).grid(row=2, column=0, columnspan=2, sticky="w", padx=8, pady=(0, 12))

        ttk.Button(f, text="Save & Connect", command=self._save_and_connect).grid(
            row=3, column=0, columnspan=2, pady=8
        )

        self.setup_status_var = tk.StringVar(value="Not connected.")
        ttk.Label(f, textvariable=self.setup_status_var, foreground="blue").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=8, pady=4
        )

    def _build_groups_tab(self):
        f = self.groups_tab

        top = ttk.Frame(f)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Button(top, text="Refresh Group List", command=self._refresh_groups).pack(side="left")
        self.groups_count_var = tk.StringVar(value=f"0 / {MAX_GROUPS} selected")
        ttk.Label(top, textvariable=self.groups_count_var).pack(side="right")

        # Scrollable checkbox list
        container = ttk.Frame(f)
        container.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        canvas = tk.Canvas(container, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.checklist_frame = ttk.Frame(canvas)

        self.checklist_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=self.checklist_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        bottom = ttk.Frame(f)
        bottom.pack(fill="x", padx=8, pady=8)
        self.start_btn = ttk.Button(bottom, text="Start Monitoring", command=self._start_monitoring)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(bottom, text="Stop Monitoring", command=self._stop_monitoring, state="disabled")
        self.stop_btn.pack(side="left", padx=8)

        self._populate_saved_groups()

    def _build_feed_tab(self):
        f = self.feed_tab
        self.feed_text = tk.Text(f, wrap="word", state="disabled")
        self.feed_text.pack(fill="both", expand=True, padx=8, pady=8)

    # ---------- Setup / connection ----------

    def _save_and_connect(self):
        api_id = self.api_id_var.get().strip()
        api_hash = self.api_hash_var.get().strip()
        if not api_id or not api_hash:
            messagebox.showerror(APP_TITLE, "Please enter both API ID and API Hash.")
            return

        self.config_data["api_id"] = api_id
        self.config_data["api_hash"] = api_hash
        save_config(self.config_data)

        try:
            self.monitor = TelegramMonitor(
                api_id=api_id,
                api_hash=api_hash,
                session_name=self.config_data.get("session_name", "zime_fetch"),
            )
        except ValueError as e:
            messagebox.showerror(APP_TITLE, str(e))
            return

        self.setup_status_var.set("Connecting... (check terminal for login prompts on first run)")
        future = self.async_thread.run_coro(self.monitor.connect())

        def on_done(fut):
            try:
                fut.result()
                self.setup_status_var.set("Connected.")
            except Exception as e:
                log.exception("Connect failed")
                self.setup_status_var.set(f"Connection failed: {e}")

        future.add_done_callback(lambda fut: self.after(0, on_done, fut))

    # ---------- Groups ----------

    def _populate_saved_groups(self):
        saved = self.config_data.get("selected_groups", [])
        for g in saved:
            self._add_group_checkbox(g["id"], g["title"], checked=True)
        self._update_group_count()

    def _add_group_checkbox(self, group_id: int, title: str, checked: bool = False):
        if group_id in self.group_vars:
            return
        var = tk.BooleanVar(value=checked)
        cb = ttk.Checkbutton(
            self.checklist_frame,
            text=title,
            variable=var,
            command=self._update_group_count,
        )
        cb.pack(anchor="w", padx=4, pady=2)
        self.group_vars[group_id] = (var, title)

    def _update_group_count(self):
        selected = [gid for gid, (var, _) in self.group_vars.items() if var.get()]
        self.groups_count_var.set(f"{len(selected)} / {MAX_GROUPS} selected")
        if len(selected) > MAX_GROUPS:
            messagebox.showwarning(
                APP_TITLE, f"You can select at most {MAX_GROUPS} groups. Please uncheck some."
            )

    def _refresh_groups(self):
        if not self.monitor:
            messagebox.showinfo(APP_TITLE, "Connect on the Setup tab first.")
            return

        future = self.async_thread.run_coro(self.monitor.list_groups())

        def on_done(fut):
            try:
                groups = fut.result()
            except Exception as e:
                log.exception("Failed to list groups")
                messagebox.showerror(APP_TITLE, f"Could not fetch groups: {e}")
                return
            for g in groups:
                self._add_group_checkbox(g["id"], g["title"])
            self._update_group_count()

        future.add_done_callback(lambda fut: self.after(0, on_done, fut))

    def _get_selected_groups(self) -> list[dict]:
        return [
            {"id": gid, "title": title}
            for gid, (var, title) in self.group_vars.items()
            if var.get()
        ]

    # ---------- Monitoring ----------

    def _start_monitoring(self):
        if not self.monitor:
            messagebox.showinfo(APP_TITLE, "Connect on the Setup tab first.")
            return

        selected = self._get_selected_groups()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select at least one group to monitor.")
            return
        if len(selected) > MAX_GROUPS:
            messagebox.showerror(APP_TITLE, f"Please select {MAX_GROUPS} groups or fewer.")
            return

        try:
            set_selected_groups(self.config_data, selected)
        except ValueError as e:
            messagebox.showerror(APP_TITLE, str(e))
            return

        self.monitor.set_watched_groups([g["id"] for g in selected])

        async def on_message(payload: dict):
            self.feed_queue.put(payload)

        self.monitor.on_message(on_message)

        self.async_thread.run_coro(self.monitor.start())
        self.monitoring = True
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self._append_feed_line(f"--- Monitoring started for {len(selected)} group(s) ---")

    def _stop_monitoring(self):
        if self.monitor:
            self.async_thread.run_coro(self.monitor.stop())
        self.monitoring = False
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self._append_feed_line("--- Monitoring stopped ---")

    # ---------- Feed ----------

    def _drain_feed_queue(self):
        try:
            while True:
                payload = self.feed_queue.get_nowait()
                line = f"[{payload.get('date', '')}] {payload.get('chat_title')} — {payload.get('sender')}: {payload.get('text')}"
                self._append_feed_line(line)
        except queue.Empty:
            pass
        finally:
            self.after(200, self._drain_feed_queue)

    def _append_feed_line(self, line: str):
        self.feed_text.config(state="normal")
        self.feed_text.insert("end", line + "\n")
        self.feed_text.see("end")
        self.feed_text.config(state="disabled")

    # ---------- Lifecycle ----------

    def _on_close(self):
        if self.monitor:
            try:
                self.async_thread.run_coro(self.monitor.stop())
            except Exception:
                pass
        self.async_thread.stop()
        self.destroy()


def run_gui():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    app = App()
    app.mainloop()


if __name__ == "__main__":
    run_gui()
