#!/usr/bin/env python3
"""
ZIME-FETCH main entry point.

Usage:
    python bot.py

Launches the lightweight Tkinter GUI: enter your Telegram API credentials
once (Setup tab), tap to select up to 25 groups to monitor (Groups tab),
then watch incoming messages live (Feed tab).

On first connect, Telethon needs your phone number and login code — these
prompts currently appear in the terminal you launched bot.py from.
"""

from gui import run_gui

if __name__ == "__main__":
    run_gui()
