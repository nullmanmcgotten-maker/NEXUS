"""
Simple local JSON config for ZIME-FETCH.

Stores:
    - Telegram API credentials (api_id / api_hash)
    - Session name (telethon .session file)
    - Selected group IDs to monitor (max MAX_GROUPS)
"""

import json
import os

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
MAX_GROUPS = 25

DEFAULT_CONFIG = {
    "api_id": "",
    "api_hash": "",
    "session_name": "zime_fetch",
    "selected_groups": [],  # list of {"id": int, "title": str}
}


def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        return dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        merged = dict(DEFAULT_CONFIG)
        merged.update(data)
        return merged
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_CONFIG)


def save_config(config: dict) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def get_selected_group_ids(config: dict) -> list[int]:
    return [g["id"] for g in config.get("selected_groups", [])]


def set_selected_groups(config: dict, groups: list[dict]) -> dict:
    """groups: list of {"id": int, "title": str}. Enforces MAX_GROUPS cap."""
    if len(groups) > MAX_GROUPS:
        raise ValueError(f"Cannot select more than {MAX_GROUPS} groups (got {len(groups)}).")
    config["selected_groups"] = groups
    save_config(config)
    return config
