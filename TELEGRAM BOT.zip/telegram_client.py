"""
Telethon wrapper for ZIME-FETCH.

Responsibilities:
    - Log in (interactive code/2FA prompt on first run, cached session after)
    - List the user's groups/channels so the GUI can offer them for selection
    - Monitor only the selected group IDs and hand off new messages via a callback
"""

import asyncio
import logging
from typing import Awaitable, Callable, Optional

from telethon import TelegramClient, events
from telethon.tl.types import Chat, Channel

log = logging.getLogger("zime_fetch.telegram_client")

MessageCallback = Callable[[dict], Awaitable[None]]


class TelegramMonitor:
    def __init__(self, api_id: str, api_hash: str, session_name: str = "zime_fetch"):
        if not api_id or not api_hash:
            raise ValueError("api_id and api_hash are required. Set them via the GUI/config first.")
        self.client = TelegramClient(session_name, int(api_id), api_hash)
        self._on_message: Optional[MessageCallback] = None
        self._watched_ids: set[int] = set()
        self._handler_registered = False

    async def connect(self):
        """Connect and, if needed, run Telethon's interactive login (code + 2FA)."""
        await self.client.connect()
        if not await self.client.is_user_authorized():
            phone = input("Enter your phone number (with country code): ").strip()
            await self.client.send_code_request(phone)
            code = input("Enter the login code you received: ").strip()
            try:
                await self.client.sign_in(phone=phone, code=code)
            except Exception as e:
                # Likely 2FA enabled
                if "password" in str(e).lower() or "SessionPasswordNeeded" in type(e).__name__:
                    password = input("Enter your 2FA password: ").strip()
                    await self.client.sign_in(password=password)
                else:
                    raise
        log.info("Connected and authorized.")

    async def list_groups(self) -> list[dict]:
        """Return all groups/channels the user is a member of (for GUI selection)."""
        groups = []
        async for dialog in self.client.iter_dialogs():
            entity = dialog.entity
            if isinstance(entity, (Chat, Channel)):
                # Skip broadcast channels the user can't meaningfully "monitor" as a group,
                # but keep megagroups and regular chats.
                is_channel_only = isinstance(entity, Channel) and not entity.megagroup and not getattr(entity, "gigagroup", False)
                if is_channel_only and not getattr(entity, "broadcast", False) is False:
                    # still include broadcast channels; users may want notifications from those too
                    pass
                groups.append({
                    "id": dialog.id,
                    "title": dialog.name or getattr(entity, "title", "Unknown"),
                })
        return groups

    def set_watched_groups(self, group_ids: list[int]):
        self._watched_ids = set(group_ids)

    def on_message(self, callback: MessageCallback):
        """Register an async callback: callback(message_dict) -> None"""
        self._on_message = callback

    def _register_handler(self):
        if self._handler_registered:
            return

        @self.client.on(events.NewMessage)
        async def handler(event):
            chat_id = event.chat_id
            if self._watched_ids and chat_id not in self._watched_ids:
                return
            if self._on_message is None:
                return
            chat = await event.get_chat()
            sender = await event.get_sender()
            payload = {
                "chat_id": chat_id,
                "chat_title": getattr(chat, "title", str(chat_id)),
                "sender": getattr(sender, "username", None) or getattr(sender, "first_name", "Unknown"),
                "text": event.raw_text or "",
                "date": event.date.isoformat() if event.date else None,
            }
            try:
                await self._on_message(payload)
            except Exception:
                log.exception("Error in message callback")

        self._handler_registered = True

    async def start(self):
        """Connect (if not already) and begin monitoring watched groups until stopped."""
        if not self.client.is_connected():
            await self.connect()
        self._register_handler()
        log.info("Monitoring %d group(s): %s", len(self._watched_ids), self._watched_ids)
        await self.client.run_until_disconnected()

    async def stop(self):
        if self.client.is_connected():
            await self.client.disconnect()
        log.info("Disconnected.")
