@echo off
call venv\Scripts\activate.bat
echo TONYBOT CLI — Scanning for setups...
python cli.py --scan
pause
