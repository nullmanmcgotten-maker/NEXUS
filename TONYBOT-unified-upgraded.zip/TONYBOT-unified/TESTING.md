# TESTING.md — Burn-In Checklist Before Live Perp Trading

This code adds real leverage, real liquidation math, and a live order path
that didn't exist before. New risk code deserves a soak period before real
money sits behind it — the checklist below is the order to go through, not
optional extras.

## Stage 0 — Unit tests (fast, run every time you change risk code)
```bash
pip install pytest --break-system-packages
pytest tests/ -v
```
All 30 tests should pass (20 perp-foundation + 10 predictive-signal). If you
touch `liquidation.py`, `position_sizing.py`, `monte_carlo.py`,
`correlation.py`, `pattern_scanner.py`, the imbalance logic in
`orderflow/pipeline.py`, or `strategy/trade_signal.py` / `core/signal_tracker.py`,
run this before anything else.

## Stage 1 — Paper mode, mock prices (minutes)
```env
PAPER_MODE=true
LIVE_TRADING=false
MARKET_TYPE=swap
```
Launch the GUI (`run.bat` / `python main.py`). Confirm:
- The **⚡ Perp Risk** tab loads without errors and the liquidation
  calculator gives sane numbers for a few manual entry/leverage combos.
- The **📈 Analytics** tab's pattern scanner and correlation matrix
  populate for your configured `SYMBOLS`.
- Try to trigger a paper trade at 50x+ leverage with a wide stop — confirm
  it still fills in paper mode (paper trades bypass the liquidation gate
  intentionally, so you can see setups the gate would otherwise block).
- The **🎯 Predictive Trade Signal** panel (below the 7-gate analysis, in
  the AI Signals view) should mostly show "waiting for a leading
  confirmation" — that's correct, it should fire far less often than the
  old AEGIS-only signal, and only with an entry/SL/TP/reasoning block filled
  in when it does. If it fires on every tick like the old signal used to,
  something's wrong with the orderflow/pattern gate — don't trust it live.
- Watch the log for `🎯 PREDICTIVE ...` lines when a signal fires, and for
  `✅`/`❌ Signal outcome resolved` lines once price later hits the SL/TP —
  that's the live accuracy tracker working. Confidence and "Setup accuracy"
  in the panel start from the backtest-seeded prior (~50-56%) and should
  visibly shift toward the live win-rate once ~10+ signals for a setup type
  have resolved. This needs real time running, not something you can fully
  verify in a five-minute smoke test.

## Stage 2 — Testnet, real API calls (hours to a day)
```env
BINANCE_TESTNET=true
LIVE_TRADING=true
PAPER_MODE=false
```
Use exchange testnet keys only (never your real account keys here). Confirm:
- `configure_leverage()` actually sets leverage/margin mode on the testnet
  account (check via the exchange's testnet UI, not just the app's log).
- Funding rate, open interest, and basis on the Perp Risk tab match what
  the testnet exchange shows for the same symbol.
- Place a few small testnet orders at varying leverage. Confirm the
  liquidation gate **rejects** orders where liquidation is closer than
  `MIN_LIQUIDATION_DISTANCE_PCT`, and rejects any order whose stop-loss
  sits beyond the computed liquidation price — force both rejection paths
  on purpose at least once each so you've seen them fire.
- Kill switch / circuit breaker still halts new orders when tripped, same
  as it did before this change (this logic wasn't touched, but it's the
  thing standing between a bug and real losses — verify it still works).

## Stage 3 — Live, minimum size (days, before scaling up)
```env
BINANCE_TESTNET=false
LIVE_TRADING=true
PAPER_MODE=false
MAX_POSITION_USD=<small — a number you're fully comfortable losing>
DEFAULT_LEVERAGE=<start low, e.g. 2-3x, regardless of your eventual target>
```
- Run for a full daily funding cycle (or several) before judging results —
  funding-drag effects only show up over time, not in a single trade.
- Compare the app's reported liquidation price against the exchange's own
  liquidation price display for at least one real open position. These
  should match closely; if they diverge by more than the exchange's own
  maintenance-margin tier rounding, stop and investigate before increasing
  size — that divergence is exactly the kind of bug that costs money at 3am.
- Only after this matches and behaves as expected across a few real
  positions should `MAX_POSITION_USD`, `DEFAULT_LEVERAGE`, and
  `MAX_LEVERAGE` be raised toward your actual target settings.

## Notes on `.env`
`.env.example` now defaults `MARKET_TYPE=swap` with `BINANCE_TESTNET=true`
and `PAPER_MODE=true` — i.e., it starts you at Stage 1 by default. Copy it
to `.env` and fill in your own API keys; never share a filled-in `.env`,
and never paste real API keys into a chat, ticket, or repo.
