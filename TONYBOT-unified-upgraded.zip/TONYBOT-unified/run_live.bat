@echo off
echo =============================================
echo   TONYBOT - LIVE MODE WARNING
echo =============================================
echo.
echo You are about to start LIVE TRADING.
echo Real money will be at risk.
echo.
echo Checklist before proceeding:
echo   [x] 1+ week of paper trading completed
echo   [x] Win rate > 50%% in backtest
echo   [x] Binance API keys restricted to THIS machine IP
echo   [x] MAX_POSITION_USD set to an amount you can fully lose
echo   [x] Telegram alerts tested and working
echo.
set /p confirm="Type LIVE to confirm: "
if /i "%confirm%"=="LIVE" (
    call venv\Scripts\activate.bat
    set PAPER_MODE=false
    set LIVE_TRADING=true
    python cli.py --run --interval 60
) else (
    echo Cancelled. Staying safe in paper mode.
)
pause
