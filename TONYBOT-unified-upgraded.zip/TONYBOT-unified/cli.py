"""
cli.py — TONYBOT Headless CLI / VPS / Server Mode Launcher
Supports: scan, backtest, run-loop, and report generation.
"""
import argparse
import asyncio
import logging
import sys
from pathlib import Path
from datetime import datetime

# --- Directory setup ---
for d in ["data", "logs", "reports"]:
    Path(d).mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/tonybot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("tonybot.cli")


def cmd_scan(args):
    """Scan all configured symbols for trade setups."""
    from tonybot.core.orchestrator import PipelineOrchestrator
    from tonybot.core.health import HealthChecker

    print("\n" + "=" * 60)
    print("  ⚡  TONYBOT — Market Setup Scanner")
    print("=" * 60)
    HealthChecker.run_checks()

    orchestrator = PipelineOrchestrator()
    setups = orchestrator.scan_all()

    if setups:
        print(f"\n✅  Found {len(setups)} actionable setups")
    else:
        print("\n⏳  No high-confidence setups found at this time.")

    # Also run the gated predictive pipeline (order-flow/pattern leading
    # confirmation on top of the lagging consensus above) — this is what
    # --run actually trades off, so it's shown here too as a pre-flight check.
    fired = asyncio.run(orchestrator.scan_predictive())
    if fired:
        print(f"✅  {len(fired)} predictive (leading+lagging gated) signal(s) fired\n")
    else:
        print("⏳  No gated predictive signals fired this scan.\n")


def cmd_backtest(args):
    """Run backtester on a symbol over historical OHLCV data."""
    from tonybot.config import config
    from tonybot.data.ccxt_source import CCXTDataSource
    from tonybot.backtest.engine import BacktestEngine

    symbol = args.symbol or (config.SYMBOLS[0] if config.SYMBOLS else "BTC/USDT")
    timeframe = args.timeframe or config.DEFAULT_TIMEFRAME
    days = args.days or config.BACKTEST_DATA_DAYS

    print(f"\n{'=' * 60}")
    print(f"  ⚡  TONYBOT Backtester")
    print(f"  Symbol: {symbol} | Timeframe: {timeframe} | Days: {days}")
    print("=" * 60)

    end_iso = datetime.utcnow().strftime("%Y-%m-%d")
    start_ts = datetime.utcnow()
    from datetime import timedelta
    start_iso = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")

    print(f"  Fetching OHLCV data from {start_iso} to {end_iso}...")
    try:
        ds = CCXTDataSource(exchange_id=config.EXCHANGE_ID)
        df = ds.fetch_ohlcv_range(symbol, timeframe, start_iso, end_iso)
        if df.empty or len(df) < 50:
            print(f"  ❌  Insufficient data retrieved ({len(df)} candles). Check symbol/exchange.")
            return

        print(f"  ✅  {len(df)} candles fetched. Running backtest...")
        engine = BacktestEngine(
            initial_balance=args.capital or 10000.0,
            taker_fee_pct=config.TAKER_FEE_PCT,
            slippage_pct=config.SLIPPAGE_PCT,
        )
        mode = "predictive" if args.predictive else "legacy"
        if args.predictive:
            print(
                "  ⚠️  Predictive mode: validates lagging consensus + chart-pattern "
                "leading confirmation only — no historical order-book data exists, so "
                "the order-flow-imbalance leading confirmation can never fire here. "
                "Treat this as a floor on live performance, not a ceiling."
            )
        result = engine.run(symbol, df, mode=mode)

        print(f"\n{'=' * 60}")
        print(f"  📊  BACKTEST RESULTS — {symbol}")
        print(f"{'=' * 60}")
        print(f"  Period:          {result.start} → {result.end}")
        print(f"  Total Trades:    {result.total_trades}")
        print(f"  Win Rate:        {result.win_rate:.1%}")
        print(f"  Profit Factor:   {result.profit_factor:.2f}")
        print(f"  Total Return:    {result.total_return_pct:+.2%}")
        print(f"  Max Drawdown:    {result.max_drawdown_pct:.2%}")
        print(f"  Sharpe Ratio:    {result.sharpe_ratio:.2f}")
        gate_pass = "✅ PASS" if result.passes_gate() else "❌ FAIL"
        print(f"  Gate Check:      {gate_pass} (WinRate≥45%, PF≥1.5)")
        print()

        if args.report:
            from tonybot.reports.generator import PDFReportGenerator
            from tonybot.core.db import Database
            db = Database()
            stats = db.get_stats()
            rg = PDFReportGenerator()
            path = rg.generate_report(stats, f"TONYBOT_Backtest_{symbol.replace('/', '')}_{end_iso}.pdf")
            if path:
                print(f"  PDF saved: {path}")

    except Exception as e:
        print(f"  ❌  Backtest error: {e}")
        logger.exception("Backtest failed")


def cmd_run(args):
    """Run headless trading engine loop."""
    from tonybot.core.engine import TradingEngine
    from tonybot.core.health import HealthChecker

    print("\n" + "=" * 60)
    print("  ⚡  TONYBOT — Headless Trading Engine")
    print("=" * 60)

    HealthChecker.run_checks()
    engine = TradingEngine()

    interval = args.interval or 60
    print(f"  Starting engine loop. Scan interval: {interval}s. Ctrl+C to stop.\n")

    try:
        asyncio.run(engine.run_loop(interval_seconds=interval))
    except KeyboardInterrupt:
        print("\n  🛑  Engine stopped by user.")


def cmd_report(args):
    """Generate PDF performance report."""
    from tonybot.core.db import Database
    from tonybot.reports.generator import PDFReportGenerator

    db = Database()
    stats = db.get_stats()
    rg = PDFReportGenerator()
    path = rg.generate_report(stats)
    if path:
        print(f"✅  PDF Report generated: {path}")
    else:
        print("❌  Failed to generate report (install reportlab: pip install reportlab)")


def main():
    parser = argparse.ArgumentParser(
        prog="tonybot",
        description="⚡ TONYBOT — Professional Trading Bot CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py --scan                        Scan all pairs for setups
  python cli.py --backtest --symbol BTC/USDT  Run BTC/USDT backtest
  python cli.py --backtest --symbol BTC/USDT --predictive  Backtest the gated predictive engine
  python cli.py --run --interval 30           Start headless engine (30s loop)
  python cli.py --report                      Generate PDF performance report
        """
    )

    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--scan", action="store_true", help="Scan all symbols for setups")
    mode.add_argument("--backtest", action="store_true", help="Run historical backtester")
    mode.add_argument("--run", action="store_true", help="Run headless engine loop")
    mode.add_argument("--report", action="store_true", help="Generate PDF performance report")

    parser.add_argument("--symbol", type=str, help="Symbol override (e.g. BTC/USDT)")
    parser.add_argument("--timeframe", type=str, help="Timeframe override (e.g. 1h)")
    parser.add_argument("--days", type=int, help="Backtest data days (default: 180)")
    parser.add_argument("--capital", type=float, help="Starting capital (default: 10000)")
    parser.add_argument("--interval", type=int, help="Engine loop interval seconds (default: 60)")
    parser.add_argument("--report-pdf", dest="report", action="store_true", help="Generate PDF after backtest")
    parser.add_argument(
        "--predictive", action="store_true",
        help="Backtest mode: use the gated AEGIS+pattern predictive pipeline instead of the legacy setup_scanner (see TESTING.md for the order-flow limitation)"
    )

    args = parser.parse_args()

    if args.scan:
        cmd_scan(args)
    elif args.backtest:
        cmd_backtest(args)
    elif args.run:
        cmd_run(args)
    elif args.report:
        cmd_report(args)


if __name__ == "__main__":
    main()
