@echo off
echo =============================================
echo   TONYBOT - Professional Trading Platform
echo =============================================

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.10+.
    pause
    exit /b 1
)

:: Create venv if needed
if not exist "venv\Scripts\activate.bat" (
    echo [1/3] Creating Python virtual environment...
    python -m venv venv
)

:: Activate venv
call venv\Scripts\activate.bat

:: Install dependencies
echo [2/3] Installing dependencies...
pip install -r requirements.txt --quiet

:: Create folders
if not exist "data" mkdir data
if not exist "logs" mkdir logs
if not exist "reports" mkdir reports

echo [3/3] Setup complete!
echo.
echo Edit .env with your API keys, then run:
echo   run.bat         - Launch GUI
echo   run_cli.bat     - CLI scan mode
echo   run_live.bat    - Live trading (after paper testing!)
pause
