# ⚡ TONYBOT v1.0 — Professional Unified Trading Platform

A production-grade algorithmic trading bot merging the best features of
**ApexBot v5** (PySide6 GUI, ML, orderflow, multi-indicator signals) and
**Oshai** (CCXT multi-exchange, 4-way setup scanner, strict risk architecture)
into one unified, solid platform.

---

## 🚀 Quick Start (Windows)

```batch
:: 1. Setup (creates venv, installs all packages)
setup.bat

:: 2. Configure your API keys
notepad .env

:: 3. Launch GUI (Paper Mode — safe, no real money)
run.bat

:: 4. CLI Scan (headless, for VPS / SSH)
run_cli.bat

:: 5. Backtest a symbol
venv\Scripts\activate
python cli.py --backtest --symbol BTC/USDT --days 180
```

---

## 🖥️ GUI Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `1` `2` `3` `4` | Switch active symbol |
| `Q` `W` `E` `R` | Timeframe: 1m / 5m / 1h / 4h |
| `Ctrl+K` | Command Palette |
| `Ctrl+L` | Toggle DRY / LIVE mode hint |

---

## 🔧 CLI Commands

```bash
python cli.py --scan                          # Scan all pairs for setups
python cli.py --backtest --symbol BTC/USDT    # Run backtester (legacy setup_scanner)
python cli.py --backtest --symbol BTC/USDT --predictive  # Backtest the gated predictive engine
python cli.py --backtest --days 360 --capital 5000  # Custom backtest params
python cli.py --run --interval 30             # Headless engine (30s loop)
python cli.py --report                        # Generate PDF performance report
```

---

## 📈 Scalp + Swing Dual-Mode Trading

`TRADING_MODE` in `.env` — `"swing"`, `"scalp"`, or `"both"` (default). In
`"both"` mode, every symbol runs through **two independently risk-managed
profiles concurrently**:

| | Scalp | Swing |
|---|---|---|
| Timeframes read | 1m, 5m, 1h | 4h, 1h, 5m |
| Stop-loss | 1× ATR | 2× ATR |
| Take-profit | 1.5× ATR | 4× ATR |

A symbol can hold a scalp position and a swing position **at the same
time** — they're tracked under separate internal keys (`"BTC/USDT|scalp"`
vs `"BTC/USDT|swing"`), sized independently, and each gets its own
exchange-side stop-loss/take-profit bracket. Portfolio heat (total risk
across all open positions) is still checked jointly, so running both
profiles doesn't let combined risk exceed `MAX_PORTFOLIO_HEAT_PCT`.

## 🔔 Telegram Alerts (headless-engine wired, with real position sizing)

`Notifier` (`tonybot/alerts/notifier.py`) previously existed in the
codebase but was never actually called from anywhere — not the GUI, not the
headless engine. Every fired entry and every close now sends a real alert
that includes actual position sizing: quantity, notional, risk amount
(`|entry - stop_loss| × quantity`), R:R, confidence, which leading
confirmation fired (order-flow / pattern / support-resistance), and whether
the position is exchange-protected. Set `TELEGRAM_BOT_TOKEN`,
`TELEGRAM_CHAT_ID`, and `ALERTS_ENABLED=true` in `.env` to receive these.

## 📊 Chart: timeframe selector + auto support/resistance overlay

The chart previously hardcoded `"1h"` and silently ignored the other three
timeframes (`1m`/`5m`/`4h`) `CandleFetcher` was already pulling every
cycle. There's now a timeframe dropdown above the chart that switches
instantly between whatever's cached (no re-fetch needed) and shows a clear
"Loading Xm…" state for anything not yet fetched. The chart also now draws
the same auto-detected support/resistance levels `SupportResistanceDetector`
feeds into the predictive engine — dashed lines, more solid the more times
price has touched that level — so what you see on the chart is literally
what the engine is watching for a bounce/breakout, not a separate cosmetic
indicator.

---

## 🛡️ Exchange-Side Stop-Loss / Take-Profit (live safety)

**If you are trading live, read this.** Previously, a live position's
stop-loss and take-profit existed *only* as this bot's own polling loop
(`monitor_and_close_positions`, checked once per `--interval` seconds)
comparing the latest fetched price against the position's stop/target. No
actual stop order ever sat on the exchange. Between polls — and if the
process crashed, lost network, or got rate-limited — a live leveraged
position had **zero real protection**, meaning a fast move or a gap could
blow straight through the intended stop with nothing to catch it. This is a
concrete, plausible cause of losses larger than the strategy's stop distance
should ever allow.

This is now fixed **for Binance USDM perpetual futures** (`MARKET_TYPE=swap`,
`EXCHANGE_ID=binance`): every entry immediately places real reduce-only
`STOP_MARKET` and `TAKE_PROFIT_MARKET` orders on the exchange itself, so
protection survives even if this bot goes offline. The polling loop now
checks exchange order status first and treats an already-filled bracket
order as the close event, rather than also sending a redundant close.

**If you're on a different exchange or in spot mode:** check the `⚠️
[UNPROTECTED]` warning in `logs/tonybot.log` at entry time. Non-Binance swap
positions currently fall back to polling-only and are explicitly flagged
`protected_by_exchange: False` — this is a real gap for those exchanges, not
a false alarm, until native brackets are implemented for them too. Spot
trading through the primary Binance client already used a real OCO order and
is unaffected.

---

## 🎯 Predictive Signal Engine (headless-engine wired)

Previously, `OrderFlowPipeline` (order-book imbalance/whale detection),
`PatternScanner` (structural chart patterns), and `PredictiveSignalEngine`
(the gate that only fires when lagging technical consensus **and** a leading
confirmation agree) were wired only into GUI worker threads — the headless
`core/engine.py` loop that actually drives `--run` / paper / testnet / live
traded off the older, purely lagging `setup_scanner` path alone. That's now
fixed: `TradingEngine` builds and owns its own `PredictiveSignalEngine` +
`SignalTracker`, fetches multi-timeframe candles and live order-book depth
every cycle, and only enters when the gate agrees. `python cli.py --scan`
also runs this same gated pipeline as a pre-flight preview of what `--run`
would actually trade.

The ML ensemble filter now also trains on a richer feature set (setup
family, risk:reward, sentiment — not just a bare technical-confidence
number) and is shared between the engine's entry filter and
`SignalRefiner`'s internal `ai_ensemble_vote` gate, instead of each holding
its own separately-untrained model.

### Backtesting the predictive engine
```bash
python cli.py --backtest --symbol BTC/USDT --predictive
```
**Limitation:** there's no historical L2 order-book data here, so the
order-flow-imbalance leading confirmation can never fire in backtest — only
the chart-pattern leading confirmation can. A predictive backtest therefore
validates "lagging consensus + pattern confluence," not the full live gate.
Treat a passing predictive backtest as a floor on live performance, not a
ceiling — the order-flow confirmation is a real testnet/live-only edge on
top of it. See `TESTING.md` Stage 1–2 for how to validate that half live.

---

## 🏗️ Architecture

```
TONYBOT/
├── main.py                   # GUI entry point (PySide6)
├── cli.py                    # Headless / VPS CLI entry point
├── tonybot.spec              # PyInstaller EXE build config
├── .env                      # Your config (never share!)
├── .env.example              # Config template
├── requirements.txt          # All dependencies
├── setup.bat / run.bat       # Windows launchers
├── tonybot/
│   ├── interfaces.py         # Core dataclasses & protocol contracts
│   ├── config.py             # Unified settings loader
│   ├── core/
│   │   ├── engine.py         # Async trading loop & cycle orchestration
│   │   ├── orchestrator.py   # CLI pipeline (scan → regime → setups)
│   │   ├── db.py             # SQLite trade journal
│   │   └── health.py         # Startup diagnostics
│   ├── data/
│   │   ├── ccxt_source.py    # CCXT multi-exchange OHLCV provider
│   │   └── binance_client.py # Async Binance REST (price, OCO orders)
│   ├── strategy/
│   │   ├── regime_classifier.py  # ADX+EMA trend/ranging detector
│   │   ├── setup_scanner.py      # 4-way setup scanner (Pullback/Breakout/RSI Div/S-R)
│   │   ├── signals.py            # 7-indicator technical signal engine + AI filter
│   │   └── multitf.py            # Multi-timeframe confluence matrix
│   ├── risk/
│   │   ├── risk_manager.py   # Drawdown circuit breaker & daily loss cap
│   │   ├── position_sizing.py # Kelly conviction sizer + correlation penalty
│   │   └── heat_guard.py     # Portfolio heat cap guard
│   ├── exchanges/
│   │   ├── manager.py        # Multi-exchange order router
│   │   └── smart_order.py    # TWAP slicing + slippage validation
│   ├── orderflow/
│   │   └── pipeline.py       # CVD, large trade detector ($50k+)
│   ├── orderbook/
│   │   └── orderbook.py      # L2 depth, walls, VPIN toxicity
│   ├── ml/
│   │   └── ensemble.py       # LightGBM signal classifier
│   ├── backtest/
│   │   ├── engine.py         # Historical backtester (fee + slippage)
│   │   └── optimizer.py      # Optuna Bayesian optimizer
│   ├── alerts/
│   │   └── notifier.py       # Telegram & Email alerts
│   ├── reports/
│   │   └── generator.py      # Monthly PDF report generator
│   ├── themes/
│   │   └── manager.py        # Dark/Midnight/Light/High-Contrast themes
│   └── ui/
│       └── main_window.py    # PySide6 main dashboard window
```

---

## 📊 Strategy Logic

### Regime Detection
- **ADX ≥ 25** → `TRENDING` (favors breakout + pullback setups)
- **ADX < 20** → `RANGING` (favors S/R bounce setups)
- EMA-9 / 21 / 50 stack → determines `UP` / `DOWN` trend direction

### Setup Scanner (4-Source Confirmation)
Each setup is validated across 4 independent signal sources:
1. **Price Action** — pattern/structure signal
2. **Volume** — spike above 1.5× 20-period average
3. **Momentum** — RSI + MACD histogram alignment with trend direction
4. **Trend Alignment** — regime trend direction confirmed

Minimum **3/4 confirmations** required to emit a tradeable setup.

### Setup Types
| Setup | Trigger |
|-------|---------|
| `PULLBACK_TO_MA` | Price within 1.2% of EMA-50 in a trending market |
| `BREAKOUT` | Bollinger Band close outside upper/lower band |
| `RSI_DIVERGENCE` | Price at 20-bar low, RSI making higher low (bullish div) |

### Technical Indicators (7-Vote Consensus)
RSI · MACD · Bollinger Bands · Supertrend · VWAP · Stochastic · EMA Cross

---

## 🛡️ Risk Controls

| Control | Default |
|---------|---------|
| Max drawdown (circuit breaker) | 15% |
| Max daily loss | 5% |
| Max open positions | 5 |
| Max portfolio heat | 15% |
| Kelly conviction sizing | 4/4 → 2% | 3/4 → 1.5% | 2/4 → 0.5% |
| Correlation penalty | 50% reduction per correlated position |

---

## 🏗️ Build Standalone EXE (Windows)

```batch
call venv\Scripts\activate
pip install pyinstaller
pyinstaller tonybot.spec --noconfirm --clean
:: Output: dist\TONYBOT\TONYBOT.exe
```

---

## ⚠️ Safety Checklist Before Live Trading

- [ ] Minimum 1 week of paper trading completed
- [ ] Backtest win rate ≥ 50%, Sharpe ≥ 0.5
- [ ] Binance API key IP-restricted to your machine only
- [ ] API key set to **Spot Trading ONLY** — no withdrawal permissions
- [ ] `MAX_POSITION_USD` set to an amount you can afford to lose entirely
- [ ] Telegram alerts verified in Settings
- [ ] `PAPER_MODE=false` and `LIVE_TRADING=true` explicitly set in `.env`

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `PySide6` | Desktop GUI framework |
| `ccxt` | Multi-exchange market data (100+ exchanges) |
| `pandas-ta` | Technical indicators (ADX, EMA, RSI, MACD, Bollinger) |
| `lightgbm` | ML signal classifier |
| `optuna` | Bayesian hyperparameter optimizer |
| `aiohttp` | Async HTTP for exchange APIs |
| `reportlab` | Monthly PDF report generation |
| `python-dotenv` | .env configuration loader |

---

*TONYBOT is for educational and research purposes. Trade at your own risk.*
