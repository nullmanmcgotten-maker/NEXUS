"""
main.py — TONYBOT GUI Launcher with Login
"""
import sys
import asyncio
import logging
import threading
from pathlib import Path

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont

from tonybot.themes.manager import theme_manager
from tonybot.core.engine import TradingEngine
from tonybot.core.health import HealthChecker
from tonybot.ui.login_dialog import LoginDialog
from tonybot.ui.main_window import MainWindow

# --- Directory setup ---
for d in ["data", "logs", "reports"]:
    Path(d).mkdir(parents=True, exist_ok=True)

# --- Logging ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/tonybot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("tonybot")

def main():
    # Health check
    HealthChecker.run_checks()

    app = QApplication(sys.argv)
    app.setApplicationName("TONYBOT v1.0")
    app.setStyle("Fusion")
    app.setStyleSheet(theme_manager.get_stylesheet())
    app.setFont(QFont("Consolas", 9))

    # Show login dialog first
    login = LoginDialog()
    if login.exec() != LoginDialog.DialogCode.Accepted:
        logger.info("Login cancelled")
        sys.exit(0)
    
    user = login.get_user()
    user_id = user['user_id'] if user else 1
    logger.info(f"User logged in: {user['username'] if user else 'default'}")

    # Initialize engine and main window
    engine = TradingEngine()
    window = MainWindow(engine)
    window.user_id = user_id
    window.user = user
    window.show()

    # Start async engine in background thread
    def run_engine():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(engine.run_loop(interval_seconds=30))
        finally:
            loop.close()

    engine_thread = threading.Thread(target=run_engine, daemon=True)
    engine_thread.start()

    logger.info("TONYBOT GUI launched successfully.")
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
