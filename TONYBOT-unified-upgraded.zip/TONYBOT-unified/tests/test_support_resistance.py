"""
tests/test_support_resistance.py — Tests for auto support/resistance
detection and its wiring into PredictiveSignalEngine as a third leading
confirmation source (alongside order-flow imbalance and chart patterns).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from tonybot.strategy.support_resistance import SupportResistanceDetector, SRLevel


def _bouncing_range_df(n=120, low=95.0, high=105.0, touches=4):
    """Builds a price series that oscillates between `low` and `high`
    `touches` times each, so both levels get repeatedly touched."""
    rng = np.random.default_rng(3)
    prices = []
    seg = n // (touches * 2)
    level = (low + high) / 2
    for i in range(touches * 2):
        target = low if i % 2 == 0 else high
        for j in range(seg):
            t = j / seg
            level = level + (target - level) * 0.3 + rng.normal(0, 0.05)
            prices.append(level)
    idx = pd.date_range(end=pd.Timestamp.now(tz="UTC"), periods=len(prices), freq="h")
    closes = np.array(prices)
    return pd.DataFrame({
        "open": closes,
        "high": closes + rng.uniform(0, 0.3, len(closes)),
        "low": closes - rng.uniform(0, 0.3, len(closes)),
        "close": closes,
        "volume": rng.uniform(10, 100, len(closes)),
    }, index=idx)


def test_detects_levels_in_a_bouncing_range():
    df = _bouncing_range_df()
    detector = SupportResistanceDetector()
    levels = detector.detect(df)
    assert len(levels) > 0
    # should find both a support (near the low) and a resistance (near the high)
    kinds = {l.kind for l in levels}
    assert "support" in kinds or "resistance" in kinds


def test_returns_empty_on_insufficient_data():
    df = pd.DataFrame({"open": [1, 2], "high": [1, 2], "low": [1, 2], "close": [1, 2], "volume": [1, 1]})
    detector = SupportResistanceDetector()
    assert detector.detect(df) == []


def test_levels_sorted_strongest_first():
    df = _bouncing_range_df(touches=6)
    detector = SupportResistanceDetector()
    levels = detector.detect(df)
    touches = [l.touches for l in levels]
    assert touches == sorted(touches, reverse=True)


def test_nearest_reaction_finds_support_bounce_for_buy():
    df = _bouncing_range_df()
    detector = SupportResistanceDetector()
    levels = detector.detect(df)
    support_levels = [l for l in levels if l.kind == "support"]
    assert support_levels, "test fixture should produce at least one support level"
    support_price = support_levels[0].price
    result = detector.nearest_reaction(df, current_price=support_price * 1.001, direction="BUY")
    assert result is not None
    assert result.kind == "support"


def test_nearest_reaction_returns_none_when_far_from_any_level():
    df = _bouncing_range_df()
    result = SupportResistanceDetector().nearest_reaction(df, current_price=99999.0, direction="BUY")
    assert result is None


def test_predictive_engine_fires_on_sr_reaction_alone():
    """With order-flow and pattern confirmation both absent, an S/R reaction
    alone should be enough to satisfy the leading-confirmation gate."""
    from tonybot.strategy.trade_signal import PredictiveSignalEngine

    class FakeRefiner:
        def evaluate(self, symbol, candles_by_tf, atr=0.0, tf_preference=None):
            return {"direction": "BUY", "aegis_score": 70.0, "gates": {}}

    class FakeOrderflow:
        def analyze_orderbook_imbalance(self, orderbook, symbol):
            return None  # no order-flow confirmation available

    def fake_detect_patterns(df):
        return []  # no pattern confirmation

    class FakeRiskManager:
        def calculate_sl_tp(self, entry, atr, direction, sl_atr_mult=2.0, tp_atr_mult=4.0):
            return (entry - 2.0, entry + 4.0)

    class FakeSRDetector:
        def nearest_reaction(self, df, current_price, direction, proximity_pct=0.003):
            return SRLevel(price=current_price, kind="support", touches=5, strength=1.0)

    engine = PredictiveSignalEngine(
        signal_refiner=FakeRefiner(),
        orderflow_pipeline=FakeOrderflow(),
        pattern_scanner_fn=fake_detect_patterns,
        risk_manager=FakeRiskManager(),
        sr_detector=FakeSRDetector(),
    )

    df = _bouncing_range_df()
    raw_candles = [[i, 100.0, 101.0, 99.0, 100.0, 10.0] for i in range(30)]
    result = engine.build_signal(
        symbol="BTC/USDT", candles_by_tf={"1h": raw_candles}, atr=1.0,
        orderbook={"bids": [], "asks": []}, pattern_df=df,
    )

    assert result["signal"] is not None
    assert "sr_support" in result["signal"].leading_confirmations
    assert result["signal"].setup_type == "SR_REACTION"


def test_predictive_engine_blocks_when_no_leading_confirmation_at_all():
    from tonybot.strategy.trade_signal import PredictiveSignalEngine

    class FakeRefiner:
        def evaluate(self, symbol, candles_by_tf, atr=0.0, tf_preference=None):
            return {"direction": "BUY", "aegis_score": 70.0, "gates": {}}

    class FakeOrderflow:
        def analyze_orderbook_imbalance(self, orderbook, symbol):
            return None

    def fake_detect_patterns(df):
        return []

    class FakeSRDetector:
        def nearest_reaction(self, df, current_price, direction, proximity_pct=0.003):
            return None

    engine = PredictiveSignalEngine(
        signal_refiner=FakeRefiner(),
        orderflow_pipeline=FakeOrderflow(),
        pattern_scanner_fn=fake_detect_patterns,
        sr_detector=FakeSRDetector(),
    )
    raw_candles = [[i, 100.0, 101.0, 99.0, 100.0, 10.0] for i in range(30)]
    result = engine.build_signal(
        symbol="BTC/USDT", candles_by_tf={"1h": raw_candles}, atr=1.0,
        orderbook=None, pattern_df=_bouncing_range_df(),
    )
    assert result["signal"] is None
    assert "no leading" in result["reason_blocked"].lower()
