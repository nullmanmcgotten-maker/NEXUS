"""
tests/test_chart_ui.py — Tests for the chart timeframe selector and
auto support/resistance overlay in the GUI.

Requires PySide6 + an offscreen Qt platform (set automatically here).
Skipped entirely if PySide6 isn't installed, so this doesn't break CI
environments that only run the headless engine.
"""
from __future__ import annotations

import os
import sys

import numpy as np
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pyside6 = pytest.importorskip("PySide6")


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv)
    yield app


def _bouncing_candles(n=120, seed=1):
    rng = np.random.default_rng(seed)
    prices = []
    level = 100.0
    for i in range(n):
        target = 95.0 if (i // 15) % 2 == 0 else 105.0
        level = level + (target - level) * 0.3 + rng.normal(0, 0.05)
        prices.append(level)
    return [[i * 3600000, p, p + 0.3, p - 0.3, p, 10.0] for i, p in enumerate(prices)]


def test_chart_loads_demo_candles_on_construction(qapp):
    from tonybot.ui.main_window import CandlestickChart
    chart = CandlestickChart()
    assert len(chart.candles) > 0


def test_chart_computes_sr_levels_on_load(qapp):
    from tonybot.ui.main_window import CandlestickChart
    chart = CandlestickChart()
    chart.load_candles(_bouncing_candles())
    assert len(chart.sr_levels) > 0
    kinds = {l.kind for l in chart.sr_levels}
    assert "support" in kinds or "resistance" in kinds


def test_chart_set_loading_state(qapp):
    from tonybot.ui.main_window import CandlestickChart
    chart = CandlestickChart()
    chart.set_loading("4h")
    assert chart._loading_tf == "4h"
    chart.load_candles(_bouncing_candles())
    assert chart._loading_tf is None  # cleared once real candles arrive


def test_chart_paints_without_crashing_with_sr_levels(qapp):
    from tonybot.ui.main_window import CandlestickChart
    chart = CandlestickChart()
    chart.load_candles(_bouncing_candles())
    chart.resize(600, 300)
    chart.show()
    qapp.processEvents()
    # if paintEvent raised, Qt would have logged/aborted — reaching here is the assertion
    assert True


def test_main_window_has_timeframe_combo_with_all_fetched_timeframes(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow

    engine = TradingEngine()
    win = MainWindow(engine)
    items = [win.chart_tf_combo.itemText(i) for i in range(win.chart_tf_combo.count())]
    assert items == ["1m", "5m", "1h", "4h"]
    assert win.chart_tf_combo.currentText() == "1h"


def test_switch_asset_updates_current_symbol_and_redraws(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow

    engine = TradingEngine()
    win = MainWindow(engine)
    win._candles_by_tf["ETHUSDT"] = {"1h": _bouncing_candles(n=40)}
    win.switch_asset("ETHUSDT")
    assert win.current_symbol == "ETHUSDT"
    assert len(win.chart.candles) > 0


def test_timeframe_change_loads_cached_candles_without_refetch(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow

    engine = TradingEngine()
    win = MainWindow(engine)
    win.current_symbol = "BTCUSDT"
    four_h_candles = _bouncing_candles(n=30, seed=9)
    win._candles_by_tf["BTCUSDT"] = {"4h": four_h_candles}

    win._on_chart_timeframe_changed("4h")
    assert win.chart.candles[-1][4] == pytest.approx(four_h_candles[-1][4])


def test_timeframe_change_shows_loading_when_not_cached(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow

    engine = TradingEngine()
    win = MainWindow(engine)
    win.current_symbol = "BTCUSDT"
    win._candles_by_tf["BTCUSDT"] = {}  # nothing cached for any tf yet

    win._on_chart_timeframe_changed("4h")
    assert win.chart._loading_tf == "4h"


def test_on_candles_ready_only_redraws_for_selected_timeframe(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow

    engine = TradingEngine()
    win = MainWindow(engine)
    win.current_symbol = "BTCUSDT"
    win.chart_tf_combo.setCurrentText("4h")

    one_h = _bouncing_candles(n=30, seed=2)
    four_h = _bouncing_candles(n=30, seed=3)

    win.on_candles_ready("BTCUSDT", "1h", one_h)
    # selected tf is "4h" — a 1h update must be cached but not drawn
    assert win._candles_by_tf["BTCUSDT"]["1h"] == one_h
    assert win.chart.candles[-1][4] != pytest.approx(one_h[-1][4])

    win.on_candles_ready("BTCUSDT", "4h", four_h)
    assert win.chart.candles[-1][4] == pytest.approx(four_h[-1][4])
