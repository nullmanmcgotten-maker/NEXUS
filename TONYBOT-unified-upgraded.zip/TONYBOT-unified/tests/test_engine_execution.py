"""
tests/test_engine_execution.py — Unit tests for TradingEngine's order-execution
and position-close loop (tonybot/core/engine.py).

These exercise the bug fixes made to engine.py:
  - db.record_trade() is used (record_open() didn't exist — engine crashed on
    the first live entry before this fix)
  - risk_manager.can_open_position() tuple return is unpacked correctly, so
    the circuit breaker / max-positions gate actually blocks entries
  - open positions are monitored and closed on SL/TP hit, with balance and
    daily PnL updated for real
  - heat_guard is consulted before sizing a new entry

No real exchange or network calls are made — ExchangeManager is monkeypatched.
Run with: pytest tests/test_engine_execution.py -v
"""
from __future__ import annotations

import asyncio
from datetime import date

import pytest

from tonybot.core.engine import TradingEngine
from tonybot.core.db import Database
from tonybot.interfaces import OrderSide, Setup, SetupType


class FakeExchangeManager:
    """Minimal stand-in for ExchangeManager: no network, deterministic fills."""

    def __init__(self, prices: dict):
        self.prices = dict(prices)
        self.orders_placed = []
        self.closes = []

    async def get_price(self, symbol, exchange_id=None):
        return self.prices.get(symbol, 0.0)

    async def place_order(self, symbol, side, quantity, entry_price=0.0,
                           stop_loss=0.0, take_profit=0.0, exchange_id=None, leverage=None):
        self.orders_placed.append((symbol, side, quantity))
        return {"status": "FILLED", "symbol": symbol, "side": side,
                "quantity": quantity, "price": entry_price}

    async def close_position(self, symbol, side, quantity, exchange_id=None,
                              sl_order_id=None, tp_order_id=None):
        price = self.prices.get(symbol, 0.0)
        self.closes.append((symbol, side, quantity, price))
        return {"status": "FILLED", "symbol": symbol, "price": price}

    async def fetch_order_status(self, symbol, order_id, exchange_id=None):
        return None  # no resting exchange orders in this fake — always fall through to price polling

    async def cancel_order_safe(self, symbol, order_id, exchange_id=None):
        return True


def make_engine(tmp_path, prices: dict) -> TradingEngine:
    """Builds a real TradingEngine (real risk/sizing/db logic) but swaps in a
    fake exchange manager and an isolated on-disk test db, so no network call
    or shared database is ever touched."""
    engine = TradingEngine()
    engine.db = Database(db_path=str(tmp_path / "test.db"))
    engine.exchange_manager = FakeExchangeManager(prices)
    return engine


def _open_setup(symbol="BTC/USDT", direction=OrderSide.BUY, entry=100.0, sl=95.0, tp=110.0):
    return Setup(
        symbol=symbol, setup_type=SetupType.BREAKOUT, direction=direction,
        confirmations=4, entry_price=entry, stop_loss=sl, take_profit=tp,
    )


class TestPositionOpening:
    def test_record_trade_used_not_missing_record_open(self, tmp_path):
        """Regression test: engine used to call the non-existent db.record_open()."""
        engine = make_engine(tmp_path, {"BTC/USDT": 100.0})
        trade_id = engine.db.record_trade(
            symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
            stop_loss=95.0, take_profit=110.0, setup_type="BREAKOUT",
            aegis_score=4.0, mode="PAPER",
        )
        assert trade_id is not None
        open_trades = engine.db.get_open_trades()
        assert len(open_trades) == 1

    def test_balance_deducted_on_open(self, tmp_path):
        engine = make_engine(tmp_path, {"BTC/USDT": 100.0})
        starting_balance = engine.balance
        engine.open_positions["BTC/USDT"] = {
            "trade_id": 1, "symbol": "BTC/USDT", "side": "BUY",
            "entry_price": 100.0, "quantity": 1.0, "stop_loss": 95.0,
            "take_profit": 110.0, "notional": 100.0, "opened_at": 0,
        }
        engine.balance -= 100.0
        assert engine.balance == starting_balance - 100.0


class TestPositionMonitoringAndClose:
    def test_take_profit_hit_closes_and_credits_balance(self, tmp_path):
        engine = make_engine(tmp_path, {"BTC/USDT": 111.0})  # price above TP=110
        trade_id = engine.db.record_trade(
            symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
            stop_loss=95.0, take_profit=110.0, mode="PAPER",
        )
        engine.open_positions["BTC/USDT"] = {
            "trade_id": trade_id, "symbol": "BTC/USDT", "side": "BUY",
            "entry_price": 100.0, "quantity": 1.0, "stop_loss": 95.0,
            "take_profit": 110.0, "notional": 100.0, "opened_at": 0,
        }
        engine.balance -= 100.0
        starting_balance = engine.balance

        closed = asyncio.run(engine.monitor_and_close_positions())

        assert len(closed) == 1
        assert closed[0]["close_reason"] == "TP"
        assert "BTC/USDT" not in engine.open_positions
        # balance should get back notional (100) + realized pnl (~11)
        assert engine.balance == pytest.approx(starting_balance + 100.0 + 11.0, abs=0.01)
        assert engine.db.get_open_trades() == []

    def test_stop_loss_hit_closes_at_a_loss(self, tmp_path):
        engine = make_engine(tmp_path, {"BTC/USDT": 94.0})  # price below SL=95
        trade_id = engine.db.record_trade(
            symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
            stop_loss=95.0, take_profit=110.0, mode="PAPER",
        )
        engine.open_positions["BTC/USDT"] = {
            "trade_id": trade_id, "symbol": "BTC/USDT", "side": "BUY",
            "entry_price": 100.0, "quantity": 1.0, "stop_loss": 95.0,
            "take_profit": 110.0, "notional": 100.0, "opened_at": 0,
        }
        closed = asyncio.run(engine.monitor_and_close_positions())
        assert closed[0]["close_reason"] == "SL"
        assert closed[0]["pnl"] < 0

    def test_position_untouched_stays_open(self, tmp_path):
        engine = make_engine(tmp_path, {"BTC/USDT": 102.0})  # between SL and TP
        trade_id = engine.db.record_trade(
            symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
            stop_loss=95.0, take_profit=110.0, mode="PAPER",
        )
        engine.open_positions["BTC/USDT"] = {
            "trade_id": trade_id, "symbol": "BTC/USDT", "side": "BUY",
            "entry_price": 100.0, "quantity": 1.0, "stop_loss": 95.0,
            "take_profit": 110.0, "notional": 100.0, "opened_at": 0,
        }
        closed = asyncio.run(engine.monitor_and_close_positions())
        assert closed == []
        assert "BTC/USDT" in engine.open_positions

    def test_short_position_take_profit(self, tmp_path):
        engine = make_engine(tmp_path, {"ETH/USDT": 88.0})  # below TP for a short
        trade_id = engine.db.record_trade(
            symbol="ETH/USDT", side="SELL", entry_price=100.0, quantity=2.0,
            stop_loss=105.0, take_profit=90.0, mode="PAPER",
        )
        engine.open_positions["ETH/USDT"] = {
            "trade_id": trade_id, "symbol": "ETH/USDT", "side": "SELL",
            "entry_price": 100.0, "quantity": 2.0, "stop_loss": 105.0,
            "take_profit": 90.0, "notional": 200.0, "opened_at": 0,
        }
        closed = asyncio.run(engine.monitor_and_close_positions())
        assert closed[0]["close_reason"] == "TP"
        assert closed[0]["pnl"] == pytest.approx((100.0 - 88.0) * 2.0)


class TestRiskGateWiring:
    def test_can_open_position_tuple_is_unpacked(self, tmp_path):
        """Regression test: engine used to check `if not can_open_position(...)`
        on a (bool, str) tuple, which is always truthy — the gate never fired."""
        engine = make_engine(tmp_path, {})
        engine.risk_manager.max_concurrent_positions = 1
        engine.open_positions["BTC/USDT"] = {
            "trade_id": 1, "symbol": "BTC/USDT", "side": "BUY", "entry_price": 100.0,
            "quantity": 1.0, "stop_loss": 95.0, "take_profit": 110.0,
            "notional": 100.0, "opened_at": 0,
        }
        can_open, reason = engine.risk_manager.can_open_position(len(engine.open_positions), 0.0)
        assert can_open is False
        assert "Max positions" in reason

    def test_circuit_breaker_blocks_new_entries(self, tmp_path):
        engine = make_engine(tmp_path, {})
        engine.risk_manager.circuit_breaker.tripped = True
        can_open, reason = engine.risk_manager.can_open_position(0, 0.0)
        assert can_open is False
        assert "Circuit breaker" in reason
