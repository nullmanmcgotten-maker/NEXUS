"""
tests/test_predictive_engine_wiring.py — Regression tests for wiring
PredictiveSignalEngine (order-flow + pattern leading confirmation on top of
the lagging AEGIS consensus) into the headless async TradingEngine.

Before this change, TradingEngine.process_cycle() drove entries purely off
SetupScanner (lagging technical setups only); PredictiveSignalEngine,
OrderFlowPipeline, and PatternScanner were only ever wired into GUI worker
threads. These tests exercise the headless path end-to-end with network
calls mocked out, so a regression here means the "smart" signal stack has
silently fallen back to GUI-only again.
"""
from __future__ import annotations

import asyncio
import time
from unittest.mock import patch, AsyncMock

import pytest

from tonybot.config import config
from tonybot.core.engine import TradingEngine
from tonybot.strategy.trade_signal import TradeSignal


def _flat_candles(symbol, timeframe="1h", limit=200):
    now = int(time.time() * 1000)
    tf_ms = 3600000
    price = 100.0
    candles = []
    for i in range(limit):
        o = price
        c = o * 1.001
        h = c * 1.001
        l = o * 0.999
        candles.append([now - (limit - i) * tf_ms, o, h, l, c, 10.0])
        price = c
    return candles


def _empty_book(symbol, limit=50):
    return {"bids": [[99, 10]], "asks": [[101, 10]]}


@pytest.fixture
def engine():
    return TradingEngine()


def test_engine_has_predictive_stack_wired(engine):
    """The headless engine must own its own PredictiveSignalEngine + SignalTracker
    instances, not rely on a GUI window to construct them."""
    assert engine.predictive_engine is not None
    assert engine.signal_tracker is not None
    assert engine.signal_refiner is not None


def test_gather_predictive_signal_returns_none_gracefully_on_no_data(engine):
    """No candle data (e.g. exchange unreachable) must degrade to None, never raise."""
    with patch.object(engine.data_source, "fetch_ohlcv_raw", return_value=[]), \
         patch.object(engine.data_source, "fetch_order_book", return_value={"bids": [], "asks": []}):
        result = asyncio.run(engine.gather_predictive_signal("BTC/USDT"))
        assert result is None


def test_process_cycle_executes_a_fired_predictive_signal(engine):
    """When PredictiveSignalEngine fires, process_cycle must size, execute,
    journal, and start tracking it — mirroring what the GUI path already did."""
    from tonybot.config import config
    original_mode = config.TRADING_MODE
    config.TRADING_MODE = "swing"  # isolate to one profile so this test verifies a single fire cleanly
    signal = TradeSignal(
        symbol="BTC/USDT", direction="BUY", setup_type="ORDERFLOW_BREAKOUT",
        entry=100.0, stop_loss=98.0, take_profit=106.0, risk_reward=3.0,
        confidence_pct=72.0, aegis_score=68.0,
        leading_confirmations=["orderflow_imbalance", "pattern:bull_flag"],
        reasoning=["test"], historical_win_rate=0.56, live_win_rate=None, live_sample_size=0,
    )
    try:
        with patch.object(engine.data_source, "fetch_ohlcv_raw", side_effect=_flat_candles), \
             patch.object(engine.data_source, "fetch_order_book", side_effect=_empty_book), \
             patch.object(engine.predictive_engine, "build_signal",
                           return_value={"signal": signal, "aegis": {}, "reason_blocked": ""}):
            results = asyncio.run(engine.process_cycle())
    finally:
        config.TRADING_MODE = original_mode

    assert len(results) == 1
    trade = results[0]
    assert trade["symbol"] == "BTC/USDT"
    assert trade["side"] == "BUY"
    assert trade["setup_type"] == "ORDERFLOW_BREAKOUT"
    assert "BTC/USDT|swing" in engine.open_positions
    assert engine.balance < 10000.0  # notional was deducted

    # journaled to the trade DB
    trades = engine.db.get_recent_trades(5)
    assert any(t["symbol"] == "BTC/USDT" and t["setup_type"] == "ORDERFLOW_BREAKOUT" for t in trades)

    # signal_tracker started tracking this fired signal for live win-rate calibration
    pending = engine.db.get_pending_outcomes("BTC/USDT")
    assert len(pending) == 1
    assert pending[0]["setup_type"] == "ORDERFLOW_BREAKOUT"


def test_process_cycle_skips_symbols_with_open_positions(engine):
    """Already-held symbol+profile combos shouldn't be re-scanned for new entries each cycle."""
    from tonybot.config import config as _config
    engine.open_positions["BTC/USDT|scalp"] = {
        "trade_id": 1, "symbol": "BTC/USDT", "profile": "scalp", "side": "BUY", "entry_price": 100.0,
        "quantity": 1.0, "stop_loss": 98.0, "take_profit": 106.0, "notional": 100.0,
        "opened_at": time.time(),
    }
    engine.open_positions["BTC/USDT|swing"] = {
        "trade_id": 2, "symbol": "BTC/USDT", "profile": "swing", "side": "BUY", "entry_price": 100.0,
        "quantity": 1.0, "stop_loss": 98.0, "take_profit": 106.0, "notional": 100.0,
        "opened_at": time.time(),
    }
    original_symbols = _config.SYMBOLS
    _config.SYMBOLS = ["BTC/USDT"]  # only the already-held symbol this cycle, both profiles held
    try:
        with patch.object(engine, "gather_predictive_signal", new_callable=AsyncMock, return_value=None) as mock_gather, \
             patch.object(engine, "monitor_and_close_positions", new_callable=AsyncMock, return_value=[]):
            asyncio.run(engine.process_cycle())
        mock_gather.assert_not_called()
    finally:
        _config.SYMBOLS = original_symbols


def test_atr_computation_from_raw_candles():
    candles = _flat_candles("BTC/USDT")
    atr = TradingEngine._compute_atr(candles)
    assert atr > 0.0
