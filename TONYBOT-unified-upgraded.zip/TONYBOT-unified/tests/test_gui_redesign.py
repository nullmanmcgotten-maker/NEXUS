"""
tests/test_gui_redesign.py — Tests locking in the sidebar redesign: no
duplicate stats between panels, functioning single-number gauges (replacing
the old three-bar AI Confidence and unlabeled Market Sentiment bar), the
Session card reflecting real TRADING_MODE, and the scanner table actually
matching its own "30 PAIRS" label.
"""
from __future__ import annotations

import os
import sys

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv)
    yield app


def _make_window(qapp):
    from tonybot.core.engine import TradingEngine
    from tonybot.ui.main_window import MainWindow
    engine = TradingEngine()
    return MainWindow(engine)


def test_no_duplicate_balance_widgets_between_panels(qapp):
    """Previously the right panel had its own giant balance/PnL duplicate of
    the left panel's; now only one 'available balance' readout exists and
    it's clearly distinct (labeled 'Available', not another equity hero)."""
    win = _make_window(qapp)
    assert not hasattr(win, "rp_balance")
    assert not hasattr(win, "rp_pnl")
    assert hasattr(win, "available_lbl")
    assert "Available" in win.available_lbl.text()


def test_no_duplicate_performance_stats_between_panels(qapp):
    """Win rate / profit factor / max DD previously appeared in BOTH
    sidebars (dd_lbl/wr_lbl on the left, rp_wr/rp_pf/rp_dd on the right) —
    now they exist exactly once, in the left ACCOUNT card's stat grid."""
    win = _make_window(qapp)
    assert not hasattr(win, "rp_wr")
    assert not hasattr(win, "rp_pf")
    assert not hasattr(win, "rp_dd")
    assert hasattr(win, "wr_val")
    assert hasattr(win, "pf_val")
    assert hasattr(win, "dd_val")


def test_ai_confidence_is_one_gauge_not_three_bars(qapp):
    """The old LOW/MID/HIGH triple-bar encoded a single ml_confidence value
    three redundant, unlabeled ways. Now it's one gauge with a visible number."""
    win = _make_window(qapp)
    assert not hasattr(win, "_ai_low")
    assert not hasattr(win, "_ai_mid")
    assert not hasattr(win, "_ai_high")
    assert hasattr(win, "ai_confidence_bar")
    assert win.ai_confidence_bar.isTextVisible()


def test_sentiment_gauge_shows_visible_number_and_descriptor(qapp):
    win = _make_window(qapp)
    assert win.sentiment_bar.isTextVisible()
    assert hasattr(win, "sentiment_desc_lbl")


def test_ai_confidence_updates_with_visible_value_and_color(qapp):
    win = _make_window(qapp)
    win.on_aegis_result({
        "direction": "BUY", "aegis_score": 72.0, "gates": {},
        "mtf_bias": "BUY", "sentiment_score": 0.2, "ml_confidence": 0.81,
    })
    assert win.ai_confidence_bar.value() == 81
    assert "81" in win.ai_confidence_bar.text()
    # sidebar "last signal" teaser updates too
    assert "BUY" in win.last_signal_lbl.text()
    assert "72" in win.last_signal_meta_lbl.text()


def test_sentiment_updates_with_descriptor(qapp):
    win = _make_window(qapp)
    win.on_sentiment_ready({"composite": 0.6, "fear_greed_index": 80, "headline_count": 5})
    assert win.sentiment_desc_lbl.text() in ("Greed", "Bullish")
    win.on_sentiment_ready({"composite": -0.6, "fear_greed_index": 15, "headline_count": 5})
    assert win.sentiment_desc_lbl.text() in ("Fear", "Bearish")


def test_session_card_reflects_trading_mode(qapp):
    from tonybot.config import config
    original = config.TRADING_MODE
    config.TRADING_MODE = "both"
    try:
        win = _make_window(qapp)
        assert win.trading_mode_lbl.text() == "BOTH"
        assert "scalp" in win.active_profiles_lbl.text()
        assert "swing" in win.active_profiles_lbl.text()
    finally:
        config.TRADING_MODE = original


def test_scanner_table_matches_its_own_30_pairs_label(qapp):
    """Was hardcoded to 8 rows while the header label said '30 PAIRS' —
    a real mismatch, not just a visual gap."""
    win = _make_window(qapp)
    assert win.scanner_table.rowCount() == 30


def test_scanner_table_includes_configured_symbols(qapp):
    from tonybot.config import config
    win = _make_window(qapp)
    table_symbols = {
        win.scanner_table.item(r, 0).text() for r in range(win.scanner_table.rowCount())
    }
    for sym in config.SYMBOLS:
        assert sym.replace("/", "") in table_symbols


def test_stat_grid_updates_from_portfolio_refresh(qapp):
    win = _make_window(qapp)
    win._update_portfolio_labels()
    # should not raise, and should have touched the consolidated stat cells
    assert win.op_val.text() != ""
    assert win.capital_pct_lbl.text().endswith("%")
