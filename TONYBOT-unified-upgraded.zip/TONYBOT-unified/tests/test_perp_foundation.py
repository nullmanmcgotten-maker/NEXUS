"""
tests/test_perp_foundation.py — Unit tests for the perp trading foundation.

Run with:  pytest tests/test_perp_foundation.py -v

These are pure unit tests against math/logic only — no network, no exchange
calls, no PySide6 required. They're the fast layer of the burn-in process
described in TESTING.md; they don't replace paper-mode/testnet soak testing,
but they catch regressions in the risk math instantly and should pass
before you ever move on to that stage.
"""
import math
import numpy as np
import pandas as pd
import pytest

from tonybot.risk.liquidation import (
    calculate_liquidation_price, evaluate_liquidation_risk,
    stop_loss_beats_liquidation, build_liquidation_heatmap,
)
from tonybot.risk.position_sizing import KellySizer, apply_funding_drag_penalty
from tonybot.risk.monte_carlo import run_monte_carlo, pooled_returns_from_positions
from tonybot.strategy.correlation import compute_correlation_matrix
from tonybot.strategy.pattern_scanner import detect_patterns
from tonybot.orderflow.pipeline import OrderFlowPipeline


# ---------------------------------------------------------------- liquidation ---
class TestLiquidation:
    def test_long_liquidation_below_entry(self):
        liq = calculate_liquidation_price(100_000, leverage=10, side="LONG")
        assert liq < 100_000
        assert math.isclose(liq, 90_500.0, rel_tol=1e-6)

    def test_short_liquidation_above_entry(self):
        liq = calculate_liquidation_price(100_000, leverage=10, side="SHORT")
        assert liq > 100_000
        assert math.isclose(liq, 109_500.0, rel_tol=1e-6)

    def test_higher_leverage_is_closer_to_entry(self):
        liq_low = calculate_liquidation_price(100_000, leverage=5, side="LONG")
        liq_high = calculate_liquidation_price(100_000, leverage=50, side="LONG")
        assert liq_high > liq_low  # 50x liquidates at a higher (closer) price than 5x

    def test_unsafe_leverage_flagged(self):
        result = evaluate_liquidation_risk(100_000, leverage=50, side="LONG", min_distance_pct=0.10)
        assert result.is_safe is False
        result_safe = evaluate_liquidation_risk(100_000, leverage=3, side="LONG", min_distance_pct=0.10)
        assert result_safe.is_safe is True

    def test_stop_loss_beats_liquidation_long(self):
        liq = calculate_liquidation_price(100_000, leverage=10, side="LONG")  # 90,500
        assert stop_loss_beats_liquidation(100_000, 92_000, liq, "LONG") is True
        assert stop_loss_beats_liquidation(100_000, 89_000, liq, "LONG") is False

    def test_stop_loss_beats_liquidation_short(self):
        liq = calculate_liquidation_price(100_000, leverage=10, side="SHORT")  # 109,500
        assert stop_loss_beats_liquidation(100_000, 108_000, liq, "SHORT") is True
        assert stop_loss_beats_liquidation(100_000, 111_000, liq, "SHORT") is False

    def test_heatmap_ordered_by_price(self):
        buckets = build_liquidation_heatmap(100_000)
        prices = [b.price for b in buckets]
        assert prices == sorted(prices)
        assert any(b.side == "LONG" for b in buckets)
        assert any(b.side == "SHORT" for b in buckets)


# ------------------------------------------------------------ position sizing ---
class TestPositionSizing:
    def test_kelly_sizer_scales_with_confirmations(self):
        sizer = KellySizer()
        full = sizer.size(balance=10_000, confirmations=4, entry=100, stop_loss=95)
        partial = sizer.size(balance=10_000, confirmations=3, entry=100, stop_loss=95)
        minimal = sizer.size(balance=10_000, confirmations=2, entry=100, stop_loss=95)
        none = sizer.size(balance=10_000, confirmations=1, entry=100, stop_loss=95)
        assert full.risk_pct > partial.risk_pct > minimal.risk_pct > 0
        assert none.quantity == 0

    def test_funding_drag_shrinks_paying_position(self):
        sizer = KellySizer()
        pos = sizer.size(balance=10_000, confirmations=4, entry=100, stop_loss=95)
        penalized = apply_funding_drag_penalty(
            pos, annualized_funding_pct=0.60, expected_holding_days=30, side="LONG",
        )
        assert penalized.quantity < pos.quantity
        assert penalized.quantity > 0  # never fully zeroed out by drag alone

    def test_funding_drag_ignores_receiving_side(self):
        """A SHORT during positive funding RECEIVES funding — no penalty."""
        sizer = KellySizer()
        pos = sizer.size(balance=10_000, confirmations=4, entry=100, stop_loss=105)
        result = apply_funding_drag_penalty(
            pos, annualized_funding_pct=0.60, expected_holding_days=30, side="SHORT",
        )
        assert result.quantity == pos.quantity

    def test_funding_drag_penalty_capped(self):
        sizer = KellySizer()
        pos = sizer.size(balance=10_000, confirmations=4, entry=100, stop_loss=95)
        extreme = apply_funding_drag_penalty(
            pos, annualized_funding_pct=5.0, expected_holding_days=365, side="LONG",
            max_drag_penalty=0.5,
        )
        assert extreme.quantity >= pos.quantity * 0.5 - 1e-9


# ------------------------------------------------------------------ analytics ---
class TestMonteCarlo:
    def test_insufficient_history_returns_none(self):
        result = run_monte_carlo(starting_value=1000, historical_returns=[0.01, -0.01], years=1)
        assert result is None

    def test_reasonable_percentile_ordering(self):
        rng = np.random.default_rng(1)
        returns = rng.normal(0.0005, 0.02, 100).tolist()
        result = run_monte_carlo(starting_value=10_000, historical_returns=returns, years=1, simulations=300, seed=1)
        assert result is not None
        p = result.percentiles
        assert p[5] <= p[25] <= p[50] <= p[75] <= p[95]
        assert 0 <= result.probability_of_loss_pct <= 100


class TestCorrelation:
    def test_identical_series_perfectly_correlated(self):
        prices = [100 + i for i in range(30)]
        matrix = compute_correlation_matrix({"A": prices, "B": prices})
        assert matrix.get("A", "B") == pytest.approx(1.0, abs=0.01)

    def test_uncorrelated_pair_below_threshold(self):
        rng = np.random.default_rng(2)
        a = list(np.cumsum(rng.normal(0, 1, 30)) + 100)
        b = list(np.cumsum(rng.normal(0, 1, 30)) + 100)
        matrix = compute_correlation_matrix({"A": a, "B": b})
        pairs = matrix.highly_correlated_pairs(threshold=0.99)
        assert pairs == []  # extremely unlikely two independent random walks hit 0.99


class TestPatternScanner:
    def test_short_history_returns_empty(self):
        df = pd.DataFrame({"open": [1]*10, "high": [1]*10, "low": [1]*10, "close": [1]*10})
        assert detect_patterns(df) == []

    def test_double_top_detected_in_synthetic_data(self):
        n = 60
        prices = [100 + 10 * math.sin(i / 5) + i * 0.02 for i in range(n)]
        df = pd.DataFrame({
            "open": prices, "high": [p * 1.01 for p in prices],
            "low": [p * 0.99 for p in prices], "close": prices,
        })
        matches = detect_patterns(df)
        assert len(matches) > 0
        assert all(m.confidence in ("High", "Medium", "Low") for m in matches)


class TestOrderFlow:
    def test_large_trade_detected(self):
        pipe = OrderFlowPipeline(large_trade_usd=1000)
        trades = [{"price": 100, "qty": 20, "isBuyerMaker": False, "symbol": "BTC/USDT"}]
        result = pipe.process_trades(trades)
        assert result["large_trades_count"] == 1
        assert result["cvd"] == 20

    def test_imbalance_flags_whale_side(self):
        pipe = OrderFlowPipeline()
        bids = [[100 - i * 0.1, 50] for i in range(15)]   # heavy bid wall
        asks = [[100 + i * 0.1, 1] for i in range(15)]
        snap = pipe.analyze_orderbook_imbalance({"bids": bids, "asks": asks}, "BTC/USDT")
        assert snap is not None
        assert snap.dominant_side == "BID"
        assert snap.whale_alert is True

    def test_insufficient_depth_returns_none(self):
        pipe = OrderFlowPipeline()
        snap = pipe.analyze_orderbook_imbalance({"bids": [[100, 1]], "asks": [[101, 1]]}, "BTC/USDT")
        assert snap is None
