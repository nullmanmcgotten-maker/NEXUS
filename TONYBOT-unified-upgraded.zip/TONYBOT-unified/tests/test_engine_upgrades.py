"""
tests/test_engine_upgrades.py — Regression tests for:
  1. MLEnsemble's richer feature set (setup-type one-hot, risk_reward, sentiment)
     actually changing predictions, not just being accepted and ignored.
  2. SignalRefiner sharing the engine's trained MLEnsemble instance instead of
     silently constructing its own untrained one.
  3. BacktestEngine's new predictive mode running without crashing and staying
     backward compatible with the legacy mode.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from tonybot.ml.ensemble import MLEnsemble, _encode_features, SETUP_FAMILIES, HAS_LIGHTGBM
from tonybot.backtest.engine import BacktestEngine, _df_window_to_raw_candles, _compute_atr


def _make_ohlcv(n=200, seed=7):
    rng = np.random.default_rng(seed)
    idx = pd.date_range(end=pd.Timestamp.now(tz="UTC"), periods=n, freq="h")
    price = 100 + np.cumsum(rng.normal(0, 1, n))
    price = np.maximum(price, 5)
    return pd.DataFrame({
        "open": price,
        "high": price + rng.uniform(0, 1, n),
        "low": price - rng.uniform(0, 1, n),
        "close": price + rng.normal(0, 0.3, n),
        "volume": rng.uniform(10, 100, n),
    }, index=idx)


def test_encode_features_one_hot_setup_family():
    base = {"tech_confidence": 0.7, "tf_confidence": 0.5, "confirmations": 3, "side": "BUY"}
    vec_orderflow = _encode_features({**base, "setup_type": "ORDERFLOW_BREAKOUT"})
    vec_pattern = _encode_features({**base, "setup_type": "PATTERN_CONFLUENCE"})
    # same base features, different setup family -> different encoded vectors
    assert vec_orderflow != vec_pattern
    # exactly one one-hot slot set for a known family, rest zero
    one_hot_orderflow = vec_orderflow[-len(SETUP_FAMILIES):]
    assert sum(one_hot_orderflow) == 1.0
    assert one_hot_orderflow[SETUP_FAMILIES.index("ORDERFLOW_BREAKOUT")] == 1.0


def test_encode_features_handles_missing_keys_gracefully():
    # Old-style narrow feature dict (no setup_type/risk_reward/sentiment) must not crash.
    vec = _encode_features({"tech_confidence": 0.6, "tf_confidence": 0.5, "confirmations": 3, "side": "SELL"})
    assert len(vec) == 6 + len(SETUP_FAMILIES)
    assert all(v == 0.0 for v in vec[-len(SETUP_FAMILIES):])  # no setup_type -> no one-hot match


@pytest.mark.skipif(not HAS_LIGHTGBM, reason="lightgbm not installed")
def test_ml_ensemble_trains_and_differentiates_setup_families():
    """Feed a training set where ORDERFLOW_BREAKOUT setups mostly win and
    REVERSAL_DIVERGENCE setups mostly lose, everything else held constant —
    the richer feature set should let the model actually separate them,
    which the old 4-feature version structurally couldn't (setup family
    wasn't a feature at all)."""
    rng = np.random.default_rng(0)
    records = []
    for _ in range(60):
        records.append({
            "tech_confidence": 0.65, "tf_confidence": 0.5, "confirmations": 3, "side": "BUY",
            "risk_reward": 2.0, "sentiment_score": 0.0, "setup_type": "ORDERFLOW_BREAKOUT",
            "pnl_usd": rng.uniform(1, 50) if rng.random() < 0.8 else -rng.uniform(1, 50),
        })
        records.append({
            "tech_confidence": 0.65, "tf_confidence": 0.5, "confirmations": 3, "side": "BUY",
            "risk_reward": 2.0, "sentiment_score": 0.0, "setup_type": "REVERSAL_DIVERGENCE",
            "pnl_usd": rng.uniform(1, 50) if rng.random() < 0.2 else -rng.uniform(1, 50),
        })

    ens = MLEnsemble(min_confidence=0.5)
    assert ens.train(records) is True
    assert ens.is_trained

    conf_orderflow = ens.predict_confidence({
        "tech_confidence": 0.65, "tf_confidence": 0.5, "confirmations": 3, "side": "BUY",
        "risk_reward": 2.0, "sentiment_score": 0.0, "setup_type": "ORDERFLOW_BREAKOUT",
    })
    conf_reversal = ens.predict_confidence({
        "tech_confidence": 0.65, "tf_confidence": 0.5, "confirmations": 3, "side": "BUY",
        "risk_reward": 2.0, "sentiment_score": 0.0, "setup_type": "REVERSAL_DIVERGENCE",
    })
    assert conf_orderflow > conf_reversal


def test_engine_shares_trained_ml_ensemble_with_signal_refiner():
    from tonybot.core.engine import TradingEngine
    engine = TradingEngine()
    assert engine.signal_refiner.ml_ensemble is engine.ml_ensemble


def test_backtest_legacy_mode_unchanged():
    df = _make_ohlcv()
    eng = BacktestEngine(initial_balance=10000)
    result = eng.run("BTC/USDT", df)  # default mode="legacy"
    assert result.symbol == "BTC/USDT"
    assert result.total_trades >= 0


def test_backtest_predictive_mode_runs_without_crashing():
    df = _make_ohlcv(n=180)
    eng = BacktestEngine(initial_balance=10000)
    result = eng.run("BTC/USDT", df, mode="predictive", lookback_bars=80)
    assert result.symbol == "BTC/USDT"
    assert result.total_trades >= 0
    assert result.win_rate >= 0.0


def test_df_window_to_raw_candles_roundtrip():
    df = _make_ohlcv(n=30)
    raw = _df_window_to_raw_candles(df)
    assert len(raw) == 30
    assert raw[0][4] == pytest.approx(df.iloc[0]["close"])
    atr = _compute_atr(raw)
    assert atr >= 0.0
