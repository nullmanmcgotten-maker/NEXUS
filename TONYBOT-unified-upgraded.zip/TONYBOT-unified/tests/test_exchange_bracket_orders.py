"""
tests/test_exchange_bracket_orders.py — Regression tests for real exchange-side
stop-loss/take-profit protection on live perp/swap positions.

Before this change, ExchangeManager.place_order() for MARKET_TYPE == "swap"
only sent the entry order — stop_loss/take_profit were never placed as real
orders on the exchange. Protection existed *only* as this bot's own polling
loop (monitor_and_close_positions) comparing the latest fetched price against
the position's stop/target values. Between polls, and if the process crashed,
lost network, or got rate-limited, a live leveraged position had zero actual
protection resting on the exchange — a real path to losses blowing well past
the intended stop distance. These tests lock in:
  1. place_order() sends real STOP_MARKET/TAKE_PROFIT_MARKET bracket orders
     for Binance USDM swap fills.
  2. Non-Binance swap exchanges get a clear "unprotected" flag instead of a
     false sense of safety.
  3. close_position() cancels any leftover bracket order so nothing orphans.
  4. The engine's monitor loop checks exchange order status first and treats
     an already-filled bracket order as the close event, instead of also
     sending a redundant close_position() call.
"""
from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest

from tonybot.config import config
from tonybot.exchanges.manager import ExchangeManager
from tonybot.core.engine import TradingEngine
from tonybot.core.db import Database


class FakeCCXTExchange:
    """Stand-in for ccxt's exchange object — records calls, returns canned fills."""

    def __init__(self):
        self.created_orders = []
        self.cancelled = []
        self.order_statuses = {}  # order_id -> status dict

    def create_order(self, symbol, type_, side, amount, price=None, params=None):
        order_id = f"order_{len(self.created_orders)}"
        order = {"id": order_id, "symbol": symbol, "type": type_, "side": side,
                  "amount": amount, "price": price, "params": params or {},
                  "average": price or 100.0}
        self.created_orders.append(order)
        return order

    def cancel_order(self, order_id, symbol):
        self.cancelled.append(order_id)
        return {"id": order_id, "status": "canceled"}

    def fetch_order(self, order_id, symbol):
        return self.order_statuses.get(order_id, {"id": order_id, "status": "open"})


class FakeCCXTSource:
    def __init__(self):
        self.exchange = FakeCCXTExchange()


@pytest.fixture
def swap_live_config():
    """Flips config to live swap mode for the duration of the test, restores after."""
    saved = (config.MARKET_TYPE, config.PAPER_MODE, config.LIVE_TRADING, config.EXCHANGE_ID)
    config.MARKET_TYPE = "swap"
    config.PAPER_MODE = False
    config.LIVE_TRADING = True
    config.EXCHANGE_ID = "binance"
    yield
    config.MARKET_TYPE, config.PAPER_MODE, config.LIVE_TRADING, config.EXCHANGE_ID = saved


def test_place_order_swap_binance_creates_real_sl_tp_brackets(swap_live_config):
    em = ExchangeManager.__new__(ExchangeManager)  # skip __init__'s real exchange connections
    em.primary_client = None
    em.market_type = "swap"
    fake_src = FakeCCXTSource()
    em.ccxt_sources = {"binance": fake_src}
    em.perp_sources = {}

    result = asyncio.run(em.place_order(
        symbol="BTC/USDT", side="BUY", quantity=1.0,
        entry_price=100.0, stop_loss=98.0, take_profit=106.0,
    ))

    assert result["status"] == "FILLED"
    assert result["protected_by_exchange"] is True
    assert result["sl_order_id"] is not None
    assert result["tp_order_id"] is not None

    order_types = [o["type"] for o in fake_src.exchange.created_orders]
    assert "STOP_MARKET" in order_types
    assert "TAKE_PROFIT_MARKET" in order_types

    sl_order = next(o for o in fake_src.exchange.created_orders if o["type"] == "STOP_MARKET")
    assert sl_order["params"]["stopPrice"] == 98.0
    assert sl_order["params"]["reduceOnly"] is True
    assert sl_order["side"] == "sell"  # opposite of the BUY entry


def test_place_order_swap_non_binance_flags_unprotected(swap_live_config):
    config.EXCHANGE_ID = "bybit"
    em = ExchangeManager.__new__(ExchangeManager)
    em.primary_client = None
    em.market_type = "swap"
    fake_src = FakeCCXTSource()
    em.ccxt_sources = {"bybit": fake_src}
    em.perp_sources = {}

    result = asyncio.run(em.place_order(
        symbol="BTC/USDT", side="BUY", quantity=1.0,
        entry_price=100.0, stop_loss=98.0, take_profit=106.0,
    ))

    assert result["status"] == "FILLED"
    assert result["protected_by_exchange"] is False
    # only the entry order was created — no bracket orders attempted for an
    # exchange we haven't implemented native brackets for
    assert len(fake_src.exchange.created_orders) == 1


def test_place_order_bracket_failure_falls_back_gracefully(swap_live_config):
    em = ExchangeManager.__new__(ExchangeManager)
    em.primary_client = None
    em.market_type = "swap"
    fake_src = FakeCCXTSource()

    call_count = {"n": 0}
    original_create = fake_src.exchange.create_order

    def flaky_create_order(symbol, type_, side, amount, price=None, params=None):
        call_count["n"] += 1
        if call_count["n"] > 1:  # entry succeeds, bracket orders fail
            raise RuntimeError("exchange rejected stop order")
        return original_create(symbol, type_, side, amount, price=price, params=params)

    fake_src.exchange.create_order = flaky_create_order
    em.ccxt_sources = {"binance": fake_src}
    em.perp_sources = {}

    result = asyncio.run(em.place_order(
        symbol="BTC/USDT", side="BUY", quantity=1.0,
        entry_price=100.0, stop_loss=98.0, take_profit=106.0,
    ))

    # entry still filled even though bracket placement failed
    assert result["status"] == "FILLED"
    assert result["protected_by_exchange"] is False


def test_close_position_cancels_leftover_bracket_orders(swap_live_config):
    em = ExchangeManager.__new__(ExchangeManager)
    em.primary_client = None
    em.market_type = "swap"
    fake_src = FakeCCXTSource()
    em.ccxt_sources = {"binance": fake_src}
    em.perp_sources = {}

    asyncio.run(em.close_position(
        symbol="BTC/USDT", side="BUY", quantity=1.0,
        sl_order_id="sl_123", tp_order_id="tp_456",
    ))

    assert "sl_123" in fake_src.exchange.cancelled
    assert "tp_456" in fake_src.exchange.cancelled


def test_engine_reconciles_already_filled_exchange_bracket(tmp_path):
    """When the exchange's own SL order has already filled, the monitor loop
    should recognize that as the close event rather than also sending a
    redundant close_position() call based on price polling."""
    engine = TradingEngine()
    engine.db = Database(db_path=str(tmp_path / "test.db"))

    close_position_called = {"count": 0}

    class FakeExchangeManager:
        async def get_price(self, symbol, exchange_id=None):
            return 97.0  # would also trigger price-based SL if reconciliation didn't short-circuit first

        async def fetch_order_status(self, symbol, order_id, exchange_id=None):
            if order_id == "sl_order_1":
                return {"id": order_id, "status": "closed", "average": 97.5}
            return {"id": order_id, "status": "open"}

        async def cancel_order_safe(self, symbol, order_id, exchange_id=None):
            return True

        async def close_position(self, *a, **kw):
            close_position_called["count"] += 1
            return {"status": "FILLED", "price": 97.0}

    engine.exchange_manager = FakeExchangeManager()

    trade_id = engine.db.record_trade(
        symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
        stop_loss=98.0, take_profit=106.0, mode="LIVE",
    )
    engine.open_positions["BTC/USDT"] = {
        "trade_id": trade_id, "symbol": "BTC/USDT", "side": "BUY",
        "entry_price": 100.0, "quantity": 1.0, "stop_loss": 98.0, "take_profit": 106.0,
        "notional": 100.0, "opened_at": 0.0,
        "sl_order_id": "sl_order_1", "tp_order_id": "tp_order_1",
        "protected_by_exchange": True,
    }

    closed = asyncio.run(engine.monitor_and_close_positions())

    assert len(closed) == 1
    assert closed[0]["close_reason"] == "SL"
    assert closed[0]["exit_price"] == 97.5
    assert "BTC/USDT" not in engine.open_positions
    # the redundant price-polling close path must NOT have also fired
    assert close_position_called["count"] == 0


def test_engine_falls_through_to_price_polling_when_no_bracket_orders(tmp_path):
    """Positions without sl_order_id/tp_order_id (paper mode, or unprotected
    live) must still be monitored via the original price-based check."""
    engine = TradingEngine()
    engine.db = Database(db_path=str(tmp_path / "test.db"))

    class FakeExchangeManager:
        async def get_price(self, symbol, exchange_id=None):
            return 97.0  # below stop_loss for a BUY

        async def close_position(self, *a, **kw):
            return {"status": "FILLED", "price": 97.0}

    engine.exchange_manager = FakeExchangeManager()
    trade_id = engine.db.record_trade(
        symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
        stop_loss=98.0, take_profit=106.0, mode="PAPER",
    )
    engine.open_positions["BTC/USDT"] = {
        "trade_id": trade_id, "symbol": "BTC/USDT", "side": "BUY",
        "entry_price": 100.0, "quantity": 1.0, "stop_loss": 98.0, "take_profit": 106.0,
        "notional": 100.0, "opened_at": 0.0,
    }

    closed = asyncio.run(engine.monitor_and_close_positions())
    assert len(closed) == 1
    assert closed[0]["close_reason"] == "SL"
