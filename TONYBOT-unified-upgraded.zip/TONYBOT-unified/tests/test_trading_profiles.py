"""
tests/test_trading_profiles.py — Tests for concurrent scalp + swing trading
profiles (TRADING_MODE="both" by default): a symbol can hold a scalp position
and a swing position at the same time, sized and risk-managed independently,
using different timeframes and ATR multiples for each.
"""
from __future__ import annotations

import asyncio
import time
from unittest.mock import patch, AsyncMock

import pytest

from tonybot.config import config
from tonybot.core.engine import TradingEngine, TRADING_PROFILES, _active_profiles, _position_key, _split_position_key
from tonybot.strategy.trade_signal import TradeSignal


def test_active_profiles_both_by_default():
    original = config.TRADING_MODE
    config.TRADING_MODE = "both"
    try:
        assert set(_active_profiles()) == {"scalp", "swing"}
    finally:
        config.TRADING_MODE = original


def test_active_profiles_single_mode():
    original = config.TRADING_MODE
    config.TRADING_MODE = "scalp"
    try:
        assert _active_profiles() == ["scalp"]
    finally:
        config.TRADING_MODE = original


def test_active_profiles_unknown_mode_falls_back_to_swing():
    original = config.TRADING_MODE
    config.TRADING_MODE = "banana"
    try:
        assert _active_profiles() == ["swing"]
    finally:
        config.TRADING_MODE = original


def test_position_key_roundtrip():
    key = _position_key("BTC/USDT", "scalp")
    assert key == "BTC/USDT|scalp"
    symbol, profile = _split_position_key(key)
    assert symbol == "BTC/USDT"
    assert profile == "scalp"


def test_split_position_key_backward_compat_bare_symbol():
    symbol, profile = _split_position_key("BTC/USDT")
    assert symbol == "BTC/USDT"
    assert profile == "swing"  # sensible default for pre-existing bare-symbol positions


def test_scalp_and_swing_profiles_have_distinct_risk_params():
    scalp = TRADING_PROFILES["scalp"]
    swing = TRADING_PROFILES["swing"]
    assert scalp["sl_atr_mult"] < swing["sl_atr_mult"]
    assert scalp["tp_atr_mult"] < swing["tp_atr_mult"]
    assert scalp["tf_preference"] != swing["tf_preference"]
    assert "1m" in scalp["tf_preference"]
    assert "4h" in swing["tf_preference"]


def test_gather_predictive_signal_passes_profile_params_to_build_signal():
    """The profile's tf_preference/ATR mults must actually reach build_signal,
    not just exist as unused config."""
    engine = TradingEngine()
    captured = {}

    def fake_build_signal(**kwargs):
        captured.update(kwargs)
        return {"signal": None, "aegis": {}, "reason_blocked": "test"}

    def fake_ohlcv(symbol, timeframe="1h", limit=200):
        return [[i, 100.0, 101.0, 99.0, 100.0, 10.0] for i in range(60)]

    with patch.object(engine.data_source, "fetch_ohlcv_raw", side_effect=fake_ohlcv), \
         patch.object(engine.data_source, "fetch_order_book", return_value={"bids": [], "asks": []}), \
         patch.object(engine.predictive_engine, "build_signal", side_effect=fake_build_signal):
        asyncio.run(engine.gather_predictive_signal("BTC/USDT", profile="scalp"))

    assert captured["tf_preference"] == TRADING_PROFILES["scalp"]["tf_preference"]
    assert captured["sl_atr_mult"] == TRADING_PROFILES["scalp"]["sl_atr_mult"]
    assert captured["tp_atr_mult"] == TRADING_PROFILES["scalp"]["tp_atr_mult"]


def test_process_cycle_can_open_both_profiles_on_same_symbol():
    """With TRADING_MODE='both', a symbol firing on both profiles should end
    up with two independent open positions, not one overwriting the other."""
    engine = TradingEngine()
    original_mode = config.TRADING_MODE
    original_symbols = config.SYMBOLS
    config.TRADING_MODE = "both"
    config.SYMBOLS = ["BTC/USDT"]

    def make_signal(profile_tag):
        return TradeSignal(
            symbol="BTC/USDT", direction="BUY", setup_type="ORDERFLOW_BREAKOUT",
            entry=100.0, stop_loss=98.0, take_profit=106.0, risk_reward=3.0,
            confidence_pct=72.0, aegis_score=68.0,
            leading_confirmations=["orderflow_imbalance"],
            reasoning=[f"test {profile_tag}"], historical_win_rate=0.56,
            live_win_rate=None, live_sample_size=0,
        )

    async def fake_gather(symbol, profile="swing"):
        return make_signal(profile)

    try:
        with patch.object(engine, "gather_predictive_signal", side_effect=fake_gather), \
             patch.object(engine, "monitor_and_close_positions", new_callable=AsyncMock, return_value=[]):
            results = asyncio.run(engine.process_cycle())
    finally:
        config.TRADING_MODE = original_mode
        config.SYMBOLS = original_symbols

    assert len(results) == 2
    assert "BTC/USDT|scalp" in engine.open_positions
    assert "BTC/USDT|swing" in engine.open_positions
    # independently sized/tracked positions, not the same dict object
    assert engine.open_positions["BTC/USDT|scalp"] is not engine.open_positions["BTC/USDT|swing"]


def test_monitor_uses_bare_symbol_for_exchange_calls_not_the_composite_key(tmp_path):
    """get_price/close_position must be called with the plain symbol
    ('BTC/USDT'), never the internal 'BTC/USDT|scalp' bookkeeping key."""
    from tonybot.core.db import Database

    engine = TradingEngine()
    engine.db = Database(db_path=str(tmp_path / "test.db"))
    calls = {"get_price_symbols": []}

    class FakeExchangeManager:
        async def get_price(self, symbol, exchange_id=None):
            calls["get_price_symbols"].append(symbol)
            return 97.0

        async def close_position(self, *a, **kw):
            return {"status": "FILLED", "price": 97.0}

    engine.exchange_manager = FakeExchangeManager()
    trade_id = engine.db.record_trade(
        symbol="BTC/USDT", side="BUY", entry_price=100.0, quantity=1.0,
        stop_loss=98.0, take_profit=106.0, mode="PAPER",
    )
    engine.open_positions["BTC/USDT|scalp"] = {
        "trade_id": trade_id, "symbol": "BTC/USDT", "profile": "scalp", "side": "BUY",
        "entry_price": 100.0, "quantity": 1.0, "stop_loss": 98.0, "take_profit": 106.0,
        "notional": 100.0, "opened_at": time.time(),
    }

    asyncio.run(engine.monitor_and_close_positions())
    assert calls["get_price_symbols"] == ["BTC/USDT"]
