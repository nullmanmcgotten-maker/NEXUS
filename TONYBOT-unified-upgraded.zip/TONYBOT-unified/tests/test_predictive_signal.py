"""
tests/test_predictive_signal.py — Unit tests for PredictiveSignalEngine
and SignalTracker (live signal accuracy tracking).

Run with: pytest tests/test_predictive_signal.py -v
No network, no GUI required — uses a temp sqlite DB and synthetic candles.
"""
import os
import tempfile
import time

import numpy as np
import pandas as pd
import pytest

from tonybot.core.db import Database
from tonybot.core.signal_tracker import SignalTracker
from tonybot.strategy.trade_signal import PredictiveSignalEngine, TradeSignal, PRIOR_WIN_RATES
from tonybot.risk.risk_manager import RiskManager


def _make_trending_candles(n=60, start=100.0, step=0.6, tf_ms=3_600_000):
    """Monotonically rising candles -> lagging indicators will eventually agree BUY."""
    rows = []
    price = start
    ts = int(time.time() * 1000) - n * tf_ms
    for i in range(n):
        o = price
        c = price + step
        h = c + 0.2
        l = o - 0.2
        v = 1000 + i
        rows.append([ts + i * tf_ms, o, h, l, c, v])
        price = c
    return rows


@pytest.fixture
def tmp_db():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    db = Database(db_path=path)
    yield db
    db.close()
    os.remove(path)


class TestSignalTracker:
    def test_log_and_resolve_win(self, tmp_db):
        tracker = SignalTracker(tmp_db)
        sig = TradeSignal(
            symbol="BTC/USDT", direction="BUY", setup_type="ORDERFLOW_BREAKOUT",
            entry=100.0, stop_loss=98.0, take_profit=104.0, risk_reward=2.0,
            confidence_pct=70.0, aegis_score=80.0,
        )
        outcome_id = tracker.log_signal(sig)
        assert outcome_id > 0

        pending = tmp_db.get_pending_outcomes("BTC/USDT")
        assert len(pending) == 1

        resolved = tracker.resolve_pending("BTC/USDT", high=105.0, low=99.0)
        assert resolved == [(outcome_id, "WIN")]

        wr, n = tracker.get_win_rate("ORDERFLOW_BREAKOUT")
        assert n == 1
        assert wr == 1.0

    def test_log_and_resolve_loss(self, tmp_db):
        tracker = SignalTracker(tmp_db)
        sig = TradeSignal(
            symbol="ETH/USDT", direction="SELL", setup_type="PATTERN_CONFLUENCE",
            entry=50.0, stop_loss=52.0, take_profit=45.0, risk_reward=2.5,
            confidence_pct=65.0, aegis_score=75.0,
        )
        tracker.log_signal(sig)
        resolved = tracker.resolve_pending("ETH/USDT", high=52.5, low=48.0)
        assert resolved[0][1] == "LOSS"
        wr, n = tracker.get_win_rate("PATTERN_CONFLUENCE")
        assert n == 1 and wr == 0.0

    def test_stop_loss_takes_precedence_on_same_tick(self, tmp_db):
        """If both SL and TP are technically touched in one bar, resolve conservatively as LOSS."""
        tracker = SignalTracker(tmp_db)
        sig = TradeSignal(
            symbol="SOL/USDT", direction="BUY", setup_type="TREND_CONTINUATION",
            entry=100.0, stop_loss=98.0, take_profit=104.0, risk_reward=2.0,
            confidence_pct=60.0, aegis_score=60.0,
        )
        tracker.log_signal(sig)
        resolved = tracker.resolve_pending("SOL/USDT", high=105.0, low=97.0)
        assert resolved[0][1] == "LOSS"

    def test_win_rate_none_when_no_samples(self, tmp_db):
        tracker = SignalTracker(tmp_db)
        wr, n = tracker.get_win_rate("REVERSAL_DIVERGENCE")
        assert wr is None
        assert n == 0

    def test_pending_untouched_by_price_stays_pending(self, tmp_db):
        tracker = SignalTracker(tmp_db)
        sig = TradeSignal(
            symbol="BNB/USDT", direction="BUY", setup_type="TREND_CONTINUATION",
            entry=100.0, stop_loss=98.0, take_profit=104.0, risk_reward=2.0,
            confidence_pct=60.0, aegis_score=60.0,
        )
        tracker.log_signal(sig)
        resolved = tracker.resolve_pending("BNB/USDT", high=101.0, low=99.0)
        assert resolved == []
        assert len(tmp_db.get_pending_outcomes("BNB/USDT")) == 1


class TestPredictiveSignalEngine:
    def test_no_leading_confirmation_blocks_signal(self, tmp_db):
        """Even a strong lagging AEGIS consensus should NOT fire without orderflow/pattern agreement."""
        engine = PredictiveSignalEngine()
        candles = _make_trending_candles()
        result = engine.build_signal(
            symbol="BTC/USDT",
            candles_by_tf={"1h": candles},
            atr=1.0,
            orderbook=None,       # no leading orderflow data
            pattern_df=None,      # no leading pattern data
        )
        assert result["signal"] is None
        assert "leading" in result["reason_blocked"] or "consensus" in result["reason_blocked"]

    def test_orderflow_imbalance_unlocks_signal(self, tmp_db):
        engine = PredictiveSignalEngine()
        candles = _make_trending_candles()
        # Strongly bid-dominant book -> should agree with BUY if AEGIS says BUY
        orderbook = {
            "bids": [[100 - i * 0.1, 50.0] for i in range(15)],
            "asks": [[100 + i * 0.1, 5.0] for i in range(15)],
        }
        result = engine.build_signal(
            symbol="BTC/USDT",
            candles_by_tf={"1h": candles},
            atr=1.0,
            orderbook=orderbook,
            pattern_df=None,
        )
        # Whether it fires depends on whether AEGIS reaches BUY consensus on this
        # synthetic trend; if it does, it must be accompanied by full pricing info.
        if result["signal"] is not None:
            sig = result["signal"]
            assert sig.direction == "BUY"
            assert sig.entry > 0
            assert sig.stop_loss < sig.entry  # BUY: SL below entry
            assert sig.take_profit > sig.entry
            assert 0.0 <= sig.confidence_pct <= 100.0
            assert len(sig.reasoning) > 0
            assert "orderflow_imbalance" in sig.leading_confirmations
            assert sig.setup_type == "ORDERFLOW_BREAKOUT"

    def test_signal_to_dict_serializes(self):
        sig = TradeSignal(
            symbol="BTC/USDT", direction="BUY", setup_type="ORDERFLOW_BREAKOUT",
            entry=100.0, stop_loss=98.0, take_profit=104.0, risk_reward=2.0,
            confidence_pct=70.0, aegis_score=80.0, reasoning=["test reason"],
        )
        d = sig.to_dict()
        assert d["symbol"] == "BTC/USDT"
        assert d["direction"] == "BUY"
        assert "timestamp" in d

    def test_confidence_blends_live_tracker_when_available(self, tmp_db):
        tracker = SignalTracker(tmp_db)
        # Seed 15 live WINs for ORDERFLOW_BREAKOUT so live win-rate should pull
        # confidence toward 100% rather than the 56% static prior.
        for i in range(15):
            sig = TradeSignal(
                symbol="BTC/USDT", direction="BUY", setup_type="ORDERFLOW_BREAKOUT",
                entry=100.0, stop_loss=98.0, take_profit=104.0, risk_reward=2.0,
                confidence_pct=70.0, aegis_score=80.0,
            )
            oid = tracker.log_signal(sig)
            tmp_db.resolve_signal_outcome(oid, "WIN", 104.0)

        wr, n = tracker.get_win_rate("ORDERFLOW_BREAKOUT")
        assert n == 15
        assert wr == 1.0
        assert wr > PRIOR_WIN_RATES["ORDERFLOW_BREAKOUT"]

    def test_missing_candle_data_blocks_gracefully(self):
        engine = PredictiveSignalEngine()
        result = engine.build_signal(
            symbol="BTC/USDT", candles_by_tf={}, atr=1.0,
        )
        assert result["signal"] is None
