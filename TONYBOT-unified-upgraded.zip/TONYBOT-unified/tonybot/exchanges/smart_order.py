"""
tonybot/exchanges/smart_order.py — TWAP Slicing & Slippage Control
Executes large orders by slicing them into smaller time-weighted order blocks.
"""
import asyncio
import logging
from typing import Dict, Any

from tonybot.config import config

logger = logging.getLogger("tonybot.smart_order")


class SmartOrderExecutor:
    """TWAP (Time-Weighted Average Price) order execution engine."""

    def __init__(self, max_slippage_pct: float = 0.15):
        self.max_slippage_pct = max_slippage_pct

    def validate_slippage(self, expected_price: float, execution_price: float, side: str) -> bool:
        if expected_price <= 0:
            return True
        if side.upper() == "BUY":
            slippage = (execution_price - expected_price) / expected_price
        else:
            slippage = (expected_price - execution_price) / expected_price

        if slippage > (self.max_slippage_pct / 100.0):
            logger.warning(f"Slippage violation: {slippage:.2%} > limit ({self.max_slippage_pct}%)")
            return False
        return True

    async def execute_twap(
        self, exchange_manager, symbol: str, side: str, total_quantity: float,
        slices: int = 5, interval_seconds: float = 2.0
    ) -> Dict[str, Any]:
        """Slices large order into equal chunks executed at fixed time intervals."""
        slice_qty = total_quantity / max(1, slices)
        filled_qty = 0.0
        avg_price = 0.0

        logger.info(f"Executing TWAP order: {side} {total_quantity} {symbol} over {slices} slices every {interval_seconds}s")

        for i in range(slices):
            res = await exchange_manager.place_order(symbol, side, slice_qty)
            filled_qty += slice_qty
            price = res.get("price", 0.0)
            avg_price += price
            if i < slices - 1:
                await asyncio.sleep(interval_seconds)

        avg_price /= max(1, slices)
        return {
            "symbol": symbol,
            "side": side,
            "total_quantity": filled_qty,
            "average_price": avg_price,
            "slices_executed": slices,
            "status": "COMPLETED",
        }
