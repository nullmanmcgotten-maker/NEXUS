"""
tonybot/exchanges/manager.py — Multi-Exchange Order Router
Routes orders across Binance REST/WS & CCXT exchange backends.
"""
from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional

from tonybot.config import config
from tonybot.data.binance_client import BinanceClient
from tonybot.data.ccxt_source import CCXTDataSource
from tonybot.data.perp_market import PerpMarketDataSource
from tonybot.risk.liquidation import evaluate_liquidation_risk, stop_loss_beats_liquidation

logger = logging.getLogger("tonybot.exchanges")


class ExchangeManager:
    """
    Manages order routing, market data, and connectivity across exchanges.

    Supports both spot and perpetual-futures (swap) market types, selected
    via config.MARKET_TYPE. When MARKET_TYPE == "swap", every exchange also
    gets a PerpMarketDataSource for funding/OI/leverage/margin-mode calls,
    and place_order() runs a liquidation-safety check before routing any
    live order (paper orders always succeed so backtests aren't blocked).
    """

    def __init__(self):
        self.primary_client = BinanceClient()
        self.ccxt_sources: Dict[str, CCXTDataSource] = {}
        self.perp_sources: Dict[str, PerpMarketDataSource] = {}
        self.market_type = config.MARKET_TYPE  # "spot" | "swap"
        self._init_exchanges()

    def _init_exchanges(self):
        primary_id = config.EXCHANGE_ID.lower()
        try:
            self.ccxt_sources[primary_id] = CCXTDataSource(
                exchange_id=primary_id,
                api_key=config.BINANCE_API_KEY,
                secret=config.BINANCE_SECRET_KEY,
            )
            if self.market_type == "swap":
                self.perp_sources[primary_id] = PerpMarketDataSource(
                    exchange_id=primary_id,
                    api_key=config.BINANCE_API_KEY,
                    secret=config.BINANCE_SECRET_KEY,
                    market_type="swap",
                )
        except Exception as e:
            logger.warning(f"Failed to initialize CCXT for {primary_id}: {e}")

        if config.MULTI_EXCHANGE_ENABLED:
            for ex_id, key, secret in (
                ("bybit", config.BYBIT_API_KEY, config.BYBIT_SECRET_KEY),
                ("okx", config.OKX_API_KEY, config.OKX_SECRET_KEY),
            ):
                if not key:
                    continue
                try:
                    self.ccxt_sources[ex_id] = CCXTDataSource(ex_id, key, secret)
                    if self.market_type == "swap":
                        self.perp_sources[ex_id] = PerpMarketDataSource(ex_id, key, secret, market_type="swap")
                except Exception as e:
                    logger.warning(f"Failed to initialize CCXT {ex_id}: {e}")

    def perp(self, exchange_id: Optional[str] = None) -> Optional[PerpMarketDataSource]:
        """Get the perp market-data source for an exchange, if perp mode is on."""
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        return self.perp_sources.get(ex_id)

    def configure_leverage(self, symbol: str, leverage: float, margin_mode: Optional[str] = None,
                            exchange_id: Optional[str] = None) -> bool:
        """Set leverage and margin mode for a symbol before opening a perp position."""
        src = self.perp(exchange_id)
        if not src:
            logger.warning("configure_leverage called but MARKET_TYPE is not 'swap'")
            return False
        ok = src.set_margin_mode(symbol, margin_mode or config.MARGIN_MODE)
        ok = src.set_leverage(symbol, leverage) and ok
        return ok

    async def get_price(self, symbol: str, exchange_id: Optional[str] = None) -> float:
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        if ex_id == "binance":
            try:
                return await self.primary_client.get_price(symbol)
            except Exception:
                pass
        if ex_id in self.ccxt_sources:
            try:
                df = self.ccxt_sources[ex_id].fetch_ohlcv_df(symbol, timeframe="1m", limit=1)
                if not df.empty:
                    return float(df["close"].iloc[-1])
            except Exception as e:
                logger.warning(f"Failed to fetch price for {symbol} via CCXT {ex_id}: {e}")
        return 0.0

    async def place_order(
        self, symbol: str, side: str, quantity: float,
        entry_price: float = 0.0, stop_loss: float = 0.0, take_profit: float = 0.0,
        exchange_id: Optional[str] = None, leverage: Optional[float] = None,
    ) -> Dict[str, Any]:
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        lev = leverage or (config.DEFAULT_LEVERAGE if self.market_type == "swap" else 1.0)

        # --- Liquidation safety gate (perp mode, live orders only) ---
        if self.market_type == "swap" and config.LIVE_TRADING and not config.PAPER_MODE and entry_price > 0:
            liq_side = "LONG" if side.upper() in ("BUY", "LONG") else "SHORT"
            mmr = config.DEFAULT_MAINTENANCE_MARGIN_RATE
            src = self.perp(ex_id)
            if src:
                mmr = src.fetch_maintenance_margin_rate(symbol, quantity * entry_price, mmr)
            result = evaluate_liquidation_risk(
                entry_price=entry_price, leverage=lev, side=liq_side,
                margin_mode=config.MARGIN_MODE, maintenance_margin_rate=mmr,
                min_distance_pct=config.MIN_LIQUIDATION_DISTANCE_PCT,
            )
            if not result.is_safe:
                logger.error(
                    f"[BLOCKED] {symbol} {side} {lev}x: liquidation only "
                    f"{result.distance_pct:.1%} away (min {config.MIN_LIQUIDATION_DISTANCE_PCT:.0%})"
                )
                return {"status": "REJECTED", "reason": "liquidation_too_close",
                        "liquidation_price": result.liquidation_price, "symbol": symbol}
            if stop_loss and not stop_loss_beats_liquidation(entry_price, stop_loss, result.liquidation_price, liq_side):
                logger.error(f"[BLOCKED] {symbol} {side}: stop-loss beyond liquidation price {result.liquidation_price:.4f}")
                return {"status": "REJECTED", "reason": "stop_beyond_liquidation",
                        "liquidation_price": result.liquidation_price, "symbol": symbol}

        if config.PAPER_MODE or not config.LIVE_TRADING:
            logger.info(f"[PAPER TRADE] {side} {quantity:.4f} {symbol} @ {entry_price:.2f} "
                        f"(lev={lev}x, SL={stop_loss:.2f}, TP={take_profit:.2f})")
            return {
                "status": "FILLED",
                "trade_id": f"paper_{int(logging.root.hasHandlers())}",
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "price": entry_price,
                "leverage": lev,
            }

        if self.market_type == "swap":
            src = self.perp(ex_id)
            if src and leverage:
                src.set_leverage(symbol, lev)
            ccxt_src = self.ccxt_sources.get(ex_id)
            if not ccxt_src:
                raise RuntimeError(f"No CCXT source configured for {ex_id}")
            order_type = "market" if entry_price <= 0 else "limit"
            order_side = "buy" if side.upper() in ("BUY", "LONG") else "sell"
            fmt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}:{symbol[-4:]}"
            params = {"reduceOnly": False}
            order = ccxt_src.exchange.create_order(
                fmt_symbol, order_type, order_side, quantity,
                price=entry_price if order_type == "limit" else None, params=params,
            )
            result: Dict[str, Any] = {"status": "FILLED", "order": order, "symbol": symbol, "leverage": lev}

            # --- Real exchange-side stop-loss / take-profit ------------------
            # Previously the only protection on a live position was this
            # process's own monitor_and_close_positions() polling loop noticing
            # price had crossed stop_loss/take_profit and *then* sending a
            # market close. Between polls (and if the process crashes, loses
            # network, or gets rate-limited) the position had zero protection
            # actually resting on the exchange — in a fast move or a gap, real
            # losses can blow straight through the intended stop with nothing
            # to catch it. This places real reduce-only conditional orders on
            # the exchange itself at entry time, so protection survives even
            # if this bot goes offline. Binance-USDM-futures order types are
            # used here since that's what the rest of this codebase (perp
            # liquidation math, funding data, etc.) already assumes; other
            # exchanges fall back to polling-only with a loud warning rather
            # than silently pretending they're protected.
            close_side = "sell" if order_side == "buy" else "buy"
            if ex_id != "binance":
                logger.warning(
                    f"[UNPROTECTED] {symbol}: native STOP_MARKET/TAKE_PROFIT_MARKET brackets are "
                    f"only implemented for Binance USDM futures right now — {ex_id} positions rely "
                    f"solely on this bot's polling loop for SL/TP. Restart-, crash-, or latency-risk "
                    f"applies until this is native for {ex_id} too."
                )
                result["protected_by_exchange"] = False
                return result

            sl_order_id = tp_order_id = None
            try:
                if stop_loss > 0:
                    sl_order = ccxt_src.exchange.create_order(
                        fmt_symbol, "STOP_MARKET", close_side, quantity,
                        params={"stopPrice": stop_loss, "reduceOnly": True, "closePosition": True},
                    )
                    sl_order_id = sl_order.get("id")
                if take_profit > 0:
                    tp_order = ccxt_src.exchange.create_order(
                        fmt_symbol, "TAKE_PROFIT_MARKET", close_side, quantity,
                        params={"stopPrice": take_profit, "reduceOnly": True, "closePosition": True},
                    )
                    tp_order_id = tp_order.get("id")
                result["protected_by_exchange"] = bool(sl_order_id or tp_order_id)
            except Exception as e:
                logger.error(
                    f"[UNPROTECTED] {symbol}: entry filled but exchange-side SL/TP order failed "
                    f"({e}). Falling back to polling-only for this position — verify manually."
                )
                result["protected_by_exchange"] = False

            result["sl_order_id"] = sl_order_id
            result["tp_order_id"] = tp_order_id
            return result

        if ex_id == "binance":
            if stop_loss > 0 and take_profit > 0:
                list_id = await self.primary_client.place_oco(
                    symbol=symbol, side=side, quantity=quantity,
                    entry_price=entry_price, sl_price=stop_loss, tp_price=take_profit
                )
                return {"status": "FILLED", "order_list_id": list_id, "symbol": symbol}
            else:
                return await self.primary_client.place_market_order(symbol, side, quantity)

        raise NotImplementedError(f"Live order execution for {ex_id} not implemented")

    async def cancel_order_safe(
        self, symbol: str, order_id: str, exchange_id: Optional[str] = None,
    ) -> bool:
        """Best-effort cancel of a leftover bracket order (e.g. the TP order
        after the SL side has already filled). Never raises."""
        if config.PAPER_MODE or not config.LIVE_TRADING or not order_id:
            return True
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        ccxt_src = self.ccxt_sources.get(ex_id)
        if not ccxt_src:
            return False
        fmt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}:{symbol[-4:]}"
        try:
            ccxt_src.exchange.cancel_order(order_id, fmt_symbol)
            return True
        except Exception as e:
            logger.debug(f"cancel_order_safe: could not cancel {order_id} for {symbol}: {e}")
            return False

    async def fetch_order_status(
        self, symbol: str, order_id: str, exchange_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Checks a live order's status directly on the exchange — used to
        detect when a resting exchange-side SL/TP bracket order has already
        filled, so the polling loop doesn't try to redundantly close a
        position the exchange itself already flattened."""
        if config.PAPER_MODE or not config.LIVE_TRADING:
            return None
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        ccxt_src = self.ccxt_sources.get(ex_id)
        if not ccxt_src:
            return None
        fmt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}:{symbol[-4:]}"
        try:
            return ccxt_src.exchange.fetch_order(order_id, fmt_symbol)
        except Exception as e:
            logger.debug(f"Could not fetch order status for {order_id} ({symbol}): {e}")
            return None

    async def close_position(
        self, symbol: str, side: str, quantity: float, exchange_id: Optional[str] = None,
        sl_order_id: Optional[str] = None, tp_order_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Flattens an open position with an opposite-side order.
        `side` is the side the position was OPENED with (BUY/LONG or SELL/SHORT) —
        this method figures out and submits the correct closing side itself.

        `sl_order_id`/`tp_order_id`, when provided (from the entry order's
        `place_order()` result), are cancelled first so a manual/early close
        doesn't leave an orphaned reduce-only conditional order still resting
        on the exchange after this position is gone.
        """
        ex_id = (exchange_id or config.EXCHANGE_ID).lower()
        exit_side = "SELL" if side.upper() in ("BUY", "LONG") else "BUY"

        if config.PAPER_MODE or not config.LIVE_TRADING:
            price = await self.get_price(symbol, ex_id)
            logger.info(f"[PAPER CLOSE] {symbol} @ {price:.4f}")
            return {"status": "FILLED", "symbol": symbol, "price": price}

        if self.market_type == "swap":
            ccxt_src = self.ccxt_sources.get(ex_id)
            if not ccxt_src:
                raise RuntimeError(f"No CCXT source configured for {ex_id}")
            fmt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}:{symbol[-4:]}"

            for leftover_id in (sl_order_id, tp_order_id):
                if not leftover_id:
                    continue
                try:
                    ccxt_src.exchange.cancel_order(leftover_id, fmt_symbol)
                except Exception as e:
                    logger.warning(f"Could not cancel leftover bracket order {leftover_id} for {symbol}: {e}")

            # reduceOnly ensures this can only ever shrink/close the position,
            # never accidentally open a new one in the opposite direction.
            order = ccxt_src.exchange.create_order(
                fmt_symbol, "market", exit_side.lower(), quantity, params={"reduceOnly": True},
            )
            price = float(order.get("average") or order.get("price") or 0.0)
            if price <= 0:
                price = await self.get_price(symbol, ex_id)
            logger.info(f"[LIVE CLOSE] {symbol} {exit_side} {quantity:.6f} @ {price:.4f}")
            return {"status": "FILLED", "order": order, "symbol": symbol, "price": price}

        if ex_id == "binance":
            order = await self.primary_client.place_market_order(symbol, exit_side, quantity)
            fills = order.get("fills") or []
            price = float(fills[0]["price"]) if fills else await self.get_price(symbol, ex_id)
            logger.info(f"[LIVE CLOSE] {symbol} {exit_side} {quantity:.6f} @ {price:.4f}")
            return {"status": "FILLED", "order": order, "symbol": symbol, "price": price}

        raise NotImplementedError(f"Live position close for {ex_id} not implemented")

    async def close(self):
        await self.primary_client.close()
