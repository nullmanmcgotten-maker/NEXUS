"""
tonybot/orderbook/orderbook.py — Level-2 Orderbook Depth & Wall Detection
Analyses L2 bid/ask depth, order book imbalance, buy/sell walls, and VPIN toxicity.
"""
from typing import Dict, Any, List


class OrderBookAnalyzer:
    """Analyzes depth snapshots for bid/ask imbalance and liquidity walls."""

    def analyze(self, depth: Dict[str, Any]) -> Dict[str, Any]:
        bids: List = depth.get("bids", [])
        asks: List = depth.get("asks", [])

        if not bids or not asks:
            return {"imbalance": 0.0, "bid_wall": 0.0, "ask_wall": 0.0, "vpin": 0.0}

        bid_vol = sum(float(b[1]) for b in bids[:20])
        ask_vol = sum(float(a[1]) for a in asks[:20])
        total_vol = bid_vol + ask_vol

        imbalance = (bid_vol - ask_vol) / total_vol if total_vol > 0 else 0.0

        max_bid = max(bids[:20], key=lambda b: float(b[1]), default=[0, 0])
        max_ask = max(asks[:20], key=lambda a: float(a[1]), default=[0, 0])

        vpin = abs(bid_vol - ask_vol) / total_vol if total_vol > 0 else 0.0

        return {
            "imbalance": imbalance,
            "total_bid_depth": bid_vol,
            "total_ask_depth": ask_vol,
            "bid_wall_price": float(max_bid[0]),
            "bid_wall_qty": float(max_bid[1]),
            "ask_wall_price": float(max_ask[0]),
            "ask_wall_qty": float(max_ask[1]),
            "vpin": vpin,
        }
