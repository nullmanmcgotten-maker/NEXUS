"""
tonybot/themes/manager.py — Theme Manager for TONYBOT
Provides dark, light, midnight, and high-contrast QSS themes with customizable accent colors.
"""
import json
import logging
from pathlib import Path

logger = logging.getLogger("tonybot.themes")

THEMES_FILE = "data/theme.json"
ACCENT_DEFAULT = "#58a6ff"


def _build_theme(bg: str, bg2: str, bg3: str, bg4: str,
                 border: str, text: str, text2: str, text3: str,
                 accent: str, green: str, red: str, amber: str) -> str:
    return f"""
QMainWindow, QWidget {{ background: {bg}; color: {text}; font-family: Consolas, monospace; font-size: 12px; }}
QSplitter::handle {{ background: {border}; }}
QTabWidget::pane {{ border: none; background: {bg2}; }}
QTabBar::tab {{ background: {bg2}; color: {text2}; padding: 5px 14px; border: none; border-right: 1px solid {border}; font-family: Consolas; font-size: 11px; }}
QTabBar::tab:selected {{ color: {accent}; border-bottom: 2px solid {accent}; }}
QTabBar::tab:hover {{ color: {text}; }}
QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: {bg}; width: 6px; border: none; }}
QScrollBar::handle:vertical {{ background: {border}; border-radius: 3px; min-height: 20px; }}
QScrollBar::handle:vertical:hover {{ background: {text3}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ background: {bg}; height: 6px; border: none; }}
QScrollBar::handle:horizontal {{ background: {border}; border-radius: 3px; min-width: 20px; }}
QStatusBar {{ background: {bg2}; color: {text3}; font-family: Consolas; font-size: 10px; border-top: 1px solid {border}; }}
QStatusBar::item {{ border: none; }}
QFrame {{ background: transparent; }}
QLabel {{ background: transparent; color: {text}; }}
QPushButton {{ background: {bg4}; color: {text}; border: 1px solid {border}; padding: 4px 12px; border-radius: 4px; font-family: Consolas; font-size: 11px; }}
QPushButton:hover {{ background: {bg3}; }}
QPushButton:pressed {{ background: {bg2}; }}
QPushButton:disabled {{ color: {text3}; }}
QComboBox {{ background: {bg4}; color: {text}; border: 1px solid {border}; padding: 3px 8px; border-radius: 4px; font-family: Consolas; font-size: 11px; }}
QComboBox QAbstractItemView {{ background: {bg4}; color: {text}; border: 1px solid {border}; selection-background-color: {accent}22; }}
QComboBox::drop-down {{ border: none; }}
QLineEdit, QSpinBox, QDoubleSpinBox {{ background: {bg4}; color: {text}; border: 1px solid {border}; padding: 4px 8px; border-radius: 4px; font-family: Consolas; font-size: 11px; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{ border-color: {accent}; }}
QCheckBox {{ color: {text}; font-family: Consolas; font-size: 11px; }}
QCheckBox::indicator {{ width: 14px; height: 14px; background: {bg4}; border: 1px solid {border}; border-radius: 3px; }}
QCheckBox::indicator:checked {{ background: {accent}; border-color: {accent}; }}
QProgressBar {{ background: {bg4}; border: none; border-radius: 3px; }}
QProgressBar::chunk {{ background: {accent}; border-radius: 3px; }}
QTableWidget {{ background: {bg}; color: {text2}; font-family: Consolas; font-size: 11px; border: none; gridline-color: {bg3}; }}
QTableWidget::item {{ padding: 4px 8px; border-bottom: 1px solid {bg3}; }}
QTableWidget::item:selected {{ background: {accent}22; color: {text}; }}
QHeaderView::section {{ background: {bg2}; color: {text3}; font-family: Consolas; font-size: 9px; border: none; padding: 4px; border-bottom: 1px solid {border}; }}
QTextEdit {{ background: {bg}; color: {text2}; border: none; font-family: Consolas; font-size: 11px; padding: 4px; }}
QDialog {{ background: {bg}; color: {text}; }}
QMenuBar {{ background: {bg2}; color: {text}; }}
QMenuBar::item:selected {{ background: {bg3}; }}
QMenu {{ background: {bg2}; color: {text}; border: 1px solid {border}; }}
QMenu::item:selected {{ background: {accent}22; }}
QToolTip {{ background: {bg3}; color: {text}; border: 1px solid {border}; padding: 4px; font-family: Consolas; font-size: 11px; }}
"""


THEMES = {
    "dark": _build_theme(
        bg="#0d1117", bg2="#161b22", bg3="#1c2128", bg4="#22272e",
        border="#30363d", text="#e6edf3", text2="#848d97", text3="#6e7681",
        accent=ACCENT_DEFAULT, green="#3fb950", red="#f85149", amber="#d29922",
    ),
    "midnight": _build_theme(
        bg="#000000", bg2="#0a0a0a", bg3="#111111", bg4="#1a1a1a",
        border="#222222", text="#e0e0e0", text2="#888888", text3="#555555",
        accent="#7b9cff", green="#33cc55", red="#ff4444", amber="#ffaa00",
    ),
    "light": _build_theme(
        bg="#ffffff", bg2="#f6f8fa", bg3="#eaeef2", bg4="#f0f3f6",
        border="#d0d7de", text="#24292f", text2="#57606a", text3="#8c959f",
        accent="#0969da", green="#1a7f37", red="#cf222e", amber="#9a6700",
    ),
    "high_contrast": _build_theme(
        bg="#000000", bg2="#0d0d0d", bg3="#1a1a1a", bg4="#262626",
        border="#555555", text="#ffffff", text2="#dddddd", text3="#aaaaaa",
        accent="#ffff00", green="#00ff88", red="#ff3333", amber="#ffcc00",
    ),
}


class ThemeManager:
    def __init__(self):
        self._current = "dark"
        self._accent = ACCENT_DEFAULT
        self._load()

    def _load(self):
        try:
            p = Path(THEMES_FILE)
            if p.exists():
                d = json.loads(p.read_text())
                self._current = d.get("theme", "dark")
                self._accent = d.get("accent", ACCENT_DEFAULT)
        except Exception:
            pass

    def _save(self):
        try:
            Path("data").mkdir(parents=True, exist_ok=True)
            Path(THEMES_FILE).write_text(
                json.dumps({"theme": self._current, "accent": self._accent})
            )
        except Exception:
            pass

    def get_stylesheet(self) -> str:
        base = THEMES.get(self._current, THEMES["dark"])
        if self._accent != ACCENT_DEFAULT:
            base = base.replace(ACCENT_DEFAULT, self._accent)
        return base

    def set_theme(self, name: str):
        if name in THEMES:
            self._current = name
            self._save()

    def set_accent(self, color: str):
        self._accent = color
        self._save()

    @property
    def current(self) -> str:
        return self._current

    @property
    def accent(self) -> str:
        return self._accent

    @property
    def available(self) -> list:
        return list(THEMES.keys())


theme_manager = ThemeManager()
