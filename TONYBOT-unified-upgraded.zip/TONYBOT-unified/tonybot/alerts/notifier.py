"""
tonybot/alerts/notifier.py — Telegram & Email Notification Dispatcher
Sends trade open/close popups, risk circuit breaker alerts, and daily summaries.

This class existed but was never actually wired into anything — not the GUI,
not the headless engine. core/engine.py now calls notify_trade_signal()/
notify_close() directly so live entries and exits actually produce a Telegram
message with real position sizing (quantity, notional, risk amount, R:R),
not just a bare symbol+price ping.
"""
import asyncio
import logging
import aiohttp

from tonybot.config import config

logger = logging.getLogger("tonybot.alerts")


class Notifier:
    """Dispatches asynchronous alerts to Telegram and Email."""

    def __init__(self):
        self.enabled = config.ALERTS_ENABLED
        self.bot_token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID

    async def send_telegram(self, message: str) -> bool:
        if not self.enabled or not self.bot_token or not self.chat_id:
            return False

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": message, "parse_mode": "Markdown"}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    return resp.status == 200
        except Exception as e:
            logger.warning(f"Failed to send Telegram alert: {e}")
            return False

    async def notify_trade(self, symbol: str, side: str, price: float, qty: float, sl: float, tp: float):
        msg = f"🚀 *TONYBOT TRADE EXECUTED*\n\n*Symbol:* `{symbol}`\n*Side:* `{side}`\n*Entry:* `${price:.2f}`\n*Qty:* `{qty:.4f}`\n*SL:* `${sl:.2f}`\n*TP:* `${tp:.2f}`"
        await self.send_telegram(msg)

    async def notify_trade_signal(
        self, symbol: str, profile: str, side: str, setup_type: str,
        entry: float, stop_loss: float, take_profit: float,
        quantity: float, notional: float, confidence_pct: float,
        risk_reward: float, leading_confirmations: list,
        protected_by_exchange=None,
    ):
        """Full entry alert with real position sizing — what actually got
        risked and how big the position is, not just symbol/price."""
        risk_amount = abs(entry - stop_loss) * quantity
        protection = (
            "✅ exchange-protected" if protected_by_exchange
            else "⚠️ polling-only, no resting exchange stop" if protected_by_exchange is False
            else "paper mode"
        )
        confirmations_str = ", ".join(leading_confirmations) if leading_confirmations else "none"
        emoji = "🟢" if side == "BUY" else "🔴"
        msg = (
            f"{emoji} *TONYBOT ENTRY — {profile.upper()}*\n\n"
            f"*Symbol:* `{symbol}`  →  *{side}*  ({setup_type})\n"
            f"*Entry:* `${entry:,.4f}`\n"
            f"*Stop-Loss:* `${stop_loss:,.4f}`\n"
            f"*Take-Profit:* `${take_profit:,.4f}`\n"
            f"*R:R:* `{risk_reward:.2f}`\n\n"
            f"*Quantity:* `{quantity:.6f}`\n"
            f"*Notional:* `${notional:,.2f}`\n"
            f"*Risk:* `${risk_amount:,.2f}`\n\n"
            f"*Confidence:* `{confidence_pct:.0f}%`\n"
            f"*Leading confirmation:* `{confirmations_str}`\n"
            f"*Protection:* {protection}"
        )
        await self.send_telegram(msg)

    async def notify_close(self, symbol: str, profile: str, side: str, exit_price: float, pnl: float, reason: str):
        emoji = "✅" if pnl >= 0 else "❌"
        msg = (
            f"{emoji} *TONYBOT CLOSE — {profile.upper()}*\n\n"
            f"*Symbol:* `{symbol}` {side} closed ({reason})\n"
            f"*Exit:* `${exit_price:,.4f}`\n"
            f"*PnL:* `{pnl:+,.2f}`"
        )
        await self.send_telegram(msg)

    async def notify_circuit_breaker(self, reason: str):
        msg = f"🚨 *TONYBOT CIRCUIT BREAKER TRIPPED*\n\n*Reason:* `{reason}`\n\n*All trading suspended until manual reset.*"
        await self.send_telegram(msg)
