"""
tonybot/data/binance_client.py — Async Binance REST Client
Handles spot & testnet market data, OCO orders, depth, and account balances.
"""
import asyncio
import hashlib
import hmac
import logging
import time
import urllib.parse
import aiohttp

from tonybot.config import config

logger = logging.getLogger("binance")

BASE_URL = "https://testnet.binance.vision/api" if config.BINANCE_TESTNET else "https://api.binance.com/api"


class BinanceClient:
    def __init__(self):
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    def _sign(self, params: dict) -> str:
        query = urllib.parse.urlencode(params)
        return hmac.new(
            config.BINANCE_SECRET_KEY.encode(),
            query.encode(),
            hashlib.sha256,
        ).hexdigest()

    async def _get(self, endpoint: str, params: dict = None, signed: bool = False):
        session = await self._get_session()
        p = params or {}
        if signed:
            p["timestamp"] = int(time.time() * 1000)
            p["signature"] = self._sign(p)
        headers = {"X-MBX-APIKEY": config.BINANCE_API_KEY} if signed else {}
        async with session.get(
            f"{BASE_URL}/{endpoint}",
            params=p,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=8),
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def _post(self, endpoint: str, params: dict):
        session = await self._get_session()
        params["timestamp"] = int(time.time() * 1000)
        params["signature"] = self._sign(params)
        headers = {"X-MBX-APIKEY": config.BINANCE_API_KEY}
        async with session.post(
            f"{BASE_URL}/{endpoint}",
            params=params,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def _delete(self, endpoint: str, params: dict):
        session = await self._get_session()
        params["timestamp"] = int(time.time() * 1000)
        params["signature"] = self._sign(params)
        headers = {"X-MBX-APIKEY": config.BINANCE_API_KEY}
        async with session.delete(
            f"{BASE_URL}/{endpoint}",
            params=params,
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def get_price(self, symbol: str) -> float:
        clean_symbol = symbol.replace("/", "")
        data = await self._get("v3/ticker/price", {"symbol": clean_symbol})
        return float(data["price"])

    async def get_candles(self, symbol: str, interval: str, limit: int = 200) -> list:
        clean_symbol = symbol.replace("/", "")
        data = await self._get("v3/klines", {
            "symbol": clean_symbol,
            "interval": interval,
            "limit": limit,
        })
        return [[c[0], c[1], c[2], c[3], c[4], c[5]] for c in data]

    async def get_order_book(self, symbol: str, limit: int = 50) -> dict:
        clean_symbol = symbol.replace("/", "")
        return await self._get("v3/depth", {"symbol": clean_symbol, "limit": limit})

    async def get_recent_trades(self, symbol: str, limit: int = 100) -> list:
        clean_symbol = symbol.replace("/", "")
        return await self._get("v3/trades", {"symbol": clean_symbol, "limit": limit})

    async def get_account_balance(self) -> dict:
        data = await self._get("v3/account", signed=True)
        return {
            b["asset"]: float(b["free"])
            for b in data.get("balances", [])
            if float(b["free"]) > 0
        }

    async def place_market_order(self, symbol: str, side: str, quantity: float) -> dict:
        clean_symbol = symbol.replace("/", "")
        return await self._post("v3/order", {
            "symbol": clean_symbol,
            "side": side,
            "type": "MARKET",
            "quantity": f"{quantity:.6f}",
        })

    async def place_oco(
        self,
        symbol: str,
        side: str,
        quantity: float,
        entry_price: float,
        sl_price: float,
        tp_price: float,
    ) -> str:
        clean_symbol = symbol.replace("/", "")
        exit_side = "SELL" if side == "BUY" else "BUY"

        entry = await self.place_market_order(symbol, side, quantity)
        logger.info(f"Market entry placed: {entry.get('orderId')}")

        oco_params = {
            "symbol": clean_symbol,
            "side": exit_side,
            "quantity": f"{quantity:.6f}",
            "price": f"{tp_price:.4f}",
            "stopPrice": f"{sl_price:.4f}",
            "stopLimitPrice": f"{sl_price * (0.999 if exit_side == 'SELL' else 1.001):.4f}",
            "stopLimitTimeInForce": "GTC",
        }
        oco = await self._post("v3/orderList/oco", oco_params)
        list_id = str(oco.get("orderListId", "unknown"))
        logger.info(f"OCO placed: listId={list_id}")
        return list_id

    async def cancel_oco(self, symbol: str, order_list_id: str):
        clean_symbol = symbol.replace("/", "")
        try:
            await self._delete("v3/orderList", {
                "symbol": clean_symbol,
                "orderListId": order_list_id,
            })
        except Exception as e:
            logger.warning(f"OCO cancel error for {symbol}: {e}")

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
