"""
tonybot/data/streamer.py — Real-time data streamer

NOTE: This module generates simulated/random prices and signals for demo
purposes only (see class docstring below). It is not currently wired into
the trading engine, orchestrator, or GUI anywhere in this codebase — nothing
here reaches order execution. Keep it that way unless it's replaced with a
real WebSocket feed; don't wire simulated prices into anything that places
orders.
"""
import logging
import time
import threading
import random
from datetime import datetime
from tonybot.core.db import Database

logger = logging.getLogger("tonybot.data.streamer")

class DataStreamer:
    """Simulates real-time price data (replace with WebSocket later)"""
    
    def __init__(self, callback=None):
        self.running = False
        self.callback = callback
        self.prices = {}
        self.db = Database()
        
        # Initial prices for symbols
        base_prices = {
            'BTC/USDT': 68000,
            'ETH/USDT': 3200,
            'SOL/USDT': 150,
            'BNB/USDT': 580
        }
        
        for sym in ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT']:
            self.prices[sym] = base_prices.get(sym, 100)
    
    def start(self):
        self.running = True
        thread = threading.Thread(target=self._run, daemon=True)
        thread.start()
    
    def stop(self):
        self.running = False
    
    def _run(self):
        while self.running:
            try:
                # Generate random price movement
                for symbol in self.prices:
                    # Random walk
                    change = random.uniform(-0.005, 0.005)  # 0.5% max change
                    self.prices[symbol] *= (1 + change)
                    
                    # Generate a random signal occasionally
                    if random.random() < 0.05:  # 5% chance per cycle
                        signal = self._generate_signal(symbol)
                        if self.callback:
                            self.callback('signal', signal)
                
                if self.callback:
                    self.callback('prices', self.prices)
                
                time.sleep(2)  # Update every 2 seconds
                
            except Exception as e:
                logger.warning(f"Streamer error: {e}")
                time.sleep(5)
    
    def _generate_signal(self, symbol):
        actions = ['BUY', 'SELL', 'HOLD']
        action = random.choices(actions, weights=[0.3, 0.3, 0.4])[0]
        confidence = random.randint(40, 85)
        price = self.prices.get(symbol, 0)
        
        return {
            'symbol': symbol,
            'action': action,
            'confidence': confidence,
            'price': price,
            'timestamp': datetime.now().isoformat(),
            'reasoning': f"AI analysis: {action} with {confidence}% confidence"
        }
