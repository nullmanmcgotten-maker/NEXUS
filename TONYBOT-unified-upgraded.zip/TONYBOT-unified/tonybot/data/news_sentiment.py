"""
tonybot/data/news_sentiment.py — Multi-source News Sentiment Aggregator

Fetches crypto sentiment from:
  1. Google News RSS   (feedparser)
  2. Reddit r/CryptoCurrency  (requests JSON)
  3. Alternative.me Fear & Greed Index  (requests JSON)
  4. NewsAPI  (requests JSON, requires NEWSAPI_KEY env var)

All sources are independently cached for 5 minutes (CACHE_TTL = 300 s).
No Qt dependency — safe to call from any background thread.
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Keyword lists
# ---------------------------------------------------------------------------
BULLISH_WORDS: list[str] = [
    "bullish", "surge", "rally", "breakout", "adoption",
    "buy", "moon", "gain", "rise", "green", "pump", "upgrade", "partnership",
]

BEARISH_WORDS: list[str] = [
    "bearish", "crash", "dump", "ban", "hack", "sell", "fear",
    "drop", "loss", "red", "scam", "lawsuit", "regulation", "decline",
]

# ---------------------------------------------------------------------------
# Cache TTL
# ---------------------------------------------------------------------------
CACHE_TTL: int = 300  # seconds (5 minutes)

# ---------------------------------------------------------------------------
# Optional feedparser import — graceful fallback if not installed
# ---------------------------------------------------------------------------
try:
    import feedparser as _feedparser  # type: ignore
    _FEEDPARSER_AVAILABLE = True
except ImportError:
    _feedparser = None  # type: ignore
    _FEEDPARSER_AVAILABLE = False
    logger.warning(
        "feedparser is not installed — Google News RSS source will return neutral sentiment. "
        "Install with: pip install feedparser>=6.0.0"
    )

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_ISO_FMT = "%Y-%m-%dT%H:%M:%SZ"


def _now_iso() -> str:
    """Return current UTC time as ISO-8601 string."""
    return datetime.now(timezone.utc).strftime(_ISO_FMT)


def _now_ts() -> float:
    """Return current monotonic timestamp for cache TTL comparison."""
    return time.monotonic()


# ---------------------------------------------------------------------------
# NewsSentiment class
# ---------------------------------------------------------------------------
class NewsSentiment:
    """
    Aggregates crypto news sentiment from multiple sources with 5-minute
    in-memory caching.  Thread-safe for concurrent reads (no mutable shared
    state after __init__ beyond the cache dict; writes are rare and short).
    """

    # Class-level cache shared across all instances:
    #   { source_name: (result: Any, fetched_at: float) }
    _cache: dict[str, tuple[Any, float]] = {}

    # -----------------------------------------------------------------------
    # Internal: keyword scoring
    # -----------------------------------------------------------------------
    @staticmethod
    def _score_text(text: str) -> float:
        """
        Count bullish keyword hits (+1 each) and bearish keyword hits (-1 each)
        using case-insensitive substring matching.  Returns raw sum.
        """
        lower = text.lower()
        score = 0.0
        for word in BULLISH_WORDS:
            if word in lower:
                score += 1.0
        for word in BEARISH_WORDS:
            if word in lower:
                score -= 1.0
        return score

    # -----------------------------------------------------------------------
    # Internal: cache helpers
    # -----------------------------------------------------------------------
    @classmethod
    def _cache_get(cls, key: str) -> tuple[Any, bool]:
        """Return (cached_value, hit).  hit=False when expired or absent."""
        entry = cls._cache.get(key)
        if entry is None:
            return None, False
        result, fetched_at = entry
        if (_now_ts() - fetched_at) < CACHE_TTL:
            return result, True
        return None, False

    @classmethod
    def _cache_set(cls, key: str, value: Any) -> None:
        cls._cache[key] = (value, _now_ts())

    # -----------------------------------------------------------------------
    # Source 1: Google News RSS
    # -----------------------------------------------------------------------
    def _fetch_google_rss(self) -> list[dict]:
        """
        Fetch crypto headlines from Google News RSS using feedparser.
        Returns list of {headline, source, sentiment, timestamp}.
        Returns [] if feedparser is not installed or request fails.
        """
        cache_key = "google_rss"
        cached, hit = self._cache_get(cache_key)
        if hit:
            return cached  # type: ignore[return-value]

        if not _FEEDPARSER_AVAILABLE:
            logger.warning("feedparser unavailable — skipping Google News RSS source.")
            return []

        url = "https://news.google.com/rss/search?q=bitcoin+crypto&hl=en"
        try:
            feed = _feedparser.parse(url)
            items: list[dict] = []
            for entry in feed.get("entries", []):
                headline: str = entry.get("title", "")
                pub: str = entry.get("published", _now_iso())
                sentiment = self._score_text(headline)
                items.append(
                    {
                        "headline": headline,
                        "source": "google_rss",
                        "sentiment": sentiment,
                        "timestamp": pub,
                    }
                )
            self._cache_set(cache_key, items)
            return items
        except Exception as exc:
            logger.warning("Google News RSS fetch failed: %s", exc)
            return []

    # -----------------------------------------------------------------------
    # Source 2: Reddit r/CryptoCurrency JSON
    # -----------------------------------------------------------------------
    def _fetch_reddit_json(self) -> list[dict]:
        """
        Fetch new posts from Reddit r/CryptoCurrency via the JSON API.
        Returns list of {headline, source, sentiment, timestamp}.
        """
        cache_key = "reddit_json"
        cached, hit = self._cache_get(cache_key)
        if hit:
            return cached  # type: ignore[return-value]

        url = "https://www.reddit.com/r/CryptoCurrency/new.json"
        headers = {"User-Agent": "tonybot/1.0"}
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            posts = data.get("data", {}).get("children", [])
            items: list[dict] = []
            for post in posts:
                pd = post.get("data", {})
                title: str = pd.get("title", "")
                created_utc: float = pd.get("created_utc", time.time())
                ts = datetime.fromtimestamp(created_utc, tz=timezone.utc).strftime(_ISO_FMT)
                sentiment = self._score_text(title)
                items.append(
                    {
                        "headline": title,
                        "source": "reddit",
                        "sentiment": sentiment,
                        "timestamp": ts,
                    }
                )
            self._cache_set(cache_key, items)
            return items
        except Exception as exc:
            logger.warning("Reddit JSON fetch failed: %s", exc)
            return []

    # -----------------------------------------------------------------------
    # Source 3: Alternative.me Fear & Greed Index
    # -----------------------------------------------------------------------
    def _fetch_fear_greed(self) -> dict:
        """
        Fetch the Alternative.me Fear & Greed Index.
        Returns {value: int, label: str, contribution: float}.
        Mapping: value >= 60 → contribution +1, value <= 40 → -1, else 0.
        """
        cache_key = "fear_greed"
        cached, hit = self._cache_get(cache_key)
        if hit:
            return cached  # type: ignore[return-value]

        url = "https://api.alternative.me/fng/?limit=1"
        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            entry = data["data"][0]
            value = int(entry.get("value", 50))
            label: str = entry.get("value_classification", "Neutral")

            if value >= 60:
                contribution = 1.0
            elif value <= 40:
                contribution = -1.0
            else:
                contribution = 0.0

            result = {"value": value, "label": label, "contribution": contribution}
            self._cache_set(cache_key, result)
            return result
        except Exception as exc:
            logger.warning("Fear & Greed Index fetch failed: %s", exc)
            return {"value": 50, "label": "Neutral", "contribution": 0.0}

    # -----------------------------------------------------------------------
    # Source 4: NewsAPI
    # -----------------------------------------------------------------------
    def _fetch_newsapi(self, query: str = "bitcoin OR ethereum OR crypto") -> list[dict]:
        """
        Fetch articles from NewsAPI /v2/everything.
        NEWSAPI_KEY is read from the environment directly (avoids circular
        imports with config).
        Returns list of {headline, source, sentiment, timestamp}.
        """
        api_key = os.getenv("NEWSAPI_KEY", "")
        if not api_key:
            return []

        cache_key = f"newsapi_{query}"
        cached, hit = self._cache_get(cache_key)
        if hit:
            return cached  # type: ignore[return-value]

        url = "https://newsapi.org/v2/everything"
        params = {
            "q": query,
            "apiKey": api_key,
            "pageSize": 20,
        }
        try:
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            articles = data.get("articles", [])
            items: list[dict] = []
            for article in articles:
                title: str = article.get("title", "") or ""
                description: str = article.get("description", "") or ""
                text = f"{title} {description}"
                pub_at: str = article.get("publishedAt", _now_iso())
                source_name: str = (
                    article.get("source", {}).get("name", "newsapi") or "newsapi"
                )
                sentiment = self._score_text(text)
                items.append(
                    {
                        "headline": title,
                        "source": f"newsapi:{source_name}",
                        "sentiment": sentiment,
                        "timestamp": pub_at,
                    }
                )
            self._cache_set(cache_key, items)
            return items
        except Exception as exc:
            logger.warning("NewsAPI fetch failed: %s", exc)
            return []

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------
    def get_composite_score(self) -> dict:
        """
        Call all sources (with caching), compute a composite sentiment score,
        and return a summary dict.

        Returns:
            {
                "composite":        float   # average sentiment across all sources
                "fear_greed_index": int     # raw 0–100 index value
                "headline_count":   int     # total headlines processed
                "sources":          dict    # {source_name: float score}
            }
        """
        source_scores: dict[str, float] = {}
        all_headlines: list[dict] = []

        # --- Google News RSS ---
        google_items = self._fetch_google_rss()
        all_headlines.extend(google_items)
        if google_items:
            source_scores["google_rss"] = (
                sum(h["sentiment"] for h in google_items) / len(google_items)
            )
        else:
            source_scores["google_rss"] = 0.0

        # --- Reddit JSON ---
        reddit_items = self._fetch_reddit_json()
        all_headlines.extend(reddit_items)
        if reddit_items:
            source_scores["reddit"] = (
                sum(h["sentiment"] for h in reddit_items) / len(reddit_items)
            )
        else:
            source_scores["reddit"] = 0.0

        # --- Fear & Greed ---
        fg = self._fetch_fear_greed()
        fear_greed_value: int = fg.get("value", 50)
        source_scores["fear_greed"] = fg.get("contribution", 0.0)

        # --- NewsAPI (optional) ---
        newsapi_items = self._fetch_newsapi()
        all_headlines.extend(newsapi_items)
        if newsapi_items:
            source_scores["newsapi"] = (
                sum(h["sentiment"] for h in newsapi_items) / len(newsapi_items)
            )
        # (no key added when not configured — keeps composite unbiased)

        # --- Composite: average of all available source scores ---
        if source_scores:
            composite = sum(source_scores.values()) / len(source_scores)
        else:
            composite = 0.0

        return {
            "composite": round(composite, 4),
            "fear_greed_index": fear_greed_value,
            "headline_count": len(all_headlines),
            "sources": source_scores,
        }

    def get_headlines(self) -> list[dict]:
        """
        Return all headlines from all sources.

        Each item: {headline: str, source: str, sentiment: float, timestamp: str}
        """
        headlines: list[dict] = []
        headlines.extend(self._fetch_google_rss())
        headlines.extend(self._fetch_reddit_json())
        headlines.extend(self._fetch_newsapi())
        # Fear & Greed is an index value, not headlines — omitted here
        return headlines
