"""
tonybot/data/ccxt_source.py — CCXT Multi-Exchange Data Provider
Provides unified market data access across 100+ exchanges using ccxt.
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import List, Optional

import ccxt
import pandas as pd

from tonybot.interfaces import Candle

logger = logging.getLogger("tonybot.data.ccxt")


class CCXTDataSource:
    """Fetches real-time and historical OHLCV candles from any CCXT-supported exchange."""

    def __init__(self, exchange_id: str = "binance", api_key: str = "", secret: str = ""):
        if not hasattr(ccxt, exchange_id):
            raise ValueError(f"Unknown CCXT exchange ID: {exchange_id!r}")
        exchange_class = getattr(ccxt, exchange_id)
        config = {"enableRateLimit": True}
        if api_key and secret:
            config["apiKey"] = api_key
            config["secret"] = secret
        self.exchange: ccxt.Exchange = exchange_class(config)
        self.exchange_id = exchange_id

    def fetch_ohlcv(
        self,
        symbol: str,
        timeframe: str = "1h",
        since: Optional[int] = None,
        limit: int = 1000,
    ) -> List[Candle]:
        """Fetch a single page of OHLCV candles as Candle objects."""
        # Sanitize symbol for ccxt format (e.g. BTCUSDT -> BTC/USDT)
        formatted_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        raw = self.exchange.fetch_ohlcv(formatted_symbol, timeframe=timeframe, since=since, limit=limit)
        return [
            Candle(
                timestamp=datetime.fromtimestamp(row[0] / 1000, tz=timezone.utc),
                open=float(row[1]), high=float(row[2]), low=float(row[3]),
                close=float(row[4]), volume=float(row[5]),
            )
            for row in raw
        ]

    def fetch_ohlcv_df(
        self,
        symbol: str,
        timeframe: str = "1h",
        since: Optional[int] = None,
        limit: int = 500,
    ) -> pd.DataFrame:
        """Fetch OHLCV candles returning a pandas DataFrame indexed by timestamp."""
        candles = self.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
        if not candles:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        data = [{
            "ts": c.timestamp,
            "open": c.open,
            "high": c.high,
            "low": c.low,
            "close": c.close,
            "volume": c.volume
        } for c in candles]
        df = pd.DataFrame(data).set_index("ts")
        return df

    def fetch_ohlcv_range(
        self,
        symbol: str,
        timeframe: str,
        start_iso: str,
        end_iso: str,
        page_limit: int = 1000,
        max_pages: int = 100,
    ) -> pd.DataFrame:
        """Page through ccxt fetch_ohlcv to pull a full historical date range."""
        formatted_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        since = int(pd.Timestamp(start_iso, tz="UTC").timestamp() * 1000)
        end_ms = int(pd.Timestamp(end_iso, tz="UTC").timestamp() * 1000)

        all_rows: list = []
        pages = 0
        while since < end_ms and pages < max_pages:
            try:
                batch = self.exchange.fetch_ohlcv(formatted_symbol, timeframe=timeframe, since=since, limit=page_limit)
            except Exception as e:
                logger.warning(f"Failed to fetch {symbol} at {since}: {e}")
                break
            if not batch:
                break
            all_rows.extend(batch)
            last_ts = batch[-1][0]
            if last_ts <= since:
                break
            since = last_ts + 1
            pages += 1
            time.sleep(self.exchange.rateLimit / 1000.0)

        if not all_rows:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

        df = pd.DataFrame(all_rows, columns=["ts", "open", "high", "low", "close", "volume"])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
        df = df.drop_duplicates(subset="ts").set_index("ts")
        df = df[(df.index >= pd.Timestamp(start_iso, tz="UTC")) & (df.index <= pd.Timestamp(end_iso, tz="UTC"))]
        return df

    def fetch_ohlcv_raw(
        self,
        symbol: str,
        timeframe: str = "1h",
        limit: int = 200,
    ) -> list:
        """
        Fetch OHLCV as the raw [[ts_ms, o, h, l, c, v], ...] list format
        (ccxt's native shape). This is the format SignalRefiner,
        PredictiveSignalEngine, and PatternScanner all expect via their
        `candles_by_tf: Dict[str, list]` inputs — kept separate from
        fetch_ohlcv_df (which returns Candle objects / a DataFrame) so the
        headless engine can feed the same predictive pipeline the GUI uses
        without a conversion round-trip.
        """
        formatted_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        try:
            return self.exchange.fetch_ohlcv(formatted_symbol, timeframe=timeframe, limit=limit)
        except Exception as e:
            logger.warning(f"Failed to fetch raw OHLCV for {symbol} {timeframe}: {e}")
            return []

    def fetch_order_book(self, symbol: str, limit: int = 20) -> dict:
        """
        Fetch current order-book depth as {"bids": [[price, qty], ...], "asks": [...]}.
        Used by PredictiveSignalEngine for leading order-flow imbalance detection.
        Returns an empty book on any failure (e.g. exchange doesn't support it) so
        callers can fall back gracefully rather than crash the signal pipeline.
        """
        formatted_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        try:
            book = self.exchange.fetch_order_book(formatted_symbol, limit=limit)
            return {"bids": book.get("bids", []), "asks": book.get("asks", [])}
        except Exception:
            return {"bids": [], "asks": []}

    def markets(self) -> list:
        try:
            self.exchange.load_markets()
            return list(self.exchange.markets.keys())
        except Exception:
            return []
