"""
tonybot/data/perp_market.py — Perpetual Futures Market Data Provider

New module. Nothing in TONYBOT previously fetched funding rates, open
interest, or mark/index basis — the whole stack assumed spot. This wraps
CCXT's unified futures endpoints so the rest of the app (risk manager,
position sizer, GUI) can reason about perp-specific costs and risk.

All methods degrade gracefully (return None / empty) if the exchange or
symbol doesn't support the endpoint, so callers can always show "N/A"
instead of crashing.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional

import ccxt

logger = logging.getLogger("tonybot.perp_market")


@dataclass
class FundingSnapshot:
    symbol: str
    funding_rate: float          # as a fraction, e.g. 0.0001 = 0.01% per interval
    funding_interval_hours: float
    next_funding_time: Optional[datetime]
    mark_price: float
    index_price: float
    timestamp: datetime

    @property
    def basis_pct(self) -> float:
        """Mark-vs-index basis as a fraction. Positive = perp trading rich."""
        if not self.index_price:
            return 0.0
        return (self.mark_price - self.index_price) / self.index_price

    @property
    def annualized_funding_pct(self) -> float:
        if self.funding_interval_hours <= 0:
            return 0.0
        periods_per_year = (365 * 24) / self.funding_interval_hours
        return self.funding_rate * periods_per_year


@dataclass
class OpenInterestSnapshot:
    symbol: str
    open_interest: float          # in base currency (contracts)
    open_interest_usd: float
    timestamp: datetime


class PerpMarketDataSource:
    """
    Perp-aware wrapper around a CCXT exchange instance. Set
    `defaultType='swap'` (or 'future' for exchanges that use that name) so
    all requests hit the perpetual futures market, not spot.
    """

    def __init__(self, exchange_id: str = "binance", api_key: str = "", secret: str = "",
                 market_type: str = "swap"):
        if not hasattr(ccxt, exchange_id):
            raise ValueError(f"Unknown CCXT exchange ID: {exchange_id!r}")
        exchange_class = getattr(ccxt, exchange_id)
        cfg = {
            "enableRateLimit": True,
            "options": {"defaultType": market_type},
        }
        if api_key and secret:
            cfg["apiKey"] = api_key
            cfg["secret"] = secret
        self.exchange: ccxt.Exchange = exchange_class(cfg)
        self.exchange_id = exchange_id
        self.market_type = market_type

    @staticmethod
    def _fmt(symbol: str) -> str:
        """Normalize e.g. BTCUSDT -> BTC/USDT:USDT (ccxt perp symbol format)."""
        if ":" in symbol:
            return symbol
        base_quote = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        quote = base_quote.split("/")[-1]
        return f"{base_quote}:{quote}"

    def fetch_funding(self, symbol: str) -> Optional[FundingSnapshot]:
        try:
            sym = self._fmt(symbol)
            fr = self.exchange.fetch_funding_rate(sym)
            interval_hours = 8.0
            if fr.get("fundingTimestamp") and fr.get("previousFundingTimestamp"):
                interval_hours = (fr["fundingTimestamp"] - fr["previousFundingTimestamp"]) / 3_600_000
            elif fr.get("interval"):
                interval_hours = float(str(fr["interval"]).rstrip("h") or 8)
            next_ft = None
            if fr.get("fundingTimestamp"):
                next_ft = datetime.fromtimestamp(fr["fundingTimestamp"] / 1000, tz=timezone.utc)
            return FundingSnapshot(
                symbol=symbol,
                funding_rate=float(fr.get("fundingRate") or 0.0),
                funding_interval_hours=interval_hours or 8.0,
                next_funding_time=next_ft,
                mark_price=float(fr.get("markPrice") or 0.0),
                index_price=float(fr.get("indexPrice") or 0.0),
                timestamp=datetime.now(tz=timezone.utc),
            )
        except Exception as e:
            logger.warning(f"fetch_funding failed for {symbol} on {self.exchange_id}: {e}")
            return None

    def fetch_funding_history(self, symbol: str, limit: int = 60) -> List[dict]:
        """Recent funding payments (rate history), most recent last."""
        try:
            sym = self._fmt(symbol)
            if not self.exchange.has.get("fetchFundingRateHistory"):
                return []
            rows = self.exchange.fetch_funding_rate_history(sym, limit=limit)
            return [
                {
                    "timestamp": datetime.fromtimestamp(r["timestamp"] / 1000, tz=timezone.utc),
                    "funding_rate": float(r.get("fundingRate") or 0.0),
                }
                for r in rows
            ]
        except Exception as e:
            logger.warning(f"fetch_funding_history failed for {symbol}: {e}")
            return []

    def fetch_open_interest(self, symbol: str) -> Optional[OpenInterestSnapshot]:
        try:
            sym = self._fmt(symbol)
            if not self.exchange.has.get("fetchOpenInterest"):
                return None
            oi = self.exchange.fetch_open_interest(sym)
            oi_amt = float(oi.get("openInterestAmount") or oi.get("openInterestValue") or 0.0)
            oi_usd = float(oi.get("openInterestValue") or 0.0)
            return OpenInterestSnapshot(
                symbol=symbol,
                open_interest=oi_amt,
                open_interest_usd=oi_usd,
                timestamp=datetime.now(tz=timezone.utc),
            )
        except Exception as e:
            logger.warning(f"fetch_open_interest failed for {symbol}: {e}")
            return None

    def fetch_maintenance_margin_rate(self, symbol: str, notional: float, default: float = 0.005) -> float:
        """
        Pull the real tiered maintenance-margin rate for this notional size
        when the exchange exposes it via ccxt's leverage-tiers endpoint;
        falls back to `default` (config.DEFAULT_MAINTENANCE_MARGIN_RATE)
        otherwise. Larger notional generally sits in a higher (worse) MMR
        tier, so this matters most for bigger positions.
        """
        try:
            sym = self._fmt(symbol)
            if not self.exchange.has.get("fetchLeverageTiers") and not self.exchange.has.get("fetchMarketLeverageTiers"):
                return default
            tiers = None
            if self.exchange.has.get("fetchMarketLeverageTiers"):
                tiers = self.exchange.fetch_market_leverage_tiers(sym)
            else:
                all_tiers = self.exchange.fetch_leverage_tiers([sym])
                tiers = all_tiers.get(sym)
            if not tiers:
                return default
            for tier in tiers:
                floor = float(tier.get("notionalFloor") or tier.get("minNotional") or 0)
                cap = float(tier.get("notionalCap") or tier.get("maxNotional") or float("inf"))
                if floor <= notional <= cap:
                    return float(tier.get("maintenanceMarginRate") or default)
            return float(tiers[-1].get("maintenanceMarginRate") or default)
        except Exception as e:
            logger.warning(f"fetch_maintenance_margin_rate failed for {symbol}: {e}")
            return default

    def set_leverage(self, symbol: str, leverage: float) -> bool:
        try:
            sym = self._fmt(symbol)
            self.exchange.set_leverage(int(leverage), sym)
            return True
        except Exception as e:
            logger.warning(f"set_leverage({leverage}) failed for {symbol}: {e}")
            return False

    def set_margin_mode(self, symbol: str, margin_mode: str) -> bool:
        try:
            sym = self._fmt(symbol)
            self.exchange.set_margin_mode(margin_mode, sym)
            return True
        except Exception as e:
            logger.warning(f"set_margin_mode({margin_mode}) failed for {symbol}: {e}")
            return False

    def fetch_positions(self) -> List[dict]:
        try:
            if not self.exchange.has.get("fetchPositions"):
                return []
            positions = self.exchange.fetch_positions()
            return [p for p in positions if float(p.get("contracts") or 0) != 0]
        except Exception as e:
            logger.warning(f"fetch_positions failed on {self.exchange_id}: {e}")
            return []
