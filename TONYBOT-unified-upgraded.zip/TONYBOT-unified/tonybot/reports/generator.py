"""
tonybot/reports/generator.py — Monthly Investor PDF Report Generator
Uses ReportLab to generate PDF performance reports.
"""
import os
import logging
from pathlib import Path
from typing import Dict, Any, List

logger = logging.getLogger("tonybot.reports")

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False


class PDFReportGenerator:
    """Generates PDF performance summaries."""

    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def generate_report(self, stats: Dict[str, Any], filename: str = "TONYBOT_Performance_Report.pdf") -> str:
        filepath = os.path.join(self.output_dir, filename)
        if not HAS_REPORTLAB:
            logger.warning("ReportLab not installed — skipping PDF generation.")
            return ""

        try:
            doc = SimpleDocTemplate(filepath, pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            story.append(Paragraph("<b>TONYBOT Professional Performance Report</b>", styles["Heading1"]))
            story.append(Spacer(1, 12))

            data = [
                ["Metric", "Value"],
                ["Total Trades", str(stats.get("total", 0))],
                ["Win Rate", f"{stats.get('win_rate', 0.0):.1%}"],
                ["Total Net PnL ($)", f"${stats.get('total_pnl', 0.0):,.2f}"],
                ["Best Trade ($)", f"${stats.get('best_trade', 0.0):,.2f}"],
                ["Worst Trade ($)", f"${stats.get('worst_trade', 0.0):,.2f}"],
            ]

            table = Table(data, colWidths=[200, 200])
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e1e2d")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 1, colors.grey),
            ]))
            story.append(table)
            doc.build(story)

            logger.info(f"Generated PDF report: {filepath}")
            return filepath
        except Exception as e:
            logger.error(f"Failed to generate PDF report: {e}")
            return ""
