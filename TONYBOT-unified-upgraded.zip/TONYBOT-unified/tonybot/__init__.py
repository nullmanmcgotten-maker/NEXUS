"""
TONYBOT — Consolidated Professional Trading & Analysis Platform
"""

__version__ = "1.0.0"
__author__ = "TONYBOT Team"
