"""
tonybot/strategy/signals.py — Technical Signal Pipeline & AI Filter
Consolidates 7 indicator evaluation functions (RSI, MACD, Bollinger, Supertrend, VWAP, Stochastic, EMA cross)
and AI filter (Ollama / HuggingFace / Fallback).
"""
import asyncio
import logging
import time
from typing import Optional, Dict, Any

import pandas as pd
import pandas_ta as ta
import aiohttp

from tonybot.config import config

logger = logging.getLogger("tonybot.signals")

_ai_cache: Dict[str, tuple[dict, float]] = {}


def _to_df(candles: list) -> pd.DataFrame:
    """Convert candle list to DatetimeIndex DataFrame."""
    if not candles:
        return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

    df = pd.DataFrame(
        candles,
        columns=["timestamp", "open", "high", "low", "close", "volume"]
    )
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    df = df.set_index("timestamp").sort_index()
    return df


class SignalEngine:
    """Evaluates 7 technical indicators to output a direction & consensus score."""

    def evaluate_technical(self, df: pd.DataFrame) -> dict:
        if len(df) < 30:
            return {"direction": "HOLD", "confidence": 0.0, "votes": {}}

        close = df["close"]
        high = df["high"]
        low = df["low"]
        volume = df["volume"]
        votes = {}

        # 1. RSI
        try:
            rsi = ta.rsi(close, length=14)
            if rsi is not None and len(rsi.dropna()) > 0:
                r = float(rsi.iloc[-1])
                votes["rsi"] = "BUY" if r < 30 else ("SELL" if r > 70 else "HOLD")
        except Exception:
            pass

        # 2. MACD
        try:
            macd = ta.macd(close)
            if macd is not None:
                mc = [c for c in macd.columns if "MACD_" in c and "MACDs" not in c and "MACDh" not in c]
                sc = [c for c in macd.columns if "MACDs_" in c]
                if mc and sc and len(macd) >= 2:
                    m, s = float(macd[mc[0]].iloc[-1]), float(macd[sc[0]].iloc[-1])
                    mp, sp = float(macd[mc[0]].iloc[-2]), float(macd[sc[0]].iloc[-2])
                    if mp < sp and m > s:
                        votes["macd"] = "BUY"
                    elif mp > sp and m < s:
                        votes["macd"] = "SELL"
                    else:
                        votes["macd"] = "HOLD"
        except Exception:
            pass

        # 3. Bollinger Bands
        try:
            bb = ta.bbands(close, length=20)
            if bb is not None:
                lc = [c for c in bb.columns if c.upper().startswith("BBL")]
                uc = [c for c in bb.columns if c.upper().startswith("BBU")]
                if lc and uc:
                    last = float(close.iloc[-1])
                    lower = float(bb[lc[0]].iloc[-1])
                    upper = float(bb[uc[0]].iloc[-1])
                    votes["bb"] = "BUY" if last < lower else ("SELL" if last > upper else "HOLD")
        except Exception:
            pass

        # 4. Supertrend
        try:
            st = ta.supertrend(high, low, close, length=10, multiplier=3.0)
            if st is not None:
                dc = [c for c in st.columns if c.upper().startswith("SUPERTD")]
                if dc:
                    d = float(st[dc[0]].iloc[-1])
                    votes["supertrend"] = "BUY" if d == 1 else ("SELL" if d == -1 else "HOLD")
        except Exception:
            pass

        # 5. VWAP
        try:
            vwap = ta.vwap(high, low, close, volume)
            if vwap is not None and len(vwap.dropna()) > 0:
                last = float(close.iloc[-1])
                v = float(vwap.iloc[-1])
                votes["vwap"] = "BUY" if last > v else "SELL"
        except Exception:
            pass

        # 6. Stochastic
        try:
            stoch = ta.stoch(high, low, close)
            if stoch is not None:
                kc = [c for c in stoch.columns if c.upper().startswith("STOCHK")]
                dc = [c for c in stoch.columns if c.upper().startswith("STOCHD")]
                if kc and dc and len(stoch) >= 2:
                    k, d = float(stoch[kc[0]].iloc[-1]), float(stoch[dc[0]].iloc[-1])
                    kp, dp = float(stoch[kc[0]].iloc[-2]), float(stoch[dc[0]].iloc[-2])
                    if k < 20 and kp < dp and k > d:
                        votes["stoch"] = "BUY"
                    elif k > 80 and kp > dp and k < d:
                        votes["stoch"] = "SELL"
                    else:
                        votes["stoch"] = "HOLD"
        except Exception:
            pass

        # 7. EMA Cross
        try:
            ema12 = ta.ema(close, length=12)
            ema26 = ta.ema(close, length=26)
            if ema12 is not None and ema26 is not None and len(ema12) >= 2:
                e12, e26 = float(ema12.iloc[-1]), float(ema26.iloc[-1])
                e12p, e26p = float(ema12.iloc[-2]), float(ema26.iloc[-2])
                if e12p < e26p and e12 > e26:
                    votes["ema_cross"] = "BUY"
                elif e12p > e26p and e12 < e26:
                    votes["ema_cross"] = "SELL"
                else:
                    votes["ema_cross"] = "HOLD"
        except Exception:
            pass

        buy_count = sum(1 for v in votes.values() if v == "BUY")
        sell_count = sum(1 for v in votes.values() if v == "SELL")
        total = len(votes) or 1

        if buy_count > sell_count and buy_count >= 2:
            return {"direction": "BUY", "confidence": buy_count / total, "votes": votes}
        if sell_count > buy_count and sell_count >= 2:
            return {"direction": "SELL", "confidence": sell_count / total, "votes": votes}
        return {"direction": "HOLD", "confidence": 0.0, "votes": votes}

    async def evaluate(self, symbol: str, candles: list) -> dict:
        if not candles:
            return {"direction": "HOLD", "confidence": 0.0}
        df = _to_df(candles)
        return await asyncio.to_thread(self.evaluate_technical, df)

    async def ai_filter(
        self, symbol: str, direction: str, signals: dict, price: float
    ) -> dict:
        """AI risk filter using technical confidence fallback when offline."""
        tech_conf = signals.get("technical", {}).get("confidence", 0.0)
        decision = "ALLOW" if tech_conf >= 0.5 else "BLOCK"
        return {
            "decision": decision,
            "reasoning": f"Tech confidence {tech_conf:.0%} ({'ALLOW' if tech_conf >= 0.5 else 'BLOCK'})"
        }
