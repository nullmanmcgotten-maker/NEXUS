"""
tonybot/strategy/support_resistance.py — Automatic Support/Resistance Detection

Finds horizontal price levels the market has repeatedly reacted to, using a
fractal/pivot method: a candle is a "swing high" if its high is the highest
in a window around it, and a "swing low" if its low is the lowest. Nearby
pivots are clustered into a single level (price rarely respects a level to
the exact cent), and each level's "strength" is how many separate times
price has touched it — more touches, more confidence traders are watching it.

This feeds two places:
  - The GUI chart, purely visual — horizontal lines at the strongest levels.
  - PredictiveSignalEngine, as a third leading-confirmation source alongside
    order-flow imbalance and chart patterns: a signal direction that also
    lines up with a bounce off support / breakout through resistance gets
    extra weight, same as the other two leading confirmations do.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import pandas as pd


@dataclass
class SRLevel:
    price: float
    kind: str          # "support" | "resistance"
    touches: int        # how many separate pivots clustered into this level
    strength: float      # 0-1, touches scaled against the strongest level found


class SupportResistanceDetector:
    """Pivot-based support/resistance level finder."""

    def __init__(self, pivot_window: int = 3, cluster_pct: float = 0.0015, max_levels: int = 6):
        """
        pivot_window: candles on each side that must be lower/higher for a
            candle to count as a swing high/low (fractal width).
        cluster_pct: pivots within this fraction of each other's price get
            merged into one level (0.0015 = 0.15%, i.e. tight clustering).
        max_levels: cap on how many levels to return (strongest first).
        """
        self.pivot_window = pivot_window
        self.cluster_pct = cluster_pct
        self.max_levels = max_levels

    def _find_pivots(self, df: pd.DataFrame) -> List[tuple]:
        """Returns [(price, kind), ...] for every swing high/low pivot found."""
        highs = df["high"].values
        lows = df["low"].values
        n = len(df)
        w = self.pivot_window
        pivots = []
        for i in range(w, n - w):
            window_highs = highs[i - w:i + w + 1]
            window_lows = lows[i - w:i + w + 1]
            if highs[i] == window_highs.max() and (window_highs == highs[i]).sum() == 1:
                pivots.append((float(highs[i]), "resistance"))
            if lows[i] == window_lows.min() and (window_lows == lows[i]).sum() == 1:
                pivots.append((float(lows[i]), "support"))
        return pivots

    def _cluster(self, pivots: List[tuple]) -> List[SRLevel]:
        """Merges nearby same-kind pivots into single levels, counting touches."""
        levels: List[SRLevel] = []
        for kind in ("support", "resistance"):
            prices = sorted(p for p, k in pivots if k == kind)
            cluster: List[float] = []
            for price in prices:
                if cluster and abs(price - cluster[-1]) / cluster[-1] <= self.cluster_pct:
                    cluster.append(price)
                else:
                    if cluster:
                        levels.append(SRLevel(
                            price=sum(cluster) / len(cluster), kind=kind,
                            touches=len(cluster), strength=0.0,
                        ))
                    cluster = [price]
            if cluster:
                levels.append(SRLevel(
                    price=sum(cluster) / len(cluster), kind=kind,
                    touches=len(cluster), strength=0.0,
                ))
        return levels

    def detect(self, df: pd.DataFrame) -> List[SRLevel]:
        """Returns the strongest levels (by touch count), most-touched first,
        capped at max_levels. Empty list if there isn't enough data."""
        if df is None or len(df) < (self.pivot_window * 2 + 5):
            return []
        pivots = self._find_pivots(df)
        if not pivots:
            return []
        levels = self._cluster(pivots)
        if not levels:
            return []
        max_touches = max(l.touches for l in levels) or 1
        for l in levels:
            l.strength = round(l.touches / max_touches, 2)
        levels.sort(key=lambda l: l.touches, reverse=True)
        return levels[: self.max_levels]

    def nearest_reaction(
        self, df: pd.DataFrame, current_price: float, direction: str, proximity_pct: float = 0.003,
    ) -> Optional[SRLevel]:
        """
        Returns the S/R level, if any, that `current_price` is currently
        reacting to in a way consistent with `direction`:
          - BUY:  price is near/bouncing off a support level (support below,
                  within proximity_pct), or has just broken above a
                  resistance level (resistance below current price too,
                  within a wider recent-breakout band).
          - SELL: mirror image off resistance / broken support.
        Used as PredictiveSignalEngine's third leading confirmation.
        """
        levels = self.detect(df)
        if not levels or current_price <= 0:
            return None

        for level in levels:
            dist_pct = abs(current_price - level.price) / current_price
            if dist_pct > proximity_pct:
                continue
            if direction == "BUY" and level.kind == "support" and current_price >= level.price:
                return level
            if direction == "BUY" and level.kind == "resistance" and current_price >= level.price:
                return level  # breakout above resistance
            if direction == "SELL" and level.kind == "resistance" and current_price <= level.price:
                return level
            if direction == "SELL" and level.kind == "support" and current_price <= level.price:
                return level  # breakdown below support
        return None
