"""
tonybot/strategy/trade_signal.py — Predictive Trade Signal Engine

Fixes the "signal fires after the move already happened" problem.

The existing SignalRefiner (AEGIS 7-gate) is entirely built on lagging
technical indicators — RSI/MACD/BB/VWAP/Stochastic/EMA all confirm only
after a candle closes or a cross completes. TONYBOT contains three
genuinely *leading* detectors that only trend/lag alone can't see coming:
OrderFlowPipeline's order-book imbalance/whale detection (bid/ask pressure
building before price moves), PatternScanner's structural patterns (a
flag/triangle/divergence completes before the breakout candle prints), and
SupportResistanceDetector's auto-detected horizontal levels (a bounce or
breakout at a level price has repeatedly reacted to before).

PredictiveSignalEngine composes:
  - SignalRefiner              -> lagging technical consensus (AEGIS score)
  - OrderFlowPipeline           -> leading order-book imbalance / whale walls
  - PatternScanner              -> leading/structural chart patterns
  - SupportResistanceDetector   -> leading support/resistance level reaction
  - RiskManager                 -> ATR-based entry/SL/TP
  - SignalTracker (optional)   -> blended historical + live win-rate

A signal is only fired (BUY/SELL, never on lagging confirmation alone) when
the AEGIS technical consensus AND at least one leading confirmation agree
on direction. This intentionally makes signals rarer than the old pipeline,
but each one is accompanied by why it fired, where to enter, where the
stop/target sit, and how reliable this exact setup has been historically.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

# Static priors used until a setup type has accumulated enough live samples.
# Seeded from typical backtest ranges for each setup family; SignalTracker
# blends these with real, per-instance rolling win-rates once n >= 10.
PRIOR_WIN_RATES: Dict[str, float] = {
    "ORDERFLOW_BREAKOUT": 0.56,
    "PATTERN_CONFLUENCE": 0.54,
    "SR_REACTION": 0.53,
    "TREND_CONTINUATION": 0.52,
    "REVERSAL_DIVERGENCE": 0.50,
}


@dataclass
class TradeSignal:
    symbol: str
    direction: str                      # BUY | SELL
    setup_type: str                     # key into PRIOR_WIN_RATES
    entry: float
    stop_loss: float
    take_profit: float
    risk_reward: float
    confidence_pct: float               # final blended confidence shown to trader
    aegis_score: float                  # raw lagging technical consensus (0-100)
    leading_confirmations: List[str] = field(default_factory=list)
    reasoning: List[str] = field(default_factory=list)
    historical_win_rate: Optional[float] = None
    live_win_rate: Optional[float] = None
    live_sample_size: int = 0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "symbol": self.symbol,
            "direction": self.direction,
            "setup_type": self.setup_type,
            "entry": self.entry,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "risk_reward": self.risk_reward,
            "confidence_pct": self.confidence_pct,
            "aegis_score": self.aegis_score,
            "leading_confirmations": self.leading_confirmations,
            "reasoning": self.reasoning,
            "historical_win_rate": self.historical_win_rate,
            "live_win_rate": self.live_win_rate,
            "live_sample_size": self.live_sample_size,
            "timestamp": self.timestamp.isoformat(),
        }


class PredictiveSignalEngine:
    """
    Wraps SignalRefiner with leading order-flow and pattern confirmation so
    a signal only fires when something *forward-looking* agrees with the
    technical consensus, and packages the result into an actionable
    TradeSignal (entry/SL/TP/reasoning/confidence) instead of a bare
    direction + score.
    """

    def __init__(
        self,
        signal_refiner=None,
        orderflow_pipeline=None,
        pattern_scanner_fn=None,
        risk_manager=None,
        signal_tracker=None,
        sr_detector=None,
        min_orderflow_imbalance: float = 0.20,
    ):
        if signal_refiner is None:
            from tonybot.strategy.signal_refiner import SignalRefiner
            signal_refiner = SignalRefiner()
        if orderflow_pipeline is None:
            from tonybot.orderflow.pipeline import OrderFlowPipeline
            orderflow_pipeline = OrderFlowPipeline()
        if pattern_scanner_fn is None:
            from tonybot.strategy.pattern_scanner import detect_patterns
            pattern_scanner_fn = detect_patterns
        if risk_manager is None:
            from tonybot.risk.risk_manager import RiskManager
            risk_manager = RiskManager()
        if sr_detector is None:
            from tonybot.strategy.support_resistance import SupportResistanceDetector
            sr_detector = SupportResistanceDetector()

        self.signal_refiner = signal_refiner
        self.orderflow = orderflow_pipeline
        self.detect_patterns = pattern_scanner_fn
        self.risk_manager = risk_manager
        self.signal_tracker = signal_tracker
        self.sr_detector = sr_detector
        self.min_orderflow_imbalance = min_orderflow_imbalance

    # ------------------------------------------------------------------

    def build_signal(
        self,
        symbol: str,
        candles_by_tf: Dict[str, list],
        atr: float,
        orderbook: Optional[Dict[str, Any]] = None,
        pattern_df: Optional[pd.DataFrame] = None,
        tf_preference: Optional[List[str]] = None,
        sl_atr_mult: float = 2.0,
        tp_atr_mult: float = 4.0,
    ) -> Dict[str, Any]:
        """
        Returns a dict:
          {"signal": TradeSignal | None, "aegis": <raw refiner result>, "reason_blocked": str}
        `signal` is None (HOLD) unless AEGIS direction agrees with at least
        one leading confirmation.

        tf_preference/sl_atr_mult/tp_atr_mult let a caller run this as a
        scalp profile (fast timeframes, tight ATR multiples) or swing
        profile (slow timeframes, wide ATR multiples) without needing two
        separate engine instances — see core/engine.py's TRADING_PROFILES.
        """
        aegis = self.signal_refiner.evaluate(symbol, candles_by_tf, atr=atr, tf_preference=tf_preference)
        direction = aegis.get("direction", "HOLD")
        aegis_score = float(aegis.get("aegis_score", 0.0))

        if direction not in ("BUY", "SELL"):
            return {"signal": None, "aegis": aegis, "reason_blocked": "No lagging technical consensus (HOLD)"}

        leading_confirmations: List[str] = []
        reasoning: List[str] = []
        setup_type = "TREND_CONTINUATION"

        # --- Leading confirmation 1: order-book imbalance / whale pressure ---
        imbalance_agrees = False
        if orderbook:
            try:
                snap = self.orderflow.analyze_orderbook_imbalance(orderbook, symbol)
            except Exception:
                snap = None
            if snap is not None:
                wants_bid = direction == "BUY" and snap.dominant_side == "BID"
                wants_ask = direction == "SELL" and snap.dominant_side == "ASK"
                if (wants_bid or wants_ask) and snap.imbalance_score >= self.min_orderflow_imbalance:
                    imbalance_agrees = True
                    leading_confirmations.append("orderflow_imbalance")
                    setup_type = "ORDERFLOW_BREAKOUT"
                    tag = "buy-side" if wants_bid else "sell-side"
                    reasoning.append(
                        f"Order book shows {snap.imbalance_score:.0%} {tag} imbalance "
                        f"({'whale-level' if snap.whale_alert else 'moderate'} pressure) "
                        f"before price has moved — leading confirmation."
                    )

        # --- Leading confirmation 2: structural chart pattern ---
        pattern_agrees = False
        if pattern_df is not None and len(pattern_df) >= 25:
            try:
                matches = self.detect_patterns(pattern_df)
            except Exception:
                matches = []
            wanted_dir = "bullish" if direction == "BUY" else "bearish"
            for m in matches:
                if m.direction == wanted_dir:
                    pattern_agrees = True
                    leading_confirmations.append(f"pattern:{m.pattern}")
                    setup_type = "PATTERN_CONFLUENCE" if setup_type != "ORDERFLOW_BREAKOUT" else setup_type
                    reasoning.append(f"{m.pattern} pattern confirmed ({m.confidence} confidence): {m.description}")
                    break  # one clean pattern is enough signal, avoid stacking noise

        # --- Leading confirmation 3: auto support/resistance reaction ---
        sr_agrees = False
        if pattern_df is not None and len(pattern_df) >= 15:
            try:
                current_price = float(pattern_df["close"].iloc[-1])
                level = self.sr_detector.nearest_reaction(pattern_df, current_price, direction)
            except Exception:
                level = None
            if level is not None:
                sr_agrees = True
                leading_confirmations.append(f"sr_{level.kind}")
                if setup_type not in ("ORDERFLOW_BREAKOUT", "PATTERN_CONFLUENCE"):
                    setup_type = "SR_REACTION"
                reasoning.append(
                    f"Price reacting to a {level.kind} level at ${level.price:,.4f} "
                    f"({level.touches} prior touches, strength {level.strength:.0%}) — leading confirmation."
                )

        if not (imbalance_agrees or pattern_agrees or sr_agrees):
            return {
                "signal": None,
                "aegis": aegis,
                "reason_blocked": (
                    f"AEGIS technical consensus says {direction} ({aegis_score:.0f}/100) but no leading "
                    f"order-flow, pattern, or support/resistance confirmation yet — waiting to avoid a lagging entry."
                ),
            }

        # --- Reasoning from the lagging gates that passed too, for context ---
        gates = aegis.get("gates", {})
        for gname, g in gates.items():
            if g.get("passed"):
                reasoning.append(f"Technical gate '{gname.replace('_', ' ')}' confirms {direction}.")

        # --- Entry / SL / TP ---
        candles = None
        for tf_pref in (tf_preference or ["1h", "5m", "4h", "1m", "1d"]):
            c = candles_by_tf.get(tf_pref)
            if c:
                candles = c
                break
        if not candles:
            return {"signal": None, "aegis": aegis, "reason_blocked": "No candle data to price entry/SL/TP"}

        entry = float(candles[-1][4])  # close of most recent candle
        stop_loss, take_profit = self.risk_manager.calculate_sl_tp(
            entry, atr, direction, sl_atr_mult=sl_atr_mult, tp_atr_mult=tp_atr_mult
        )
        risk = abs(entry - stop_loss)
        reward = abs(take_profit - entry)
        risk_reward = round(reward / risk, 2) if risk > 0 else 0.0

        # --- Confidence: blend AEGIS score with historical + live win-rate ---
        historical_wr = PRIOR_WIN_RATES.get(setup_type, 0.5)
        live_wr = None
        live_n = 0
        if self.signal_tracker is not None:
            try:
                live_wr, live_n = self.signal_tracker.get_win_rate(setup_type)
            except Exception:
                live_wr, live_n = None, 0

        blended_wr = historical_wr
        if live_wr is not None and live_n > 0:
            weight_live = min(live_n / 30.0, 1.0)
            blended_wr = weight_live * live_wr + (1 - weight_live) * historical_wr

        # Situational modifier: extra confirmation nudges confidence up.
        n_leading = len(leading_confirmations)
        situational_boost = min(0.10, 0.04 * n_leading)
        confidence = max(0.0, min(1.0, 0.5 * (aegis_score / 100.0) + 0.5 * blended_wr + situational_boost))
        confidence_pct = round(confidence * 100, 1)

        reasoning.append(
            f"Setup '{setup_type}' historical win-rate {historical_wr:.0%}"
            + (f", live rolling win-rate {live_wr:.0%} over {live_n} trades" if live_wr is not None and live_n > 0 else ", not enough live trades yet to override the prior")
            + "."
        )

        signal = TradeSignal(
            symbol=symbol,
            direction=direction,
            setup_type=setup_type,
            entry=entry,
            stop_loss=stop_loss,
            take_profit=take_profit,
            risk_reward=risk_reward,
            confidence_pct=confidence_pct,
            aegis_score=aegis_score,
            leading_confirmations=leading_confirmations,
            reasoning=reasoning,
            historical_win_rate=historical_wr,
            live_win_rate=live_wr,
            live_sample_size=live_n,
        )
        return {"signal": signal, "aegis": aegis, "reason_blocked": ""}
