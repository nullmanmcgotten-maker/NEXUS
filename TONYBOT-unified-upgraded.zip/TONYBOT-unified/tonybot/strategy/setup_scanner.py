"""
tonybot/strategy/setup_scanner.py — 4-Way Setup Scanner with Confirmation Scoring
Scans for Pullback to MA, Bollinger Breakout, RSI Divergence, & S/R Bounces.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import List
import pandas as pd

from tonybot.interfaces import Regime, RegimeType, TrendDirection, Setup, SetupType, OrderSide


class SetupScanner:
    """
    Scans for price action setups and scores confirmations across 4 independent sources:
    1. Price Action (Pattern/Structure)
    2. Volume (Spike / Above Average)
    3. Momentum (RSI + MACD histogram alignment)
    4. Trend Alignment (Regime consensus)
    """

    def __init__(self, min_confirmations: int = 3, volume_multiplier: float = 1.5):
        self.min_confirmations = min_confirmations
        self.volume_multiplier = volume_multiplier

    def scan(self, symbol: str, annotated_df: pd.DataFrame, regime: Regime) -> List[Setup]:
        if len(annotated_df) < 30:
            return []

        setups: List[Setup] = []
        last = annotated_df.iloc[-1]
        prev = annotated_df.iloc[-2]

        avg_volume = annotated_df["volume"].tail(20).mean()
        volume_confirmed = last["volume"] > (avg_volume * self.volume_multiplier) if avg_volume > 0 else False

        rsi = last.get("rsi")
        macd_hist = last.get("MACDh_12_26_9")
        momentum_confirmed = False
        if pd.notna(rsi) and pd.notna(macd_hist):
            if regime.trend_direction == TrendDirection.UP:
                momentum_confirmed = rsi > 50 and macd_hist > 0
            elif regime.trend_direction == TrendDirection.DOWN:
                momentum_confirmed = rsi < 50 and macd_hist < 0

        trend_confirmed = regime.trend_direction != TrendDirection.NONE

        # --- Setup 1: Pullback to 50 EMA ---
        if regime.regime_type == RegimeType.TRENDING and regime.trend_direction != TrendDirection.NONE:
            ema50 = last.get("ema50")
            if pd.notna(ema50) and ema50 > 0:
                distance_pct = abs(last["close"] - ema50) / ema50
                price_action_confirmed = distance_pct < 0.012  # within 1.2% of 50 EMA
                if price_action_confirmed:
                    confirmations = sum([price_action_confirmed, volume_confirmed, momentum_confirmed, trend_confirmed])
                    if confirmations >= self.min_confirmations:
                        side = OrderSide.BUY if regime.trend_direction == TrendDirection.UP else OrderSide.SELL
                        setups.append(self._build_setup(
                            symbol, SetupType.PULLBACK_TO_MA, side, confirmations,
                            price_action_confirmed, volume_confirmed, momentum_confirmed, trend_confirmed,
                            last, annotated_df
                        ))

        # --- Setup 2: Bollinger Squeeze Breakout ---
        bbu = last.get("BBU_20_2.0")
        bbl = last.get("BBL_20_2.0")
        if pd.notna(bbu) and pd.notna(bbl):
            breakout_up = last["close"] > bbu and prev["close"] <= prev.get("BBU_20_2.0", bbu)
            breakout_down = last["close"] < bbl and prev["close"] >= prev.get("BBL_20_2.0", bbl)
            if breakout_up or breakout_down:
                price_action_confirmed = True
                confirmations = sum([price_action_confirmed, volume_confirmed, momentum_confirmed, trend_confirmed])
                if confirmations >= self.min_confirmations:
                    side = OrderSide.BUY if breakout_up else OrderSide.SELL
                    setups.append(self._build_setup(
                        symbol, SetupType.BREAKOUT, side, confirmations,
                        price_action_confirmed, volume_confirmed, momentum_confirmed, trend_confirmed,
                        last, annotated_df
                    ))

        # --- Setup 3: RSI Divergence ---
        window = annotated_df.tail(20)
        if pd.notna(rsi) and len(window) == 20:
            min_close = window["close"].min()
            if window["close"].iloc[-1] <= min_close * 1.002:
                price_low_idx = window["close"].idxmin()
                rsi_at_low = window.loc[price_low_idx, "rsi"]
                if pd.notna(rsi_at_low) and rsi > rsi_at_low:
                    confirmations = sum([True, volume_confirmed, momentum_confirmed, trend_confirmed])
                    if confirmations >= self.min_confirmations:
                        setups.append(self._build_setup(
                            symbol, SetupType.RSI_DIVERGENCE, OrderSide.BUY, confirmations,
                            True, volume_confirmed, momentum_confirmed, trend_confirmed,
                            last, annotated_df
                        ))

        return setups

    def _build_setup(
        self, symbol, setup_type, side, confirmations,
        price_ok, vol_ok, mom_ok, trend_ok, last_row, df
    ) -> Setup:
        sources = []
        if price_ok: sources.append("price_action")
        if vol_ok: sources.append("volume")
        if mom_ok: sources.append("momentum")
        if trend_ok: sources.append("trend_alignment")

        entry = float(last_row["close"])
        atr = float((df["high"].tail(14) - df["low"].tail(14)).mean())
        if atr <= 0:
            atr = entry * 0.01

        if side == OrderSide.BUY:
            stop_loss = entry - 1.5 * atr
            take_profit = entry + 2.5 * atr
        else:
            stop_loss = entry + 1.5 * atr
            take_profit = entry - 2.5 * atr

        ts = df.index[-1]
        if not isinstance(ts, datetime):
            ts = datetime.now(timezone.utc)

        confidence_score = (confirmations / 4.0) * 100.0

        return Setup(
            symbol=symbol, setup_type=setup_type, direction=side,
            confirmations=confirmations, confirmation_sources=sources,
            entry_price=entry, stop_loss=stop_loss, take_profit=take_profit,
            timestamp=ts, confidence_score=confidence_score
        )
