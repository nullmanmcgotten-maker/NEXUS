"""
tonybot/strategy/regime_classifier.py — ADX & EMA Trend/Ranging Market Classifier
"""
from __future__ import annotations

from datetime import datetime, timezone
import pandas as pd
import pandas_ta as ta

from tonybot.interfaces import Regime, RegimeType, TrendDirection


class RegimeClassifier:
    """ADX-based trending/ranging/volatile regime detector with EMA-stack direction."""

    def __init__(self, trending_threshold: float = 25.0, ranging_threshold: float = 20.0):
        self.trending_threshold = trending_threshold
        self.ranging_threshold = ranging_threshold

    def annotate(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add adx, ema9/21/50, rsi, macd, bbands columns to an OHLCV dataframe."""
        out = df.copy()
        if len(out) < 20:
            return out

        try:
            adx_df = ta.adx(out["high"], out["low"], out["close"], length=14)
            if adx_df is not None:
                out["adx"] = adx_df.iloc[:, 0]
        except Exception:
            out["adx"] = 0.0

        try:
            out["ema9"] = ta.ema(out["close"], length=9)
            out["ema21"] = ta.ema(out["close"], length=21)
            out["ema50"] = ta.ema(out["close"], length=50)
            out["rsi"] = ta.rsi(out["close"], length=14)
        except Exception:
            pass

        try:
            macd_df = ta.macd(out["close"])
            if macd_df is not None:
                out = out.join(macd_df)
        except Exception:
            pass

        try:
            bb_df = ta.bbands(out["close"], length=20)
            if bb_df is not None:
                out = out.join(bb_df)
        except Exception:
            pass

        return out

    def classify(self, symbol: str, annotated_df: pd.DataFrame) -> Regime:
        if annotated_df.empty or len(annotated_df) < 5:
            return Regime(symbol=symbol, regime_type=RegimeType.UNKNOWN, trend_direction=TrendDirection.NONE, adx=0.0, timestamp=datetime.now(timezone.utc))

        last = annotated_df.iloc[-1]
        adx_val = float(last.get("adx", 0.0) or 0.0)

        if adx_val > self.trending_threshold:
            regime_type = RegimeType.TRENDING
        elif adx_val < self.ranging_threshold:
            regime_type = RegimeType.RANGING
        else:
            regime_type = RegimeType.UNKNOWN

        ema9, ema21, ema50 = last.get("ema9"), last.get("ema21"), last.get("ema50")
        if pd.notna(ema9) and pd.notna(ema21) and pd.notna(ema50):
            if ema9 > ema21 > ema50:
                direction = TrendDirection.UP
            elif ema9 < ema21 < ema50:
                direction = TrendDirection.DOWN
            else:
                direction = TrendDirection.NONE
        else:
            direction = TrendDirection.NONE

        ts = annotated_df.index[-1]
        if not isinstance(ts, datetime):
            ts = datetime.now(timezone.utc)

        return Regime(
            symbol=symbol,
            regime_type=regime_type,
            trend_direction=direction,
            adx=adx_val,
            timestamp=ts,
        )
