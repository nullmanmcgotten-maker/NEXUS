"""
tonybot/strategy/signal_refiner.py — 7-Gate AEGIS Signal Refiner
Synthesizes SignalEngine, MultiTFConfluence, NewsSentiment, and MLEnsemble
into a single AegisScore (0-100) and BUY/SELL/HOLD direction.

Gate weights:
    trend_alignment    1.5
    rsi_filter         1.0
    macd_confirmation  1.2
    bollinger_position 1.0
    volume_confirmation 1.2
    sentiment_gate     0.8
    ai_ensemble_vote   1.5
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

import pandas as pd

logger = logging.getLogger("tonybot.signal_refiner")

GATE_WEIGHTS: Dict[str, float] = {
    "trend_alignment":    1.5,
    "rsi_filter":         1.0,
    "macd_confirmation":  1.2,
    "bollinger_position": 1.0,
    "volume_confirmation":1.2,
    "sentiment_gate":     0.8,
    "ai_ensemble_vote":   1.5,
}

TOTAL_WEIGHT: float = sum(GATE_WEIGHTS.values())  # 8.2


def _candles_to_df(candles: list) -> pd.DataFrame:
    """Convert raw candle list [[ts, o, h, l, c, v], ...] to a DataFrame."""
    if not candles:
        return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
    df = pd.DataFrame(candles, columns=["timestamp", "open", "high", "low", "close", "volume"])
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    df = df.set_index("timestamp").sort_index()
    return df


def _run_async(coro):
    """Run a coroutine from a synchronous context (worker thread)."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=10)
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


class SignalRefiner:
    """
    Orchestrates the 7-gate weighted signal pipeline and produces an AegisScore.
    All upstream module calls are wrapped in try/except — a failing gate is marked
    as failed (contribution=0) and evaluation continues.
    """

    def __init__(
        self,
        signal_engine=None,
        mtf_confluence=None,
        news_sentiment=None,
        ml_ensemble=None,
    ):
        # Lazy imports to avoid circular dependencies at module load time
        if signal_engine is None:
            from tonybot.strategy.signals import SignalEngine
            signal_engine = SignalEngine()
        if mtf_confluence is None:
            from tonybot.strategy.multitf import MultiTFConfluence
            mtf_confluence = MultiTFConfluence()
        if news_sentiment is None:
            from tonybot.data.news_sentiment import NewsSentiment
            news_sentiment = NewsSentiment()
        if ml_ensemble is None:
            from tonybot.ml.ensemble import MLEnsemble
            ml_ensemble = MLEnsemble()

        self.signal_engine = signal_engine
        self.mtf_confluence = mtf_confluence
        self.news_sentiment = news_sentiment
        self.ml_ensemble = ml_ensemble

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def evaluate(
        self,
        symbol: str,
        candles_by_tf: Dict[str, list],
        atr: float = 0.0,
        tf_preference: Optional[List[str]] = None,
    ) -> dict:
        """
        Run the full 7-gate evaluation for a symbol.

        Args:
            symbol:        e.g. "BTCUSDT"
            candles_by_tf: {"1h": [...], "4h": [...], ...}  raw Binance kline lists
            atr:           pre-computed ATR value (optional; for record-keeping)
            tf_preference: which timeframe to read primary TA votes from, in
                           fallback order. Defaults to the original
                           swing-oriented ["1h","5m","4h","1m","1d"]; a scalp
                           profile passes ["1m","5m","1h"] instead so the
                           7-gate technical read is actually about the fast
                           timeframe being traded, not always defaulting to 1h.

        Returns a dict with keys:
            direction, aegis_score, gates, signal_engine_votes,
            mtf_bias, sentiment_score, ml_confidence, atr
        """
        # ---- Step 1: Get primary TA votes from the preferred TF (fallback to any TF) ----
        df_1h = pd.DataFrame()
        for tf_pref in (tf_preference or ["1h", "5m", "4h", "1m", "1d"]):
            candles = candles_by_tf.get(tf_pref, [])
            if candles:
                df_1h = _candles_to_df(candles)
                if len(df_1h) >= 30:
                    break

        tech_result: dict = {"direction": "HOLD", "confidence": 0.0, "votes": {}}
        if len(df_1h) >= 30:
            try:
                tech_result = self.signal_engine.evaluate_technical(df_1h)
            except Exception as exc:
                logger.warning("SignalEngine.evaluate_technical failed: %s", exc)

        votes: dict = tech_result.get("votes", {})
        tech_direction: str = tech_result.get("direction", "HOLD")
        tech_confidence: float = float(tech_result.get("confidence", 0.0))

        # Determine primary direction from vote majority
        primary_direction = self._primary_direction(votes, tech_direction)

        # ---- Step 2: MTF confluence ----
        mtf_bias = "HOLD"
        mtf_confidence = 0.0
        try:
            mtf_result = _run_async(
                self.mtf_confluence.evaluate_confluence(symbol, candles_by_tf)
            )
            mtf_bias = mtf_result.get("overall_bias", "HOLD")
            alignment_score = mtf_result.get("alignment_score", 0)
            total_tfs = max(mtf_result.get("total_timeframes", 1), 1)
            mtf_confidence = alignment_score / total_tfs
        except Exception as exc:
            logger.warning("MultiTFConfluence.evaluate_confluence failed: %s", exc)

        # ---- Step 3: Sentiment ----
        sentiment_score = 0.0
        try:
            sentiment_result = self.news_sentiment.get_composite_score()
            sentiment_score = float(sentiment_result.get("composite", 0.0))
        except Exception as exc:
            logger.warning("NewsSentiment.get_composite_score failed: %s", exc)

        # ---- Step 4: ML ensemble confidence ----
        ml_confidence = 0.5
        try:
            ml_features = {
                "tech_confidence": tech_confidence,
                "tf_confidence": mtf_confidence,
                "confirmations": sum(1 for v in votes.values() if v == primary_direction),
                "side": primary_direction,
            }
            ml_confidence = float(self.ml_ensemble.predict_confidence(ml_features))
        except Exception as exc:
            logger.warning("MLEnsemble.predict_confidence failed: %s", exc)

        # ---- Step 5: Evaluate each gate ----
        gates: Dict[str, dict] = {}
        passing_weight = 0.0

        for gate_name, weight in GATE_WEIGHTS.items():
            passed = False
            try:
                passed = self._evaluate_gate(
                    gate_name=gate_name,
                    primary=primary_direction,
                    votes=votes,
                    mtf_bias=mtf_bias,
                    sentiment_score=sentiment_score,
                    ml_confidence=ml_confidence,
                )
            except Exception as exc:
                logger.warning("Gate %s evaluation error: %s", gate_name, exc)

            contribution = weight if passed else 0.0
            if passed:
                passing_weight += weight

            gates[gate_name] = {
                "passed": passed,
                "weight": weight,
                "contribution": contribution,
            }

        # ---- Step 6: AegisScore and final direction ----
        aegis_score = round((passing_weight / TOTAL_WEIGHT) * 100, 1)

        direction = "HOLD"
        if aegis_score >= 65.0:
            if primary_direction in ("BUY", "SELL"):
                direction = primary_direction

        return {
            "direction": direction,
            "aegis_score": aegis_score,
            "gates": gates,
            "signal_engine_votes": votes,
            "mtf_bias": mtf_bias,
            "sentiment_score": sentiment_score,
            "ml_confidence": ml_confidence,
            "atr": atr,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _primary_direction(votes: dict, tech_direction: str) -> str:
        """Determine primary direction from indicator votes."""
        buy_count = sum(1 for v in votes.values() if v == "BUY")
        sell_count = sum(1 for v in votes.values() if v == "SELL")
        if buy_count > sell_count and buy_count >= 2:
            return "BUY"
        if sell_count > buy_count and sell_count >= 2:
            return "SELL"
        # Fall back to tech_direction if it's decisive
        if tech_direction in ("BUY", "SELL"):
            return tech_direction
        return "HOLD"

    @staticmethod
    def _evaluate_gate(
        gate_name: str,
        primary: str,
        votes: dict,
        mtf_bias: str,
        sentiment_score: float,
        ml_confidence: float,
    ) -> bool:
        """Return True if this gate passes for the primary direction."""
        if primary == "HOLD":
            # Gates can't pass for HOLD direction
            return False

        if gate_name == "trend_alignment":
            return mtf_bias == primary

        elif gate_name == "rsi_filter":
            return votes.get("rsi") == primary

        elif gate_name == "macd_confirmation":
            return votes.get("macd") == primary

        elif gate_name == "bollinger_position":
            return votes.get("bb") == primary

        elif gate_name == "volume_confirmation":
            # Use VWAP vote as volume/price proxy
            return votes.get("vwap") == primary

        elif gate_name == "sentiment_gate":
            if primary == "BUY":
                return sentiment_score > 0
            elif primary == "SELL":
                return sentiment_score < 0
            return False

        elif gate_name == "ai_ensemble_vote":
            return ml_confidence >= 0.60

        return False
