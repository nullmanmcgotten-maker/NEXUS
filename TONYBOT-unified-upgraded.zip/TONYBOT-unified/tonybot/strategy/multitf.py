"""
tonybot/strategy/multitf.py — Multi-Timeframe Confluence Matrix
Evaluates direction bias across multiple timeframes (1m, 5m, 1h, 4h).
"""
import asyncio
from typing import Dict, List, Any

from tonybot.strategy.signals import SignalEngine


class MultiTFConfluence:
    """Evaluates multi-timeframe alignment across configured timeframes."""

    def __init__(self, timeframes: List[str] = None):
        self.timeframes = timeframes or ["1m", "5m", "1h", "4h"]
        self.engine = SignalEngine()

    async def evaluate_confluence(self, symbol: str, candles_by_tf: Dict[str, list]) -> Dict[str, Any]:
        biases = {}
        for tf in self.timeframes:
            candles = candles_by_tf.get(tf, [])
            if candles:
                res = await self.engine.evaluate(symbol, candles)
                biases[tf] = res.get("direction", "HOLD")
            else:
                biases[tf] = "HOLD"

        buys = sum(1 for d in biases.values() if d == "BUY")
        sells = sum(1 for d in biases.values() if d == "SELL")
        total = len(biases) or 1

        overall_bias = "BUY" if buys > sells and buys >= 2 else ("SELL" if sells > buys and sells >= 2 else "HOLD")
        alignment_score = max(buys, sells)

        return {
            "symbol": symbol,
            "overall_bias": overall_bias,
            "alignment_score": alignment_score,
            "total_timeframes": total,
            "biases": biases,
        }
