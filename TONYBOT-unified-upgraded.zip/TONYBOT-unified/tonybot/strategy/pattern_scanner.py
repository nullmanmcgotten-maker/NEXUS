"""
tonybot/strategy/pattern_scanner.py — Chart Pattern Scanner

Ported (rewritten, not copy-pasted) from nexus-portfolio's patterns.js:
double top/bottom, head & shoulders, bull/bear flag, ascending triangle,
and RSI divergence, running against real OHLCV candles instead of nexus's
tick-approximated candles.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal

import pandas as pd

PatternDirection = Literal["bullish", "bearish"]
Confidence = Literal["High", "Medium", "Low"]


@dataclass
class PatternMatch:
    pattern: str
    direction: PatternDirection
    confidence: Confidence
    description: str
    index: int  # candle index where the pattern was confirmed


def _rsi(closes: pd.Series, period: int = 14) -> pd.Series:
    delta = closes.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    rs = gain / loss.replace(0, float("nan"))
    return 100 - (100 / (1 + rs))


def _find_peaks_troughs(high: pd.Series, low: pd.Series):
    peaks, troughs = [], []
    n = len(high)
    for i in range(2, n - 2):
        if high.iloc[i] > high.iloc[i-1] and high.iloc[i] > high.iloc[i-2] \
           and high.iloc[i] > high.iloc[i+1] and high.iloc[i] > high.iloc[i+2]:
            peaks.append((i, high.iloc[i]))
        if low.iloc[i] < low.iloc[i-1] and low.iloc[i] < low.iloc[i-2] \
           and low.iloc[i] < low.iloc[i+1] and low.iloc[i] < low.iloc[i+2]:
            troughs.append((i, low.iloc[i]))
    return peaks, troughs


def detect_patterns(df: pd.DataFrame) -> List[PatternMatch]:
    """
    df must have columns: open, high, low, close (as produced by
    CCXTDataSource.fetch_ohlcv_df). Needs at least 25 candles.
    """
    if len(df) < 25:
        return []

    high, low, close = df["high"], df["low"], df["close"]
    n = len(df)
    last = n - 1
    results: List[PatternMatch] = []

    peaks, troughs = _find_peaks_troughs(high, low)

    # Double Top
    if len(peaks) >= 2:
        (i1, v1), (i2, v2) = peaks[-2], peaks[-1]
        if abs(v1 - v2) / v1 < 0.02 and (i2 - i1) >= 5:
            results.append(PatternMatch(
                "Double Top", "bearish", "High",
                f"Two peaks near ${v1:,.2f} — bearish reversal signal", i2,
            ))

    # Double Bottom
    if len(troughs) >= 2:
        (i1, v1), (i2, v2) = troughs[-2], troughs[-1]
        if abs(v1 - v2) / v1 < 0.02 and (i2 - i1) >= 5:
            results.append(PatternMatch(
                "Double Bottom", "bullish", "High",
                f"Two troughs near ${v1:,.2f} — bullish reversal signal", i2,
            ))

    # Head & Shoulders
    if len(peaks) >= 3:
        (il, vl), (ih, vh), (ir, vr) = peaks[-3], peaks[-2], peaks[-1]
        if vh > vl and vh > vr and abs(vl - vr) / vl < 0.04:
            results.append(PatternMatch(
                "Head & Shoulders", "bearish", "Medium",
                f"Head at ${vh:,.2f}, shoulders at ${vl:,.2f}/${vr:,.2f}", ir,
            ))

    # Inverse Head & Shoulders
    if len(troughs) >= 3:
        (il, vl), (ih, vh), (ir, vr) = troughs[-3], troughs[-2], troughs[-1]
        if vh < vl and vh < vr and abs(vl - vr) / vl < 0.04:
            results.append(PatternMatch(
                "Inverse Head & Shoulders", "bullish", "Medium",
                f"Head at ${vh:,.2f}, shoulders at ${vl:,.2f}/${vr:,.2f}", ir,
            ))

    # Bull / Bear Flag
    if n >= 25:
        recent = close.iloc[-10:]
        pre = close.iloc[-25:-10]
        pre_move_pct = (pre.iloc[-1] - pre.iloc[0]) / pre.iloc[0] * 100
        consolidation = recent.max() / recent.min() - 1
        if pre_move_pct > 8 and consolidation < 0.04:
            results.append(PatternMatch(
                "Bull Flag", "bullish", "Medium",
                f"+{pre_move_pct:.1f}% pole, tight {consolidation*100:.1f}% flag — continuation likely", last,
            ))
        if pre_move_pct < -8 and consolidation < 0.04:
            results.append(PatternMatch(
                "Bear Flag", "bearish", "Medium",
                f"{pre_move_pct:.1f}% pole, tight {consolidation*100:.1f}% flag — breakdown likely", last,
            ))

    # Ascending Triangle
    if len(troughs) >= 3:
        last3 = troughs[-3:]
        rising_lows = last3[2][1] > last3[1][1] > last3[0][1]
        flat_resistance = abs(high.iloc[last] - high.iloc[last-5]) / high.iloc[last] < 0.015
        if rising_lows and flat_resistance:
            results.append(PatternMatch(
                "Ascending Triangle", "bullish", "Medium",
                f"Rising lows + flat resistance at ${high.iloc[last]:,.2f} — bullish breakout setup", last,
            ))

    # RSI Divergence
    rsi = _rsi(close)
    if len(peaks) >= 2:
        (i1, v1), (i2, v2) = peaks[-2], peaks[-1]
        r1, r2 = rsi.iloc[i1], rsi.iloc[i2]
        if pd.notna(r1) and pd.notna(r2):
            price_higher = v2 > v1
            rsi_lower = r2 < r1
            if price_higher and rsi_lower:
                results.append(PatternMatch(
                    "Bearish RSI Divergence", "bearish", "High",
                    "Price made a higher high but RSI made a lower high — momentum weakening", last,
                ))
            elif not price_higher and not rsi_lower:
                results.append(PatternMatch(
                    "Bullish RSI Divergence", "bullish", "High",
                    "Price made a lower high but RSI made a higher high — hidden strength", last,
                ))

    return results
