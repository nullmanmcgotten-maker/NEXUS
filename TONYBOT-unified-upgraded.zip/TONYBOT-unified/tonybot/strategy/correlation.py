"""
tonybot/strategy/correlation.py — Portfolio Correlation Matrix

Ported (rewritten) from nexus-portfolio's expert.js computeCorrelation /
renderCorrelationMatrix. Computes Pearson correlation between assets' return
series so correlated exposure can be flagged before it's opened — TONYBOT's
CorrelationAwareSizer already penalizes correlated positions, this is what
feeds it real numbers instead of a manually-supplied count.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np


@dataclass
class CorrelationMatrix:
    symbols: List[str]
    matrix: List[List[Optional[float]]]  # None where insufficient data

    def get(self, sym_a: str, sym_b: str) -> Optional[float]:
        if sym_a not in self.symbols or sym_b not in self.symbols:
            return None
        i, j = self.symbols.index(sym_a), self.symbols.index(sym_b)
        return self.matrix[i][j]

    def highly_correlated_pairs(self, threshold: float = 0.7) -> List[tuple]:
        """Pairs at or above `threshold` |correlation| — candidates for the
        correlation penalty in position sizing."""
        pairs = []
        for i, a in enumerate(self.symbols):
            for j, b in enumerate(self.symbols):
                if j <= i:
                    continue
                v = self.matrix[i][j]
                if v is not None and abs(v) >= threshold:
                    pairs.append((a, b, v))
        return pairs


def _pearson(a: np.ndarray, b: np.ndarray) -> Optional[float]:
    n = min(len(a), len(b))
    if n < 5:
        return None
    a, b = a[-n:], b[-n:]
    a_dev, b_dev = a - a.mean(), b - b.mean()
    denom = np.sqrt((a_dev**2).sum() * (b_dev**2).sum())
    if denom == 0:
        return None
    return round(float((a_dev * b_dev).sum() / denom), 2)


def compute_correlation_matrix(price_histories: Dict[str, List[float]], max_assets: int = 8) -> CorrelationMatrix:
    """
    price_histories: {symbol: [close prices in chronological order]}.
    Only symbols with >=10 price points are included, capped at max_assets
    (matches nexus's `.slice(0, 8)` cap to keep the matrix readable).
    """
    symbols = [s for s, prices in price_histories.items() if len(prices) >= 10][:max_assets]
    returns = {}
    for s in symbols:
        prices = np.array(price_histories[s], dtype=float)
        returns[s] = (prices[1:] - prices[:-1]) / prices[:-1]

    matrix: List[List[Optional[float]]] = []
    for a in symbols:
        row = []
        for b in symbols:
            row.append(1.0 if a == b else _pearson(returns[a], returns[b]))
        matrix.append(row)

    return CorrelationMatrix(symbols=symbols, matrix=matrix)
