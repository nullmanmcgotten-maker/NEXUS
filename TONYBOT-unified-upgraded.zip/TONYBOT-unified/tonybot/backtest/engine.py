"""
tonybot/backtest/engine.py — Historical Backtester with Fee & Slippage Modeling
Simulates strategy performance over real OHLCV data with gate validation.

Two entry-signal sources are supported:
  - "legacy":     the original lagging-only SetupScanner path (regime + 4-source
                  setup confirmation). Fast, no network, always available.
  - "predictive": the same PredictiveSignalEngine (AEGIS lagging consensus +
                  gated leading confirmation) that core/engine.py now uses live.
                  IMPORTANT LIMITATION: historical L2 order-book data doesn't
                  exist here, so the order-flow-imbalance leading confirmation
                  can never fire in backtest — only the chart-pattern leading
                  confirmation can. A predictive backtest is therefore a valid
                  test of the "lagging consensus + pattern confluence" half of
                  the gate, not the full live gate. Treat a predictive backtest
                  pass as a floor, not a ceiling, on live performance.
"""
from __future__ import annotations

import logging
from typing import List, Dict, Any, Optional
import pandas as pd
import numpy as np

from tonybot.interfaces import BacktestResult, Trade, OrderSide, OrderStatus
from tonybot.strategy.regime_classifier import RegimeClassifier
from tonybot.strategy.setup_scanner import SetupScanner

logger = logging.getLogger("tonybot.backtest")


class _NullNewsSentiment:
    """Neutral, network-free sentiment stub for backtesting.

    Using the *live* NewsSentiment here would apply today's news score to
    every historical bar — meaningless at best, look-ahead bias at worst.
    Backtests instead run the sentiment_gate as always-neutral (fails for
    both directions), which is honest about what history alone can validate.
    """

    def get_composite_score(self) -> dict:
        return {"composite": 0.0}


def _compute_atr(candles: list, length: int = 14) -> float:
    """True-range ATR from raw [[ts,o,h,l,c,v], ...] candles."""
    if len(candles) < 2:
        return 0.0
    trs = []
    window = candles[-(length + 1):]
    for i in range(1, len(window)):
        hi, lo, prev_close = window[i][2], window[i][3], window[i - 1][4]
        trs.append(max(hi - lo, abs(hi - prev_close), abs(lo - prev_close)))
    return sum(trs) / len(trs) if trs else 0.0


def _df_window_to_raw_candles(window: pd.DataFrame) -> list:
    """Convert an OHLCV DataFrame slice (DatetimeIndex) to raw
    [[ts_ms,o,h,l,c,v], ...] — the format SignalRefiner/PredictiveSignalEngine
    expect, mirroring what ccxt/Binance REST return live."""
    ts_ms = (window.index.astype("int64") // 1_000_000).tolist()
    return [
        [ts_ms[i], float(row.open), float(row.high), float(row.low), float(row.close), float(row.volume)]
        for i, row in enumerate(window.itertuples(index=False))
    ]


class BacktestEngine:
    """Historical backtester with realistic fee, slippage, and gate validation."""

    def __init__(
        self,
        initial_balance: float = 10000.0,
        taker_fee_pct: float = 0.001,
        slippage_pct: float = 0.0005,
    ):
        self.initial_balance = initial_balance
        self.taker_fee_pct = taker_fee_pct
        self.slippage_pct = slippage_pct
        self.classifier = RegimeClassifier()
        self.scanner = SetupScanner()
        self._predictive_engine = None  # lazily built; heavier import chain

    def _get_predictive_engine(self):
        if self._predictive_engine is None:
            from tonybot.strategy.signal_refiner import SignalRefiner
            from tonybot.strategy.trade_signal import PredictiveSignalEngine
            from tonybot.risk.risk_manager import RiskManager

            signal_refiner = SignalRefiner(news_sentiment=_NullNewsSentiment())
            self._predictive_engine = PredictiveSignalEngine(
                signal_refiner=signal_refiner,
                risk_manager=RiskManager(),
            )
        return self._predictive_engine

    def run(
        self,
        symbol: str,
        df: pd.DataFrame,
        mode: str = "legacy",
        timeframe_label: str = "1h",
        lookback_bars: int = 300,
    ) -> BacktestResult:
        """
        mode: "legacy" (default, fast, original setup_scanner path) or
              "predictive" (gated AEGIS + pattern-confirmation path — see
              module docstring for the order-flow limitation).
        lookback_bars: for mode="predictive" only — how many trailing candles
              are handed to the signal pipeline as history at each bar (it
              recomputes indicators from scratch each step, so this bounds
              per-bar cost instead of feeding the ever-growing full window).
        """
        if df.empty or len(df) < 50:
            return BacktestResult(
                symbol=symbol, start="N/A", end="N/A", total_trades=0,
                win_rate=0.0, profit_factor=0.0, total_return_pct=0.0,
                max_drawdown_pct=0.0, sharpe_ratio=0.0
            )

        if mode == "predictive":
            return self._run_predictive(symbol, df, timeframe_label, lookback_bars)
        return self._run_legacy(symbol, df)

    # ------------------------------------------------------------------
    # Legacy path (original lagging-only setup_scanner)
    # ------------------------------------------------------------------
    def _run_legacy(self, symbol: str, df: pd.DataFrame) -> BacktestResult:
        balance = self.initial_balance
        peak_balance = self.initial_balance
        max_drawdown = 0.0
        trades: List[Trade] = []
        equity_curve: List[float] = [balance]

        annotated = self.classifier.annotate(df)

        for i in range(50, len(annotated)):
            window = annotated.iloc[:i+1]
            last_candle = window.iloc[-1]
            regime = self.classifier.classify(symbol, window)
            setups = self.scanner.scan(symbol, window, regime)

            for setup in setups:
                entry_price = setup.entry_price * (1 + self.slippage_pct if setup.direction == OrderSide.BUY else 1 - self.slippage_pct)
                stop_loss = setup.stop_loss
                take_profit = setup.take_profit
                trade, balance, peak_balance, max_drawdown = self._simulate_trade(
                    symbol=symbol, direction=setup.direction, entry_price=entry_price,
                    stop_loss=stop_loss, take_profit=take_profit, entry_time=last_candle.name,
                    future=annotated.iloc[i+1:min(i+30, len(annotated))],
                    balance=balance, peak_balance=peak_balance, max_drawdown=max_drawdown,
                )
                if trade is not None:
                    trades.append(trade)
                    equity_curve.append(balance)
                break  # process one setup per candle bar

        return self._build_result(symbol, df, trades, equity_curve, balance)

    # ------------------------------------------------------------------
    # Predictive path (AEGIS lagging consensus + pattern leading confirmation)
    # ------------------------------------------------------------------
    def _run_predictive(self, symbol: str, df: pd.DataFrame, timeframe_label: str, lookback_bars: int) -> BacktestResult:
        engine = self._get_predictive_engine()

        balance = self.initial_balance
        peak_balance = self.initial_balance
        max_drawdown = 0.0
        trades: List[Trade] = []
        equity_curve: List[float] = [balance]

        min_bars = max(50, lookback_bars // 4)
        for i in range(min_bars, len(df)):
            window = df.iloc[max(0, i + 1 - lookback_bars):i + 1]
            if len(window) < 30:
                continue

            raw_candles = _df_window_to_raw_candles(window)
            atr = _compute_atr(raw_candles)

            try:
                result = engine.build_signal(
                    symbol=symbol,
                    candles_by_tf={timeframe_label: raw_candles},
                    atr=atr,
                    orderbook=None,  # no historical L2 data — see module docstring
                    pattern_df=window,
                )
            except Exception as e:
                logger.debug(f"Predictive signal error at bar {i}: {e}")
                continue

            signal = result.get("signal")
            if signal is None:
                continue

            direction = OrderSide.BUY if signal.direction == "BUY" else OrderSide.SELL
            entry_price = signal.entry * (1 + self.slippage_pct if direction == OrderSide.BUY else 1 - self.slippage_pct)

            trade, balance, peak_balance, max_drawdown = self._simulate_trade(
                symbol=symbol, direction=direction, entry_price=entry_price,
                stop_loss=signal.stop_loss, take_profit=signal.take_profit, entry_time=window.index[-1],
                future=df.iloc[i+1:min(i+30, len(df))],
                balance=balance, peak_balance=peak_balance, max_drawdown=max_drawdown,
            )
            if trade is not None:
                trades.append(trade)
                equity_curve.append(balance)

        return self._build_result(symbol, df, trades, equity_curve, balance)

    # ------------------------------------------------------------------
    # Shared trade simulation (fee + slippage + forward-looking SL/TP exit)
    # ------------------------------------------------------------------
    def _simulate_trade(
        self, symbol: str, direction: OrderSide, entry_price: float,
        stop_loss: float, take_profit: float, entry_time,
        future: pd.DataFrame, balance: float, peak_balance: float, max_drawdown: float,
    ):
        risk_amt = balance * 0.02
        stop_dist = abs(entry_price - stop_loss)
        if stop_dist <= 0:
            return None, balance, peak_balance, max_drawdown

        qty = risk_amt / stop_dist
        fee_entry = entry_price * qty * self.taker_fee_pct

        exit_price = entry_price
        exit_time = entry_time

        for f_idx, f_row in future.iterrows():
            high = f_row["high"]
            low = f_row["low"]

            if direction == OrderSide.BUY:
                if low <= stop_loss:
                    exit_price = stop_loss * (1 - self.slippage_pct)
                    exit_time = f_idx
                    break
                elif high >= take_profit:
                    exit_price = take_profit * (1 - self.slippage_pct)
                    exit_time = f_idx
                    break
            else:
                if high >= stop_loss:
                    exit_price = stop_loss * (1 + self.slippage_pct)
                    exit_time = f_idx
                    break
                elif low <= take_profit:
                    exit_price = take_profit * (1 + self.slippage_pct)
                    exit_time = f_idx
                    break

        fee_exit = exit_price * qty * self.taker_fee_pct
        total_fees = fee_entry + fee_exit

        if direction == OrderSide.BUY:
            raw_pnl = (exit_price - entry_price) * qty
        else:
            raw_pnl = (entry_price - exit_price) * qty

        net_pnl = raw_pnl - total_fees
        balance += net_pnl

        peak_balance = max(peak_balance, balance)
        dd = (peak_balance - balance) / peak_balance if peak_balance > 0 else 0.0
        max_drawdown = max(max_drawdown, dd)

        trade = Trade(
            symbol=symbol, side=direction, entry_price=entry_price,
            quantity=qty, stop_loss=stop_loss, take_profit=take_profit,
            entry_time=entry_time, exit_price=exit_price, exit_time=exit_time,
            pnl=net_pnl, status=OrderStatus.FILLED, fees_paid=total_fees
        )
        return trade, balance, peak_balance, max_drawdown

    def _build_result(self, symbol: str, df: pd.DataFrame, trades: List[Trade], equity_curve: List[float], balance: float) -> BacktestResult:
        total_trades = len(trades)
        wins = [t for t in trades if (t.pnl or 0) > 0]
        losses = [t for t in trades if (t.pnl or 0) <= 0]
        win_rate = len(wins) / total_trades if total_trades > 0 else 0.0

        gross_win = sum(t.pnl for t in wins) if wins else 0.0
        gross_loss = abs(sum(t.pnl for t in losses)) if losses else 1.0
        profit_factor = gross_win / gross_loss if gross_loss > 0 else gross_win

        total_return_pct = (balance - self.initial_balance) / self.initial_balance

        equity_arr = np.array(equity_curve, dtype=float)
        returns = np.diff(equity_arr) / equity_arr[:-1] if len(equity_arr) > 1 else np.array([0.0])
        max_drawdown = 0.0
        if len(equity_arr) > 0:
            running_peak = np.maximum.accumulate(equity_arr)
            drawdowns = (running_peak - equity_arr) / np.where(running_peak > 0, running_peak, 1.0)
            max_drawdown = float(np.max(drawdowns)) if len(drawdowns) else 0.0
        sharpe = (np.mean(returns) / np.std(returns) * np.sqrt(365 * 24)) if len(returns) > 5 and np.std(returns) > 0 else 0.0

        return BacktestResult(
            symbol=symbol,
            start=str(df.index[0]),
            end=str(df.index[-1]),
            total_trades=total_trades,
            win_rate=win_rate,
            profit_factor=profit_factor,
            total_return_pct=total_return_pct,
            max_drawdown_pct=max_drawdown,
            sharpe_ratio=sharpe,
            trades=trades,
        )
