"""
tonybot/backtest/optimizer.py — Optuna Bayesian Hyperparameter Optimizer
Optimizes strategy parameters (ADX threshold, min confirmations, risk multipliers).
"""
import logging
from typing import Dict, Any
import pandas as pd

try:
    import optuna
    HAS_OPTUNA = True
except ImportError:
    HAS_OPTUNA = False

from tonybot.backtest.engine import BacktestEngine

logger = logging.getLogger("tonybot.optimizer")


class OptunaOptimizer:
    """Bayesian Hyperparameter Optimizer for strategy tuning."""

    def __init__(self, n_trials: int = 30):
        self.n_trials = n_trials

    def optimize(self, symbol: str, df: pd.DataFrame) -> Dict[str, Any]:
        if not HAS_OPTUNA:
            logger.warning("Optuna not installed — returning default parameters.")
            return {"adx_threshold": 25.0, "min_confirmations": 3}

        def objective(trial):
            adx_thresh = trial.suggest_float("adx_threshold", 15.0, 35.0)
            min_conf = trial.suggest_int("min_confirmations", 2, 4)

            engine = BacktestEngine()
            engine.classifier.trending_threshold = adx_thresh
            engine.scanner.min_confirmations = min_conf

            res = engine.run(symbol, df)
            return res.sharpe_ratio

        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(direction="maximize")
        study.optimize(objective, n_trials=self.n_trials)

        logger.info(f"Optuna Optimization Best Params for {symbol}: {study.best_params}")
        return study.best_params
