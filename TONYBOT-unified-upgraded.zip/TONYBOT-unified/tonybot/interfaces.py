"""
TONYBOT Core Type Definitions, Interfaces, Protocols, Dataclasses, and Enums.
Synthesized from Oshai and ApexBot v5 architecture.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, Protocol, List, Dict, Any


class TrendDirection(str, Enum):
    UP = "UP"
    DOWN = "DOWN"
    NONE = "NONE"


class RegimeType(str, Enum):
    TRENDING = "TRENDING"
    RANGING = "RANGING"
    VOLATILE = "VOLATILE"
    UNKNOWN = "UNKNOWN"


class SetupType(str, Enum):
    PULLBACK_TO_MA = "PULLBACK_TO_MA"
    SUPPORT_RESISTANCE_BOUNCE = "SUPPORT_RESISTANCE_BOUNCE"
    BREAKOUT = "BREAKOUT"
    RSI_DIVERGENCE = "RSI_DIVERGENCE"
    CONFLUENCE = "CONFLUENCE"


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    NEUTRAL = "NEUTRAL"


class OrderStatus(str, Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


@dataclass
class Candle:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass
class Regime:
    symbol: str
    regime_type: RegimeType
    trend_direction: TrendDirection
    adx: float
    timestamp: datetime


@dataclass
class Setup:
    symbol: str
    setup_type: SetupType
    direction: OrderSide
    confirmations: int
    confirmation_sources: List[str] = field(default_factory=list)
    entry_price: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0
    timestamp: Optional[datetime] = None
    confidence_score: float = 0.0


@dataclass
class SignalResult:
    symbol: str
    timeframe: str
    direction: OrderSide
    consensus_score: int
    signals: Dict[str, str] = field(default_factory=dict)
    indicator_values: Dict[str, float] = field(default_factory=dict)
    regime: str = "UNKNOWN"
    ml_confidence: float = 0.0
    timestamp: Optional[datetime] = None


@dataclass
class PositionSize:
    risk_pct: float
    position_value: float
    quantity: float
    stop_loss_price: float
    take_profit_price: float = 0.0


@dataclass
class Trade:
    symbol: str
    side: OrderSide
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit: float
    entry_time: datetime
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    pnl: Optional[float] = None
    pnl_pct: Optional[float] = None
    status: OrderStatus = OrderStatus.PENDING
    fees_paid: float = 0.0
    trade_id: Optional[str] = None
    setup_type: Optional[str] = None


@dataclass
class BacktestResult:
    symbol: str
    start: str
    end: str
    total_trades: int
    win_rate: float
    profit_factor: float
    total_return_pct: float
    max_drawdown_pct: float
    sharpe_ratio: float
    sortino_ratio: float = 0.0
    trades: List[Trade] = field(default_factory=list)

    def passes_gate(self, min_win_rate: float = 0.45, min_profit_factor: float = 1.5) -> bool:
        return self.win_rate >= min_win_rate and self.profit_factor >= min_profit_factor


# --- Protocols (Interface Contracts) ---

class DataSource(Protocol):
    def fetch_ohlcv(self, symbol: str, timeframe: str, since: Optional[int], limit: int) -> List[Candle]: ...


class Sizer(Protocol):
    def size(self, balance: float, confirmations: int, entry: float, stop_loss: float) -> PositionSize: ...


class RiskManagerProtocol(Protocol):
    def can_open_position(self, symbol: str, open_positions: int) -> bool: ...
    def check_circuit_breaker(self, current_drawdown_pct: float) -> bool: ...
