"""
tonybot/core/signal_tracker.py — Live Signal Outcome Tracker

Logs every fired TradeSignal, then on subsequent price ticks checks whether
price has hit the stop-loss or take-profit and resolves the outcome as
WIN/LOSS. This is what lets PredictiveSignalEngine report a real, live
accuracy rate per setup type instead of a static backtest number that never
updates.
"""
from __future__ import annotations

import logging
from typing import Optional, Tuple

logger = logging.getLogger("tonybot.signal_tracker")


class SignalTracker:
    def __init__(self, db):
        self.db = db

    def log_signal(self, signal) -> int:
        """signal: a TradeSignal (see strategy.trade_signal)."""
        return self.db.log_signal_outcome(
            symbol=signal.symbol,
            setup_type=signal.setup_type,
            direction=signal.direction,
            entry_price=signal.entry,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
            confidence_at_signal=signal.confidence_pct,
        )

    def resolve_pending(self, symbol: str, high: float, low: float) -> list:
        """
        Check all PENDING signals for `symbol` against the high/low of the
        latest price move. Resolves WIN if take_profit was touched, LOSS if
        stop_loss was touched. If both were technically touched in the same
        tick (fast move), stop-loss takes precedence — conservative.
        Returns list of (outcome_id, status) resolved this call.
        """
        resolved = []
        for row in self.db.get_pending_outcomes(symbol):
            direction = row["direction"]
            sl = row["stop_loss"]
            tp = row["take_profit"]

            hit_sl = (direction == "BUY" and low <= sl) or (direction == "SELL" and high >= sl)
            hit_tp = (direction == "BUY" and high >= tp) or (direction == "SELL" and low <= tp)

            if hit_sl:
                self.db.resolve_signal_outcome(row["outcome_id"], "LOSS", sl)
                resolved.append((row["outcome_id"], "LOSS"))
            elif hit_tp:
                self.db.resolve_signal_outcome(row["outcome_id"], "WIN", tp)
                resolved.append((row["outcome_id"], "WIN"))
        return resolved

    def get_win_rate(self, setup_type: str) -> Tuple[Optional[float], int]:
        result = self.db.get_setup_win_rate(setup_type)
        return result["win_rate"], result["sample_size"]
