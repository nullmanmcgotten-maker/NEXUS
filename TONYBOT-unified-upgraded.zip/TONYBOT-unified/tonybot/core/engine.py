"""
tonybot/core/engine.py — Core Async Trading Engine for TONYBOT
Main async trading loop connecting data fetching, regime classification, setup scanning,
technical signals, risk checks, position sizing, execution, and journaling.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone, date
from typing import Dict, List, Any, Optional

from tonybot.config import config
from tonybot.interfaces import OrderSide, RegimeType, Setup
from tonybot.core.db import Database
from tonybot.core.signal_tracker import SignalTracker
from tonybot.data.ccxt_source import CCXTDataSource
from tonybot.strategy.regime_classifier import RegimeClassifier
from tonybot.strategy.setup_scanner import SetupScanner
from tonybot.strategy.signals import SignalEngine
from tonybot.strategy.multitf import MultiTFConfluence
from tonybot.strategy.signal_refiner import SignalRefiner, _candles_to_df as _raw_candles_to_df
from tonybot.strategy.trade_signal import PredictiveSignalEngine, TradeSignal
from tonybot.risk.risk_manager import RiskManager
from tonybot.risk.position_sizing import KellySizer, CorrelationAwareSizer
from tonybot.risk.heat_guard import PortfolioHeatGuard
from tonybot.exchanges.manager import ExchangeManager
from tonybot.ml.ensemble import MLEnsemble
from tonybot.alerts.notifier import Notifier

logger = logging.getLogger("tonybot.engine")

# Scalp vs swing profiles for gather_predictive_signal()/process_cycle(). Both
# share one PredictiveSignalEngine instance (see TradingEngine.__init__) —
# these just parametrize which timeframes it reads and how wide its ATR-based
# stop/target are, so "swing and scalp trading" is two coherent, independently
# risk-managed position streams per symbol rather than one blended average.
TRADING_PROFILES: Dict[str, Dict[str, Any]] = {
    "scalp": {
        "tf_preference": ["1m", "5m", "1h"],
        "atr_source_tf": ["1m", "5m"],
        "sl_atr_mult": 1.0,
        "tp_atr_mult": 1.5,
    },
    "swing": {
        "tf_preference": ["4h", "1h", "5m"],
        "atr_source_tf": ["4h", "1h"],
        "sl_atr_mult": 2.0,
        "tp_atr_mult": 4.0,
    },
}


def _active_profiles() -> List[str]:
    mode = (config.TRADING_MODE or "both").lower()
    if mode == "both":
        return ["scalp", "swing"]
    if mode in TRADING_PROFILES:
        return [mode]
    logger.warning(f"Unknown TRADING_MODE '{config.TRADING_MODE}' — defaulting to swing only.")
    return ["swing"]


def _position_key(symbol: str, profile: str) -> str:
    return f"{symbol}|{profile}"


def _split_position_key(key: str) -> tuple:
    if "|" in key:
        symbol, profile = key.split("|", 1)
        return symbol, profile
    return key, "swing"  # backward-compat for any pre-existing bare-symbol keys


class TradingEngine:
    """Core Trading Engine orchestrating automated scanning and execution."""

    def __init__(self):
        self.db = Database()
        self.data_source = CCXTDataSource(exchange_id=config.EXCHANGE_ID)
        self.regime_classifier = RegimeClassifier(
            trending_threshold=config.ADX_TRENDING_THRESHOLD,
            ranging_threshold=config.ADX_RANGING_THRESHOLD
        )
        self.setup_scanner = SetupScanner(min_confirmations=config.MIN_CONFIRMATIONS_REQUIRED)
        self.signal_engine = SignalEngine()
        self.multitf_matrix = MultiTFConfluence(timeframes=config.TIMEFRAMES)
        self.risk_manager = RiskManager(
            max_concurrent_positions=config.MAX_CONCURRENT_POSITIONS,
            max_daily_loss_pct=config.MAX_DAILY_LOSS_PCT,
            max_drawdown_pct=config.MAX_DRAWDOWN_PCT,
            max_portfolio_heat_pct=config.MAX_PORTFOLIO_HEAT_PCT
        )
        self.base_sizer = KellySizer(
            risk_full=config.MAX_RISK_PER_TRADE_FULL,
            risk_partial=config.MAX_RISK_PER_TRADE_PARTIAL,
            risk_minimal=config.MAX_RISK_PER_TRADE_MINIMAL
        )
        self.position_sizer = CorrelationAwareSizer(base_sizer=self.base_sizer)
        self.heat_guard = PortfolioHeatGuard(max_heat_pct=config.MAX_PORTFOLIO_HEAT_PCT)
        self.exchange_manager = ExchangeManager()

        # --- Predictive signal stack -----------------------------------
        # Previously SignalRefiner (lagging AEGIS consensus), OrderFlowPipeline
        # (leading order-book imbalance), and PatternScanner (leading chart
        # structure) were only ever wired into GUI worker threads — the
        # headless async loop that actually drives paper/testnet/live trading
        # ran on the older, purely lagging setup_scanner path alone. That
        # meant the "smart" half of the codebase only fired while someone had
        # the window open. PredictiveSignalEngine composes all three plus
        # ATR-based risk sizing into a single gated signal (entries only fire
        # when lagging technical consensus AND at least one leading
        # confirmation agree), and SignalTracker persists every fired signal
        # so its confidence blends toward this engine's own live win-rate
        # instead of staying pinned to a static backtest prior forever.
        self.signal_tracker = SignalTracker(self.db)
        self.signal_refiner = SignalRefiner()
        self.predictive_engine = PredictiveSignalEngine(
            signal_refiner=self.signal_refiner,
            risk_manager=self.risk_manager,
            signal_tracker=self.signal_tracker,
        )
        self.ml_ensemble = MLEnsemble(min_confidence=config.ML_MIN_CONFIDENCE)
        self._try_train_ml_ensemble()
        # SignalRefiner's own ai_ensemble_vote gate (heaviest-weighted of its
        # 7 gates) otherwise lazily constructs its own untrained MLEnsemble —
        # sharing this instance means the gate benefits from the same warm
        # start instead of silently pass-throughing at 0.5 (always failing
        # its own >=0.60 threshold) until the GUI happens to train one.
        self.signal_refiner.ml_ensemble = self.ml_ensemble

        # Notifier previously existed but was never actually called from
        # anywhere — Telegram alerts, like the predictive signal engine
        # before it, only ever fired from GUI code paths. Every fired entry
        # and every close now sends a real alert with actual position size.
        self.notifier = Notifier()

        self.running = False
        self.open_positions: Dict[str, Dict[str, Any]] = {}
        self.balance = config.INITIAL_BALANCE

    def _try_train_ml_ensemble(self) -> None:
        """Best-effort warm start: train the LightGBM filter from whatever
        closed trade history already exists so it's not sitting idle at
        0.5-confidence pass-through from a cold start every restart.

        risk_reward and setup_type are derived from columns the trades table
        already has (entry/stop/take-profit, setup_type) — no schema
        migration needed. sentiment_score isn't persisted per-trade yet, so
        historical warm-start rows use a neutral 0.0 there; live predictions
        (see gather_predictive_signal) pass the real current sentiment.
        """
        try:
            closed = [t for t in self.db.get_recent_trades(limit=500) if t.get("status") == "CLOSED"]
            records = []
            for t in closed:
                entry, sl, tp = float(t.get("entry_price", 0)), float(t.get("stop_loss", 0)), float(t.get("take_profit", 0))
                risk = abs(entry - sl)
                reward = abs(tp - entry)
                records.append({
                    "tech_confidence": float(t.get("aegis_score", 50.0)) / 100.0,
                    "tf_confidence": 0.5,
                    "confirmations": 3,
                    "side": t.get("side"),
                    "risk_reward": round(reward / risk, 2) if risk > 0 else 2.0,
                    "sentiment_score": 0.0,
                    "setup_type": t.get("setup_type", ""),
                    "pnl_usd": t.get("pnl", 0.0),
                })
            if self.ml_ensemble.train(records):
                logger.info(f"ML ensemble warm-started on {len(records)} closed trades.")
        except Exception as e:
            logger.info(f"ML ensemble warm start skipped: {e}")

    async def monitor_and_close_positions(self) -> List[Dict[str, Any]]:
        """
        Checks every open position against its stop-loss / take-profit and,
        for any that have been hit, flattens the position (paper or live),
        journals the close, and realizes PnL into balance/risk tracking.

        This is the other half of process_cycle()'s entries — without it,
        positions opened by the engine are never closed, balance never moves,
        and the daily-loss/drawdown checks have nothing real to work with.
        """
        closed = []
        for pos_key, pos in list(self.open_positions.items()):
            symbol, profile = _split_position_key(pos_key)

            # If this position has real exchange-side SL/TP orders resting on
            # the exchange (see exchanges/manager.place_order), check those
            # directly first — the exchange may have already flattened the
            # position between polls. Skipping straight to a price-based
            # guess here would risk sending a redundant close order against
            # a position that's already gone, or misreporting the exit price.
            if pos.get("sl_order_id") or pos.get("tp_order_id"):
                reconciled = await self._reconcile_exchange_bracket_fill(pos_key, symbol, pos)
                if reconciled is not None:
                    closed.append(reconciled)
                    continue

            try:
                price = await self.exchange_manager.get_price(symbol)
            except Exception as e:
                logger.warning(f"Could not fetch price for {symbol} while monitoring: {e}")
                continue
            if price <= 0:
                continue

            # Symbols with an open position are skipped in process_cycle's
            # scan loop (no new entries while already holding), but any
            # still-pending signal_outcomes rows for this symbol/profile
            # still need resolving so live win-rate keeps updating. Single-
            # price high/low is an approximation here vs. the real candle
            # range used in gather_predictive_signal, but it's enough to
            # catch an obvious SL/TP touch without re-running the full fetch.
            try:
                self.signal_tracker.resolve_pending(symbol, high=price, low=price)
            except Exception as e:
                logger.debug(f"Signal tracker resolve skipped for {symbol}: {e}")

            side = pos["side"]
            hit_sl = (side == "BUY" and price <= pos["stop_loss"]) or \
                     (side == "SELL" and price >= pos["stop_loss"])
            hit_tp = (side == "BUY" and price >= pos["take_profit"]) or \
                     (side == "SELL" and price <= pos["take_profit"])
            if not (hit_sl or hit_tp):
                continue

            try:
                close_res = await self.exchange_manager.close_position(
                    symbol=symbol, side=side, quantity=pos["quantity"],
                    sl_order_id=pos.get("sl_order_id"), tp_order_id=pos.get("tp_order_id"),
                )
            except Exception as e:
                logger.error(f"Failed to close {symbol} ({profile}) at broker/exchange: {e}")
                continue

            exit_price = close_res.get("price", price) or price
            if side == "BUY":
                pnl = (exit_price - pos["entry_price"]) * pos["quantity"]
            else:
                pnl = (pos["entry_price"] - exit_price) * pos["quantity"]

            self.db.close_trade(pos["trade_id"], exit_price)
            self.balance += pos["notional"] + pnl
            self.risk_manager.record_pnl(date.today(), pnl)
            self.risk_manager.update_drawdown(self.balance)

            del self.open_positions[pos_key]
            reason = "SL" if hit_sl else "TP"
            logger.info(f"[{reason} HIT] Closed {symbol} ({profile}) {side} @ {exit_price:.4f} | PnL: {pnl:+.2f}")
            closed.append({**pos, "profile": profile, "exit_price": exit_price, "pnl": pnl, "close_reason": reason})
            await self._notify_close(symbol, profile, side, exit_price, pnl, reason)

        return closed

    async def _reconcile_exchange_bracket_fill(self, pos_key: str, symbol: str, pos: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Checks whether this position's exchange-side SL or TP order has
        already filled. Returns a close record (and updates balance/db/risk
        state) if so, or None if the position is still genuinely open."""
        for order_id, reason in ((pos.get("sl_order_id"), "SL"), (pos.get("tp_order_id"), "TP")):
            if not order_id:
                continue
            status = await self.exchange_manager.fetch_order_status(symbol, order_id)
            if not status or status.get("status") not in ("closed", "filled"):
                continue

            exit_price = float(status.get("average") or status.get("price") or 0.0)
            if exit_price <= 0:
                try:
                    exit_price = await self.exchange_manager.get_price(symbol)
                except Exception:
                    exit_price = pos["entry_price"]

            side = pos["side"]
            if side == "BUY":
                pnl = (exit_price - pos["entry_price"]) * pos["quantity"]
            else:
                pnl = (pos["entry_price"] - exit_price) * pos["quantity"]

            other_id = pos.get("tp_order_id") if reason == "SL" else pos.get("sl_order_id")
            if other_id:
                try:
                    await self.exchange_manager.cancel_order_safe(symbol, other_id)
                except Exception as e:
                    logger.debug(f"Could not cancel sibling bracket order {other_id} for {symbol}: {e}")

            self.db.close_trade(pos["trade_id"], exit_price)
            self.balance += pos["notional"] + pnl
            self.risk_manager.record_pnl(date.today(), pnl)
            self.risk_manager.update_drawdown(self.balance)
            del self.open_positions[pos_key]

            _, profile = _split_position_key(pos_key)
            logger.info(f"[{reason} HIT — exchange-filled] Closed {symbol} ({profile}) {side} @ {exit_price:.4f} | PnL: {pnl:+.2f}")
            await self._notify_close(symbol, profile, side, exit_price, pnl, reason)
            return {**pos, "profile": profile, "exit_price": exit_price, "pnl": pnl, "close_reason": reason}

        return None

    async def _notify_entry(self, symbol: str, profile: str, signal: TradeSignal, quantity: float, notional: float, order_res: Dict[str, Any]) -> None:
        try:
            await self.notifier.notify_trade_signal(
                symbol=symbol, profile=profile, side=signal.direction, setup_type=signal.setup_type,
                entry=signal.entry, stop_loss=signal.stop_loss, take_profit=signal.take_profit,
                quantity=quantity, notional=notional, confidence_pct=signal.confidence_pct,
                risk_reward=signal.risk_reward, leading_confirmations=signal.leading_confirmations,
                protected_by_exchange=order_res.get("protected_by_exchange"),
            )
        except Exception as e:
            logger.debug(f"Telegram entry notification skipped for {symbol}: {e}")

    async def _notify_close(self, symbol: str, profile: str, side: str, exit_price: float, pnl: float, reason: str) -> None:
        try:
            await self.notifier.notify_close(symbol, profile, side, exit_price, pnl, reason)
        except Exception as e:
            logger.debug(f"Telegram close notification skipped for {symbol}: {e}")

    async def scan_symbol(self, symbol: str) -> List[Setup]:
        """Fetches market candles, annotates indicators, classifies regime, and scans setups.
        Used for regime/backtest context and by the CLI orchestrator; live entries are decided
        by gather_predictive_signal() below, which is the gated leading+lagging pipeline."""
        try:
            df = await asyncio.to_thread(
                self.data_source.fetch_ohlcv_df,
                symbol, config.DEFAULT_TIMEFRAME, None, 100
            )
            if df.empty or len(df) < 30:
                return []

            annotated_df = self.regime_classifier.annotate(df)
            regime = self.regime_classifier.classify(symbol, annotated_df)
            setups = self.setup_scanner.scan(symbol, annotated_df, regime)
            return setups
        except Exception as e:
            logger.error(f"Error scanning symbol {symbol}: {e}")
            return []

    @staticmethod
    def _compute_atr(candles: list, length: int = 14) -> float:
        """True-range ATR from raw [[ts,o,h,l,c,v], ...] candles (Wilder-style simple mean)."""
        if len(candles) < 2:
            return 0.0
        trs = []
        window = candles[-(length + 1):]
        for i in range(1, len(window)):
            hi, lo, prev_close = window[i][2], window[i][3], window[i - 1][4]
            trs.append(max(hi - lo, abs(hi - prev_close), abs(lo - prev_close)))
        return sum(trs) / len(trs) if trs else 0.0

    async def gather_predictive_signal(self, symbol: str, profile: str = "swing") -> Optional[TradeSignal]:
        """
        Pulls multi-timeframe candles + live order-book depth for `symbol`, runs
        them through PredictiveSignalEngine (AEGIS lagging consensus gated by
        order-flow/pattern/support-resistance leading confirmation), applies the
        ML ensemble as a secondary filter once it has enough closed trades to be
        trained, and returns a fireable TradeSignal or None.

        `profile` ("scalp" or "swing", see TRADING_PROFILES) controls which
        timeframes the technical read and entry price are drawn from, and how
        wide the ATR-based stop/target are — a scalp signal on the same
        symbol at the same moment can look completely different from (and
        fire independently of) a swing signal.
        """
        try:
            profile_cfg = TRADING_PROFILES.get(profile, TRADING_PROFILES["swing"])
            timeframes = list(dict.fromkeys(config.TIMEFRAMES + [config.DEFAULT_TIMEFRAME]))
            fetches = {
                tf: asyncio.to_thread(self.data_source.fetch_ohlcv_raw, symbol, tf, 200)
                for tf in timeframes
            }
            orderbook_fetch = asyncio.to_thread(self.data_source.fetch_order_book, symbol, 50)

            candles_by_tf: Dict[str, list] = {}
            for tf, fut in fetches.items():
                candles = await fut
                if candles:
                    candles_by_tf[tf] = candles
            orderbook = await orderbook_fetch

            if not candles_by_tf:
                return None

            # ATR (and the candles used for pattern/S-R detection + entry
            # pricing fallback) is drawn from this profile's own preferred
            # timeframes — a scalp profile's ATR should reflect 1m/5m noise,
            # not the same 1h ATR a swing profile would use.
            atr_source = None
            for tf in profile_cfg["atr_source_tf"] + ["1h", config.DEFAULT_TIMEFRAME]:
                if candles_by_tf.get(tf):
                    atr_source = candles_by_tf[tf]
                    break
            if atr_source is None:
                atr_source = next(iter(candles_by_tf.values()))
            atr = self._compute_atr(atr_source)

            pattern_df = await asyncio.to_thread(_raw_candles_to_df, atr_source)

            result = self.predictive_engine.build_signal(
                symbol=symbol,
                candles_by_tf=candles_by_tf,
                atr=atr,
                orderbook=orderbook,
                pattern_df=pattern_df,
                tf_preference=profile_cfg["tf_preference"],
                sl_atr_mult=profile_cfg["sl_atr_mult"],
                tp_atr_mult=profile_cfg["tp_atr_mult"],
            )

            # Resolve any pending signals for this symbol against the latest
            # candle's high/low — this is what lets confidence drift from the
            # static backtest prior toward this bot's own live win-rate.
            if atr_source:
                last = atr_source[-1]
                try:
                    self.signal_tracker.resolve_pending(symbol, high=float(last[2]), low=float(last[3]))
                except Exception as e:
                    logger.debug(f"Signal tracker resolve skipped for {symbol}: {e}")

            signal = result.get("signal")
            if signal is None:
                logger.debug(f"{symbol} [{profile}]: {result.get('reason_blocked')}")
                return None

            # Secondary ML filter — only enforced once the ensemble has trained
            # on enough closed trades; before that it pass-throughs at 0.5.
            if self.ml_ensemble.is_trained:
                aegis = result.get("aegis", {}) or {}
                ml_conf = self.ml_ensemble.predict_confidence({
                    "tech_confidence": signal.aegis_score / 100.0,
                    "tf_confidence": 0.5,  # SignalRefiner.evaluate() doesn't expose raw mtf_confidence, only mtf_bias
                    "confirmations": 2 + len(signal.leading_confirmations),
                    "side": signal.direction,
                    "risk_reward": signal.risk_reward,
                    "sentiment_score": aegis.get("sentiment_score", 0.0),
                    "setup_type": signal.setup_type,
                })
                if ml_conf < self.ml_ensemble.min_confidence:
                    logger.info(
                        f"{symbol} [{profile}]: predictive signal {signal.direction} blocked by ML filter "
                        f"({ml_conf:.0%} < {self.ml_ensemble.min_confidence:.0%})"
                    )
                    return None

            return signal
        except Exception as e:
            logger.error(f"Error gathering predictive signal for {symbol} [{profile}]: {e}")
            return None

    async def process_cycle(self) -> List[Dict[str, Any]]:
        """Single processing cycle over all configured trading symbols."""
        results = []
        today = date.today()

        # Always check open positions for SL/TP first, regardless of whether
        # new entries are allowed this cycle — exits are never gated.
        await self.monitor_and_close_positions()

        if self.risk_manager.daily_loss_limit_hit(today, self.balance):
            logger.warning("Daily loss limit reached — skipping new entry scans today.")
            return results

        for symbol in config.SYMBOLS:
            for profile in _active_profiles():
                pos_key = _position_key(symbol, profile)
                if pos_key in self.open_positions:
                    continue

                signal = await self.gather_predictive_signal(symbol, profile=profile)
                if signal is None:
                    continue

                portfolio_heat = self.heat_guard.calculate_total_heat(
                    list(self.open_positions.values()), self.balance
                )
                can_open, reason = self.risk_manager.can_open_position(
                    len(self.open_positions), portfolio_heat
                )
                if not can_open:
                    logger.info(f"Skipping new entries: {reason}")
                    return results

                # Confirmation strength for Kelly sizing: the predictive engine
                # already requires the AEGIS technical consensus (baseline of 2)
                # plus >=1 leading confirmation; each extra leading confirmation
                # (order-flow + pattern + support/resistance all agreeing) pushes
                # it toward full risk.
                confirmations = min(4, 2 + len(signal.leading_confirmations))
                win_rate = signal.live_win_rate if signal.live_win_rate is not None else signal.historical_win_rate

                pos_size = self.position_sizer.size(
                    balance=self.balance,
                    confirmations=confirmations,
                    entry=signal.entry,
                    stop_loss=signal.stop_loss,
                    take_profit=signal.take_profit,
                    win_rate=win_rate or 0.5,
                    avg_win=max(signal.risk_reward, 0.1),
                    avg_loss=1.0,
                )

                if pos_size.quantity <= 0:
                    continue

                notional = pos_size.quantity * signal.entry
                if not self.heat_guard.is_heat_acceptable(
                    list(self.open_positions.values()),
                    abs(signal.entry - signal.stop_loss) * pos_size.quantity,
                    self.balance,
                ):
                    logger.info(f"Skipping {symbol} [{profile}]: would exceed max portfolio heat")
                    continue

                # Execute order (paper or live)
                side_str = signal.direction
                order_res = await self.exchange_manager.place_order(
                    symbol=symbol,
                    side=side_str,
                    quantity=pos_size.quantity,
                    entry_price=signal.entry,
                    stop_loss=signal.stop_loss,
                    take_profit=signal.take_profit
                )

                if order_res.get("status") == "FILLED":
                    trade_id = self.db.record_trade(
                        symbol=symbol, side=side_str, entry_price=signal.entry,
                        quantity=pos_size.quantity, stop_loss=signal.stop_loss, take_profit=signal.take_profit,
                        setup_type=signal.setup_type, aegis_score=signal.aegis_score,
                        mode="PAPER" if config.PAPER_MODE else "LIVE",
                    )
                    try:
                        self.signal_tracker.log_signal(signal)
                    except Exception as e:
                        logger.debug(f"Signal tracker log skipped for {symbol}: {e}")
                    position_record = {
                        "trade_id": trade_id,
                        "symbol": symbol,
                        "profile": profile,
                        "side": side_str,
                        "entry_price": signal.entry,
                        "quantity": pos_size.quantity,
                        "stop_loss": signal.stop_loss,
                        "take_profit": signal.take_profit,
                        "notional": notional,
                        "opened_at": datetime.now(timezone.utc).timestamp(),
                        "setup_type": signal.setup_type,
                        "confidence_pct": signal.confidence_pct,
                        "reasoning": signal.reasoning,
                        "sl_order_id": order_res.get("sl_order_id"),
                        "tp_order_id": order_res.get("tp_order_id"),
                        "protected_by_exchange": order_res.get("protected_by_exchange"),
                    }
                    self.open_positions[pos_key] = position_record
                    self.balance -= notional
                    results.append(position_record)
                    protection_note = (
                        "exchange-protected" if order_res.get("protected_by_exchange")
                        else "⚠️ polling-only (no resting exchange stop)" if not config.PAPER_MODE
                        else "paper"
                    )
                    logger.info(
                        f"[ENTRY] {symbol} [{profile}] {side_str} @ {signal.entry:.4f} | "
                        f"{signal.setup_type} | confidence={signal.confidence_pct:.0f}% | "
                        f"confirmations={signal.leading_confirmations} | {protection_note}"
                    )
                    await self._notify_entry(symbol, profile, signal, pos_size.quantity, notional, order_res)
                elif order_res.get("status") == "REJECTED":
                    logger.warning(f"Order rejected for {symbol} [{profile}]: {order_res.get('reason')}")

        self.db.record_equity(self.balance, "PAPER" if config.PAPER_MODE else "LIVE")
        return results

    async def run_loop(self, interval_seconds: int = 60):
        """Main background loop."""
        self.running = True
        logger.info(f"TONYBOT Async Engine started. Loop interval = {interval_seconds}s")
        while self.running:
            try:
                await self.process_cycle()
            except Exception as e:
                logger.error(f"Error in engine execution cycle: {e}")
            await asyncio.sleep(interval_seconds)

    def stop(self):
        self.running = False
        logger.info("TONYBOT Async Engine stopping...")
