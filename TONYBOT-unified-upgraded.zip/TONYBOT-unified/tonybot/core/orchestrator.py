"""
tonybot/core/orchestrator.py — Command Line & Headless Pipeline Orchestrator
Synthesizes Oshai CLI scanning and headless execution flows.
"""
from __future__ import annotations

import logging
from typing import List
from tonybot.config import config
from tonybot.interfaces import Setup
from tonybot.data.ccxt_source import CCXTDataSource
from tonybot.strategy.regime_classifier import RegimeClassifier
from tonybot.strategy.setup_scanner import SetupScanner

logger = logging.getLogger("tonybot.orchestrator")


class PipelineOrchestrator:
    """CLI / Headless Pipeline for market scanning, regime analysis, and setup reporting."""

    def __init__(self):
        self.data_source = CCXTDataSource(exchange_id=config.EXCHANGE_ID)
        self.classifier = RegimeClassifier(
            trending_threshold=config.ADX_TRENDING_THRESHOLD,
            ranging_threshold=config.ADX_RANGING_THRESHOLD
        )
        self.scanner = SetupScanner(min_confirmations=config.MIN_CONFIRMATIONS_REQUIRED)

    def scan_all(self) -> List[Setup]:
        all_setups: List[Setup] = []
        print(f"\nScanning {len(config.SYMBOLS)} symbols on timeframe {config.DEFAULT_TIMEFRAME} via {config.EXCHANGE_ID.upper()}...")
        print("=" * 60)

        for symbol in config.SYMBOLS:
            try:
                df = self.data_source.fetch_ohlcv_df(symbol, timeframe=config.DEFAULT_TIMEFRAME, limit=100)
                if df.empty or len(df) < 30:
                    print(f"  [{symbol}] Insufficient OHLCV data.")
                    continue

                annotated = self.classifier.annotate(df)
                regime = self.classifier.classify(symbol, annotated)
                setups = self.scanner.scan(symbol, annotated, regime)

                print(f"  [{symbol}] Regime: {regime.regime_type.value:<10} | Trend: {regime.trend_direction.value:<6} | ADX: {regime.adx:.1f} | Setups Found: {len(setups)}")
                for s in setups:
                    print(f"    -> SETUP: {s.setup_type.value} | Dir: {s.direction.value} | Price: ${s.entry_price:.2f} | Conf: {s.confirmations}/4 ({s.confidence_score:.0f}%) | SL: ${s.stop_loss:.2f} | TP: ${s.take_profit:.2f}")
                all_setups.extend(setups)

            except Exception as e:
                print(f"  [{symbol}] Error scanning: {e}")

        print("=" * 60)
        print(f"Scan complete. Total valid trade setups found: {len(all_setups)}\n")
        return all_setups

    async def scan_predictive(self) -> list:
        """
        Runs the same gated predictive pipeline (AEGIS lagging consensus +
        order-flow/pattern leading confirmation + live-tracked win-rate) that
        drives `--run`, so `--scan` shows what the engine would actually act
        on instead of only the older, more permissive setup_scanner view
        above. This is what makes '--scan' useful as a pre-flight check
        before switching from paper to testnet/live.
        """
        from tonybot.core.engine import TradingEngine

        engine = TradingEngine()
        fired = []
        print(f"\nRunning predictive signal pipeline on {len(config.SYMBOLS)} symbols...")
        print("=" * 60)
        for symbol in config.SYMBOLS:
            signal = await engine.gather_predictive_signal(symbol)
            if signal is None:
                print(f"  [{symbol}] waiting — no gated entry (needs lagging consensus + leading confirmation)")
                continue
            print(
                f"  [{symbol}] 🎯 {signal.direction} {signal.setup_type} | "
                f"entry ${signal.entry:.4f} SL ${signal.stop_loss:.4f} TP ${signal.take_profit:.4f} "
                f"| R:R {signal.risk_reward} | confidence {signal.confidence_pct:.0f}% "
                f"| leading: {', '.join(signal.leading_confirmations)}"
            )
            for r in signal.reasoning:
                print(f"      - {r}")
            fired.append(signal)
        print("=" * 60)
        print(f"Predictive scan complete. {len(fired)} gated signal(s) fired.\n")
        return fired
