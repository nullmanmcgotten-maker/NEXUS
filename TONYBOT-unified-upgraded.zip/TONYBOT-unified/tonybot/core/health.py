"""
tonybot/core/health.py — Startup Health Checks & Environment Diagnostic Pipeline
"""
import sys
import logging
from typing import Dict, Any

from tonybot.config import config

logger = logging.getLogger("tonybot.health")


class HealthChecker:
    """Runs non-fatal diagnostics on API keys, environment, and dependencies."""

    @staticmethod
    def run_checks() -> Dict[str, Any]:
        results = {
            "python_version": sys.version.split()[0],
            "exchange_id": config.EXCHANGE_ID,
            "binance_keys": bool(config.BINANCE_API_KEY and config.BINANCE_SECRET_KEY),
            "paper_mode": config.PAPER_MODE,
            "live_trading": config.LIVE_TRADING,
            "symbols_configured": len(config.SYMBOLS),
            "status": "OK",
        }

        logger.info(
            f"[HEALTH CHECK] Python {results['python_version']} | "
            f"Mode: {'PAPER' if results['paper_mode'] else 'LIVE'} | "
            f"Exchange: {results['exchange_id'].upper()} | "
            f"Symbols: {results['symbols_configured']}"
        )
        if not results["binance_keys"] and config.EXCHANGE_ID == "binance":
            logger.warning(
                "[HEALTH CHECK] Binance API keys not set — running in SIMULATION mode. "
                "Add keys to .env to enable real data / live trading."
            )

        return results
