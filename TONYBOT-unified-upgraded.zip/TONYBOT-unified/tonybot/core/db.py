"""
tonybot/core/db.py — Complete SQLite Database from Documentation
"""
import logging
import sqlite3
import time
import hashlib
import secrets
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger("tonybot.db")
DB_PATH = "data/tonybot.db"

class Database:
    def __init__(self, db_path: str = DB_PATH):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        """Initialize complete database schema"""
        self.conn.executescript("""
        -- Users Registry Table
        CREATE TABLE IF NOT EXISTS users_registry (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            recovery_key TEXT,
            role TEXT DEFAULT 'trader',
            is_active INTEGER DEFAULT 1,
            created_at REAL DEFAULT (strftime('%s', 'now')),
            last_login REAL
        );

        -- Trades Table
        CREATE TABLE IF NOT EXISTS trades (
            trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            signal_id INTEGER,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            entry_price REAL NOT NULL,
            quantity REAL NOT NULL,
            stop_loss REAL,
            take_profit REAL,
            exit_price REAL,
            pnl REAL,
            pnl_pct REAL,
            status TEXT DEFAULT 'OPEN',
            aegis_score REAL,
            mode TEXT DEFAULT 'PAPER',
            setup_type TEXT,
            confirmations INTEGER,
            entry_time REAL DEFAULT (strftime('%s', 'now')),
            exit_time REAL,
            fees_paid REAL DEFAULT 0,
            close_reason TEXT,
            FOREIGN KEY (user_id) REFERENCES users_registry(user_id)
        );

        -- Signals Table
        CREATE TABLE IF NOT EXISTS signals (
            signal_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            symbol TEXT NOT NULL,
            action TEXT NOT NULL,
            gate_score REAL NOT NULL,
            gates_passed INTEGER NOT NULL,
            aegis_score REAL NOT NULL,
            ai_confidence REAL,
            sentiment_score REAL,
            mtf_alignment REAL,
            price_at_signal REAL NOT NULL,
            reasoning TEXT,
            generated_at REAL DEFAULT (strftime('%s', 'now')),
            FOREIGN KEY (user_id) REFERENCES users_registry(user_id)
        );

        -- Market Data Table
        CREATE TABLE IF NOT EXISTS market_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            timestamp REAL NOT NULL,
            open REAL NOT NULL,
            high REAL NOT NULL,
            low REAL NOT NULL,
            close REAL NOT NULL,
            volume REAL NOT NULL,
            UNIQUE(symbol, timeframe, timestamp)
        );

        -- Equity Snapshots
        CREATE TABLE IF NOT EXISTS equity_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL DEFAULT (strftime('%s', 'now')),
            equity REAL NOT NULL,
            mode TEXT NOT NULL
        );

        -- Performance Metrics
        CREATE TABLE IF NOT EXISTS performance_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT UNIQUE NOT NULL,
            metric_value REAL,
            updated_at REAL DEFAULT (strftime('%s', 'now'))
        );

        -- API Configuration
        CREATE TABLE IF NOT EXISTS api_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            provider TEXT DEFAULT 'openrouter',
            api_key TEXT,
            api_url TEXT DEFAULT 'https://openrouter.ai/api/v1/chat/completions',
            model TEXT DEFAULT 'deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B',
            is_active INTEGER DEFAULT 1,
            updated_at REAL DEFAULT (strftime('%s', 'now')),
            FOREIGN KEY (user_id) REFERENCES users_registry(user_id)
        );

        -- Signal Outcomes Table (tracks predictive TradeSignal win/loss for live accuracy)
        CREATE TABLE IF NOT EXISTS signal_outcomes (
            outcome_id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            setup_type TEXT NOT NULL,
            direction TEXT NOT NULL,
            entry_price REAL NOT NULL,
            stop_loss REAL NOT NULL,
            take_profit REAL NOT NULL,
            confidence_at_signal REAL,
            status TEXT DEFAULT 'PENDING',
            resolution_price REAL,
            opened_at REAL DEFAULT (strftime('%s', 'now')),
            resolved_at REAL
        );

        -- Indexes
        CREATE INDEX IF NOT EXISTS idx_signal_outcomes_setup ON signal_outcomes(setup_type);
        CREATE INDEX IF NOT EXISTS idx_signal_outcomes_status ON signal_outcomes(status);
        CREATE INDEX IF NOT EXISTS idx_signal_outcomes_symbol ON signal_outcomes(symbol);
        CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
        CREATE INDEX IF NOT EXISTS idx_trades_entry_time ON trades(entry_time);
        CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
        CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id);
        CREATE INDEX IF NOT EXISTS idx_signals_symbol ON signals(symbol);
        CREATE INDEX IF NOT EXISTS idx_signals_user ON signals(user_id);
        CREATE INDEX IF NOT EXISTS idx_market_data_symbol_time ON market_data(symbol, timestamp);
        CREATE INDEX IF NOT EXISTS idx_users_username ON users_registry(username);
        CREATE INDEX IF NOT EXISTS idx_users_email ON users_registry(email);
        """)
        self.conn.commit()
        logger.info("✅ Database schema initialized")

    # ============================================================
    # USER OPERATIONS
    # ============================================================
    
    def create_user(self, username: str, password: str, email: str) -> Dict:
        """Create a new user with hashed password"""
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        recovery_key = secrets.token_hex(16)
        
        try:
            cur = self.conn.execute("""
                INSERT INTO users_registry (username, password_hash, email, recovery_key)
                VALUES (?, ?, ?, ?)
            """, (username, password_hash, email, recovery_key))
            self.conn.commit()
            return {
                'success': True,
                'user_id': cur.lastrowid,
                'recovery_key': recovery_key,
                'message': 'User created successfully'
            }
        except sqlite3.IntegrityError as e:
            error_msg = str(e)
            if 'username' in error_msg:
                return {'success': False, 'message': 'Username already exists'}
            elif 'email' in error_msg:
                return {'success': False, 'message': 'Email already registered'}
            return {'success': False, 'message': f'Registration error: {error_msg}'}

    def login_user(self, username: str, password: str) -> Dict:
        """Authenticate user"""
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        cur = self.conn.execute("""
            SELECT * FROM users_registry 
            WHERE username=? AND password_hash=? AND is_active=1
        """, (username, password_hash))
        row = cur.fetchone()
        
        if row:
            self.conn.execute(
                "UPDATE users_registry SET last_login=? WHERE user_id=?",
                (time.time(), row['user_id'])
            )
            self.conn.commit()
            return {'success': True, 'user': dict(row)}
        return {'success': False, 'message': 'Invalid username or password'}

    def get_user_by_recovery_key(self, recovery_key: str) -> Optional[Dict]:
        cur = self.conn.execute(
            "SELECT * FROM users_registry WHERE recovery_key=?",
            (recovery_key,)
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def reset_password(self, recovery_key: str, new_password: str) -> Dict:
        user = self.get_user_by_recovery_key(recovery_key)
        if not user:
            return {'success': False, 'message': 'Invalid recovery key'}
        
        password_hash = hashlib.sha256(new_password.encode()).hexdigest()
        new_recovery_key = secrets.token_hex(16)
        
        self.conn.execute("""
            UPDATE users_registry 
            SET password_hash=?, recovery_key=?
            WHERE recovery_key=?
        """, (password_hash, new_recovery_key, recovery_key))
        self.conn.commit()
        return {'success': True, 'message': 'Password reset successful'}

    def get_user(self, username: str) -> Optional[Dict]:
        cur = self.conn.execute(
            "SELECT user_id, username, email, role, is_active, created_at, last_login FROM users_registry WHERE username=?",
            (username,)
        )
        row = cur.fetchone()
        return dict(row) if row else None

    # ============================================================
    # API CONFIGURATION
    # ============================================================
    
    def save_api_config(self, user_id: int, provider: str, api_key: str, 
                         api_url: str, model: str) -> bool:
        try:
            self.conn.execute("""
                INSERT OR REPLACE INTO api_config 
                (user_id, provider, api_key, api_url, model, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, provider, api_key, api_url, model, time.time()))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"API config save error: {e}")
            return False

    def get_api_config(self, user_id: int) -> Dict:
        cur = self.conn.execute(
            "SELECT * FROM api_config WHERE user_id=? AND is_active=1",
            (user_id,)
        )
        row = cur.fetchone()
        if row:
            return dict(row)
        return {
            'provider': 'openrouter',
            'api_url': 'https://openrouter.ai/api/v1/chat/completions',
            'model': 'deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B',
            'api_key': ''
        }

    # ============================================================
    # TRADE OPERATIONS
    # ============================================================
    
    def record_trade(self, symbol: str, side: str, entry_price: float, 
                     quantity: float, stop_loss: float = 0, take_profit: float = 0,
                     user_id: int = 1, setup_type: str = "MANUAL",
                     aegis_score: float = 0, mode: str = "PAPER") -> int:
        now = time.time()
        cur = self.conn.execute("""
            INSERT INTO trades 
            (user_id, symbol, side, entry_price, quantity, stop_loss, take_profit, 
             setup_type, aegis_score, mode, entry_time, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
        """, (user_id, symbol, side, entry_price, quantity, stop_loss, take_profit,
              setup_type, aegis_score, mode, now))
        self.conn.commit()
        return cur.lastrowid

    def close_trade(self, trade_id: int, exit_price: float) -> Dict:
        cur = self.conn.execute(
            "SELECT * FROM trades WHERE trade_id=? AND status='OPEN'",
            (trade_id,)
        )
        trade = cur.fetchone()
        if not trade:
            return {'success': False, 'error': 'Trade not found'}
        
        trade_dict = dict(trade)
        entry_price = trade_dict['entry_price']
        quantity = trade_dict['quantity']
        side = trade_dict['side']
        
        if side == 'BUY':
            pnl = (exit_price - entry_price) * quantity
        else:
            pnl = (entry_price - exit_price) * quantity
        
        pnl_pct = (pnl / (entry_price * quantity)) * 100 if entry_price * quantity > 0 else 0
        now = time.time()
        
        self.conn.execute("""
            UPDATE trades 
            SET exit_price=?, pnl=?, pnl_pct=?, status='CLOSED', exit_time=?
            WHERE trade_id=?
        """, (exit_price, pnl, pnl_pct, now, trade_id))
        self.conn.commit()
        
        return {'success': True, 'trade': trade_dict, 'pnl': pnl, 'pnl_pct': pnl_pct}

    def get_open_trades(self, user_id: int = None) -> List[Dict]:
        if user_id:
            cur = self.conn.execute(
                "SELECT * FROM trades WHERE status='OPEN' AND user_id=? ORDER BY entry_time DESC",
                (user_id,)
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM trades WHERE status='OPEN' ORDER BY entry_time DESC"
            )
        return [dict(row) for row in cur.fetchall()]

    def get_recent_trades(self, limit: int = 100, user_id: int = None) -> List[Dict]:
        if user_id:
            cur = self.conn.execute(
                "SELECT * FROM trades WHERE user_id=? ORDER BY entry_time DESC LIMIT ?",
                (user_id, limit)
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM trades ORDER BY entry_time DESC LIMIT ?",
                (limit,)
            )
        return [dict(row) for row in cur.fetchall()]

    # ============================================================
    # SIGNAL OPERATIONS
    # ============================================================
    
    def record_signal(self, symbol: str, action: str, gate_score: float,
                      gates_passed: int, aegis_score: float,
                      price: float, user_id: int = 1,
                      ai_confidence: float = 0, sentiment_score: float = 0,
                      mtf_alignment: float = 0, reasoning: str = "") -> int:
        now = time.time()
        cur = self.conn.execute("""
            INSERT INTO signals 
            (user_id, symbol, action, gate_score, gates_passed, aegis_score, 
             price_at_signal, ai_confidence, sentiment_score, mtf_alignment, 
             reasoning, generated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (user_id, symbol, action, gate_score, gates_passed, aegis_score,
              price, ai_confidence, sentiment_score, mtf_alignment, reasoning, now))
        self.conn.commit()
        return cur.lastrowid

    def get_recent_signals(self, limit: int = 50, user_id: int = None) -> List[Dict]:
        if user_id:
            cur = self.conn.execute(
                "SELECT * FROM signals WHERE user_id=? ORDER BY generated_at DESC LIMIT ?",
                (user_id, limit)
            )
        else:
            cur = self.conn.execute(
                "SELECT * FROM signals ORDER BY generated_at DESC LIMIT ?",
                (limit,)
            )
        return [dict(row) for row in cur.fetchall()]

    # ============================================================
    # PERFORMANCE
    # ============================================================
    
    def get_performance_stats(self, user_id: int = None) -> Dict[str, Any]:
        if user_id:
            cur = self.conn.execute("""
                SELECT 
                    COUNT(*) as total_trades,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
                    SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses,
                    SUM(pnl) as total_pnl,
                    AVG(pnl) as avg_pnl,
                    MAX(pnl) as best_trade,
                    MIN(pnl) as worst_trade,
                    COUNT(CASE WHEN status='OPEN' THEN 1 END) as open_positions
                FROM trades WHERE user_id=?
            """, (user_id,))
        else:
            cur = self.conn.execute("""
                SELECT 
                    COUNT(*) as total_trades,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
                    SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses,
                    SUM(pnl) as total_pnl,
                    AVG(pnl) as avg_pnl,
                    MAX(pnl) as best_trade,
                    MIN(pnl) as worst_trade,
                    COUNT(CASE WHEN status='OPEN' THEN 1 END) as open_positions
                FROM trades
            """)
        row = cur.fetchone()
        if row and row[0] > 0:
            stats = dict(row)
            stats['win_rate'] = stats['wins'] / stats['total_trades'] if stats['total_trades'] > 0 else 0
            return stats
        return {
            'total_trades': 0, 'wins': 0, 'losses': 0, 'total_pnl': 0,
            'avg_pnl': 0, 'best_trade': 0, 'worst_trade': 0,
            'open_positions': 0, 'win_rate': 0
        }

    def get_stats(self) -> Dict[str, Any]:
        return self.get_performance_stats()

    def record_equity(self, equity: float, mode: str):
        self.conn.execute(
            "INSERT INTO equity_snapshots (equity, mode) VALUES (?, ?)",
            (equity, mode)
        )
        self.conn.commit()

    # ============================================================
    # SIGNAL OUTCOME TRACKING (for live signal accuracy)
    # ============================================================

    def log_signal_outcome(self, symbol: str, setup_type: str, direction: str,
                            entry_price: float, stop_loss: float, take_profit: float,
                            confidence_at_signal: float = 0.0) -> int:
        now = time.time()
        cur = self.conn.execute("""
            INSERT INTO signal_outcomes
            (symbol, setup_type, direction, entry_price, stop_loss, take_profit,
             confidence_at_signal, status, opened_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
        """, (symbol, setup_type, direction, entry_price, stop_loss, take_profit,
              confidence_at_signal, now))
        self.conn.commit()
        return cur.lastrowid

    def get_pending_outcomes(self, symbol: str = None) -> List[Dict]:
        if symbol:
            cur = self.conn.execute(
                "SELECT * FROM signal_outcomes WHERE status='PENDING' AND symbol=?",
                (symbol,)
            )
        else:
            cur = self.conn.execute("SELECT * FROM signal_outcomes WHERE status='PENDING'")
        return [dict(row) for row in cur.fetchall()]

    def resolve_signal_outcome(self, outcome_id: int, status: str, resolution_price: float) -> None:
        self.conn.execute("""
            UPDATE signal_outcomes
            SET status=?, resolution_price=?, resolved_at=?
            WHERE outcome_id=?
        """, (status, resolution_price, time.time(), outcome_id))
        self.conn.commit()

    def get_setup_win_rate(self, setup_type: str) -> Dict[str, Any]:
        """Live rolling win-rate for a setup type, based on resolved (WIN/LOSS) signals only."""
        cur = self.conn.execute("""
            SELECT
                SUM(CASE WHEN status='WIN' THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN status IN ('WIN','LOSS') THEN 1 ELSE 0 END) as resolved
            FROM signal_outcomes WHERE setup_type=?
        """, (setup_type,))
        row = cur.fetchone()
        resolved = row["resolved"] or 0
        wins = row["wins"] or 0
        win_rate = (wins / resolved) if resolved > 0 else None
        return {"win_rate": win_rate, "sample_size": resolved}

    def close(self):
        if self.conn:
            self.conn.close()

    def __del__(self):
        self.close()
