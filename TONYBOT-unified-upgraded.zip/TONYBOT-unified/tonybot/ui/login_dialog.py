"""
tonybot/ui/login_dialog.py — Login/Signup Dialog with Copyable Recovery Key
"""
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from tonybot.core.db import Database

class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.db = Database()
        self.setWindowTitle("TONYBOT - Login")
        self.setFixedSize(450, 550)
        self.setStyleSheet("""
            QDialog { background: #0A0E1A; }
            QLabel { color: #E8EAF0; }
            QLineEdit { 
                background: #141C35; 
                border: 1px solid #2A3D60; 
                border-radius: 6px; 
                padding: 10px; 
                color: #E8EAF0;
                font-size: 12px;
            }
            QLineEdit:focus { border-color: #00D4FF; }
            QPushButton {
                background: #141C35;
                border: 1px solid #2A3D60;
                border-radius: 6px;
                padding: 10px;
                color: #E8EAF0;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover { background: #1E2D4A; }
            QPushButton#login_btn { background: #00D4FF; color: #0A0E1A; }
            QPushButton#login_btn:hover { background: #00B8E6; }
            QPushButton#signup_btn { background: #00FF88; color: #0A0E1A; }
            QPushButton#signup_btn:hover { background: #00CC66; }
            QPushButton#copy_btn { background: #7B4FE0; color: white; }
            QPushButton#copy_btn:hover { background: #6A3FD0; }
            QTextEdit { 
                background: #141C35; 
                border: 2px solid #00FF88; 
                border-radius: 6px; 
                padding: 10px; 
                color: #00FF88;
                font-size: 14px;
                font-weight: bold;
                font-family: monospace;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # Logo
        logo = QLabel("⚡ TONYBOT")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet("font-size: 28px; font-weight: bold; color: #00D4FF;")
        layout.addWidget(logo)
        
        # Mode toggle
        self.mode = 'login'
        mode_layout = QHBoxLayout()
        self.login_tab = QPushButton("LOGIN")
        self.login_tab.setObjectName("login_btn")
        self.login_tab.clicked.connect(lambda: self.set_mode('login'))
        self.signup_tab = QPushButton("SIGN UP")
        self.signup_tab.clicked.connect(lambda: self.set_mode('signup'))
        mode_layout.addWidget(self.login_tab)
        mode_layout.addWidget(self.signup_tab)
        layout.addLayout(mode_layout)
        
        # Form
        self.form_widget = QWidget()
        self.form_layout = QVBoxLayout(self.form_widget)
        self.form_layout.setSpacing(10)
        
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        self.username_input.setStyleSheet("font-size: 12px;")
        self.form_layout.addWidget(self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setStyleSheet("font-size: 12px;")
        self.form_layout.addWidget(self.password_input)
        
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("Email (required for signup)")
        self.email_input.setStyleSheet("font-size: 12px;")
        self.email_input.hide()
        self.form_layout.addWidget(self.email_input)
        
        # Recovery Key Display (shows on signup success)
        self.recovery_frame = QFrame()
        self.recovery_frame.setStyleSheet("background: #0F1628; border: 1px solid #1E2D4A; border-radius: 6px; padding: 10px;")
        recovery_layout = QVBoxLayout(self.recovery_frame)
        
        recovery_label = QLabel("🔑 YOUR RECOVERY KEY - SAVE THIS!")
        recovery_label.setStyleSheet("color: #00FF88; font-weight: bold; font-size: 11px;")
        recovery_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        recovery_layout.addWidget(recovery_label)
        
        self.recovery_text = QTextEdit()
        self.recovery_text.setPlaceholderText("Recovery key will appear here")
        self.recovery_text.setMaximumHeight(60)
        self.recovery_text.setReadOnly(True)
        recovery_layout.addWidget(self.recovery_text)
        
        copy_layout = QHBoxLayout()
        self.copy_btn = QPushButton("📋 COPY KEY")
        self.copy_btn.setObjectName("copy_btn")
        self.copy_btn.clicked.connect(self.copy_recovery_key)
        copy_layout.addWidget(self.copy_btn)
        
        self.done_btn = QPushButton("✅ I'VE SAVED IT - CONTINUE TO LOGIN")
        self.done_btn.setObjectName("signup_btn")
        self.done_btn.clicked.connect(self.continue_to_login)
        copy_layout.addWidget(self.done_btn)
        
        recovery_layout.addLayout(copy_layout)
        self.recovery_frame.hide()
        self.form_layout.addWidget(self.recovery_frame)
        
        # Recovery Input (for password reset)
        self.recovery_input = QLineEdit()
        self.recovery_input.setPlaceholderText("Recovery Key (for password reset)")
        self.recovery_input.setStyleSheet("font-size: 12px; font-family: monospace;")
        self.recovery_input.hide()
        self.form_layout.addWidget(self.recovery_input)
        
        self.new_password_input = QLineEdit()
        self.new_password_input.setPlaceholderText("New Password")
        self.new_password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.new_password_input.setStyleSheet("font-size: 12px;")
        self.new_password_input.hide()
        self.form_layout.addWidget(self.new_password_input)
        
        self.action_btn = QPushButton("LOGIN")
        self.action_btn.setObjectName("login_btn")
        self.action_btn.clicked.connect(self.handle_action)
        self.form_layout.addWidget(self.action_btn)
        
        self.reset_btn = QPushButton("Forgot Password? Click to Reset")
        self.reset_btn.setStyleSheet("background: transparent; border: none; color: #7A8BA8; font-size: 10px;")
        self.reset_btn.clicked.connect(self.toggle_reset)
        self.form_layout.addWidget(self.reset_btn)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("color: #7A8BA8; font-size: 10px;")
        self.form_layout.addWidget(self.status_label)
        
        layout.addWidget(self.form_widget)
        self.set_mode('login')
        self.recovery_key = ""
    
    def set_mode(self, mode):
        self.mode = mode
        if mode == 'login':
            self.login_tab.setStyleSheet("background: #00D4FF; color: #0A0E1A; font-weight: bold;")
            self.signup_tab.setStyleSheet("background: #141C35; color: #E8EAF0;")
            self.email_input.hide()
            self.recovery_frame.hide()
            self.recovery_input.hide()
            self.new_password_input.hide()
            self.reset_btn.show()
            self.action_btn.setText("LOGIN")
            self.action_btn.setObjectName("login_btn")
            self.username_input.setPlaceholderText("Username")
            self.password_input.setPlaceholderText("Password")
            self.status_label.setText("")
        elif mode == 'signup':
            self.signup_tab.setStyleSheet("background: #00FF88; color: #0A0E1A; font-weight: bold;")
            self.login_tab.setStyleSheet("background: #141C35; color: #E8EAF0;")
            self.email_input.show()
            self.recovery_frame.hide()
            self.recovery_input.hide()
            self.new_password_input.hide()
            self.reset_btn.hide()
            self.action_btn.setText("SIGN UP")
            self.action_btn.setObjectName("signup_btn")
            self.username_input.setPlaceholderText("Choose Username")
            self.password_input.setPlaceholderText("Choose Password")
            self.email_input.setPlaceholderText("Email Address")
            self.status_label.setText("")
    
    def toggle_reset(self):
        if self.recovery_input.isVisible():
            self.recovery_input.hide()
            self.new_password_input.hide()
            self.reset_btn.setText("Forgot Password? Click to Reset")
            self.action_btn.setText("LOGIN")
            self.action_btn.setObjectName("login_btn")
            self.status_label.setText("")
        else:
            self.recovery_input.show()
            self.new_password_input.show()
            self.reset_btn.setText("Cancel Password Reset")
            self.action_btn.setText("RESET PASSWORD")
            self.action_btn.setObjectName("login_btn")
            self.username_input.setPlaceholderText("Username (optional)")
            self.password_input.setPlaceholderText("Current Password (optional)")
            self.status_label.setText("Enter your Recovery Key and New Password")
    
    def copy_recovery_key(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.recovery_key)
        self.status_label.setText("✅ Recovery key copied to clipboard!")
        self.status_label.setStyleSheet("color: #00FF88; font-size: 10px;")
    
    def continue_to_login(self):
        self.recovery_frame.hide()
        self.set_mode('login')
        self.status_label.setText("✅ Account created! Please login with your credentials.")
        self.status_label.setStyleSheet("color: #00FF88; font-size: 10px;")
    
    def handle_action(self):
        username = self.username_input.text().strip()
        password = self.password_input.text().strip()
        
        # Password Reset Mode
        if self.recovery_input.isVisible() and self.new_password_input.isVisible():
            recovery_key = self.recovery_input.text().strip()
            new_password = self.new_password_input.text().strip()
            if not recovery_key or not new_password:
                self.status_label.setText("⚠️ Recovery Key and New Password required")
                return
            if len(new_password) < 6:
                self.status_label.setText("⚠️ Password must be at least 6 characters")
                return
            result = self.db.reset_password(recovery_key, new_password)
            if result['success']:
                self.status_label.setText("✅ Password reset! Please login.")
                self.recovery_input.hide()
                self.new_password_input.hide()
                self.reset_btn.setText("Forgot Password? Click to Reset")
                self.action_btn.setText("LOGIN")
            else:
                self.status_label.setText(f"❌ {result['message']}")
            return
        
        # Login Mode
        if self.mode == 'login':
            result = self.db.login_user(username, password)
            if result['success']:
                self.status_label.setText("✅ Login successful!")
                self.accept()
            else:
                self.status_label.setText("❌ Invalid username or password")
        
        # Signup Mode
        elif self.mode == 'signup':
            email = self.email_input.text().strip()
            if not email:
                self.status_label.setText("⚠️ Email required for signup")
                return
            if len(password) < 6:
                self.status_label.setText("⚠️ Password must be at least 6 characters")
                return
            result = self.db.create_user(username, password, email)
            if result['success']:
                self.recovery_key = result['recovery_key']
                self.recovery_text.setText(self.recovery_key)
                self.recovery_frame.show()
                self.status_label.setText("✅ Account created! Copy your recovery key.")
                self.status_label.setStyleSheet("color: #00FF88; font-size: 10px;")
                self.action_btn.hide()
            else:
                self.status_label.setText(f"❌ {result['message']}")
    
    def get_user(self):
        username = self.username_input.text().strip()
        return self.db.get_user(username)

if __name__ == "__main__":
    app = QApplication([])
    dialog = LoginDialog()
    if dialog.exec() == QDialog.DialogCode.Accepted:
        print("Login successful")
