"""
tonybot/ui/perp_risk_tab.py — Perp Risk & Funding Tab

New tab: TONYBOT had no perp-specific UI at all. This surfaces the things
that matter for perpetual futures specifically and that spot trading never
needed: funding rate + annualized drag, mark/index basis, open interest, a
liquidation calculator, and a liquidation heatmap across common leverage
tiers so you can see at a glance where crowded leverage sits relative to
price.

Follows the visual language already established in nexus_tab.py (dark
panel cards, cyan/green/red accent colors, monospace tables) so it drops
into the same QTabWidget without looking bolted-on.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QFrame,
    QPushButton, QComboBox, QDoubleSpinBox, QTableWidget, QTableWidgetItem,
)

from tonybot.risk.liquidation import (
    evaluate_liquidation_risk, build_liquidation_heatmap, stop_loss_beats_liquidation,
)

CYAN = "#00D4FF"
GREEN = "#00FF88"
RED = "#FF3B5C"
AMBER = "#F0B90B"
BG = "#0F1628"
BORDER = "#1E2D4A"
TEXT2 = "#7A8BA8"


class LiquidationHeatmapWidget(QWidget):
    """Horizontal bar: current price in the middle, liquidation clusters for
    LONGs below it and SHORTs above it, colored by how much leverage it
    takes to get liquidated there (more leverage = more crowded = brighter)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(90)
        self.current_price = 0.0
        self.buckets = []

    def set_data(self, current_price: float, buckets: list):
        self.current_price = current_price
        self.buckets = buckets
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        painter.fillRect(0, 0, w, h, QColor(BG))

        if not self.buckets or self.current_price <= 0:
            painter.setPen(QColor(TEXT2))
            painter.drawText(10, h // 2, "No data — press Refresh")
            painter.end()
            return

        prices = [b.price for b in self.buckets] + [self.current_price]
        lo, hi = min(prices), max(prices)
        span = (hi - lo) or 1.0
        margin = 40
        usable_w = w - 2 * margin

        def x_for(price):
            return margin + int((price - lo) / span * usable_w)

        mid_y = h // 2
        painter.setPen(QPen(QColor(BORDER), 1))
        painter.drawLine(margin, mid_y, w - margin, mid_y)

        for b in self.buckets:
            x = x_for(b.price)
            intensity = max(0.15, 1.0 - min(b.leverage, 100) / 100)
            color = QColor(RED) if b.side == "LONG" else QColor(GREEN)
            color.setAlphaF(0.35 + 0.5 * (1 - intensity))
            bar_h = int(h * 0.35 * (1 - intensity * 0.5))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(color))
            if b.side == "LONG":
                painter.drawRect(x - 1, mid_y, 2, bar_h)
            else:
                painter.drawRect(x - 1, mid_y - bar_h, 2, bar_h)
            painter.setPen(QColor(TEXT2))
            painter.setFont(QFont("Consolas", 7))
            painter.drawText(x - 8, mid_y + (bar_h + 12 if b.side == "LONG" else -bar_h - 4), f"{int(b.leverage)}x")

        cx = x_for(self.current_price)
        painter.setPen(QPen(QColor(CYAN), 2))
        painter.drawLine(cx, 4, cx, h - 4)
        painter.setPen(QColor(CYAN))
        painter.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        painter.drawText(cx + 4, 14, f"${self.current_price:,.2f}")
        painter.end()


def _card(label: str, value: str, color: str) -> tuple[QFrame, QLabel]:
    frame = QFrame()
    frame.setStyleSheet(f"background:{BG}; border:1px solid {BORDER}; border-radius:6px; padding:8px;")
    lay = QVBoxLayout(frame)
    lay.addWidget(QLabel(label))
    val = QLabel(value)
    val.setStyleSheet(f"font-size:16px; font-weight:bold; color:{color};")
    lay.addWidget(val)
    return frame, val


class PerpRiskTab(QWidget):
    """Perp Risk & Funding dashboard tab. Drop into main_window via:
        from tonybot.ui.perp_risk_tab import PerpRiskTab
        tabs.addTab(PerpRiskTab(exchange_manager=self.exchange_manager), "⚡ Perp Risk")
    """

    def __init__(self, parent=None, exchange_manager=None, default_symbol: str = "BTC/USDT"):
        super().__init__(parent)
        self.exchange_manager = exchange_manager
        self.symbol = default_symbol
        self._last_price = 0.0
        self._setup_ui()
        self._start_timer()

    # ------------------------------------------------------------ UI ----
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 6, 6, 6)

        header = QLabel("⚡ PERP RISK & FUNDING")
        header.setStyleSheet(f"font-size:16px; font-weight:bold; color:{CYAN}; padding:4px;")
        layout.addWidget(header)

        # --- Symbol row ---
        sym_row = QHBoxLayout()
        sym_row.addWidget(QLabel("Symbol:"))
        self.symbol_box = QComboBox()
        self.symbol_box.setEditable(True)
        self.symbol_box.addItems(["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT"])
        sym_row.addWidget(self.symbol_box)
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_data)
        sym_row.addWidget(refresh_btn)
        sym_row.addStretch()
        layout.addLayout(sym_row)

        # --- Summary cards: funding / basis / OI / next funding ---
        cards_row = QHBoxLayout()
        self.cards = {}
        for key, label in [("funding", "Funding Rate"), ("apr", "Annualized"),
                            ("basis", "Mark/Index Basis"), ("oi", "Open Interest")]:
            frame, val = _card(label, "—", CYAN)
            self.cards[key] = val
            cards_row.addWidget(frame)
        layout.addLayout(cards_row)

        # --- Liquidation heatmap ---
        layout.addWidget(QLabel("📊 LIQUIDATION HEATMAP (by leverage tier)"))
        self.heatmap = LiquidationHeatmapWidget()
        layout.addWidget(self.heatmap)

        # --- Liquidation calculator ---
        layout.addWidget(QLabel("🧮 LIQUIDATION CALCULATOR"))
        calc_row = QGridLayout()

        self.entry_spin = QDoubleSpinBox()
        self.entry_spin.setRange(0, 10_000_000)
        self.entry_spin.setDecimals(2)
        self.entry_spin.setPrefix("$")

        self.leverage_spin = QDoubleSpinBox()
        self.leverage_spin.setRange(1, 125)
        self.leverage_spin.setValue(5)
        self.leverage_spin.setSuffix("x")

        self.sl_spin = QDoubleSpinBox()
        self.sl_spin.setRange(0, 10_000_000)
        self.sl_spin.setDecimals(2)
        self.sl_spin.setPrefix("$")

        self.side_box = QComboBox()
        self.side_box.addItems(["LONG", "SHORT"])

        self.margin_box = QComboBox()
        self.margin_box.addItems(["isolated", "cross"])

        for i, (lbl, w) in enumerate([
            ("Entry Price", self.entry_spin), ("Leverage", self.leverage_spin),
            ("Side", self.side_box), ("Margin Mode", self.margin_box),
            ("Stop Loss (optional)", self.sl_spin),
        ]):
            calc_row.addWidget(QLabel(lbl), i // 3, (i % 3) * 2)
            calc_row.addWidget(w, i // 3, (i % 3) * 2 + 1)
        layout.addLayout(calc_row)

        calc_btn = QPushButton("Calculate Liquidation Price")
        calc_btn.clicked.connect(self.calculate_liquidation)
        layout.addWidget(calc_btn)

        self.calc_result = QLabel("—")
        self.calc_result.setStyleSheet(f"font-family:Consolas; font-size:12px; padding:6px; "
                                        f"background:{BG}; border:1px solid {BORDER}; border-radius:4px;")
        self.calc_result.setWordWrap(True)
        layout.addWidget(self.calc_result)

        self.status_label = QLabel("🟢 Ready")
        self.status_label.setStyleSheet(f"font-size:9px; color:{TEXT2}; padding:4px;")
        layout.addWidget(self.status_label)
        layout.addStretch()

    # -------------------------------------------------------- timers ----
    def _start_timer(self):
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(30_000)
        QTimer.singleShot(500, self.refresh_data)

    # -------------------------------------------------------- actions ---
    def refresh_data(self):
        self.status_label.setText("🔄 Refreshing...")
        threading.Thread(target=self._fetch, daemon=True).start()

    def _fetch(self):
        symbol = self.symbol_box.currentText().strip() or self.symbol
        try:
            src = self.exchange_manager.perp() if self.exchange_manager else None
            if not src:
                self._update_status("⚠️ No perp data source (set MARKET_TYPE=swap in .env)")
                return
            snap = src.fetch_funding(symbol)
            oi = src.fetch_open_interest(symbol)
            if snap:
                self._last_price = snap.mark_price or self._last_price
                heatmap = build_liquidation_heatmap(snap.mark_price) if snap.mark_price else []
                self._apply_update(snap, oi, heatmap)
            else:
                self._update_status(f"⚠️ Could not fetch funding for {symbol}")
        except Exception as e:
            self._update_status(f"⚠️ {str(e)[:60]}")

    def _apply_update(self, snap, oi, heatmap):
        fr_color = GREEN if snap.funding_rate <= 0 else RED
        self.cards["funding"].setText(f"{snap.funding_rate*100:+.4f}%")
        self.cards["funding"].setStyleSheet(f"font-size:16px; font-weight:bold; color:{fr_color};")
        self.cards["apr"].setText(f"{snap.annualized_funding_pct*100:+.1f}%/yr")
        self.cards["basis"].setText(f"{snap.basis_pct*100:+.3f}%")
        if oi:
            self.cards["oi"].setText(f"${oi.open_interest_usd:,.0f}" if oi.open_interest_usd else f"{oi.open_interest:,.0f}")
        self.heatmap.set_data(snap.mark_price, heatmap)
        self.entry_spin.setValue(snap.mark_price)
        self.status_label.setText(f"🟢 Updated {datetime.now().strftime('%H:%M:%S')} — {snap.symbol}")

    def _update_status(self, text: str):
        self.status_label.setText(text)

    def calculate_liquidation(self):
        entry = self.entry_spin.value()
        leverage = self.leverage_spin.value()
        side = self.side_box.currentText()
        margin_mode = self.margin_box.currentText()
        stop = self.sl_spin.value()

        if entry <= 0:
            self.calc_result.setText("Enter a valid entry price first.")
            return

        result = evaluate_liquidation_risk(
            entry_price=entry, leverage=leverage, side=side, margin_mode=margin_mode,
        )
        lines = [
            f"Liquidation Price: ${result.liquidation_price:,.4f}   "
            f"(distance: {result.distance_pct*100:.2f}%)",
        ]
        if result.is_safe:
            lines.append("✅ Liquidation distance OK")
        else:
            lines.append("⚠️ Liquidation is very close — consider lowering leverage")

        if stop > 0:
            beats = stop_loss_beats_liquidation(entry, stop, result.liquidation_price, side)
            lines.append(
                "✅ Stop-loss triggers before liquidation" if beats
                else "🛑 Stop-loss is BEYOND liquidation price — your stop will never fire, the exchange gets there first"
            )

        color = GREEN if result.is_safe else RED
        self.calc_result.setStyleSheet(
            f"font-family:Consolas; font-size:12px; padding:6px; color:{color}; "
            f"background:{BG}; border:1px solid {BORDER}; border-radius:4px;"
        )
        self.calc_result.setText("\n".join(lines))
