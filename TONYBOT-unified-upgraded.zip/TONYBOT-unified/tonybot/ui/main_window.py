"""
TONYBOT v10.0 — AEGIS Complete Dashboard
Full rebuild: 7-gate signal pipeline, candlestick chart, multi-view center,
ATR risk management, kill switch, circuit breaker, Telegram notifications.
"""
from __future__ import annotations

import json
import logging
import math
import sys
import threading
import time
from datetime import date, datetime
from typing import Optional

import pandas as pd
import requests
from PySide6.QtCore import (
    Q_ARG, QMetaObject, QThread, QTimer, Qt, Signal, Slot,
)
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QBrush
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMainWindow,
    QProgressBar, QPushButton, QSizePolicy, QStackedWidget,
    QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit,
    QVBoxLayout, QWidget,
)

try:
    import websocket as _websocket
    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False

from tonybot.config import config
from tonybot.core.db import Database
from tonybot.risk.risk_manager import RiskManager
from tonybot.strategy.signal_refiner import SignalRefiner
from tonybot.strategy.trade_signal import PredictiveSignalEngine
from tonybot.core.signal_tracker import SignalTracker
from tonybot.themes.manager import theme_manager
from tonybot.exchanges.manager import ExchangeManager
from tonybot.ui.perp_risk_tab import PerpRiskTab
from tonybot.ui.analytics_tab import AnalyticsTab
from tonybot.ui.nexus_tab import NexusTab
from tonybot.ui.workers import CandleFetcher, SentimentWorker

logger = logging.getLogger("tonybot.ui")

# ── Colour palette ────────────────────────────────────────────────
BG       = "#0A0E1A"
PANEL    = "#0F1628"
PANEL2   = "#141D35"
BORDER   = "#1E2D4A"
GREEN    = "#00FF88"
RED      = "#FF3B5C"
CYAN     = "#00D4FF"
AMBER    = "#F0B90B"
TEXT     = "#E8EAF0"
TEXT2    = "#7A8BA8"
PURPLE   = "#7B4FE0"

# ── Utility helpers ───────────────────────────────────────────────
def _lbl(text: str, size: int = 10, bold: bool = False,
         color: str = TEXT) -> QLabel:
    lbl = QLabel(text)
    w = "bold" if bold else "normal"
    lbl.setStyleSheet(
        f"color:{color};font-size:{size}px;font-weight:{w};"
        f"font-family:Consolas,monospace;background:transparent;"
    )
    return lbl


def _btn(text: str, color: str = CYAN, fg: str = BG,
         checkable: bool = False) -> QPushButton:
    b = QPushButton(text)
    b.setCheckable(checkable)
    b.setStyleSheet(
        f"QPushButton{{background:{color};color:{fg};"
        f"border:none;padding:5px 10px;border-radius:4px;"
        f"font-family:Consolas;font-size:10px;font-weight:bold;}}"
        f"QPushButton:checked{{background:#22304A;color:{CYAN};"
        f"border:1px solid {CYAN};}}"
        f"QPushButton:hover{{opacity:0.85;}}"
    )
    return b


def _frame(bg: str = PANEL, border: bool = True) -> QFrame:
    f = QFrame()
    b = f"border:1px solid {BORDER};" if border else ""
    f.setStyleSheet(
        f"QFrame{{background:{bg};{b}border-radius:6px;}}"
    )
    return f


def _table(cols: list[str], row_height: int = 20) -> QTableWidget:
    t = QTableWidget(0, len(cols))
    t.setHorizontalHeaderLabels(cols)
    t.setStyleSheet(
        f"QTableWidget{{background:{BG};color:{TEXT2};"
        f"font-family:Consolas;font-size:9px;border:none;"
        f"gridline-color:{BORDER};}}"
        f"QHeaderView::section{{background:{PANEL};color:{TEXT2};"
        f"font-size:9px;border:none;padding:3px;}}"
        f"QTableWidget::item{{padding:2px 4px;}}"
    )
    t.verticalHeader().setVisible(False)
    t.horizontalHeader().setStretchLastSection(True)
    t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    t.setAlternatingRowColors(False)
    t.verticalHeader().setDefaultSectionSize(row_height)
    return t


def _progress(lo: int = 0, hi: int = 100,
              color: str = CYAN, height: int = 8) -> QProgressBar:
    pb = QProgressBar()
    pb.setRange(lo, hi)
    pb.setValue(lo)
    pb.setTextVisible(False)
    pb.setFixedHeight(height)
    pb.setStyleSheet(
        f"QProgressBar{{background:{BORDER};border:none;"
        f"border-radius:{height//2}px;}}"
        f"QProgressBar::chunk{{background:{color};"
        f"border-radius:{height//2}px;}}"
    )
    return pb


def _card(title: str = "") -> tuple:
    """A visually distinct grouping — subtle raised tint + border + rounded
    corners — for a labeled section within a sidebar. Replaces the previous
    plain "───" text-line dividers, which read as a placeholder rather than
    an intentional grouping."""
    f = QFrame()
    f.setStyleSheet(
        f"QFrame{{background:{PANEL2};border:1px solid {BORDER};border-radius:8px;}}"
    )
    lay = QVBoxLayout(f)
    lay.setContentsMargins(14, 12, 14, 14)
    lay.setSpacing(9)
    if title:
        lay.addWidget(_lbl(title, 9, True, TEXT2))
    return f, lay


def _gauge(color: str = CYAN, height: int = 20) -> QProgressBar:
    """A progress bar with its numeric value rendered in the fill itself —
    the previous AI Confidence / Market Sentiment bars had no visible number
    at all, so a real reading and an empty placeholder looked identical."""
    pb = QProgressBar()
    pb.setRange(0, 100)
    pb.setValue(0)
    pb.setTextVisible(True)
    pb.setAlignment(Qt.AlignmentFlag.AlignCenter)
    pb.setFixedHeight(height)
    pb.setStyleSheet(
        f"QProgressBar{{background:{BORDER};border:none;border-radius:{height//2}px;"
        f"color:{TEXT};font-size:9px;font-weight:bold;font-family:Consolas;}}"
        f"QProgressBar::chunk{{background:{color};border-radius:{height//2}px;}}"
    )
    return pb


def _stat_cell(caption: str) -> tuple:
    """One cell of a compact stat grid: small caption, bold value beneath.
    Returns (container_widget, value_label) so callers can update the value."""
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(1)
    lay.addWidget(_lbl(caption, 8, False, TEXT2))
    value_lbl = _lbl("—", 13, True, TEXT)
    lay.addWidget(value_lbl)
    return w, value_lbl


# ═══════════════════════════════════════════════════════════════════
# TELEGRAM BOT
# ═══════════════════════════════════════════════════════════════════
class TelegramBot:
    def __init__(self):
        self.token   = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.enabled = bool(self.token and self.chat_id)
        if self.enabled:
            logger.info("Telegram Bot Connected")

    def send_message(self, message: str) -> bool:
        if not self.enabled:
            return False
        try:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            resp = requests.post(
                url,
                json={"chat_id": self.chat_id,
                      "text": message, "parse_mode": "HTML"},
                timeout=10,
            )
            return resp.status_code == 200
        except Exception as exc:
            logger.warning("Telegram error: %s", exc)
            return False

    def send_signal(self, symbol: str, action: str,
                    confidence: float, price: float,
                    aegis_score: float = 0) -> None:
        if not self.enabled:
            return
        emoji = "🟢" if action == "BUY" else ("🔴" if action == "SELL" else "🟡")
        msg = (
            f"{emoji} <b>AEGIS SIGNAL</b>\n\n"
            f"📊 <b>{symbol}</b> → {action}\n"
            f"💰 Price: ${price:,.4f}\n"
            f"🎯 AegisScore: {aegis_score:.0f}/100\n"
            f"💪 Confidence: {confidence:.0f}%"
        )
        self.send_message(msg)


# ═══════════════════════════════════════════════════════════════════
# CANDLESTICK CHART
# ═══════════════════════════════════════════════════════════════════
class CandlestickChart(QWidget):
    """
    OHLCV candlestick chart with EMA-12/26 overlays, volume bars, and
    auto-detected support/resistance levels.
    Candle format: [timestamp_ms, open, high, low, close, volume]
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.candles: list = []      # [[ts, o, h, l, c, v], ...]
        self.sr_levels: list = []    # SRLevel objects for the current candle set
        self._loading_tf: Optional[str] = None
        self.setMinimumHeight(260)
        self.setStyleSheet(
            f"background:{BG};border:1px solid {BORDER};border-radius:6px;"
        )
        from tonybot.strategy.support_resistance import SupportResistanceDetector
        self._sr_detector = SupportResistanceDetector()
        self._load_demo()

    # ── public API ────────────────────────────────────────────────
    def load_candles(self, candles: list) -> None:
        self._loading_tf = None
        self.candles = list(candles[-80:])
        self.sr_levels = self._compute_sr_levels(self.candles)
        self.update()

    def set_loading(self, tf: str) -> None:
        """Called when the user picks a timeframe that hasn't been fetched
        yet — shows a clear "fetching Xm..." state instead of either a blank
        chart or (worse) silently leaving the previous timeframe's candles
        on screen mislabeled as the newly selected one."""
        self._loading_tf = tf
        self.update()

    def _compute_sr_levels(self, candles: list) -> list:
        if len(candles) < 15:
            return []
        try:
            df = pd.DataFrame(candles, columns=["ts", "open", "high", "low", "close", "volume"])
            return self._sr_detector.detect(df)
        except Exception:
            return []

    def update_live_candle(self, price: float) -> None:
        if not self.candles:
            self.candles.append([
                int(time.time() * 1000), price, price, price, price, 0
            ])
        else:
            c = list(self.candles[-1])
            c[4] = price                        # close
            c[2] = max(c[2], price)             # high
            c[3] = min(c[3], price)             # low
            self.candles[-1] = c
        self.update()

    # ── internal helpers ──────────────────────────────────────────
    def _load_demo(self):
        p = 67000.0
        ts = int(time.time() * 1000) - 60 * 60 * 1000 * 50
        for _ in range(50):
            o = p
            p += (0.5 - __import__("random").random()) * 400
            h = max(o, p) + abs(__import__("random").random() * 150)
            l = min(o, p) - abs(__import__("random").random() * 150)
            v = __import__("random").random() * 1000
            self.candles.append([ts, o, h, l, p, v])
            ts += 60 * 60 * 1000

    @staticmethod
    def _ema(values: list, span: int) -> list:
        if not values:
            return []
        k = 2 / (span + 1)
        result = [values[0]]
        for v in values[1:]:
            result.append(v * k + result[-1] * (1 - k))
        return result

    def _price_to_y(self, price, p_min, p_range, chart_top, chart_h):
        if p_range == 0:
            return chart_top + chart_h // 2
        return chart_top + chart_h - int((price - p_min) / p_range * chart_h)

    # ── paint ─────────────────────────────────────────────────────
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()

        margin_l, margin_r = 8, 64
        margin_t, margin_b = 10, 22
        chart_area_h = int(h * 0.72)
        vol_area_h   = int(h * 0.18)
        gap          = int(h * 0.05)

        chart_top = margin_t
        vol_top   = chart_top + chart_area_h + gap
        chart_w   = w - margin_l - margin_r

        # background grid
        painter.fillRect(0, 0, w, h, QColor(BG))
        painter.setPen(QPen(QColor(BORDER), 1))
        for i in range(5):
            y = chart_top + i * chart_area_h // 4
            painter.drawLine(margin_l, y, w - margin_r, y)

        if len(self.candles) < 2:
            painter.setPen(QColor(TEXT2))
            label = f"Loading {self._loading_tf}…" if self._loading_tf else "Loading…"
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, label)
            return

        candles = self.candles
        closes  = [c[4] for c in candles]
        highs   = [c[2] for c in candles]
        lows    = [c[3] for c in candles]
        volumes = [c[5] for c in candles]

        p_min = min(lows)
        p_max = max(highs)
        p_rng = p_max - p_min if p_max != p_min else 1.0
        v_max = max(volumes) if volumes and max(volumes) > 0 else 1.0

        n  = len(candles)
        bw = max(2, int(chart_w / n) - 1)

        # ── candles ────────────────────────────────────────────────
        for i, c in enumerate(candles):
            ts, op, hi, lo, cl, vol = c
            x = margin_l + int(i * chart_w / n) + bw // 2
            y_op = self._price_to_y(op, p_min, p_rng, chart_top, chart_area_h)
            y_cl = self._price_to_y(cl, p_min, p_rng, chart_top, chart_area_h)
            y_hi = self._price_to_y(hi, p_min, p_rng, chart_top, chart_area_h)
            y_lo = self._price_to_y(lo, p_min, p_rng, chart_top, chart_area_h)
            color = QColor(GREEN) if cl >= op else QColor(RED)

            # wick
            painter.setPen(QPen(color, 1))
            painter.drawLine(x, y_hi, x, y_lo)

            # body
            body_top = min(y_op, y_cl)
            body_h   = max(1, abs(y_cl - y_op))
            painter.fillRect(x - bw // 2, body_top, bw, body_h, color)

            # volume bar
            v_h = max(1, int((vol / v_max) * vol_area_h))
            painter.fillRect(
                x - bw // 2, vol_top + vol_area_h - v_h,
                bw, v_h, color
            )

        # ── EMA overlays ───────────────────────────────────────────
        for span, color_str in [(12, CYAN), (26, "#FF8C00")]:
            ema = self._ema(closes, span)
            painter.setPen(QPen(QColor(color_str), 1))
            pts = []
            for i, v in enumerate(ema):
                x = margin_l + int(i * chart_w / n) + bw // 2
                y = self._price_to_y(v, p_min, p_rng, chart_top, chart_area_h)
                pts.append((x, y))
            for i in range(1, len(pts)):
                painter.drawLine(pts[i-1][0], pts[i-1][1], pts[i][0], pts[i][1])

        # ── auto support/resistance levels ────────────────────────
        # Dashed horizontal lines at price levels this symbol has
        # repeatedly reacted to (see strategy/support_resistance.py) — the
        # same detector PredictiveSignalEngine uses as a leading
        # confirmation, so what you see here is what the engine is actually
        # watching for a bounce/breakout, not a cosmetic-only overlay.
        for level in self.sr_levels:
            if not (p_min <= level.price <= p_max):
                continue
            y = self._price_to_y(level.price, p_min, p_rng, chart_top, chart_area_h)
            color = QColor(GREEN if level.kind == "support" else RED)
            color.setAlpha(90 + int(level.strength * 100))  # stronger levels draw more solid
            pen = QPen(color, 1, Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.drawLine(margin_l, y, w - margin_r, y)
            painter.setPen(color)
            label = f"{'S' if level.kind == 'support' else 'R'} ${level.price:,.4g} ({level.touches}x)"
            painter.drawText(margin_l + 4, y - 3, label)

        # ── y-axis labels ──────────────────────────────────────────
        painter.setPen(QColor(TEXT2))
        font = QFont("Consolas", 7)
        painter.setFont(font)
        for i in range(5):
            price_val = p_min + (i / 4) * p_rng
            y = self._price_to_y(price_val, p_min, p_rng, chart_top, chart_area_h)
            painter.drawText(w - margin_r + 2, y + 4, f"${price_val:,.0f}")

        # ── x-axis time labels ─────────────────────────────────────
        positions = [0, n // 3, 2 * n // 3, n - 1]
        for idx in positions:
            if 0 <= idx < len(candles):
                ts_ms = candles[idx][0]
                try:
                    dt = datetime.fromtimestamp(ts_ms / 1000)
                    label = dt.strftime("%H:%M")
                except Exception:
                    label = ""
                x = margin_l + int(idx * chart_w / n) + bw // 2
                painter.drawText(x - 15, h - 4, label)


# ═══════════════════════════════════════════════════════════════════
# SIGNAL REFINER WORKER
# ═══════════════════════════════════════════════════════════════════
class SignalRefinerWorker(QThread):
    aegis_result = Signal(dict)

    def __init__(self, refiner: SignalRefiner, symbol: str,
                 candles_by_tf: dict, atr: float):
        super().__init__()
        self.refiner       = refiner
        self.symbol        = symbol
        self.candles_by_tf = candles_by_tf
        self.atr           = atr

    def run(self):
        try:
            result = self.refiner.evaluate(
                self.symbol, self.candles_by_tf, self.atr
            )
            self.aegis_result.emit(result)
        except Exception as exc:
            logger.warning("SignalRefinerWorker error: %s", exc)
            self.aegis_result.emit({
                "direction": "HOLD", "aegis_score": 0.0,
                "gates": {}, "signal_engine_votes": {},
                "mtf_bias": "HOLD", "sentiment_score": 0.0,
                "ml_confidence": 0.5, "atr": self.atr,
            })


# ═══════════════════════════════════════════════════════════════════
# PREDICTIVE TRADE SIGNAL WORKER
# Produces an actionable signal (entry/SL/TP/reasoning/confidence) that
# only fires when a leading order-flow or pattern confirmation agrees
# with the lagging AEGIS technical consensus — see strategy/trade_signal.py
# ═══════════════════════════════════════════════════════════════════
class TradeSignalWorker(QThread):
    trade_signal_result = Signal(dict)  # {"signal": dict|None, "reason_blocked": str}

    def __init__(self, engine, symbol: str, candles_by_tf: dict, atr: float):
        super().__init__()
        self.engine = engine
        self.symbol = symbol
        self.candles_by_tf = candles_by_tf
        self.atr = atr

    def run(self):
        try:
            from tonybot.ui.workers import fetch_order_book_rest
            orderbook = fetch_order_book_rest(self.symbol)

            pattern_df = None
            candles = None
            for tf_pref in ["1h", "5m", "4h", "1m", "1d"]:
                c = self.candles_by_tf.get(tf_pref)
                if c:
                    candles = c
                    break
            if candles:
                pattern_df = pd.DataFrame(
                    candles, columns=["timestamp", "open", "high", "low", "close", "volume"]
                )

            result = self.engine.build_signal(
                self.symbol, self.candles_by_tf, self.atr,
                orderbook=orderbook, pattern_df=pattern_df,
            )
            signal = result.get("signal")
            self.trade_signal_result.emit({
                "signal": signal.to_dict() if signal else None,
                "reason_blocked": result.get("reason_blocked", ""),
            })
        except Exception as exc:
            logger.warning("TradeSignalWorker error: %s", exc)
            self.trade_signal_result.emit({"signal": None, "reason_blocked": f"Error: {exc}"})


# ═══════════════════════════════════════════════════════════════════
# ORDER BOOK FETCHER
# ═══════════════════════════════════════════════════════════════════
class OrderBookFetcher(QThread):
    orderbook_update = Signal(str, dict)

    def __init__(self):
        super().__init__()
        self._running = True
        self._symbol  = "BTCUSDT"

    def set_symbol(self, symbol: str):
        self._symbol = symbol

    def run(self):
        while self._running:
            try:
                clean = self._symbol.replace("/", "")
                resp  = requests.get(
                    f"https://api.binance.com/api/v3/depth"
                    f"?symbol={clean}&limit=5",
                    timeout=5,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    bids = [[float(b[0]), float(b[1])]
                            for b in data.get("bids", [])[:5]]
                    asks = [[float(a[0]), float(a[1])]
                            for a in data.get("asks", [])[:5]]
                    self.orderbook_update.emit(
                        self._symbol, {"bids": bids, "asks": asks}
                    )
            except Exception:
                pass
            time.sleep(2)

    def stop(self):
        self._running = False


# ═══════════════════════════════════════════════════════════════════
# TRADE MANAGER
# ═══════════════════════════════════════════════════════════════════
class TradeManager:
    def __init__(self, db: Database, log_cb, telegram: TelegramBot,
                 risk_manager: RiskManager):
        self.db             = db
        self.log            = log_cb
        self.telegram       = telegram
        self.risk           = risk_manager
        self.balance        = float(config.INITIAL_BALANCE)
        self.open_positions: dict = {}
        self.daily_pnl      = 0.0
        self.trades: list   = []
        self._trade_id      = 0
        self.kill_switch_active = False

    def execute_trade(self, symbol: str, action: str, price: float,
                      confidence: float, atr: float = 0.0) -> tuple[bool, str]:
        if self.kill_switch_active:
            return False, "Kill switch active"
        if symbol in self.open_positions:
            return False, "Already in position"

        can, reason = self.risk.can_open_position(len(self.open_positions))
        if not can:
            return False, reason

        # ATR sizing
        if atr > 0:
            size = self.risk.calculate_position_size(
                self.balance, config.MAX_RISK_PER_TRADE_FULL, atr
            )
            sl, tp = self.risk.calculate_sl_tp(price, atr, action)
        else:
            size = min(200.0, self.balance * 0.02)
            if action == "BUY":
                sl, tp = price * 0.97, price * 1.05
            else:
                sl, tp = price * 1.03, price * 0.95

        if size <= 0 or self.balance < size:
            return False, "Insufficient balance"

        quantity = size / price if price > 0 else 0
        self._trade_id += 1
        trade = {
            "id": self._trade_id, "symbol": symbol,
            "action": action, "entry": price,
            "size": size, "quantity": quantity,
            "sl": sl, "tp": tp,
            "confidence": confidence, "atr": atr,
            "entry_time": datetime.now(), "status": "OPEN",
        }
        self.open_positions[symbol] = trade
        self.balance -= size

        self.db.record_trade(
            symbol, action, price, quantity, sl, tp,
            aegis_score=confidence,
            mode="PAPER" if not config.LIVE_TRADING else "LIVE",
        )
        self.telegram.send_signal(symbol, action, confidence, price, confidence)
        self.log(
            f"✅ {action} {symbol} @ ${price:,.4f} | "
            f"Size:${size:.0f} | SL:${sl:,.4f} | TP:${tp:,.4f}"
        )
        return True, "Trade executed"

    def _close_positions(self, current_prices: dict):
        closed = []
        for sym, pos in list(self.open_positions.items()):
            price = current_prices.get(sym, pos["entry"])
            hit_sl = (pos["action"] == "BUY" and price <= pos["sl"]) or \
                     (pos["action"] == "SELL" and price >= pos["sl"])
            hit_tp = (pos["action"] == "BUY" and price >= pos["tp"]) or \
                     (pos["action"] == "SELL" and price <= pos["tp"])
            if hit_sl or hit_tp:
                closed.append(sym)

        for sym in closed:
            pos   = self.open_positions.pop(sym)
            price = current_prices.get(sym, pos["entry"])
            if pos["action"] == "BUY":
                pnl = (price - pos["entry"]) * pos["quantity"]
            else:
                pnl = (pos["entry"] - price) * pos["quantity"]

            pos.update(pnl=pnl, exit_price=price,
                       status="CLOSED", exit_time=datetime.now())
            self.balance   += pos["size"] + pnl
            self.daily_pnl += pnl
            self.trades.append(pos)

            self.db.close_trade(pos["id"], price)
            self.risk.record_pnl(date.today(), pnl)
            self.risk.update_drawdown(self.balance)

            icon = "📈" if pnl >= 0 else "📉"
            reason = "SL" if (pos["action"] == "BUY" and price <= pos["sl"]) or \
                              (pos["action"] == "SELL" and price >= pos["sl"]) \
                     else "TP"
            self.log(f"{icon} CLOSED {sym} {reason} | PnL: ${pnl:+.2f}")
        return closed

    def get_stats(self) -> dict:
        return {
            "balance":        self.balance,
            "daily_pnl":      self.daily_pnl,
            "open_positions": len(self.open_positions),
            "open_list":      list(self.open_positions.values()),
            "trades":         self.trades[-30:],
        }


# ═══════════════════════════════════════════════════════════════════
# MAIN WINDOW
# ═══════════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self, engine=None):
        super().__init__()
        self.engine          = engine
        self.user: dict      = {}
        self.user_id: int    = 1
        self.current_symbol  = "BTCUSDT"

        # live data stores
        self._candles_by_tf: dict = {}   # symbol → {tf → candles}
        self._latest_sentiment: dict = {}
        self._latest_atr: float = 0.0
        self._latest_aegis: dict = {}
        self._current_prices: dict = {}
        self.kill_switch_active = False

        # core objects
        self.db           = Database()
        self.telegram     = TelegramBot()
        self.risk_manager = RiskManager(
            max_concurrent_positions=config.MAX_CONCURRENT_POSITIONS,
            max_daily_loss_pct=config.MAX_DAILY_LOSS_PCT,
            max_drawdown_pct=config.MAX_DRAWDOWN_PCT,
        )
        self.trade_manager = TradeManager(
            self.db, self.log, self.telegram, self.risk_manager
        )
        self.signal_refiner = SignalRefiner()
        self.signal_tracker = SignalTracker(self.db)
        self.predictive_engine = PredictiveSignalEngine(
            signal_refiner=self.signal_refiner,
            risk_manager=self.risk_manager,
            signal_tracker=self.signal_tracker,
        )
        self._latest_trade_signal: Optional[dict] = None

        # window
        self.setWindowTitle("⚡ AEGIS Trading Engine v10.0")
        self.setGeometry(80, 80, 1560, 900)
        self.setMinimumSize(1300, 750)
        self.setStyleSheet(
            f"QMainWindow{{background:{BG};}}"
            f"QWidget{{background:{BG};color:{TEXT};"
            f"font-family:Consolas,monospace;}}"
            f"QLabel{{background:transparent;}}"
            f"QGroupBox{{color:{TEXT2};border:1px solid {BORDER};"
            f"border-radius:4px;margin-top:8px;padding-top:6px;}}"
        )

        # build UI
        central = QWidget()
        root    = QVBoxLayout(central)
        root.setSpacing(0)
        root.setContentsMargins(0, 0, 0, 0)

        root.addWidget(self._build_header())

        main_row = QHBoxLayout()
        main_row.setSpacing(4)
        main_row.setContentsMargins(4, 4, 4, 0)
        main_row.addWidget(self._build_left_panel())
        main_row.addWidget(self._build_center(), 1)
        main_row.addWidget(self._build_right_panel())
        root.addLayout(main_row, 1)

        root.addWidget(self._build_exec_log())

        # --- Wrap the original single-page AEGIS view in a top-level tab
        # widget alongside the new perp/analytics/portfolio tabs, so nothing
        # about the existing layout above has to change. ---
        self.exchange_manager = self.engine.exchange_manager if self.engine else ExchangeManager()

        main_tabs = QTabWidget()
        main_tabs.setStyleSheet(
            f"QTabWidget::pane{{background:{BG};border:none;}}"
            f"QTabBar::tab{{background:{PANEL};color:{TEXT2};"
            f"padding:8px 16px;border:none;font-weight:bold;}}"
            f"QTabBar::tab:selected{{color:{CYAN};border-bottom:2px solid {CYAN};}}"
        )
        main_tabs.addTab(central, "🎯 AEGIS")

        # Previously a failed optional tab only got a one-line self.log()
        # message inside the in-app "📋 Log" widget — nothing went to
        # logs/tonybot.log or the console, so if you weren't specifically
        # looking at that tab when it happened, the failure was invisible.
        # _load_optional_tab now writes the full traceback to all three
        # places and shows a disabled placeholder tab so it's obvious
        # something didn't load instead of a tab just quietly not existing.
        self._load_optional_tab(main_tabs, "⚡ Perp Risk", lambda: PerpRiskTab(exchange_manager=self.exchange_manager))
        self._load_optional_tab(
            main_tabs, "📈 Analytics",
            lambda: AnalyticsTab(data_source=self.engine.data_source if self.engine else None),
        )
        self._load_optional_tab(main_tabs, "📊 Nexus", lambda: NexusTab())

        self.setCentralWidget(main_tabs)

        # background workers
        self._candle_fetcher = CandleFetcher(self.current_symbol)
        self._candle_fetcher.candles_ready.connect(self.on_candles_ready)
        self._candle_fetcher.start()

        self._sentiment_worker = SentimentWorker()
        self._sentiment_worker.sentiment_ready.connect(self.on_sentiment_ready)
        self._sentiment_worker.start()

        self._ob_fetcher = OrderBookFetcher()
        self._ob_fetcher.orderbook_update.connect(self._on_orderbook)
        self._ob_fetcher.start()

        # UTC clock
        self._clock_timer = QTimer()
        self._clock_timer.timeout.connect(self._tick_clock)
        self._clock_timer.start(1000)

        # Websocket
        self._start_websocket()

        self.log("✅ AEGIS Trading Engine v10.0 started")
        if self.telegram.enabled:
            self.log("📱 Telegram: Connected")
        else:
            self.log("⚠️ Telegram: Not configured (set TELEGRAM_BOT_TOKEN in .env)")

    # ──────────────────────────────────────────────────────────────
    # HEADER
    # ──────────────────────────────────────────────────────────────
    def _load_optional_tab(self, main_tabs: "QTabWidget", label: str, factory) -> None:
        """Builds an optional tab via `factory()` and adds it. On failure,
        logs the FULL traceback to logs/tonybot.log + console + the in-app
        Log widget (not just a truncated str(e)), and adds a disabled
        placeholder tab in its place so a missing tab is visible in the UI
        itself rather than something you'd only notice by its absence."""
        import traceback
        try:
            widget = factory()
            main_tabs.addTab(widget, label)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error(f"Tab '{label}' failed to load:\n{tb}")
            print(f"[TAB LOAD FAILED] {label}: {e}\n{tb}", file=sys.stderr)
            try:
                self.log(f"⚠️ {label} tab failed to load: {e} (full traceback in logs/tonybot.log)")
            except Exception:
                pass  # log widget itself may not exist yet in edge-case ordering
            placeholder = QWidget()
            layout = QVBoxLayout(placeholder)
            msg = QLabel(f"⚠️ {label} failed to load.\n\n{e}\n\nSee logs/tonybot.log for the full traceback.")
            msg.setWordWrap(True)
            msg.setStyleSheet(f"color:{TEXT2}; padding:24px;")
            layout.addWidget(msg)
            layout.addStretch()
            main_tabs.addTab(placeholder, f"⚠️ {label}")

    def _build_header(self) -> QFrame:
        hdr = _frame(bg="#0D1525", border=False)
        hdr.setFixedHeight(48)
        lay = QHBoxLayout(hdr)
        lay.setContentsMargins(12, 4, 12, 4)
        lay.setSpacing(12)

        lay.addWidget(_lbl("⚡ AEGIS TRADING ENGINE", 14, True, CYAN))
        lay.addSpacing(8)

        self._conn_dot  = _lbl("● CONNECTING", 10, False, AMBER)
        lay.addWidget(self._conn_dot)

        self._mode_lbl  = _lbl("📄 PAPER MODE", 10, True, AMBER)
        lay.addWidget(self._mode_lbl)

        lay.addStretch()

        self.kill_btn = QPushButton("⚡ KILL SWITCH")
        self.kill_btn.setCheckable(True)
        self.kill_btn.setStyleSheet(
            f"QPushButton{{background:#1E0A14;color:{RED};"
            f"border:2px solid {RED};border-radius:4px;"
            f"padding:5px 12px;font-weight:bold;font-size:10px;}}"
            f"QPushButton:checked{{background:{RED};color:{BG};}}"
        )
        self.kill_btn.toggled.connect(self._on_kill_switch)
        lay.addWidget(self.kill_btn)

        lay.addSpacing(8)
        self._utc_clock = _lbl("00:00:00 UTC", 10, False, TEXT2)
        lay.addWidget(self._utc_clock)

        self._user_lbl  = _lbl("USER", 10, False, TEXT2)
        lay.addWidget(self._user_lbl)
        return hdr

    # ──────────────────────────────────────────────────────────────
    # LEFT PANEL
    # ──────────────────────────────────────────────────────────────
    def _build_left_panel(self) -> QFrame:
        pnl = _frame()
        pnl.setFixedWidth(250)
        lay = QVBoxLayout(pnl)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(14)

        # ── Account: hero equity + PnL + compact stat grid ──────────
        account_card, account_lay = _card("ACCOUNT")
        self.equity_lbl = _lbl(f"${config.INITIAL_BALANCE:,.0f}", 24, True, GREEN)
        account_lay.addWidget(self.equity_lbl)
        self.pnl_lbl = _lbl("Daily PnL  $0.00", 10, False, TEXT2)
        account_lay.addWidget(self.pnl_lbl)

        grid = QGridLayout()
        grid.setContentsMargins(0, 6, 0, 0)
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(8)
        wr_cell, self.wr_val = _stat_cell("WIN RATE")
        dd_cell, self.dd_val = _stat_cell("MAX DD")
        op_cell, self.op_val = _stat_cell("OPEN POS")
        pf_cell, self.pf_val = _stat_cell("PROF. FACTOR")
        grid.addWidget(wr_cell, 0, 0)
        grid.addWidget(dd_cell, 0, 1)
        grid.addWidget(op_cell, 1, 0)
        grid.addWidget(pf_cell, 1, 1)
        account_lay.addLayout(grid)

        cap_row = QHBoxLayout()
        cap_row.addWidget(_lbl("Capital deployed", 8, False, TEXT2))
        cap_row.addStretch()
        self.capital_pct_lbl = _lbl("0%", 8, True, TEXT2)
        cap_row.addWidget(self.capital_pct_lbl)
        account_lay.addLayout(cap_row)
        self.capital_bar = _progress(color=CYAN, height=6)
        account_lay.addWidget(self.capital_bar)
        lay.addWidget(account_card)

        # ── Session: which strategy profiles are actually running ───
        # Previously invisible in the GUI entirely — TRADING_MODE (scalp/
        # swing/both, see core/engine.py TRADING_PROFILES) had no on-screen
        # representation, so there was no way to glance at the dashboard and
        # confirm which profiles were actually live.
        session_card, session_lay = _card("SESSION")
        self.trading_mode_lbl = _lbl(config.TRADING_MODE.upper(), 13, True, CYAN)
        session_lay.addWidget(self.trading_mode_lbl)
        self.active_profiles_lbl = _lbl("", 9, False, TEXT2)
        self.active_profiles_lbl.setWordWrap(True)
        session_lay.addWidget(self.active_profiles_lbl)
        self._refresh_session_card()
        lay.addWidget(session_card)

        # ── Navigation ────────────────────────────────────────────
        nav_card, nav_lay = _card("NAVIGATION")
        self._nav_btns: list[QPushButton] = []
        nav_items = [
            ("📊 MARKET SCAN", 0), ("🧠 AI SIGNALS", 1),
            ("📰 NEWS FEED", 2), ("⚙️ SETTINGS", 3),
        ]
        for label, idx in nav_items:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setStyleSheet(
                f"QPushButton{{background:{PANEL};color:{TEXT2};"
                f"border:1px solid {BORDER};border-radius:5px;"
                f"padding:7px;font-size:10px;text-align:left;}}"
                f"QPushButton:checked{{background:#1A2A3A;"
                f"color:{CYAN};border-color:{CYAN};}}"
                f"QPushButton:hover{{color:{TEXT};}}"
            )
            b.clicked.connect(lambda _, i=idx: self.switch_view(i))
            nav_lay.addWidget(b)
            self._nav_btns.append(b)
        self._nav_btns[0].setChecked(True)
        lay.addWidget(nav_card)

        self._cb_banner = _lbl("⛔ CIRCUIT BREAKER ACTIVE", 10, True, RED)
        self._cb_banner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._cb_banner.setStyleSheet(
            f"background:#3A0A14;color:{RED};border:1px solid {RED};"
            f"border-radius:6px;padding:6px;font-size:10px;font-weight:bold;"
        )
        self._cb_banner.hide()
        lay.addWidget(self._cb_banner)

        # Backward-compat aliases: older code/tests may still reference the
        # original flat label names (balance_lbl, wr_lbl, dd_lbl, op_lbl).
        self.balance_lbl = self.equity_lbl
        self.wr_lbl = self.wr_val
        self.dd_lbl = self.dd_val
        self.op_lbl = self.op_val

        lay.addStretch()
        self._session_started_lbl = _lbl("", 8, False, "#3A4A6A")
        self._session_started_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._session_started_lbl.setText(f"Session started {datetime.now().strftime('%H:%M:%S')}")
        lay.addWidget(self._session_started_lbl)
        return pnl

    def _refresh_session_card(self) -> None:
        from tonybot.core.engine import _active_profiles, TRADING_PROFILES
        try:
            profiles = _active_profiles()
        except Exception:
            profiles = ["swing"]
        self.trading_mode_lbl.setText(config.TRADING_MODE.upper())
        descriptions = []
        for p in profiles:
            cfg = TRADING_PROFILES.get(p, {})
            tfs = "/".join(cfg.get("tf_preference", [])[:2])
            descriptions.append(f"{p} ({tfs})")
        self.active_profiles_lbl.setText("Running: " + ", ".join(descriptions))

    # ──────────────────────────────────────────────────────────────
    # RIGHT PANEL
    # ──────────────────────────────────────────────────────────────
    def _build_right_panel(self) -> QFrame:
        pnl = _frame()
        pnl.setFixedWidth(230)
        lay = QVBoxLayout(pnl)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(14)

        # ── Trading mode + available balance ─────────────────────
        mode_card, mode_lay = _card("TRADING MODE")
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["PAPER", "LIVE"])
        self.mode_combo.setStyleSheet(
            f"QComboBox{{background:{PANEL};color:{AMBER};"
            f"border:1px solid {BORDER};border-radius:4px;"
            f"padding:5px;font-size:10px;font-weight:bold;}}"
            f"QComboBox QAbstractItemView{{background:{PANEL};"
            f"color:{TEXT};border:1px solid {BORDER};}}"
        )
        self.mode_combo.currentTextChanged.connect(self._on_mode_changed)
        mode_lay.addWidget(self.mode_combo)
        self.available_lbl = _lbl(f"Available  ${config.INITIAL_BALANCE:,.0f}", 10, False, TEXT2)
        mode_lay.addWidget(self.available_lbl)
        lay.addWidget(mode_card)

        # ── Manual order entry ────────────────────────────────────
        order_card, order_lay = _card("MANUAL ORDER")
        self.sym_input = QLineEdit(self.current_symbol)
        self.sym_input.setStyleSheet(
            f"QLineEdit{{background:{PANEL};color:{TEXT};"
            f"border:1px solid {BORDER};border-radius:4px;padding:5px;}}"
        )
        order_lay.addWidget(self.sym_input)
        self.qty_input = QLineEdit("0.001")
        self.qty_input.setStyleSheet(self.sym_input.styleSheet())
        self.qty_input.setPlaceholderText("Quantity")
        order_lay.addWidget(self.qty_input)

        btn_row = QHBoxLayout()
        b_buy  = QPushButton("BUY")
        b_sell = QPushButton("SELL")
        b_buy.setStyleSheet(
            f"QPushButton{{background:{GREEN};color:{BG};"
            f"border:none;border-radius:5px;padding:9px;"
            f"font-weight:bold;font-size:13px;}}"
        )
        b_sell.setStyleSheet(
            f"QPushButton{{background:{RED};color:{BG};"
            f"border:none;border-radius:5px;padding:9px;"
            f"font-weight:bold;font-size:13px;}}"
        )
        b_buy.clicked.connect(lambda: self._manual_trade("BUY"))
        b_sell.clicked.connect(lambda: self._manual_trade("SELL"))
        btn_row.addWidget(b_buy)
        btn_row.addWidget(b_sell)
        order_lay.addLayout(btn_row)

        self.auto_btn = QPushButton("🤖 AUTO OFF")
        self.auto_btn.setCheckable(True)
        self.auto_btn.setStyleSheet(
            f"QPushButton{{background:#1E0A14;color:{RED};"
            f"border:1px solid {RED};border-radius:5px;"
            f"padding:6px;font-size:10px;font-weight:bold;}}"
            f"QPushButton:checked{{background:#0A1E14;"
            f"color:{GREEN};border-color:{GREEN};}}"
        )
        self.auto_btn.toggled.connect(self._on_auto_toggled)
        order_lay.addWidget(self.auto_btn)
        lay.addWidget(order_card)

        # ── Signal readouts: one clean numeric gauge each, replacing the
        # previous LOW/MID/HIGH triple-bar (three mostly-empty bars with no
        # visible number, representing what is really just one confidence
        # value) and the unlabeled sentiment bar. ────────────────────────
        signal_card, signal_lay = _card("SIGNAL READOUT")

        sent_row = QHBoxLayout()
        sent_row.addWidget(_lbl("Market Sentiment", 9, False, TEXT2))
        sent_row.addStretch()
        self.sentiment_desc_lbl = _lbl("Neutral", 9, True, AMBER)
        sent_row.addWidget(self.sentiment_desc_lbl)
        signal_lay.addLayout(sent_row)
        self.sentiment_bar = _gauge(color=AMBER, height=18)
        self.sentiment_bar.setFormat("%p")
        signal_lay.addWidget(self.sentiment_bar)

        signal_lay.addWidget(_lbl("AI Confidence", 9, False, TEXT2))
        self.ai_confidence_bar = _gauge(color=CYAN, height=18)
        self.ai_confidence_bar.setFormat("%p%")
        signal_lay.addWidget(self.ai_confidence_bar)
        lay.addWidget(signal_card)

        # ── Last fired signal — fills what was previously dead space with
        # something genuinely useful: a glance at what AEGIS last concluded,
        # without switching to the full AI Signals tab.
        recent_card, recent_lay = _card("LAST SIGNAL")
        self.last_signal_lbl = _lbl("No signal yet", 12, True, TEXT2)
        recent_lay.addWidget(self.last_signal_lbl)
        self.last_signal_meta_lbl = _lbl("", 8, False, TEXT2)
        recent_lay.addWidget(self.last_signal_meta_lbl)
        lay.addWidget(recent_card)

        lay.addStretch()
        self._refresh_footer_lbl = _lbl("Signals refresh continuously", 8, False, "#3A4A6A")
        self._refresh_footer_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._refresh_footer_lbl)
        return pnl

    # ──────────────────────────────────────────────────────────────
    # CENTER — stacked views
    # ──────────────────────────────────────────────────────────────
    def _build_center(self) -> QWidget:
        container = QWidget()
        vbox = QVBoxLayout(container)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)

        self._stack = QStackedWidget()
        self._stack.addWidget(self._build_market_scan())   # 0
        self._stack.addWidget(self._build_ai_signals())    # 1
        self._stack.addWidget(self._build_news_feed())     # 2
        self._stack.addWidget(self._build_settings())      # 3
        vbox.addWidget(self._stack, 1)
        return container

    def _build_market_scan(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        # asset selector + price
        top = _frame(bg="#0D1525", border=False)
        top.setFixedHeight(40)
        tlay = QHBoxLayout(top)
        tlay.setContentsMargins(6, 2, 6, 2)
        self._asset_btns: dict[str, QPushButton] = {}
        for sym in ["BTC", "ETH", "SOL", "BNB"]:
            b = QPushButton(sym)
            b.setCheckable(True)
            b.setFixedWidth(46)
            b.setStyleSheet(
                f"QPushButton{{background:{PANEL};color:{TEXT2};"
                f"border:1px solid {BORDER};border-radius:3px;"
                f"font-size:10px;font-weight:bold;padding:3px;}}"
                f"QPushButton:checked{{background:{CYAN};"
                f"color:{BG};border-color:{CYAN};}}"
            )
            b.clicked.connect(lambda _, s=sym: self.switch_asset(f"{s}USDT"))
            tlay.addWidget(b)
            self._asset_btns[sym] = b
        self._asset_btns["BTC"].setChecked(True)
        tlay.addStretch()

        self.chart_tf_combo = QComboBox()
        self.chart_tf_combo.addItems(["1m", "5m", "1h", "4h"])
        self.chart_tf_combo.setCurrentText("1h")
        self.chart_tf_combo.setFixedWidth(64)
        self.chart_tf_combo.setStyleSheet(
            f"QComboBox{{background:{PANEL};color:{AMBER};"
            f"border:1px solid {BORDER};border-radius:3px;"
            f"font-size:10px;font-weight:bold;padding:3px;}}"
            f"QComboBox QAbstractItemView{{background:{PANEL};"
            f"color:{TEXT};selection-background-color:{CYAN};}}"
        )
        self.chart_tf_combo.currentTextChanged.connect(self._on_chart_timeframe_changed)
        tlay.addWidget(self.chart_tf_combo)

        self.price_lbl  = _lbl("$0.00", 22, True, GREEN)
        self.change_lbl = _lbl("0.00%", 12, False, TEXT2)
        tlay.addWidget(self.price_lbl)
        tlay.addWidget(self.change_lbl)
        lay.addWidget(top)

        self.chart = CandlestickChart()
        lay.addWidget(self.chart, 2)

        lay.addWidget(_lbl("MARKET SCANNER — 30 PAIRS", 9, False, TEXT2))
        self.scanner_table = _table(
            ["Symbol", "Price", "24h%", "RSI", "AegisScore", "Signal"], 18
        )
        self.scanner_table.horizontalHeader().setStretchLastSection(False)
        for i, cw in enumerate([80, 90, 60, 45, 80, 60]):
            self.scanner_table.setColumnWidth(i, cw)
        lay.addWidget(self.scanner_table, 1)
        self._init_scanner()
        return w

    def _build_ai_signals(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        # AegisScore + badge
        score_row = QHBoxLayout()
        self.aegis_score_lbl = _lbl("—", 48, True, CYAN)
        self.aegis_score_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_row.addWidget(self.aegis_score_lbl, 1)
        self.signal_badge = _lbl("HOLD", 28, True, AMBER)
        self.signal_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.signal_badge.setStyleSheet(
            f"color:{AMBER};font-size:28px;font-weight:bold;"
            f"background:#2A2A1A;border-radius:6px;padding:8px;"
        )
        score_row.addWidget(self.signal_badge, 1)
        lay.addLayout(score_row)

        lay.addWidget(_lbl("7-GATE ANALYSIS", 9, False, TEXT2))
        self.gate_table = _table(["Gate", "Status", "Weight", "Score%"], 22)
        for i, cw in enumerate([160, 50, 55, 70]):
            self.gate_table.setColumnWidth(i, cw)
        lay.addWidget(self.gate_table, 1)
        self._init_gate_table()

        # MTF / sentiment / ML row
        info_row = QHBoxLayout()
        self.mtf_lbl       = _lbl("MTF: —", 9)
        self.sent_val_lbl  = _lbl("Sentiment: —", 9)
        self.ml_conf_lbl   = _lbl("ML: —", 9)
        for lbl in [self.mtf_lbl, self.sent_val_lbl, self.ml_conf_lbl]:
            info_row.addWidget(lbl, 1)
        lay.addLayout(info_row)

        # ── Predictive Trade Signal (entry/SL/TP/reasoning/accuracy) ──
        lay.addWidget(_lbl("─" * 40, 8, False, BORDER))
        lay.addWidget(_lbl("🎯 PREDICTIVE TRADE SIGNAL", 9, True, TEXT2))

        levels_row = QHBoxLayout()
        self.ts_entry_lbl = _lbl("Entry: —", 10)
        self.ts_sl_lbl    = _lbl("SL: —", 10, False, RED)
        self.ts_tp_lbl    = _lbl("TP: —", 10, False, GREEN)
        self.ts_rr_lbl    = _lbl("R:R —", 10)
        for lbl in [self.ts_entry_lbl, self.ts_sl_lbl, self.ts_tp_lbl, self.ts_rr_lbl]:
            levels_row.addWidget(lbl, 1)
        lay.addLayout(levels_row)

        conf_row = QHBoxLayout()
        self.ts_confidence_lbl = _lbl("Confidence: —", 11, True, CYAN)
        self.ts_accuracy_lbl   = _lbl("Setup accuracy: —", 10, False, TEXT2)
        conf_row.addWidget(self.ts_confidence_lbl, 1)
        conf_row.addWidget(self.ts_accuracy_lbl, 1)
        lay.addLayout(conf_row)

        self.ts_reasoning_txt = QTextEdit()
        self.ts_reasoning_txt.setReadOnly(True)
        self.ts_reasoning_txt.setMaximumHeight(90)
        self.ts_reasoning_txt.setStyleSheet(
            f"QTextEdit{{background:{BG};border:1px solid {BORDER};"
            f"border-radius:4px;color:{TEXT};font-size:10px;}}"
        )
        self.ts_reasoning_txt.setPlainText("Waiting for a leading confirmation (orderflow/pattern)...")
        lay.addWidget(self.ts_reasoning_txt)

        return w

    def _build_news_feed(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        lay.addWidget(_lbl("📰 CRYPTO NEWS SENTIMENT FEED", 11, True, CYAN))
        self.news_list = QListWidget()
        self.news_list.setStyleSheet(
            f"QListWidget{{background:{BG};border:1px solid {BORDER};"
            f"border-radius:4px;color:{TEXT};}}"
            f"QListWidget::item{{padding:4px;border-bottom:"
            f"1px solid {BORDER};}}"
            f"QListWidget::item:selected{{background:#1A2A3A;}}"
        )
        lay.addWidget(self.news_list, 1)

        refresh_btn = _btn("🔄 Refresh News")
        refresh_btn.clicked.connect(self._refresh_news)
        lay.addWidget(refresh_btn)
        return w

    def _build_settings(self) -> QWidget:
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)

        lay.addWidget(_lbl("⚙️ SYSTEM SETTINGS", 13, True, CYAN))

        lay.addWidget(_lbl("RISK LIMITS", 10, True, TEXT2))
        self._settings_dd  = _lbl(f"Max Drawdown: {config.MAX_DRAWDOWN_PCT*100:.0f}%", 10)
        self._settings_dl  = _lbl(f"Daily Loss Limit: {config.MAX_DAILY_LOSS_PCT*100:.0f}%", 10)
        self._settings_mp  = _lbl(f"Max Positions: {config.MAX_CONCURRENT_POSITIONS}", 10)
        for lbl in [self._settings_dd, self._settings_dl, self._settings_mp]:
            lay.addWidget(lbl)

        lay.addWidget(_lbl("─" * 40, 8, False, BORDER))
        reset_btn = _btn("🔓 Reset Circuit Breaker", RED, BG)
        reset_btn.clicked.connect(self._reset_circuit_breaker)
        lay.addWidget(reset_btn)

        from tonybot.ui.settings_dialog import SettingsDialog
        open_settings_btn = _btn("🔧 Open API Settings")
        open_settings_btn.clicked.connect(
            lambda: SettingsDialog(self.user_id, self).exec()
        )
        lay.addWidget(open_settings_btn)

        mode_note = _lbl(
            "Paper mode: set LIVE_TRADING=false in .env\n"
            "Live mode:  set LIVE_TRADING=true in .env",
            9, False, TEXT2,
        )
        mode_note.setWordWrap(True)
        lay.addWidget(mode_note)

        tele_lbl = _lbl(
            "Telegram: set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env",
            9, False, TEXT2,
        )
        tele_lbl.setWordWrap(True)
        lay.addWidget(tele_lbl)

        lay.addStretch()
        return w

    def _build_exec_log(self) -> QWidget:
        tabs = QTabWidget()
        tabs.setMaximumHeight(180)
        tabs.setStyleSheet(
            f"QTabWidget::pane{{background:{PANEL};"
            f"border:1px solid {BORDER};border-radius:4px;}}"
            f"QTabBar::tab{{background:{PANEL};color:{TEXT2};"
            f"padding:4px 10px;border:none;}}"
            f"QTabBar::tab:selected{{color:{CYAN};"
            f"border-bottom:2px solid {CYAN};}}"
        )

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet(
            f"QTextEdit{{background:{BG};color:{TEXT2};"
            f"font-family:Consolas;font-size:9px;border:none;}}"
        )
        tabs.addTab(self.log_text, "📋 Log")

        self.open_pos_table = _table(
            ["Symbol", "Side", "Entry", "SL", "TP", "PnL"], 18
        )
        tabs.addTab(self.open_pos_table, "📂 Open Positions")

        self.trade_hist_table = _table(
            ["Symbol", "Side", "Entry", "Exit", "PnL $"], 18
        )
        tabs.addTab(self.trade_hist_table, "📊 Trade History")

        return tabs

    # ──────────────────────────────────────────────────────────────
    # INIT HELPERS
    # ──────────────────────────────────────────────────────────────
    def _init_scanner(self):
        # Was hardcoded to 8 symbols while the header label claimed "30
        # PAIRS" — a label that was simply wrong, and the real cause of the
        # empty space under the table (8 rows in a viewport sized for many
        # more). Uses config.SYMBOLS first (what the engine actually trades)
        # plus enough additional major pairs to make "30 PAIRS" true.
        configured = [s.replace("/", "") for s in config.SYMBOLS]
        extra = [
            "XRPUSDT", "ADAUSDT", "DOGEUSDT", "AVAXUSDT", "DOTUSDT", "LINKUSDT",
            "MATICUSDT", "LTCUSDT", "TRXUSDT", "ATOMUSDT", "UNIUSDT", "XLMUSDT",
            "ETCUSDT", "FILUSDT", "APTUSDT", "ARBUSDT", "OPUSDT", "NEARUSDT",
            "SUIUSDT", "INJUSDT", "TIAUSDT", "SEIUSDT", "RUNEUSDT", "FTMUSDT",
            "AAVEUSDT", "SANDUSDT",
        ]
        SYMBOLS = list(dict.fromkeys(configured + extra))[:30]
        for sym in SYMBOLS:
            row = self.scanner_table.rowCount()
            self.scanner_table.insertRow(row)
            self.scanner_table.setItem(row, 0, QTableWidgetItem(sym))
            for col in range(1, 6):
                self.scanner_table.setItem(row, col, QTableWidgetItem("—"))

    GATE_NAMES = [
        "trend_alignment", "rsi_filter", "macd_confirmation",
        "bollinger_position", "volume_confirmation",
        "sentiment_gate", "ai_ensemble_vote",
    ]
    GATE_WEIGHTS_DISPLAY = {
        "trend_alignment": 1.5, "rsi_filter": 1.0,
        "macd_confirmation": 1.2, "bollinger_position": 1.0,
        "volume_confirmation": 1.2, "sentiment_gate": 0.8,
        "ai_ensemble_vote": 1.5,
    }

    def _init_gate_table(self):
        for name in self.GATE_NAMES:
            row = self.gate_table.rowCount()
            self.gate_table.insertRow(row)
            self.gate_table.setItem(row, 0, QTableWidgetItem(name.replace("_", " ").title()))
            self.gate_table.setItem(row, 1, QTableWidgetItem("—"))
            w = self.GATE_WEIGHTS_DISPLAY.get(name, 1.0)
            self.gate_table.setItem(row, 2, QTableWidgetItem(f"{w:.1f}"))
            self.gate_table.setItem(row, 3, QTableWidgetItem("—"))

    # ──────────────────────────────────────────────────────────────
    # WEBSOCKET
    # ──────────────────────────────────────────────────────────────
    def _start_websocket(self):
        if not HAS_WEBSOCKET:
            self.log("⚠️ websocket-client not installed — no live prices")
            return
        t = threading.Thread(target=self._ws_loop, daemon=True)
        t.start()
        self.log("📡 WebSocket connecting to Binance…")

    def _ws_loop(self):
        symbols = ["btcusdt", "ethusdt", "solusdt", "bnbusdt",
                   "xrpusdt", "adausdt", "dogeusdt", "avaxusdt"]
        streams = "/".join(f"{s}@ticker" for s in symbols)
        url = f"wss://stream.binance.com:9443/stream?streams={streams}"

        def on_open(ws):
            QMetaObject.invokeMethod(
                self, "_set_connected", Qt.ConnectionType.QueuedConnection,
                Q_ARG(bool, True)
            )

        def on_message(ws, message):
            try:
                data  = json.loads(message).get("data", {})
                sym   = data.get("s", "")
                price = float(data.get("c", 0))
                chg   = float(data.get("P", 0))
                if sym and price:
                    QMetaObject.invokeMethod(
                        self, "on_price_update",
                        Qt.ConnectionType.QueuedConnection,
                        Q_ARG(str, sym), Q_ARG(float, price), Q_ARG(float, chg),
                    )
            except Exception:
                pass

        def on_error(ws, error):
            logger.warning("WS error: %s", error)

        def on_close(ws, *a):
            QMetaObject.invokeMethod(
                self, "_set_connected", Qt.ConnectionType.QueuedConnection,
                Q_ARG(bool, False)
            )
            time.sleep(5)
            self._ws_loop()

        ws = _websocket.WebSocketApp(
            url, on_open=on_open, on_message=on_message,
            on_error=on_error, on_close=on_close,
        )
        ws.run_forever()

    @Slot(bool)
    def _set_connected(self, connected: bool):
        if connected:
            self._conn_dot.setText("● CONNECTED")
            self._conn_dot.setStyleSheet(
                f"color:{GREEN};font-size:10px;background:transparent;"
            )
        else:
            self._conn_dot.setText("● DISCONNECTED")
            self._conn_dot.setStyleSheet(
                f"color:{RED};font-size:10px;background:transparent;"
            )

    # ──────────────────────────────────────────────────────────────
    # PRICE UPDATE (from WebSocket)
    # ──────────────────────────────────────────────────────────────
    @Slot(str, float, float)
    def on_price_update(self, symbol: str, price: float, change: float):
        self._current_prices[symbol] = price
        # resolve any pending predictive signals against this price tick
        try:
            resolved = self.signal_tracker.resolve_pending(symbol, high=price, low=price)
            for outcome_id, status in resolved:
                icon = "✅" if status == "WIN" else "❌"
                self.log(f"{icon} Signal outcome resolved: {symbol} → {status}")
        except Exception as exc:
            logger.warning("resolve_pending error: %s", exc)

        # update scanner row
        for row in range(self.scanner_table.rowCount()):
            item = self.scanner_table.item(row, 0)
            if item and item.text() == symbol:
                self.scanner_table.setItem(
                    row, 1, QTableWidgetItem(f"${price:,.4f}")
                )
                ci = QTableWidgetItem(f"{change:+.2f}%")
                ci.setForeground(QColor(GREEN if change >= 0 else RED))
                self.scanner_table.setItem(row, 2, ci)
                rsi = max(20.0, min(80.0, 50 + change * 1.5))
                self.scanner_table.setItem(row, 3, QTableWidgetItem(f"{rsi:.0f}"))
                break

        if symbol == self.current_symbol:
            self.price_lbl.setText(f"${price:,.4f}")
            c_color = GREEN if change >= 0 else RED
            self.change_lbl.setText(f"{change:+.2f}%")
            self.change_lbl.setStyleSheet(
                f"color:{c_color};font-size:12px;background:transparent;"
            )
            self.chart.update_live_candle(price)
            self._rsi_fallback_analyze(symbol, price, change)

        # check SL/TP
        self.trade_manager._close_positions(self._current_prices)
        self._update_portfolio_labels()

    def _rsi_fallback_analyze(self, symbol: str, price: float, change: float):
        """Simple RSI stub used before full candle data arrives."""
        if self._candles_by_tf.get(symbol, {}).get("1h"):
            return  # full pipeline active
        rsi = max(20.0, min(80.0, 50 + change * 1.5))
        if rsi < 35:
            direction, conf = "BUY", 60
        elif rsi > 65:
            direction, conf = "SELL", 60
        else:
            direction, conf = "HOLD", 40
        self._update_signal_badge(direction, conf)

    # ──────────────────────────────────────────────────────────────
    # CANDLE WORKER SLOT
    # ──────────────────────────────────────────────────────────────
    @Slot(str, str, list)
    def on_candles_ready(self, symbol: str, tf: str, candles: list):
        if symbol not in self._candles_by_tf:
            self._candles_by_tf[symbol] = {}
        self._candles_by_tf[symbol][tf] = candles

        # Chart previously only ever listened for tf == "1h" — the other
        # three timeframes CandleFetcher already pulls every cycle (1m/5m/4h)
        # were fetched and cached here but never actually shown; there was
        # no timeframe selector for the chart at all. Now it redraws
        # whenever new candles arrive for whichever timeframe is selected.
        selected_tf = getattr(self, "chart_tf_combo", None)
        selected_tf = selected_tf.currentText() if selected_tf else "1h"
        if symbol == self.current_symbol and tf == selected_tf:
            self.chart.load_candles(candles)
            self._compute_atr(candles)

        # trigger full signal eval once we have 1h+4h at minimum
        tf_data = self._candles_by_tf.get(symbol, {})
        if "1h" in tf_data and "4h" in tf_data:
            self._trigger_signal_eval(symbol)

    def _on_chart_timeframe_changed(self, tf: str):
        """User picked a different chart timeframe — redraw immediately from
        whatever's already cached for the current symbol (no re-fetch needed,
        CandleFetcher already pulls all configured timeframes continuously),
        and fall back to a placeholder until the next fetch cycle fills it in
        if this timeframe hasn't arrived yet."""
        cached = self._candles_by_tf.get(self.current_symbol, {}).get(tf)
        if cached:
            self.chart.load_candles(cached)
        else:
            self.chart.set_loading(tf)

    def _compute_atr(self, candles: list):
        if len(candles) < 15:
            return
        trs = []
        for i in range(1, min(15, len(candles))):
            hi, lo, prev_cl = candles[i][2], candles[i][3], candles[i-1][4]
            tr = max(hi - lo, abs(hi - prev_cl), abs(lo - prev_cl))
            trs.append(tr)
        self._latest_atr = sum(trs) / len(trs) if trs else 0.0

    def _trigger_signal_eval(self, symbol: str):
        tf_data = dict(self._candles_by_tf.get(symbol, {}))
        worker = SignalRefinerWorker(
            self.signal_refiner, symbol, tf_data, self._latest_atr
        )
        worker.aegis_result.connect(self.on_aegis_result)
        worker.start()
        self._sr_worker = worker  # keep reference

        ts_worker = TradeSignalWorker(
            self.predictive_engine, symbol, tf_data, self._latest_atr
        )
        ts_worker.trade_signal_result.connect(self.on_trade_signal_result)
        ts_worker.start()
        self._ts_worker = ts_worker  # keep reference

    # ──────────────────────────────────────────────────────────────
    # SENTIMENT WORKER SLOT
    # ──────────────────────────────────────────────────────────────
    @Slot(dict)
    def on_sentiment_ready(self, result: dict):
        self._latest_sentiment = result
        composite = float(result.get("composite", 0.0))
        # map -N..+N → 0..100 (typical range -2 to +2)
        bar_val = int(max(0, min(100, (composite + 3) / 6 * 100)))
        self.sentiment_bar.setValue(bar_val)
        if composite > 0.1:
            color, desc = GREEN, "Greed" if composite > 0.5 else "Bullish"
        elif composite < -0.1:
            color, desc = RED, "Fear" if composite < -0.5 else "Bearish"
        else:
            color, desc = AMBER, "Neutral"
        self.sentiment_desc_lbl.setText(desc)
        self.sentiment_desc_lbl.setStyleSheet(
            f"color:{color};font-size:9px;font-weight:bold;background:transparent;"
        )
        self.sentiment_bar.setStyleSheet(
            f"QProgressBar{{background:{BORDER};border:none;border-radius:9px;"
            f"color:{TEXT};font-size:9px;font-weight:bold;font-family:Consolas;}}"
            f"QProgressBar::chunk{{background:{color};border-radius:9px;}}"
        )
        fg_idx = result.get("fear_greed_index", 50)
        self.log(
            f"📰 Sentiment: composite={composite:+.3f} | "
            f"FG={fg_idx} | headlines={result.get('headline_count',0)}"
        )
        if self._stack.currentIndex() == 2:
            self._refresh_news()

    # ──────────────────────────────────────────────────────────────
    # AEGIS RESULT SLOT
    # ──────────────────────────────────────────────────────────────
    @Slot(dict)
    def on_aegis_result(self, result: dict):
        self._latest_aegis = result
        direction   = result.get("direction", "HOLD")
        aegis_score = float(result.get("aegis_score", 0.0))
        gates       = result.get("gates", {})
        mtf_bias    = result.get("mtf_bias", "HOLD")
        sent_score  = float(result.get("sentiment_score", 0.0))
        ml_conf     = float(result.get("ml_confidence", 0.5))

        # update AI signals view
        self.aegis_score_lbl.setText(f"{aegis_score:.0f}")
        color_map = {"BUY": GREEN, "SELL": RED, "HOLD": AMBER}
        bg_map    = {"BUY": "#0A1E14", "SELL": "#1E0A14", "HOLD": "#2A2A1A"}
        d_color   = color_map.get(direction, AMBER)
        d_bg      = bg_map.get(direction, "#2A2A1A")
        self.signal_badge.setText(direction)
        self.signal_badge.setStyleSheet(
            f"color:{d_color};font-size:28px;font-weight:bold;"
            f"background:{d_bg};border-radius:6px;padding:8px;"
        )
        self.aegis_score_lbl.setStyleSheet(
            f"color:{d_color};font-size:48px;font-weight:bold;"
            f"background:transparent;"
        )

        # sidebar "last signal" teaser (see _build_right_panel)
        self.last_signal_lbl.setText(f"{self.current_symbol} → {direction}")
        self.last_signal_lbl.setStyleSheet(
            f"color:{d_color};font-size:12px;font-weight:bold;background:transparent;"
        )
        self.last_signal_meta_lbl.setText(
            f"Score {aegis_score:.0f}/100 · {datetime.now().strftime('%H:%M:%S')}"
        )

        # gate table
        for row, name in enumerate(self.GATE_NAMES):
            if row >= self.gate_table.rowCount():
                break
            g = gates.get(name, {})
            passed = g.get("passed", False)
            contrib = g.get("contribution", 0.0)
            weight  = g.get("weight", 0.0)
            status_item = QTableWidgetItem("✅" if passed else "❌")
            status_item.setForeground(QColor(GREEN if passed else RED))
            self.gate_table.setItem(row, 1, status_item)
            self.gate_table.setItem(row, 3, QTableWidgetItem(
                f"{contrib/8.2*100:.0f}%" if weight > 0 else "—"
            ))

        self.mtf_lbl.setText(f"MTF: {mtf_bias}")
        self.sent_val_lbl.setText(f"Sentiment: {sent_score:+.3f}")
        self.ml_conf_lbl.setText(f"ML Conf: {ml_conf:.0%}")

        # AI confidence gauge — one clean number instead of the previous
        # three separate LOW/MID/HIGH bars (which encoded a single value
        # three redundant, confusing ways with no visible number on any of them)
        conf_pct = int(ml_conf * 100)
        self.ai_confidence_bar.setValue(conf_pct)
        conf_color = RED if conf_pct < 40 else (AMBER if conf_pct < 65 else GREEN)
        self.ai_confidence_bar.setStyleSheet(
            f"QProgressBar{{background:{BORDER};border:none;border-radius:9px;"
            f"color:{TEXT};font-size:9px;font-weight:bold;font-family:Consolas;}}"
            f"QProgressBar::chunk{{background:{conf_color};border-radius:9px;}}"
        )

        # update scanner AegisScore for symbol
        sym = self.current_symbol
        for row in range(self.scanner_table.rowCount()):
            item = self.scanner_table.item(row, 0)
            if item and item.text() == sym:
                self.scanner_table.setItem(
                    row, 4, QTableWidgetItem(f"{aegis_score:.0f}")
                )
                sig_item = QTableWidgetItem(direction)
                sig_item.setForeground(QColor(color_map.get(direction, AMBER)))
                self.scanner_table.setItem(row, 5, sig_item)
                # row background
                bg_color = (QColor("#0A1E14") if direction == "BUY"
                           else QColor("#1E0A14") if direction == "SELL"
                           else QColor("#1A1A0A"))
                for col in range(self.scanner_table.columnCount()):
                    ci = self.scanner_table.item(row, col)
                    if ci:
                        ci.setBackground(bg_color)
                break

        # record signal in DB
        if direction != "HOLD":
            try:
                price = self._current_prices.get(sym, 0.0)
                self.db.record_signal(
                    sym, direction,
                    gate_score=aegis_score / 100,
                    gates_passed=sum(1 for g in gates.values() if g.get("passed")),
                    aegis_score=aegis_score,
                    price=price,
                    ai_confidence=ml_conf,
                    sentiment_score=sent_score,
                    mtf_alignment=1.0 if mtf_bias == direction else 0.0,
                )
            except Exception as exc:
                logger.warning("record_signal error: %s", exc)

        # auto-trade
        if self.auto_btn.isChecked() and not self.kill_switch_active:
            if direction in ("BUY", "SELL"):
                price = self._current_prices.get(sym, 0.0)
                if price > 0:
                    ok, msg = self.trade_manager.execute_trade(
                        sym, direction, price,
                        ml_conf * 100, self._latest_atr
                    )
                    if ok:
                        self._update_portfolio_labels()

    # ──────────────────────────────────────────────────────────────
    # PREDICTIVE TRADE SIGNAL SLOT
    # ──────────────────────────────────────────────────────────────
    @Slot(dict)
    def on_trade_signal_result(self, result: dict):
        self._latest_trade_signal = result
        signal = result.get("signal")

        if signal is None:
            self.ts_entry_lbl.setText("Entry: —")
            self.ts_sl_lbl.setText("SL: —")
            self.ts_tp_lbl.setText("TP: —")
            self.ts_rr_lbl.setText("R:R —")
            self.ts_confidence_lbl.setText("Confidence: —")
            self.ts_accuracy_lbl.setText("Setup accuracy: —")
            self.ts_reasoning_txt.setPlainText(
                result.get("reason_blocked") or "No leading confirmation yet — waiting to avoid a lagging entry."
            )
            return

        self.ts_entry_lbl.setText(f"Entry: ${signal['entry']:,.4f}")
        self.ts_sl_lbl.setText(f"SL: ${signal['stop_loss']:,.4f}")
        self.ts_tp_lbl.setText(f"TP: ${signal['take_profit']:,.4f}")
        self.ts_rr_lbl.setText(f"R:R {signal['risk_reward']:.2f}")

        conf = signal["confidence_pct"]
        conf_color = GREEN if conf >= 65 else (AMBER if conf >= 50 else RED)
        self.ts_confidence_lbl.setText(f"Confidence: {conf:.0f}%")
        self.ts_confidence_lbl.setStyleSheet(f"color:{conf_color};font-size:11px;font-weight:bold;")

        live_wr = signal.get("live_win_rate")
        live_n  = signal.get("live_sample_size", 0)
        hist_wr = signal.get("historical_win_rate")
        if live_wr is not None and live_n > 0:
            self.ts_accuracy_lbl.setText(f"Setup accuracy: {live_wr:.0%} live ({live_n} trades)")
        elif hist_wr is not None:
            self.ts_accuracy_lbl.setText(f"Setup accuracy: ~{hist_wr:.0%} (backtest prior, no live trades yet)")
        else:
            self.ts_accuracy_lbl.setText("Setup accuracy: —")

        reasoning_lines = signal.get("reasoning", [])
        confirmations = signal.get("leading_confirmations", [])
        header = f"[{signal['setup_type']}] leading confirmation: {', '.join(confirmations) or 'none'}\n"
        self.ts_reasoning_txt.setPlainText(header + "\n".join(f"• {r}" for r in reasoning_lines))

        # log the fired signal for live accuracy tracking
        try:
            from tonybot.strategy.trade_signal import TradeSignal
            from datetime import datetime as _dt
            ts_obj = TradeSignal(
                symbol=signal["symbol"], direction=signal["direction"], setup_type=signal["setup_type"],
                entry=signal["entry"], stop_loss=signal["stop_loss"], take_profit=signal["take_profit"],
                risk_reward=signal["risk_reward"], confidence_pct=signal["confidence_pct"],
                aegis_score=signal["aegis_score"], leading_confirmations=confirmations,
                reasoning=reasoning_lines, historical_win_rate=hist_wr, live_win_rate=live_wr,
                live_sample_size=live_n,
            )
            self.signal_tracker.log_signal(ts_obj)
            self.log(
                f"🎯 PREDICTIVE {signal['direction']} {signal['symbol']} | "
                f"Entry ${signal['entry']:,.4f} SL ${signal['stop_loss']:,.4f} TP ${signal['take_profit']:,.4f} "
                f"| Conf {conf:.0f}% | {signal['setup_type']}"
            )
        except Exception as exc:
            logger.warning("log_signal error: %s", exc)

    def _update_signal_badge(self, direction: str, confidence: int):
        c_map = {"BUY": GREEN, "SELL": RED, "HOLD": AMBER}
        b_map = {"BUY": "#0A1E14", "SELL": "#1E0A14", "HOLD": "#2A2A1A"}
        self.signal_badge.setText(direction)
        self.signal_badge.setStyleSheet(
            f"color:{c_map.get(direction, AMBER)};"
            f"font-size:28px;font-weight:bold;"
            f"background:{b_map.get(direction, '#2A2A1A')};"
            f"border-radius:6px;padding:8px;"
        )

    # ──────────────────────────────────────────────────────────────
    # ORDER BOOK
    # ──────────────────────────────────────────────────────────────
    @Slot(str, dict)
    def _on_orderbook(self, symbol: str, book: dict):
        pass  # could be wired to an order book widget if needed

    # ──────────────────────────────────────────────────────────────
    # PORTFOLIO LABELS
    # ──────────────────────────────────────────────────────────────
    def _update_portfolio_labels(self):
        stats   = self.trade_manager.get_stats()
        balance = stats["balance"]
        pnl     = stats["daily_pnl"]
        n_open  = stats["open_positions"]

        self.equity_lbl.setText(f"${balance:,.0f}")
        pnl_color = GREEN if pnl >= 0 else RED
        self.pnl_lbl.setText(f"Daily PnL  ${pnl:+.2f}")
        self.pnl_lbl.setStyleSheet(
            f"color:{pnl_color};font-size:10px;background:transparent;"
        )
        self.op_val.setText(str(n_open))
        self.available_lbl.setText(f"Available  ${balance:,.0f}")

        used_pct = int((1 - balance / config.INITIAL_BALANCE) * 100)
        used_pct = max(0, min(100, used_pct))
        self.capital_bar.setValue(used_pct)
        self.capital_pct_lbl.setText(f"{used_pct}%")

        # DB stats
        try:
            db_stats = self.db.get_performance_stats()
            wr   = db_stats.get("win_rate", 0)
            wins = db_stats.get("wins", 0)
            tots = db_stats.get("total_trades", 0)
            gross_p = max(db_stats.get("best_trade", 0) * wins, 0.01)
            gross_l = abs(min(db_stats.get("worst_trade", -0.01) * (tots - wins), -0.01))
            pf  = gross_p / gross_l
            self.wr_val.setText(f"{wr:.0%}")
            self.pf_val.setText(f"{pf:.2f}")
        except Exception:
            pass

        # circuit breaker
        if self.risk_manager.circuit_breaker.tripped:
            self._cb_banner.show()
        else:
            self._cb_banner.hide()

        # drawdown
        dd = self.risk_manager.update_drawdown(balance)
        self.dd_val.setText(f"{dd:.2%}")

        # open positions table
        self.open_pos_table.setRowCount(0)
        for pos in stats["open_list"]:
            r = self.open_pos_table.rowCount()
            self.open_pos_table.insertRow(r)
            cur = self._current_prices.get(pos["symbol"], pos["entry"])
            if pos["action"] == "BUY":
                live_pnl = (cur - pos["entry"]) * pos["quantity"]
            else:
                live_pnl = (pos["entry"] - cur) * pos["quantity"]
            items = [
                pos["symbol"], pos["action"],
                f"${pos['entry']:,.4f}", f"${pos['sl']:,.4f}",
                f"${pos['tp']:,.4f}", f"${live_pnl:+.2f}",
            ]
            for ci, val in enumerate(items):
                item = QTableWidgetItem(val)
                if ci == 1:
                    item.setForeground(QColor(GREEN if val == "BUY" else RED))
                if ci == 5:
                    item.setForeground(QColor(GREEN if live_pnl >= 0 else RED))
                self.open_pos_table.setItem(r, ci, item)

        # trade history table
        self.trade_hist_table.setRowCount(0)
        for t in reversed(stats["trades"]):
            r = self.trade_hist_table.rowCount()
            self.trade_hist_table.insertRow(r)
            ep = t.get("exit_price", 0)
            pnl_v = t.get("pnl", 0)
            row_items = [
                t["symbol"], t["action"],
                f"${t['entry']:,.4f}",
                f"${ep:,.4f}" if ep else "—",
                f"${pnl_v:+.2f}" if pnl_v else "—",
            ]
            for ci, val in enumerate(row_items):
                item = QTableWidgetItem(val)
                if ci == 1:
                    item.setForeground(QColor(GREEN if val == "BUY" else RED))
                if ci == 4 and pnl_v:
                    item.setForeground(QColor(GREEN if pnl_v >= 0 else RED))
                self.trade_hist_table.setItem(r, ci, item)

    # ──────────────────────────────────────────────────────────────
    # UI EVENT HANDLERS
    # ──────────────────────────────────────────────────────────────
    def switch_view(self, index: int):
        self._stack.setCurrentIndex(index)
        for i, b in enumerate(self._nav_btns):
            b.setChecked(i == index)

    def switch_asset(self, symbol: str):
        self.current_symbol = symbol
        self.sym_input.setText(symbol)
        for s, b in self._asset_btns.items():
            b.setChecked(f"{s}USDT" == symbol)
        self._ob_fetcher.set_symbol(symbol)
        self._candle_fetcher.set_symbol(symbol)
        # Show whatever's already cached for this symbol+timeframe immediately
        # instead of a blank chart until the next fetch cycle comes in.
        self._on_chart_timeframe_changed(self.chart_tf_combo.currentText())
        self.log(f"🔄 Switched to {symbol}")

    def _on_kill_switch(self, checked: bool):
        self.kill_switch_active = True if checked else False
        self.trade_manager.kill_switch_active = self.kill_switch_active
        state = "ACTIVE" if checked else "DISARMED"
        self.log(f"⚡ Kill Switch {state}")
        if not checked:
            self._cb_banner.hide()

    def _on_mode_changed(self, mode: str):
        color = RED if mode == "LIVE" else AMBER
        self._mode_lbl.setText(
            f"{'🔴 LIVE MODE' if mode == 'LIVE' else '📄 PAPER MODE'}"
        )
        self._mode_lbl.setStyleSheet(
            f"color:{color};font-size:10px;font-weight:bold;"
            f"background:transparent;"
        )
        self.log(f"⚙️ Mode changed to {mode}")

    def _on_auto_toggled(self, checked: bool):
        self.auto_btn.setText("🤖 AUTO ON" if checked else "🤖 AUTO OFF")
        self.log("🤖 Auto-trade " + ("ENABLED" if checked else "DISABLED"))

    def _manual_trade(self, action: str):
        sym   = self.sym_input.text().strip().upper() or self.current_symbol
        price = self._current_prices.get(sym, 0.0)
        if price <= 0:
            self.log(f"⚠️ No price available for {sym}")
            return
        ok, msg = self.trade_manager.execute_trade(
            sym, action, price, 100.0, self._latest_atr
        )
        if ok:
            self._update_portfolio_labels()
        else:
            self.log(f"⚠️ {action} {sym} rejected: {msg}")

    def _reset_circuit_breaker(self):
        self.risk_manager.circuit_breaker.reset()
        self._cb_banner.hide()
        self.log("🔓 Circuit breaker reset")

    def _tick_clock(self):
        self._utc_clock.setText(
            datetime.utcnow().strftime("%H:%M:%S UTC")
        )

    def _refresh_news(self):
        def _fetch():
            try:
                from tonybot.data.news_sentiment import NewsSentiment
                headlines = NewsSentiment().get_headlines()
                # emit back to main thread via a simple list
                QMetaObject.invokeMethod(
                    self, "_populate_news",
                    Qt.ConnectionType.QueuedConnection,
                    Q_ARG(object, headlines),
                )
            except Exception as exc:
                logger.warning("News fetch error: %s", exc)

        threading.Thread(target=_fetch, daemon=True).start()

    @Slot(object)
    def _populate_news(self, headlines: list):
        self.news_list.clear()
        if not headlines:
            self.news_list.addItem("No headlines available — check API keys")
            return
        for h in headlines:
            text    = h.get("headline", "")
            source  = h.get("source", "")
            sent    = float(h.get("sentiment", 0.0))
            ts      = h.get("timestamp", "")
            color   = GREEN if sent > 0 else (RED if sent < 0 else TEXT2)
            label   = f"{sent:+.2f} │ [{source}] {text[:100]}  ({ts[:16]})"
            item    = QListWidgetItem(label)
            item.setForeground(QColor(color))
            self.news_list.addItem(item)

    def log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"<span style='color:{TEXT2}'>[{ts}]</span> {msg}")
        self.log_text.verticalScrollBar().setValue(
            self.log_text.verticalScrollBar().maximum()
        )


# ═══════════════════════════════════════════════════════════════════
# STANDALONE ENTRY
# ═══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(theme_manager.get_stylesheet())
    app.setFont(QFont("Consolas", 9))
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
