"""
tonybot/ui/settings_dialog.py — Settings with API Integration
"""
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from tonybot.core.db import Database
import requests

class SettingsDialog(QDialog):
    def __init__(self, user_id: int, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.db = Database()
        self.setWindowTitle("TONYBOT - Settings")
        self.setFixedSize(500, 450)
        self.setStyleSheet("""
            QDialog { background: #0A0E1A; }
            QLabel { color: #E8EAF0; }
            QLineEdit, QComboBox { 
                background: #141C35; 
                border: 1px solid #2A3D60; 
                border-radius: 6px; 
                padding: 8px; 
                color: #E8EAF0;
            }
            QLineEdit:focus { border-color: #00D4FF; }
            QPushButton {
                background: #141C35;
                border: 1px solid #2A3D60;
                border-radius: 6px;
                padding: 10px;
                color: #E8EAF0;
                font-weight: bold;
            }
            QPushButton:hover { background: #1E2D4A; }
            QPushButton#save_btn { background: #00D4FF; color: #0A0E1A; }
            QPushButton#save_btn:hover { background: #00B8E6; }
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        title = QLabel("⚙️ Settings")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #00D4FF;")
        layout.addWidget(title)
        
        # API Section
        api_group = QGroupBox("AI API Configuration (OpenRouter)")
        api_group.setStyleSheet("QGroupBox { color: #7A8BA8; border: 1px solid #1E2D4A; border-radius: 6px; margin-top: 10px; padding-top: 10px; }")
        api_layout = QVBoxLayout(api_group)
        
        provider_layout = QHBoxLayout()
        provider_layout.addWidget(QLabel("Provider:"))
        self.provider_combo = QComboBox()
        self.provider_combo.addItems(['openrouter', 'openai', 'anthropic', 'deepseek'])
        provider_layout.addWidget(self.provider_combo)
        api_layout.addLayout(provider_layout)
        
        key_layout = QHBoxLayout()
        key_layout.addWidget(QLabel("API Key:"))
        self.api_key_input = QLineEdit()
        self.api_key_input.setPlaceholderText("Enter your API key")
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        key_layout.addWidget(self.api_key_input)
        api_layout.addLayout(key_layout)
        
        url_layout = QHBoxLayout()
        url_layout.addWidget(QLabel("API URL:"))
        self.api_url_input = QLineEdit()
        self.api_url_input.setPlaceholderText("https://openrouter.ai/api/v1/chat/completions")
        url_layout.addWidget(self.api_url_input)
        api_layout.addLayout(url_layout)
        
        model_layout = QHBoxLayout()
        model_layout.addWidget(QLabel("Model:"))
        self.model_combo = QComboBox()
        self.model_combo.addItems([
            'deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B',
            'deepseek-ai/DeepSeek-R1-Distill-Qwen-7B',
            'google/gemini-2.0-flash-exp:free',
            'mistralai/mistral-7b-instruct:free',
            'meta-llama/llama-3.2-3b-instruct:free'
        ])
        self.model_combo.setEditable(True)
        model_layout.addWidget(self.model_combo)
        api_layout.addLayout(model_layout)
        
        layout.addWidget(api_group)
        
        # Load saved config
        config = self.db.get_api_config(user_id)
        if config:
            self.api_key_input.setText(config.get('api_key', ''))
            self.api_url_input.setText(config.get('api_url', ''))
            self.model_combo.setCurrentText(config.get('model', ''))
            self.provider_combo.setCurrentText(config.get('provider', 'openrouter'))
        
        self.test_btn = QPushButton("🔌 Test Connection")
        self.test_btn.clicked.connect(self.test_connection)
        layout.addWidget(self.test_btn)
        
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #7A8BA8; font-size: 10px;")
        layout.addWidget(self.status_label)
        
        self.save_btn = QPushButton("💾 Save Settings")
        self.save_btn.setObjectName("save_btn")
        self.save_btn.clicked.connect(self.save_settings)
        layout.addWidget(self.save_btn)
        
        # Telegram Section
        tele_group = QGroupBox("Telegram Bot (from .env)")
        tele_group.setStyleSheet("QGroupBox { color: #7A8BA8; border: 1px solid #1E2D4A; border-radius: 6px; margin-top: 10px; }")
        tele_layout = QVBoxLayout(tele_group)
        
        tele_status = QLabel("ℹ️ Configure TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env file")
        tele_status.setWordWrap(True)
        tele_status.setStyleSheet("color: #7A8BA8; font-size: 10px;")
        tele_layout.addWidget(tele_status)
        
        layout.addWidget(tele_group)
    
    def test_connection(self):
        api_key = self.api_key_input.text().strip()
        api_url = self.api_url_input.text().strip() or "https://openrouter.ai/api/v1/chat/completions"
        model = self.model_combo.currentText()
        
        if not api_key:
            self.status_label.setText("⚠️ Please enter your API key")
            return
        
        self.status_label.setText("🔍 Testing connection...")
        QApplication.processEvents()
        
        try:
            headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
            data = {"model": model, "messages": [{"role": "user", "content": "Say OK"}], "max_tokens": 10}
            resp = requests.post(api_url, headers=headers, json=data, timeout=10)
            if resp.status_code == 200:
                self.status_label.setText("✅ Connection successful! API is working.")
            else:
                self.status_label.setText(f"❌ API Error: {resp.status_code}")
        except Exception as e:
            self.status_label.setText(f"❌ Connection failed: {str(e)[:60]}")
    
    def save_settings(self):
        api_key = self.api_key_input.text().strip()
        api_url = self.api_url_input.text().strip()
        model = self.model_combo.currentText()
        provider = self.provider_combo.currentText()
        
        if not api_key:
            self.status_label.setText("⚠️ API Key is required")
            return
        
        if not api_url:
            api_url = "https://openrouter.ai/api/v1/chat/completions"
        
        success = self.db.save_api_config(self.user_id, provider, api_key, api_url, model)
        if success:
            self.status_label.setText("✅ Settings saved successfully!")
            self.accept()
        else:
            self.status_label.setText("❌ Failed to save settings")
