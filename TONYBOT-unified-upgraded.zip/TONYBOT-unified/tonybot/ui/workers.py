"""
tonybot/ui/workers.py — Background QThread Workers

CandleFetcher:  Fetches OHLC candles from Binance REST for multiple timeframes.
                Emits candles_ready(symbol, timeframe, candles_list) every 30s.

SentimentWorker: Fetches news sentiment via NewsSentiment.get_composite_score().
                 Emits sentiment_ready(dict) every 300s (5 min).

Both workers use Qt signals for thread-safe UI updates — no direct widget access.
"""
from __future__ import annotations

import logging
import time
from typing import List

import requests
from PySide6.QtCore import QThread, Signal

logger = logging.getLogger("tonybot.workers")

# ---------------------------------------------------------------------------
# CandleFetcher
# ---------------------------------------------------------------------------
TIMEFRAMES = ["1m", "5m", "1h", "4h"]
BINANCE_REST = "https://api.binance.com/api/v3/klines"
CANDLE_LIMIT = 100
FETCH_INTERVAL = 30  # seconds between full refreshes


class CandleFetcher(QThread):
    """
    Fetches Binance kline (candle) data for a symbol across multiple timeframes.
    Runs continuously in background; emits candles_ready for each TF on each cycle.
    """

    candles_ready = Signal(str, str, list)  # (symbol, timeframe, candles)

    def __init__(self, symbol: str = "BTCUSDT", timeframes: List[str] = None):
        super().__init__()
        self._symbol = symbol
        self._timeframes = timeframes or TIMEFRAMES
        self._running = True
        self.daemon = True

    def set_symbol(self, symbol: str) -> None:
        """Thread-safe symbol update (takes effect on next fetch cycle)."""
        self._symbol = symbol

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        """Main worker loop — fetch all TFs, emit results, sleep, repeat."""
        while self._running:
            symbol = self._symbol  # snapshot to avoid mid-loop race
            for tf in self._timeframes:
                if not self._running:
                    break
                candles = self._fetch_candles(symbol, tf)
                if candles:
                    self.candles_ready.emit(symbol, tf, candles)
            # Sleep in small chunks so stop() is responsive
            for _ in range(FETCH_INTERVAL * 2):
                if not self._running:
                    break
                time.sleep(0.5)

    def _fetch_candles(self, symbol: str, interval: str) -> list:
        """Fetch klines from Binance REST. Returns list of [ts,o,h,l,c,v] or []."""
        clean = symbol.replace("/", "")
        try:
            resp = requests.get(
                BINANCE_REST,
                params={"symbol": clean, "interval": interval, "limit": CANDLE_LIMIT},
                timeout=8,
            )
            resp.raise_for_status()
            data = resp.json()
            # Each kline: [openTime, open, high, low, close, volume, ...]
            return [[int(c[0]), float(c[1]), float(c[2]), float(c[3]), float(c[4]), float(c[5])]
                    for c in data]
        except Exception as exc:
            logger.warning("CandleFetcher %s/%s failed: %s", symbol, interval, exc)
            return []


# ---------------------------------------------------------------------------
# OrderBookFetcher — lightweight depth snapshot for leading orderflow signals
# ---------------------------------------------------------------------------
BINANCE_DEPTH = "https://api.binance.com/api/v3/depth"


def fetch_order_book_rest(symbol: str, limit: int = 20) -> dict:
    """Fetch current order-book depth from Binance REST (no ccxt dependency,
    consistent with CandleFetcher's approach). Returns an empty book on any
    failure so callers can fall back gracefully."""
    clean = symbol.replace("/", "")
    try:
        resp = requests.get(BINANCE_DEPTH, params={"symbol": clean, "limit": limit}, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        bids = [[float(p), float(q)] for p, q in data.get("bids", [])]
        asks = [[float(p), float(q)] for p, q in data.get("asks", [])]
        return {"bids": bids, "asks": asks}
    except Exception as exc:
        logger.warning("OrderBook fetch %s failed: %s", symbol, exc)
        return {"bids": [], "asks": []}


# ---------------------------------------------------------------------------
# SentimentWorker
# ---------------------------------------------------------------------------
SENTIMENT_INTERVAL = 300  # seconds (5 minutes)


class SentimentWorker(QThread):
    """
    Fetches multi-source news sentiment every 5 minutes.
    Emits sentiment_ready(dict) with the full composite result.
    """

    sentiment_ready = Signal(dict)  # full composite result dict

    def __init__(self):
        super().__init__()
        self._running = True
        self.daemon = True

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        """Main worker loop — fetch sentiment, emit, sleep 5 min, repeat."""
        while self._running:
            result = self._fetch_sentiment()
            self.sentiment_ready.emit(result)
            # Sleep in small chunks so stop() is responsive
            for _ in range(SENTIMENT_INTERVAL * 2):
                if not self._running:
                    break
                time.sleep(0.5)

    def _fetch_sentiment(self) -> dict:
        """Call NewsSentiment.get_composite_score() safely."""
        try:
            from tonybot.data.news_sentiment import NewsSentiment
            ns = NewsSentiment()
            return ns.get_composite_score()
        except Exception as exc:
            logger.warning("SentimentWorker fetch failed: %s", exc)
            return {
                "composite": 0.0,
                "fear_greed_index": 50,
                "headline_count": 0,
                "sources": {},
            }
