"""
tonybot/ui/analytics_tab.py — Analytics Tab: Patterns / Monte Carlo / Correlation

New tab combining three tools ported from nexus-portfolio (pattern scanner,
Monte Carlo simulator, correlation matrix) that TONYBOT didn't have. Reuses
TONYBOT's own CCXTDataSource for OHLCV instead of nexus's client-side
tick accumulation, so results are available immediately rather than only
after minutes of the dashboard being open.
"""
from __future__ import annotations

import threading
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QComboBox, QSpinBox, QDoubleSpinBox, QTableWidget, QTableWidgetItem,
    QTextEdit, QSplitter,
)

from tonybot.config import config
from tonybot.data.ccxt_source import CCXTDataSource
from tonybot.strategy.pattern_scanner import detect_patterns
from tonybot.risk.monte_carlo import run_monte_carlo, pooled_returns_from_positions
from tonybot.strategy.correlation import compute_correlation_matrix

CYAN = "#00D4FF"
GREEN = "#00FF88"
RED = "#FF3B5C"
AMBER = "#F0B90B"
BG = "#0F1628"
BORDER = "#1E2D4A"
TEXT2 = "#7A8BA8"


class AnalyticsTab(QWidget):
    """
    Drop into main_window via:
        from tonybot.ui.analytics_tab import AnalyticsTab
        tabs.addTab(AnalyticsTab(data_source=self.engine.data_source), "📈 Analytics")
    """

    def __init__(self, parent=None, data_source: CCXTDataSource | None = None):
        super().__init__(parent)
        self.data_source = data_source or CCXTDataSource(exchange_id=config.EXCHANGE_ID)
        self.symbols = list(config.SYMBOLS) or ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT"]
        self._setup_ui()

    # ------------------------------------------------------------ UI ----
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 6, 6, 6)

        header = QLabel("📈 ANALYTICS — PATTERNS · MONTE CARLO · CORRELATION")
        header.setStyleSheet(f"font-size:16px; font-weight:bold; color:{CYAN}; padding:4px;")
        layout.addWidget(header)

        splitter = QSplitter(Qt.Orientation.Vertical)

        splitter.addWidget(self._build_pattern_panel())
        splitter.addWidget(self._build_montecarlo_panel())
        splitter.addWidget(self._build_correlation_panel())
        splitter.setSizes([260, 260, 260])

        layout.addWidget(splitter)

    def _build_pattern_panel(self) -> QWidget:
        panel = QFrame()
        panel.setStyleSheet(f"background:{BG}; border:1px solid {BORDER}; border-radius:6px;")
        lay = QVBoxLayout(panel)

        row = QHBoxLayout()
        row.addWidget(QLabel("🔍 PATTERN SCANNER"))
        scan_btn = QPushButton("Scan All Symbols")
        scan_btn.clicked.connect(self.run_pattern_scan)
        row.addWidget(scan_btn)
        row.addStretch()
        lay.addLayout(row)

        self.pattern_table = QTableWidget(0, 4)
        self.pattern_table.setHorizontalHeaderLabels(["Symbol", "Pattern", "Description", "Confidence"])
        self.pattern_table.setStyleSheet("font-size:9px; font-family:monospace;")
        lay.addWidget(self.pattern_table)
        return panel

    def _build_montecarlo_panel(self) -> QWidget:
        panel = QFrame()
        panel.setStyleSheet(f"background:{BG}; border:1px solid {BORDER}; border-radius:6px;")
        lay = QVBoxLayout(panel)

        row = QHBoxLayout()
        row.addWidget(QLabel("🎲 MONTE CARLO SIMULATOR"))
        row.addWidget(QLabel("Symbol:"))
        self.mc_symbol = QComboBox()
        self.mc_symbol.addItems(self.symbols)
        row.addWidget(self.mc_symbol)
        row.addWidget(QLabel("Years:"))
        self.mc_years = QDoubleSpinBox()
        self.mc_years.setRange(0.1, 10)
        self.mc_years.setValue(1.0)
        row.addWidget(self.mc_years)
        row.addWidget(QLabel("Sims:"))
        self.mc_sims = QSpinBox()
        self.mc_sims.setRange(100, 5000)
        self.mc_sims.setValue(500)
        self.mc_sims.setSingleStep(100)
        row.addWidget(self.mc_sims)
        run_btn = QPushButton("Run Simulation")
        run_btn.clicked.connect(self.run_monte_carlo_sim)
        row.addWidget(run_btn)
        row.addStretch()
        lay.addLayout(row)

        self.mc_result = QLabel("—")
        self.mc_result.setStyleSheet(f"font-family:Consolas; font-size:11px; color:{TEXT2}; padding:4px;")
        self.mc_result.setWordWrap(True)
        lay.addWidget(self.mc_result)
        return panel

    def _build_correlation_panel(self) -> QWidget:
        panel = QFrame()
        panel.setStyleSheet(f"background:{BG}; border:1px solid {BORDER}; border-radius:6px;")
        lay = QVBoxLayout(panel)

        row = QHBoxLayout()
        row.addWidget(QLabel("🔗 CORRELATION MATRIX"))
        corr_btn = QPushButton("Compute")
        corr_btn.clicked.connect(self.run_correlation)
        row.addWidget(corr_btn)
        row.addStretch()
        lay.addLayout(row)

        self.corr_table = QTableWidget(0, 0)
        self.corr_table.setStyleSheet("font-size:9px; font-family:monospace;")
        lay.addWidget(self.corr_table)
        return panel

    # -------------------------------------------------------- actions ---
    def run_pattern_scan(self):
        threading.Thread(target=self._pattern_scan_worker, daemon=True).start()

    def _pattern_scan_worker(self):
        rows = []
        for sym in self.symbols:
            try:
                df = self.data_source.fetch_ohlcv_df(sym, timeframe=config.DEFAULT_TIMEFRAME, limit=100)
                if df.empty:
                    continue
                for match in detect_patterns(df):
                    rows.append((sym, match))
            except Exception:
                continue
        self._render_patterns(rows)

    def _render_patterns(self, rows):
        self.pattern_table.setRowCount(0)
        color_map = {"bullish": GREEN, "bearish": RED}
        for sym, m in rows:
            r = self.pattern_table.rowCount()
            self.pattern_table.insertRow(r)
            self.pattern_table.setItem(r, 0, QTableWidgetItem(sym))
            pat_item = QTableWidgetItem(m.pattern)
            pat_item.setForeground(QColor(color_map.get(m.direction, TEXT2)))
            self.pattern_table.setItem(r, 1, pat_item)
            self.pattern_table.setItem(r, 2, QTableWidgetItem(m.description))
            self.pattern_table.setItem(r, 3, QTableWidgetItem(m.confidence))
        if not rows:
            self.pattern_table.setRowCount(1)
            self.pattern_table.setItem(0, 0, QTableWidgetItem("—"))
            self.pattern_table.setItem(0, 1, QTableWidgetItem("No patterns detected right now"))

    def run_monte_carlo_sim(self):
        threading.Thread(target=self._monte_carlo_worker, daemon=True).start()

    def _monte_carlo_worker(self):
        symbol = self.mc_symbol.currentText()
        try:
            df = self.data_source.fetch_ohlcv_df(symbol, timeframe="1d", limit=180)
            if df.empty or len(df) < 10:
                self._set_mc_text("⚠ Not enough price history for this symbol yet.")
                return
            closes = df["close"].tolist()
            returns = pooled_returns_from_positions({symbol: closes}, {symbol: 1.0})
            result = run_monte_carlo(
                starting_value=closes[-1], historical_returns=returns,
                years=self.mc_years.value(), simulations=self.mc_sims.value(),
            )
            if not result:
                self._set_mc_text("⚠ Not enough return samples to simulate.")
                return
            p = result.percentiles
            text = (
                f"Starting: ${result.starting_value:,.2f}   Sims: {result.simulations}   "
                f"Horizon: {result.horizon_years:.1f}y\n"
                f"5th %: ${p[5]:,.2f}   25th %: ${p[25]:,.2f}   Median: ${p[50]:,.2f}   "
                f"75th %: ${p[75]:,.2f}   95th %: ${p[95]:,.2f}\n"
                f"Probability of loss: {result.probability_of_loss_pct:.1f}%   "
                f"μ={result.mean_daily_return*100:.4f}%/day  σ={result.stddev_daily_return*100:.4f}%/day"
            )
            self._set_mc_text(text)
        except Exception as e:
            self._set_mc_text(f"⚠ {str(e)[:80]}")

    def _set_mc_text(self, text: str):
        self.mc_result.setText(text)

    def run_correlation(self):
        threading.Thread(target=self._correlation_worker, daemon=True).start()

    def _correlation_worker(self):
        try:
            histories = {}
            for sym in self.symbols:
                df = self.data_source.fetch_ohlcv_df(sym, timeframe=config.DEFAULT_TIMEFRAME, limit=100)
                if not df.empty:
                    histories[sym] = df["close"].tolist()
            matrix = compute_correlation_matrix(histories)
            self._render_correlation(matrix)
        except Exception:
            pass

    def _render_correlation(self, matrix):
        n = len(matrix.symbols)
        self.corr_table.setRowCount(n)
        self.corr_table.setColumnCount(n)
        self.corr_table.setHorizontalHeaderLabels(matrix.symbols)
        self.corr_table.setVerticalHeaderLabels(matrix.symbols)
        for i in range(n):
            for j in range(n):
                v = matrix.matrix[i][j]
                text = "—" if v is None else f"{v:+.2f}"
                item = QTableWidgetItem(text)
                if v is not None:
                    if abs(v) >= 0.7:
                        item.setBackground(QColor(255, 77, 106, 130) if v > 0 else QColor(0, 212, 170, 100))
                    elif abs(v) >= 0.4:
                        item.setBackground(QColor(240, 185, 11, 90))
                self.corr_table.setItem(i, j, item)
