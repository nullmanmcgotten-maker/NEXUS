"""
NEXUS Dashboard Tab — Full Portfolio Management
Integrated into TONYBOT as a new tab
"""

import sys
import json
import logging
import threading
import time
from datetime import datetime
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import requests

logger = logging.getLogger("tonybot.ui.nexus")

class NexusTab(QWidget):
    """NEXUS Dashboard Tab - Full Portfolio & Market Analysis"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.start_data_thread()
        self.start_timer()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(6, 6, 6, 6)
        
        # Tab header
        header = QLabel("📊 NEXUS PORTFOLIO DASHBOARD")
        header.setStyleSheet("font-size: 16px; font-weight: bold; color: #00D4FF; padding: 8px;")
        layout.addWidget(header)
        
        # Top row - Market Summary
        summary_layout = QHBoxLayout()
        self.summary_labels = {}
        for label, value in [("Total Value", "$0"), ("24h Change", "0%"), ("Positions", "0"), ("Watchlist", "0")]:
            frame = QFrame()
            frame.setStyleSheet("background: #0F1628; border: 1px solid #1E2D4A; border-radius: 6px; padding: 8px;")
            frame_layout = QVBoxLayout(frame)
            frame_layout.addWidget(QLabel(label))
            val = QLabel(value)
            val.setStyleSheet("font-size: 18px; font-weight: bold; color: #00FF88;")
            frame_layout.addWidget(val)
            self.summary_labels[label] = val
            summary_layout.addWidget(frame)
        layout.addLayout(summary_layout)
        
        # Splitter for main content
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # LEFT PANEL - Market Scanner & Order Book
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setSpacing(4)
        
        # Market Scanner
        left_layout.addWidget(QLabel("📊 MARKET SCANNER"))
        self.scanner_table = QTableWidget(0, 5)
        self.scanner_table.setHorizontalHeaderLabels(["Symbol", "Price", "24h", "RSI", "Signal"])
        self.scanner_table.setMaximumHeight(200)
        self.scanner_table.setStyleSheet("font-size: 9px; font-family: monospace;")
        left_layout.addWidget(self.scanner_table)
        
        # Order Book
        left_layout.addWidget(QLabel("📖 ORDER BOOK"))
        self.order_book_text = QTextEdit()
        self.order_book_text.setReadOnly(True)
        self.order_book_text.setMaximumHeight(150)
        self.order_book_text.setStyleSheet("font-family: monospace; font-size: 9px; background: #0d1117; border: 1px solid #1E2D4A;")
        left_layout.addWidget(self.order_book_text)
        
        # Trade History
        left_layout.addWidget(QLabel("📋 TRADE HISTORY"))
        self.history_table = QTableWidget(0, 4)
        self.history_table.setHorizontalHeaderLabels(["Symbol", "Side", "Price", "PnL"])
        self.history_table.setMaximumHeight(100)
        self.history_table.setStyleSheet("font-size: 8px; font-family: monospace;")
        left_layout.addWidget(self.history_table)
        
        splitter.addWidget(left)
        
        # RIGHT PANEL - Analytics & News
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setSpacing(4)
        
        # Analytics Grid
        analytics_layout = QGridLayout()
        metrics = [
            ("Win Rate", "0%", "#00FF88"),
            ("Profit Factor", "0.0", "#00D4FF"),
            ("Max DD", "0%", "#FF3B5C"),
            ("Sharpe", "0.0", "#7B4FE0"),
        ]
        self.metric_labels = {}
        for i, (label, value, color) in enumerate(metrics):
            frame = QFrame()
            frame.setStyleSheet("background: #0F1628; border: 1px solid #1E2D4A; border-radius: 4px; padding: 6px;")
            f_layout = QVBoxLayout(frame)
            f_layout.addWidget(QLabel(label))
            val = QLabel(value)
            val.setStyleSheet(f"font-size: 16px; font-weight: bold; color: {color};")
            f_layout.addWidget(val)
            self.metric_labels[label] = val
            analytics_layout.addWidget(frame, i // 2, i % 2)
        right_layout.addLayout(analytics_layout)
        
        # News Feed
        right_layout.addWidget(QLabel("📰 LATEST NEWS"))
        self.news_text = QTextEdit()
        self.news_text.setReadOnly(True)
        self.news_text.setMaximumHeight(150)
        self.news_text.setStyleSheet("font-family: monospace; font-size: 8px; color: #848d97; background: #0d1117; border: 1px solid #1E2D4A;")
        right_layout.addWidget(self.news_text)
        
        # Controls
        controls_layout = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh_data)
        controls_layout.addWidget(self.refresh_btn)
        
        self.screener_btn = QPushButton("🔍 Run Screener")
        self.screener_btn.clicked.connect(self.run_screener)
        controls_layout.addWidget(self.screener_btn)
        
        self.alert_btn = QPushButton("🔔 Set Alert")
        self.alert_btn.clicked.connect(self.set_alert)
        controls_layout.addWidget(self.alert_btn)
        
        right_layout.addLayout(controls_layout)
        
        splitter.addWidget(right)
        splitter.setSizes([400, 600])
        
        layout.addWidget(splitter)
        
        # Status bar
        self.status_label = QLabel("🟢 LIVE DATA READY")
        self.status_label.setStyleSheet("font-size: 9px; color: #7A8BA8; padding: 4px;")
        layout.addWidget(self.status_label)
    
    def start_data_thread(self):
        """Start background data fetching"""
        self.data_thread = threading.Thread(target=self.fetch_data_loop, daemon=True)
        self.data_thread.start()
    
    def start_timer(self):
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(15000)
    
    def fetch_data_loop(self):
        while True:
            try:
                self.fetch_market_data()
                time.sleep(15)
            except Exception as e:
                logger.warning(f"NexusTab data fetch failed, retrying in 5s: {e}")
                time.sleep(5)
    
    def fetch_market_data(self):
        """Fetch real market data"""
        try:
            # BTC price
            resp = requests.get("https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                price = float(data['lastPrice'])
                change = float(data['priceChangePercent'])
                self.update_scanner("BTC", price, change)
            
            # ETH price
            resp = requests.get("https://api.binance.com/api/v3/ticker/24hr?symbol=ETHUSDT", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                price = float(data['lastPrice'])
                change = float(data['priceChangePercent'])
                self.update_scanner("ETH", price, change)
            
            # SOL price
            resp = requests.get("https://api.binance.com/api/v3/ticker/24hr?symbol=SOLUSDT", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                price = float(data['lastPrice'])
                change = float(data['priceChangePercent'])
                self.update_scanner("SOL", price, change)
            
            # BNB price
            resp = requests.get("https://api.binance.com/api/v3/ticker/24hr?symbol=BNBUSDT", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                price = float(data['lastPrice'])
                change = float(data['priceChangePercent'])
                self.update_scanner("BNB", price, change)
            
            # Update summary
            total_value = self.calculate_total_value()
            self.summary_labels["Total Value"].setText(f"${total_value:,.0f}")
            
            # Update status
            self.status_label.setText(f"🟢 Updated: {datetime.now().strftime('%H:%M:%S')}")
            
        except Exception as e:
            self.status_label.setText(f"⚠️ Data fetch: {str(e)[:30]}")
    
    def update_scanner(self, symbol, price, change):
        """Update scanner table"""
        found = False
        rsi = 50 + (change / 2)
        rsi = max(30, min(70, rsi))
        
        signal = "BUY" if rsi < 35 else "SELL" if rsi > 65 else "HOLD"
        signal_color = "#00FF88" if signal == "BUY" else "#FF3B5C" if signal == "SELL" else "#F0B90B"
        
        for i in range(self.scanner_table.rowCount()):
            if self.scanner_table.item(i, 0).text() == symbol:
                self.scanner_table.setItem(i, 1, QTableWidgetItem(f"${price:,.2f}"))
                change_item = QTableWidgetItem(f"{change:+.2f}%")
                change_item.setForeground(QColor("#00FF88") if change >= 0 else QColor("#FF3B5C"))
                self.scanner_table.setItem(i, 2, change_item)
                self.scanner_table.setItem(i, 3, QTableWidgetItem(f"{rsi:.0f}"))
                signal_item = QTableWidgetItem(signal)
                signal_item.setForeground(QColor(signal_color))
                self.scanner_table.setItem(i, 4, signal_item)
                found = True
                break
        
        if not found:
            row = self.scanner_table.rowCount()
            self.scanner_table.insertRow(row)
            self.scanner_table.setItem(row, 0, QTableWidgetItem(symbol))
            self.scanner_table.setItem(row, 1, QTableWidgetItem(f"${price:,.2f}"))
            change_item = QTableWidgetItem(f"{change:+.2f}%")
            change_item.setForeground(QColor("#00FF88") if change >= 0 else QColor("#FF3B5C"))
            self.scanner_table.setItem(row, 2, change_item)
            self.scanner_table.setItem(row, 3, QTableWidgetItem(f"{rsi:.0f}"))
            signal_item = QTableWidgetItem(signal)
            signal_item.setForeground(QColor(signal_color))
            self.scanner_table.setItem(row, 4, signal_item)
    
    def calculate_total_value(self):
        """Calculate total portfolio value"""
        total = 10000  # Base balance
        try:
            resp = requests.get("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT", timeout=3)
            if resp.status_code == 200:
                data = resp.json()
                total += float(data['price']) * 0.5  # 0.5 BTC
        except Exception as e:
            logger.warning(f"Portfolio value calc: failed to fetch BTC price, using base only: {e}")
        return total
    
    def refresh_data(self):
        """Manual refresh"""
        self.status_label.setText("🔄 Refreshing...")
        threading.Thread(target=self.fetch_market_data, daemon=True).start()
    
    def run_screener(self):
        """Run screener analysis"""
        self.status_label.setText("🔍 Scanning for signals...")
        self.fetch_market_data()
        self.status_label.setText("✅ Scan complete")
    
    def set_alert(self):
        """Set price alert"""
        symbol, ok = QInputDialog.getText(self, "Set Alert", "Enter symbol (e.g. BTC):")
        if ok and symbol:
            price, ok2 = QInputDialog.getDouble(self, "Set Alert", "Enter target price:")
            if ok2:
                self.status_label.setText(f"🔔 Alert set for {symbol} @ ${price:.2f}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = NexusTab()
    window.show()
    sys.exit(app.exec())
