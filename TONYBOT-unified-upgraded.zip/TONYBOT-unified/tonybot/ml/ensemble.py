"""
tonybot/ml/ensemble.py — LightGBM Machine Learning Ensemble Classifier
Trains on historical trade features to rank signal probability and filter low-edge setups.

Feature set (see _encode_features): tech_confidence, tf_confidence, confirmations,
side, risk_reward, sentiment_score, and a one-hot of the predictive setup family
(ORDERFLOW_BREAKOUT / PATTERN_CONFLUENCE / TREND_CONTINUATION / REVERSAL_DIVERGENCE).
Previously this was 4 generic features (tech_confidence, tf_confidence, confirmations,
side) with no visibility into *why* a signal fired — an order-flow-confirmed breakout
and a pure lagging trend-continuation setup looked identical to the classifier. The
one-hot setup-family feature plus risk_reward and sentiment give it enough signal to
actually differentiate which *kind* of edge tends to hold up historically.
"""
import logging
from typing import List, Dict, Any, Optional
import numpy as np

logger = logging.getLogger("tonybot.ml")

try:
    import lightgbm as lgb
    HAS_LIGHTGBM = True
except ImportError:
    HAS_LIGHTGBM = False

# Order matters — must stay in sync with the one-hot slice in _encode_features.
SETUP_FAMILIES = ["ORDERFLOW_BREAKOUT", "PATTERN_CONFLUENCE", "SR_REACTION", "TREND_CONTINUATION", "REVERSAL_DIVERGENCE"]

FEATURE_NAMES = [
    "tech_confidence", "tf_confidence", "confirmations", "side_is_buy",
    "risk_reward", "sentiment_score",
] + [f"setup_{s.lower()}" for s in SETUP_FAMILIES]


def _encode_features(features: Dict[str, Any]) -> List[float]:
    setup_type = str(features.get("setup_type", "")).upper()
    one_hot = [1.0 if setup_type == s else 0.0 for s in SETUP_FAMILIES]
    return [
        float(features.get("tech_confidence", 0.5)),
        float(features.get("tf_confidence", 0.5)),
        float(features.get("confirmations", 3)),
        1.0 if features.get("side") == "BUY" else 0.0,
        float(features.get("risk_reward", 2.0)),
        float(features.get("sentiment_score", 0.0)),
        *one_hot,
    ]


class MLEnsemble:
    """Machine Learning Signal Classifier powered by LightGBM."""

    def __init__(self, min_confidence: float = 0.60):
        self.min_confidence = min_confidence
        self.model = None
        self.is_trained = False

    def train(self, trade_records: List[Dict[str, Any]]) -> bool:
        if not HAS_LIGHTGBM or len(trade_records) < 20:
            logger.info("Insufficient trade history for LightGBM training (need 20+ trades).")
            return False

        try:
            X = [_encode_features(tr) for tr in trade_records]
            y = [1 if float(tr.get("pnl_usd", 0.0)) > 0 else 0 for tr in trade_records]

            X = np.array(X)
            y = np.array(y)

            train_data = lgb.Dataset(X, label=y, feature_name=FEATURE_NAMES)
            params = {
                "objective": "binary",
                "metric": "binary_logloss",
                "boosting_type": "gbdt",
                "verbose": -1,
                "learning_rate": 0.05,
            }
            self.model = lgb.train(params, train_data, num_boost_round=50)
            self.is_trained = True
            logger.info(f"LightGBM model training completed on {len(trade_records)} trades, {len(FEATURE_NAMES)} features.")
            return True
        except Exception as e:
            logger.error(f"LightGBM training error: {e}")
            return False

    def predict_confidence(self, features: Dict[str, Any]) -> float:
        if not self.is_trained or self.model is None:
            return float(features.get("tech_confidence", 0.5))

        try:
            feat_vec = np.array([_encode_features(features)])
            prob = float(self.model.predict(feat_vec)[0])
            return prob
        except Exception:
            return 0.5
