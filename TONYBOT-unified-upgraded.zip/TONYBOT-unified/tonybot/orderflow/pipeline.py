"""
tonybot/orderflow/pipeline.py — Order Flow Analytics Engine
Calculates CVD (Cumulative Volume Delta), Footprint Data, & Large Trade Detector ($50k+).

Also includes order-book imbalance / whale-pressure detection, ported from
mergedbot's order_flow.py concept (that repo's implementation was a thin
skeleton, so this is a clean rewrite against TONYBOT's own data shapes
rather than a copy-paste merge).
"""
import time
from dataclasses import dataclass
from typing import Dict, List, Any, Optional


@dataclass
class ImbalanceSnapshot:
    symbol: str
    imbalance_score: float        # 0..1, how lopsided bid vs ask volume is
    dominant_side: str            # "BID" | "ASK" | "NEUTRAL"
    whale_alert: bool             # a single side is unusually dominant
    bid_volume: float
    ask_volume: float
    support_levels: int           # count of unusually large bid clusters
    resistance_levels: int        # count of unusually large ask clusters
    timestamp: float


class OrderFlowPipeline:
    """Processes tick/trade data to generate Order Flow analytics."""

    def __init__(self, large_trade_usd: float = 50000.0):
        self.large_trade_usd = large_trade_usd
        self.cvd = 0.0
        self.recent_large_trades: List[Dict[str, Any]] = []

    def process_trades(self, trades: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Process a list of recent trades (from exchange API).
        Each trade dict expected to have 'price', 'qty', 'isBuyerMaker'.
        """
        buy_vol = 0.0
        sell_vol = 0.0

        for t in trades:
            price = float(t.get("price", 0.0))
            qty = float(t.get("qty", t.get("amount", 0.0)))
            val_usd = price * qty
            is_sell = t.get("isBuyerMaker", False)

            if is_sell:
                sell_vol += qty
                self.cvd -= qty
            else:
                buy_vol += qty
                self.cvd += qty

            if val_usd >= self.large_trade_usd:
                self.recent_large_trades.append({
                    "symbol": t.get("symbol", "UNKNOWN"),
                    "side": "SELL" if is_sell else "BUY",
                    "price": price,
                    "qty": qty,
                    "val_usd": val_usd,
                    "timestamp": time.time(),
                })

        # Retain last 50 large trades
        self.recent_large_trades = self.recent_large_trades[-50:]

        return {
            "cvd": self.cvd,
            "buy_volume": buy_vol,
            "sell_volume": sell_vol,
            "large_trades_count": len(self.recent_large_trades),
            "recent_large_trades": self.recent_large_trades,
        }

    def analyze_orderbook_imbalance(
        self,
        orderbook: Dict[str, Any],
        symbol: str,
        min_depth: int = 10,
        whale_threshold: float = 0.35,
        large_cluster_quantile: float = 0.9,
    ) -> Optional[ImbalanceSnapshot]:
        """
        Score how lopsided current order-book depth is between bids and
        asks, and flag "whale walls" — unusually large resting orders that
        cluster near the top of the book (a common precursor to a stop-hunt
        or a level being defended).

        `orderbook` is the standard ccxt/exchange shape:
            {"bids": [[price, qty], ...], "asks": [[price, qty], ...]}
        Returns None if there isn't enough depth to say anything meaningful.
        """
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])
        if len(bids) < min_depth or len(asks) < min_depth:
            return None

        bid_qtys = [float(b[1]) for b in bids]
        ask_qtys = [float(a[1]) for a in asks]
        total_bid = sum(bid_qtys)
        total_ask = sum(ask_qtys)
        total = total_bid + total_ask
        if total <= 0:
            return None

        raw_imbalance = (total_bid - total_ask) / total  # -1..+1
        imbalance_score = min(1.0, abs(raw_imbalance))
        dominant_side = "BID" if raw_imbalance > 0.05 else "ASK" if raw_imbalance < -0.05 else "NEUTRAL"
        whale_alert = imbalance_score >= whale_threshold

        def _large_cluster_count(qtys: List[float]) -> int:
            if len(qtys) < min_depth:
                return 0
            sorted_q = sorted(qtys)
            idx = int(len(sorted_q) * large_cluster_quantile)
            threshold = sorted_q[min(idx, len(sorted_q) - 1)]
            if threshold <= 0:
                return 0
            return sum(1 for q in qtys if q >= threshold and q > 0)

        return ImbalanceSnapshot(
            symbol=symbol,
            imbalance_score=imbalance_score,
            dominant_side=dominant_side,
            whale_alert=whale_alert,
            bid_volume=total_bid,
            ask_volume=total_ask,
            support_levels=_large_cluster_count(bid_qtys),
            resistance_levels=_large_cluster_count(ask_qtys),
            timestamp=time.time(),
        )
