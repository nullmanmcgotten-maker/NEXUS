"""
tonybot/risk/risk_manager.py — Comprehensive Risk Management Engine
Combines drawdown circuit breaker, daily loss cap, position limits, and portfolio safety rules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Dict
import logging

from tonybot.risk.liquidation import (
    evaluate_liquidation_risk, stop_loss_beats_liquidation, LiquidationResult,
)

logger = logging.getLogger("tonybot.risk")


class CircuitBreaker:
    """Hard stop: once tripped, blocks all new trades until manually reset."""

    def __init__(self, max_drawdown_pct: float = 0.15):
        self.max_drawdown_pct = max_drawdown_pct
        self.tripped = False
        self.trip_reason: str = ""

    def check(self, current_drawdown_pct: float) -> bool:
        if current_drawdown_pct >= self.max_drawdown_pct:
            self.tripped = True
            self.trip_reason = f"Drawdown {current_drawdown_pct:.1%} exceeds limit {self.max_drawdown_pct:.1%}"
            logger.critical(f"[CIRCUIT BREAKER TRIPPED] {self.trip_reason}")
            return False
        return True

    def reset(self):
        self.tripped = False
        self.trip_reason = ""
        logger.info("[CIRCUIT BREAKER RESET] Risk limits cleared.")


@dataclass
class RiskManager:
    max_concurrent_positions: int = 5
    max_daily_loss_pct: float = 0.05
    max_drawdown_pct: float = 0.15
    max_portfolio_heat_pct: float = 15.0

    _daily_pnl: Dict[str, float] = field(default_factory=dict)
    _peak_balance: float = 0.0

    def __post_init__(self):
        self.circuit_breaker = CircuitBreaker(self.max_drawdown_pct)

    def can_open_position(self, open_positions_count: int, portfolio_heat_pct: float = 0.0) -> tuple[bool, str]:
        if self.circuit_breaker.tripped:
            logger.warning("Trade rejected: Circuit breaker is active!")
            return (False, "Circuit breaker active")
        if open_positions_count >= self.max_concurrent_positions:
            logger.warning(f"Trade rejected: Open positions ({open_positions_count}) >= max limit ({self.max_concurrent_positions})")
            return (False, f"Max positions reached: {open_positions_count}/{self.max_concurrent_positions}")
        if portfolio_heat_pct > self.max_portfolio_heat_pct:
            logger.warning(f"Trade rejected: Portfolio heat ({portfolio_heat_pct:.1f}%) > max limit ({self.max_portfolio_heat_pct:.1f}%)")
            return (False, f"Portfolio heat exceeded: {portfolio_heat_pct:.1f}% > {self.max_portfolio_heat_pct:.1f}%")
        return (True, "")

    def calculate_position_size(self, balance: float, risk_per_trade: float, atr: float) -> float:
        """ATR-based position sizing. Returns position size in USD."""
        if atr <= 0:
            return 0.0
        from tonybot.config import config
        raw = (balance * risk_per_trade) / (atr * 2)
        return min(raw, config.MAX_POSITION_USD)

    def check_liquidation_safety(
        self,
        entry_price: float,
        stop_loss: float,
        leverage: float,
        side: str,
        margin_mode: str = "isolated",
        maintenance_margin_rate: float = 0.005,
        min_distance_pct: float = 0.10,
    ) -> tuple[bool, str, LiquidationResult]:
        """
        Perp-specific pre-trade gate. Two independent checks:
          1. Liquidation must sit at least `min_distance_pct` away from entry
             at the chosen leverage (protects against over-leveraging even
             with no stop set).
          2. The stop-loss itself must trigger before liquidation would,
             i.e. leverage isn't so high that the exchange liquidates you
             before your own stop has a chance to fire.
        This runs in addition to (not instead of) can_open_position().
        """
        result = evaluate_liquidation_risk(
            entry_price=entry_price, leverage=leverage, side=side,
            margin_mode=margin_mode, maintenance_margin_rate=maintenance_margin_rate,
            min_distance_pct=min_distance_pct,
        )
        if not result.is_safe:
            reason = (
                f"Liquidation too close: {result.distance_pct:.1%} away "
                f"(min {min_distance_pct:.0%}) at {leverage:.0f}x — reduce leverage"
            )
            logger.warning(f"Trade rejected: {reason}")
            return (False, reason, result)

        if stop_loss and not stop_loss_beats_liquidation(entry_price, stop_loss, result.liquidation_price, side):
            reason = (
                f"Stop-loss ({stop_loss:.4f}) is beyond liquidation price "
                f"({result.liquidation_price:.4f}) — exchange liquidates before your stop fires"
            )
            logger.warning(f"Trade rejected: {reason}")
            return (False, reason, result)

        return (True, "", result)

    def calculate_sl_tp(self, entry: float, atr: float, direction: str,
                        sl_atr_mult: float = 2.0, tp_atr_mult: float = 4.0) -> tuple[float, float]:
        """Returns (stop_loss, take_profit) using ATR multiples.
        Defaults (2x/4x) match the original swing-oriented behavior; a scalp
        profile passes tighter multiples (e.g. 1x/1.5x) for faster, smaller
        moves on lower timeframes."""
        if direction == "BUY":
            sl = entry - atr * sl_atr_mult
            tp = entry + atr * tp_atr_mult
        else:
            sl = entry + atr * sl_atr_mult
            tp = entry - atr * tp_atr_mult
        return sl, tp

    def record_pnl(self, day: date, pnl: float):
        key = day.isoformat()
        self._daily_pnl[key] = self._daily_pnl.get(key, 0.0) + pnl

    def daily_loss_limit_hit(self, day: date, balance: float) -> bool:
        key = day.isoformat()
        pnl_today = self._daily_pnl.get(key, 0.0)
        if balance <= 0:
            return True
        if pnl_today < 0 and (abs(pnl_today) / balance) >= self.max_daily_loss_pct:
            logger.warning(f"Daily loss limit hit: Today PnL=${pnl_today:.2f} ({abs(pnl_today)/balance:.1%})")
            return True
        return False

    def update_drawdown(self, current_balance: float) -> float:
        self._peak_balance = max(self._peak_balance, current_balance)
        if self._peak_balance <= 0:
            return 0.0
        drawdown = (self._peak_balance - current_balance) / self._peak_balance
        self.circuit_breaker.check(drawdown)
        return drawdown
