"""
tonybot/risk/liquidation.py — Perpetual Futures Liquidation Math

Provides liquidation price calculation (isolated & cross margin, long & short),
distance-to-liquidation checks, and a liquidation-heatmap data generator that
estimates where leveraged positions across the market would blow up relative
to the current price. This is new: TONYBOT previously had no perp-specific
risk math at all (spot-only).

Liquidation formulas (standard linear/USDT-margined perp convention):

Isolated margin, LONG:
    liq_price = entry * (1 - 1/leverage + maintenance_margin_rate)

Isolated margin, SHORT:
    liq_price = entry * (1 + 1/leverage - maintenance_margin_rate)

Cross margin substitutes the position's share of total account equity for
1/leverage, since the whole account balance backs the position:

    effective_margin_ratio = position_margin_equivalent / position_notional

These are the same formulas used by Binance/Bybit/OKX USDT-M perps to a good
approximation; exact numbers can differ slightly by a few bps depending on
the exchange's tiered maintenance-margin schedule, which is why
`maintenance_margin_rate` is a parameter — plug in the real tier via
`fetch_maintenance_margin_rate` in perp_market.py when available instead of
the config default.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal

Side = Literal["LONG", "SHORT"]
MarginMode = Literal["isolated", "cross"]


@dataclass
class LiquidationResult:
    entry_price: float
    liquidation_price: float
    leverage: float
    side: Side
    margin_mode: MarginMode
    distance_pct: float          # abs distance from entry to liq, as a fraction
    maintenance_margin_rate: float
    is_safe: bool                # False if distance_pct < min_distance_pct


def calculate_liquidation_price(
    entry_price: float,
    leverage: float,
    side: Side,
    margin_mode: MarginMode = "isolated",
    maintenance_margin_rate: float = 0.005,
    wallet_balance: float | None = None,
    position_notional: float | None = None,
) -> float:
    """
    Compute liquidation price for a single position.

    For isolated margin only entry/leverage/mmr are needed.
    For cross margin, pass wallet_balance and position_notional so the
    function can derive the effective margin ratio backing this position
    (cross margin uses the whole account as collateral, so liquidation is
    further away than isolated at the same leverage — but a loss on this
    position eats into margin available for every other open position).
    """
    if entry_price <= 0 or leverage <= 0:
        return 0.0

    if margin_mode == "cross" and wallet_balance and position_notional and position_notional > 0:
        margin_ratio = wallet_balance / position_notional
    else:
        margin_ratio = 1.0 / leverage

    if side == "LONG":
        liq = entry_price * (1 - margin_ratio + maintenance_margin_rate)
    else:  # SHORT
        liq = entry_price * (1 + margin_ratio - maintenance_margin_rate)

    return max(0.0, liq)


def evaluate_liquidation_risk(
    entry_price: float,
    leverage: float,
    side: Side,
    margin_mode: MarginMode = "isolated",
    maintenance_margin_rate: float = 0.005,
    min_distance_pct: float = 0.10,
    wallet_balance: float | None = None,
    position_notional: float | None = None,
) -> LiquidationResult:
    """Full liquidation risk evaluation, used as a pre-trade gate."""
    liq_price = calculate_liquidation_price(
        entry_price, leverage, side, margin_mode, maintenance_margin_rate,
        wallet_balance, position_notional,
    )
    distance_pct = abs(entry_price - liq_price) / entry_price if entry_price else 0.0
    return LiquidationResult(
        entry_price=entry_price,
        liquidation_price=liq_price,
        leverage=leverage,
        side=side,
        margin_mode=margin_mode,
        distance_pct=distance_pct,
        maintenance_margin_rate=maintenance_margin_rate,
        is_safe=distance_pct >= min_distance_pct,
    )


def stop_loss_beats_liquidation(
    entry_price: float, stop_loss: float, liquidation_price: float, side: Side,
) -> bool:
    """
    Sanity check: your stop-loss must trigger BEFORE liquidation would, with
    room to spare. If this returns False, the exchange will liquidate you
    before your own stop ever fires (e.g. a wide stop paired with high
    leverage) — the stop is decorative, not protective.
    """
    if side == "LONG":
        return stop_loss > liquidation_price
    return stop_loss < liquidation_price


@dataclass
class HeatmapBucket:
    price: float
    leverage: float
    side: Side
    distance_pct: float


def build_liquidation_heatmap(
    current_price: float,
    leverage_tiers: List[float] | None = None,
    maintenance_margin_rate: float = 0.005,
) -> List[HeatmapBucket]:
    """
    Build a liquidation heatmap: for common leverage tiers traders use on
    this symbol (proxy for where market-wide liquidation clusters sit),
    compute the long-liquidation price below current price and the
    short-liquidation price above it. This approximates the popular
    "liquidation heatmap" visualization (real versions use live open-interest
    distribution; this is a leverage-tier proxy that needs no extra data feed
    and still tells you where crowded leverage clusters are likely to sit).
    """
    tiers = leverage_tiers or [3, 5, 10, 20, 25, 50, 75, 100]
    buckets: List[HeatmapBucket] = []
    for lev in tiers:
        long_liq = calculate_liquidation_price(current_price, lev, "LONG", "isolated", maintenance_margin_rate)
        short_liq = calculate_liquidation_price(current_price, lev, "SHORT", "isolated", maintenance_margin_rate)
        buckets.append(HeatmapBucket(
            price=long_liq, leverage=lev, side="LONG",
            distance_pct=abs(current_price - long_liq) / current_price,
        ))
        buckets.append(HeatmapBucket(
            price=short_liq, leverage=lev, side="SHORT",
            distance_pct=abs(current_price - short_liq) / current_price,
        ))
    return sorted(buckets, key=lambda b: b.price)
