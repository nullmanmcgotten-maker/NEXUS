"""
tonybot/risk/heat_guard.py — Portfolio Heat & Volatility Guards
Calculates total open portfolio heat (aggregate risk) and volatility-adjusted sizing.
"""
from __future__ import annotations

from typing import List, Dict, Any


class PortfolioHeatGuard:
    """Monitors open positions and total portfolio risk exposure."""

    def __init__(self, max_heat_pct: float = 15.0):
        self.max_heat_pct = max_heat_pct

    def calculate_total_heat(self, open_positions: List[Dict[str, Any]], account_balance: float) -> float:
        """
        Total heat % = sum(position_risk_amount) / account_balance * 100.
        Each position dict should contain 'entry_price', 'stop_loss', 'quantity'.
        """
        if account_balance <= 0 or not open_positions:
            return 0.0

        total_risk_usd = 0.0
        for pos in open_positions:
            entry = pos.get("entry_price", 0.0)
            sl = pos.get("stop_loss", 0.0)
            qty = pos.get("quantity", 0.0)
            risk_usd = abs(entry - sl) * qty
            total_risk_usd += risk_usd

        return (total_risk_usd / account_balance) * 100.0

    def is_heat_acceptable(self, open_positions: List[Dict[str, Any]], new_trade_risk_usd: float, account_balance: float) -> bool:
        current_heat = self.calculate_total_heat(open_positions, account_balance)
        new_heat = current_heat + (new_trade_risk_usd / account_balance * 100.0 if account_balance > 0 else 0)
        return new_heat <= self.max_heat_pct
