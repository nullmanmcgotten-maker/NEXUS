"""
tonybot/risk/position_sizing.py — Conviction-Scaled Kelly Sizer & Correlation Penalizer
"""
from __future__ import annotations

from tonybot.interfaces import PositionSize


class KellySizer:
    """
    Risk-per-trade is scaled by confirmation strength:
      4/4 confirmations -> full risk   (default 2.0%)
      3/4 confirmations -> partial risk (default 1.5%)
      2/4 confirmations -> minimal risk (default 0.5%)
      <2  confirmations -> no trade (size = 0)
    Uses half-Kelly cap for safety.
    """

    def __init__(
        self,
        risk_full: float = 0.02,
        risk_partial: float = 0.015,
        risk_minimal: float = 0.005,
        kelly_fraction_cap: float = 0.5,
    ):
        self.risk_full = risk_full
        self.risk_partial = risk_partial
        self.risk_minimal = risk_minimal
        self.kelly_fraction_cap = kelly_fraction_cap

    def kelly_fraction(self, win_rate: float, avg_win: float, avg_loss: float) -> float:
        if avg_loss <= 0:
            return 0.0
        r = avg_win / avg_loss
        f_star = win_rate - (1 - win_rate) / r
        return max(0.0, f_star)

    def risk_pct_for_confirmations(self, confirmations: int) -> float:
        if confirmations >= 4:
            return self.risk_full
        if confirmations == 3:
            return self.risk_partial
        if confirmations == 2:
            return self.risk_minimal
        return 0.0

    def size(
        self,
        balance: float,
        confirmations: int,
        entry: float,
        stop_loss: float,
        take_profit: float = 0.0,
        win_rate: float = 0.5,
        avg_win: float = 1.0,
        avg_loss: float = 1.0,
    ) -> PositionSize:
        base_risk_pct = self.risk_pct_for_confirmations(confirmations)
        if base_risk_pct == 0.0 or entry <= 0:
            return PositionSize(risk_pct=0.0, position_value=0.0, quantity=0.0, stop_loss_price=stop_loss, take_profit_price=take_profit)

        kelly_cap = self.kelly_fraction(win_rate, avg_win, avg_loss) * self.kelly_fraction_cap
        risk_pct = min(base_risk_pct, kelly_cap) if kelly_cap > 0 else base_risk_pct

        risk_amount = balance * risk_pct
        stop_distance = abs(entry - stop_loss)
        if stop_distance <= 0:
            return PositionSize(risk_pct=0.0, position_value=0.0, quantity=0.0, stop_loss_price=stop_loss, take_profit_price=take_profit)

        quantity = risk_amount / stop_distance
        position_value = quantity * entry

        return PositionSize(
            risk_pct=risk_pct,
            position_value=position_value,
            quantity=quantity,
            stop_loss_price=stop_loss,
            take_profit_price=take_profit,
        )


class CorrelationAwareSizer:
    """Scales down position size when portfolio holds correlated open positions."""

    def __init__(self, base_sizer: KellySizer, correlation_penalty: float = 0.5):
        self.base_sizer = base_sizer
        self.correlation_penalty = correlation_penalty

    def size(
        self,
        balance: float,
        confirmations: int,
        entry: float,
        stop_loss: float,
        correlated_open_positions: int = 0,
        **kwargs,
    ) -> PositionSize:
        base = self.base_sizer.size(balance, confirmations, entry, stop_loss, **kwargs)
        if correlated_open_positions > 0 and base.quantity > 0:
            factor = self.correlation_penalty ** correlated_open_positions
            return PositionSize(
                risk_pct=base.risk_pct * factor,
                position_value=base.position_value * factor,
                quantity=base.quantity * factor,
                stop_loss_price=base.stop_loss_price,
                take_profit_price=base.take_profit_price,
            )
        return base


def apply_funding_drag_penalty(
    position: PositionSize,
    annualized_funding_pct: float,
    expected_holding_days: float,
    side: str,
    warn_apr: float = 0.30,
    max_drag_penalty: float = 0.5,
) -> PositionSize:
    """
    Shrink a perp position size to account for funding cost eaten over the
    expected holding period. Spot never had this problem — a position held
    for a week at 30%/yr funding is very different from the same position
    held for six hours, and a position paying funding (long when funding is
    positive, short when negative) needs a bigger expected edge to be worth
    holding at all.

    `annualized_funding_pct` and `side` together determine whether this
    position PAYS or RECEIVES funding:
      - LONG pays when funding_rate > 0 (annualized_funding_pct > 0)
      - SHORT pays when funding_rate < 0 (annualized_funding_pct < 0)
    Positions that receive funding are never penalized (drag is negative,
    i.e. a tailwind) — only position size, not P&L expectation, is adjusted.

    Returns a new PositionSize with risk_pct/position_value/quantity scaled
    down proportionally to how much of the trade's risk budget the expected
    funding cost would consume over the holding period.
    """
    if position.quantity <= 0 or expected_holding_days <= 0:
        return position

    is_long = side.upper() in ("BUY", "LONG")
    pays_funding = (is_long and annualized_funding_pct > 0) or (not is_long and annualized_funding_pct < 0)
    if not pays_funding:
        return position

    holding_fraction_of_year = expected_holding_days / 365.0
    expected_funding_cost_pct = abs(annualized_funding_pct) * holding_fraction_of_year

    if expected_funding_cost_pct <= 0:
        return position

    # Scale penalty relative to the warn threshold: at exactly warn_apr *
    # over the full holding period*, apply the full max_drag_penalty; scale
    # linearly below that, cap at max_drag_penalty above it.
    warn_cost_pct = warn_apr * holding_fraction_of_year
    severity = min(1.0, expected_funding_cost_pct / warn_cost_pct) if warn_cost_pct > 0 else 1.0
    penalty_factor = 1.0 - (max_drag_penalty * severity)
    penalty_factor = max(1.0 - max_drag_penalty, penalty_factor)

    return PositionSize(
        risk_pct=position.risk_pct * penalty_factor,
        position_value=position.position_value * penalty_factor,
        quantity=position.quantity * penalty_factor,
        stop_loss_price=position.stop_loss_price,
        take_profit_price=position.take_profit_price,
    )
