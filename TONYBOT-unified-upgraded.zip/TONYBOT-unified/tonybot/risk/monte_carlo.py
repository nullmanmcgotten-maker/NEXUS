"""
tonybot/risk/monte_carlo.py — Monte Carlo Portfolio Simulator

Ported (rewritten) from nexus-portfolio's montecarlo.js: samples returns
from real historical price history, projects N random paths forward using
Box-Muller normal sampling, and reports the percentile fan (5/25/50/75/95)
plus probability of loss. Uses numpy instead of a hand-rolled Box-Muller
loop since we're in Python.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import numpy as np


@dataclass
class MonteCarloResult:
    starting_value: float
    simulations: int
    horizon_years: float
    mean_daily_return: float
    stddev_daily_return: float
    percentiles: dict            # {5: value, 25: value, 50: value, 75: value, 95: value}
    probability_of_loss_pct: float
    sample_paths: List[List[float]]  # a small subset of paths, for plotting


def run_monte_carlo(
    starting_value: float,
    historical_returns: List[float],
    years: float = 1.0,
    simulations: int = 500,
    trading_days_per_year: int = 252,
    sample_paths_to_keep: int = 40,
    seed: int | None = None,
) -> MonteCarloResult | None:
    """
    `historical_returns` should be a flat list of daily (or per-bar)
    fractional returns pooled across the portfolio's held assets, weighted
    by position size — same approach nexus-portfolio used client-side.
    Returns None if there isn't enough history to estimate mean/stddev
    meaningfully (mirrors nexus's "need more price history" guard).
    """
    if len(historical_returns) < 10 or starting_value <= 0:
        return None

    rng = np.random.default_rng(seed)
    returns = np.array(historical_returns, dtype=float)
    mean = float(returns.mean())
    stddev = float(returns.std())
    steps = max(1, round(years * trading_days_per_year))

    # Vectorized path simulation: (simulations, steps) matrix of random
    # shocks, cumulative-product to build equity paths.
    shocks = rng.normal(loc=mean, scale=stddev, size=(simulations, steps))
    growth = np.clip(1.0 + shocks, 0.0, None)  # can't go below 0 in one step
    paths = starting_value * np.cumprod(growth, axis=1)
    paths = np.hstack([np.full((simulations, 1), starting_value), paths])

    finals = paths[:, -1]
    finals_sorted = np.sort(finals)

    def pct(q: float) -> float:
        idx = min(int(simulations * q), simulations - 1)
        return float(finals_sorted[idx])

    prob_loss = float((finals < starting_value).sum()) / simulations * 100

    stride = max(1, simulations // sample_paths_to_keep)
    sample_paths = paths[::stride].tolist()

    return MonteCarloResult(
        starting_value=starting_value,
        simulations=simulations,
        horizon_years=years,
        mean_daily_return=mean,
        stddev_daily_return=stddev,
        percentiles={5: pct(0.05), 25: pct(0.25), 50: pct(0.50), 75: pct(0.75), 95: pct(0.95)},
        probability_of_loss_pct=prob_loss,
        sample_paths=sample_paths,
    )


def pooled_returns_from_positions(price_histories: dict, weights: dict) -> List[float]:
    """
    Helper: given {symbol: [prices...]} and {symbol: weight_fraction},
    build the weighted-pooled returns list run_monte_carlo expects — mirrors
    nexus's `positions.forEach` weighting logic.
    """
    pooled: List[float] = []
    for symbol, prices in price_histories.items():
        if len(prices) < 5:
            continue
        w = weights.get(symbol, 0.0)
        for i in range(1, len(prices)):
            if prices[i-1] == 0:
                continue
            pooled.append(((prices[i] - prices[i-1]) / prices[i-1]) * w)
    return pooled
