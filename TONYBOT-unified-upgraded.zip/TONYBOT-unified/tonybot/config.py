"""
tonybot/config.py — Central Configuration Management for TONYBOT
Supports both pydantic-settings and standard dotenv parsing.
"""
from __future__ import annotations

import os
from typing import List, Any
from dotenv import load_dotenv

load_dotenv()

def _get(k: str, d: Any = None, req: bool = False) -> str:
    v = os.getenv(k, str(d) if d is not None else "")
    if req and not v:
        raise EnvironmentError(f"Required config parameter '{k}' missing from environment")
    return v

def _bool(k: str, d: bool = False) -> bool:
    return os.getenv(k, str(d)).lower() in ("true", "1", "yes", "on")

def _float(k: str, d: float = 0.0) -> float:
    try:
        return float(os.getenv(k, str(d)))
    except ValueError:
        return d

def _int(k: str, d: int = 0) -> int:
    try:
        return int(os.getenv(k, str(d)))
    except ValueError:
        return d

def _list(k: str, d: str = "") -> List[str]:
    raw = os.getenv(k, d)
    return [x.strip() for x in raw.split(",") if x.strip()]


class TonyBotConfig:
    """Central configuration class containing all active settings for TONYBOT."""

    def __init__(self):
        # Exchange Settings
        self.EXCHANGE_ID = _get("EXCHANGE_ID", "binance")
        self.BINANCE_API_KEY = _get("BINANCE_API_KEY", "")
        self.BINANCE_SECRET_KEY = _get("BINANCE_SECRET_KEY", "")
        self.BINANCE_TESTNET = _bool("BINANCE_TESTNET", True)
        self.MULTI_EXCHANGE_ENABLED = _bool("MULTI_EXCHANGE_ENABLED", False)

        self.BYBIT_API_KEY = _get("BYBIT_API_KEY", "")
        self.BYBIT_SECRET_KEY = _get("BYBIT_SECRET_KEY", "")
        self.OKX_API_KEY = _get("OKX_API_KEY", "")
        self.OKX_SECRET_KEY = _get("OKX_SECRET_KEY", "")
        self.OKX_PASSPHRASE = _get("OKX_PASSPHRASE", "")

        # Trading Pairs & Timeframes
        self.SYMBOLS = _list("SYMBOLS", "BTC/USDT,ETH/USDT,SOL/USDT,BNB/USDT")
        self.TIMEFRAMES = _list("TIMEFRAMES", "1m,5m,1h,4h")
        self.DEFAULT_TIMEFRAME = _get("DEFAULT_TIMEFRAME", "1h")
        # "swing" | "scalp" | "both" — see core/engine.py TRADING_PROFILES.
        # "both" runs each symbol through both profiles concurrently (a
        # symbol can be held as a swing position and a scalp position at the
        # same time; they're tracked and sized independently).
        self.TRADING_MODE = _get("TRADING_MODE", "both")

        # Mode & Capital
        self.PAPER_MODE = _bool("PAPER_MODE", True)
        self.LIVE_TRADING = _bool("LIVE_TRADING", False)
        self.INITIAL_BALANCE = _float("INITIAL_BALANCE", 10000.0)
        self.MAX_POSITION_USD = _float("MAX_POSITION_USD", 50.0)

        # Perpetual Futures Settings
        self.MARKET_TYPE = _get("MARKET_TYPE", "spot")  # "spot" | "swap" (perp)
        self.DEFAULT_LEVERAGE = _float("DEFAULT_LEVERAGE", 3.0)
        self.MAX_LEVERAGE = _float("MAX_LEVERAGE", 10.0)
        self.MARGIN_MODE = _get("MARGIN_MODE", "isolated")  # "isolated" | "cross"
        # Maintenance margin rate used for liquidation math when the exchange
        # doesn't expose a per-symbol tiered schedule via ccxt. This is a
        # conservative low-tier estimate; real tiers are fetched when available.
        self.DEFAULT_MAINTENANCE_MARGIN_RATE = _float("DEFAULT_MAINTENANCE_MARGIN_RATE", 0.005)
        # Hard floor: block any order whose liquidation price is closer than
        # this % away from entry, regardless of stop-loss placement.
        self.MIN_LIQUIDATION_DISTANCE_PCT = _float("MIN_LIQUIDATION_DISTANCE_PCT", 0.10)
        # Funding rate above which the position-sizer applies a drag penalty
        # to expected value (annualized, e.g. 0.30 = 30%/yr).
        self.FUNDING_DRAG_WARN_APR = _float("FUNDING_DRAG_WARN_APR", 0.30)

        # Risk Management
        self.MAX_RISK_PER_TRADE_FULL = _float("MAX_RISK_PER_TRADE_FULL", 0.02)
        self.MAX_RISK_PER_TRADE_PARTIAL = _float("MAX_RISK_PER_TRADE_PARTIAL", 0.015)
        self.MAX_RISK_PER_TRADE_MINIMAL = _float("MAX_RISK_PER_TRADE_MINIMAL", 0.005)
        self.MAX_CONCURRENT_POSITIONS = _int("MAX_CONCURRENT_POSITIONS", 5)
        self.MAX_DAILY_LOSS_PCT = _float("MAX_DAILY_LOSS_PCT", 0.05)
        self.MAX_DRAWDOWN_PCT = _float("MAX_DRAWDOWN_PCT", 0.15)
        self.MAX_PORTFOLIO_HEAT_PCT = _float("MAX_PORTFOLIO_HEAT_PCT", 15.0)

        # Strategy & Thresholds
        self.ADX_TRENDING_THRESHOLD = _float("ADX_TRENDING_THRESHOLD", 25.0)
        self.ADX_RANGING_THRESHOLD = _float("ADX_RANGING_THRESHOLD", 20.0)
        self.MIN_CONFIRMATIONS_REQUIRED = _int("MIN_CONFIRMATIONS_REQUIRED", 3)
        self.MIN_SIGNAL_CONSENSUS = _int("MIN_SIGNAL_CONSENSUS", 3)
        self.MIN_TF_CONFLUENCE = _int("MIN_TF_CONFLUENCE", 3)

        # Machine Learning & AI Reasoning
        self.HF_API_KEY = _get("HF_API_KEY", "")
        self.HF_MODEL = _get("HF_MODEL", "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B")
        self.HF_FALLBACK_MODEL = _get("HF_FALLBACK_MODEL", "mistralai/Mistral-7B-Instruct-v0.3")
        self.ML_MIN_CONFIDENCE = _float("ML_MIN_CONFIDENCE", 0.60)
        self.ML_RETRAIN_INTERVAL_HOURS = _int("ML_RETRAIN_INTERVAL_HOURS", 168)

        # Alerts & Notifications
        self.ALERTS_ENABLED = _bool("ALERTS_ENABLED", False)
        self.TELEGRAM_BOT_TOKEN = _get("TELEGRAM_BOT_TOKEN", "")
        self.TELEGRAM_CHAT_ID = _get("TELEGRAM_CHAT_ID", "")
        self.ALERT_EMAIL_FROM = _get("ALERT_EMAIL_FROM", "")
        self.ALERT_EMAIL_TO = _get("ALERT_EMAIL_TO", "")
        self.ALERT_SMTP_HOST = _get("ALERT_SMTP_HOST", "smtp.gmail.com")
        self.ALERT_SMTP_PORT = _int("ALERT_SMTP_PORT", 587)
        self.ALERT_SMTP_PASSWORD = _get("ALERT_SMTP_PASSWORD", "")

        # Backtest & Fees
        self.TAKER_FEE_PCT = _float("TAKER_FEE_PCT", 0.001)
        self.SLIPPAGE_PCT = _float("SLIPPAGE_PCT", 0.0005)
        self.BACKTEST_DATA_DAYS = _int("BACKTEST_DATA_DAYS", 180)
        self.REPORTS_DIR = _get("REPORTS_DIR", "reports")
        self.AUTO_MONTHLY_REPORT = _bool("AUTO_MONTHLY_REPORT", True)

        # Logging & System
        self.LOG_LEVEL = _get("LOG_LEVEL", "INFO")
        self.LOG_FILE = _get("LOG_FILE", "logs/tonybot.log")

    def summary(self) -> str:
        return f"TONYBOT Config: Exchange={self.EXCHANGE_ID}, Mode={'PAPER' if self.PAPER_MODE else 'LIVE'}, Pairs={len(self.SYMBOLS)}"


# Global singleton instance
config = TonyBotConfig()
