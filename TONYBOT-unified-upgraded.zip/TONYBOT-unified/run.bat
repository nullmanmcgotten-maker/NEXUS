@echo off
call venv\Scripts\activate.bat
echo Launching TONYBOT GUI (Paper Mode)...
python main.py
pause
